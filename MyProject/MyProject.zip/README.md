# newwap

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

## 项目结构 ##

├─ ─ ─ ─ ─ ─ ─  .README.md  项目结构
│ 
│  index.html                               //html模板   
│  
│  
├─config                                    //配置文件
│      
├─src                                       //源码目录
│  │  App.vue                               //主页面
│  │  main.js                               //Webpack 预编译入口
│  │  
│  ├─api                                    //api
│  │      agentUtil.js                
│  │      lotteryUtil.js
│  │      msgUtil.js
│  │      paramDataUtil.js
│  │      payUtil.js
│  │      report.js
│  │      tools.js
│  │      User.js
│  │      userUtil.js
│  │      Util.js
│  │      webUtil.js
│  │      
│  ├─components                             //通用组件目录
│  │  │  Arrow.vue
│  │  │  CopyRight.vue
│  │  │  Download.vue
│  │  │  DownloadApp.vue
│  │  │  GetbackPwd.vue
│  │  │  Login.vue                          //登录组件
│  │  │  Register.vue                       //注册组件
│  │  │  Scroller.vue
│  │  │  Spinner.vue
│  │  │  Turntable.vue                      //抽奖组件
│  │  │  
│  │  └─module
│  │          core.js
│  │          render.js
│  │          
│  ├─page                                   //主要组件目录
│  │  │  Index.vue
│  │  │  
│  │  ├─Activity
│  │  │      DiscountsActivity.vue
│  │  │      DiscountsActivityAlert.vue
│  │  │      
│  │  ├─Agency
│  │  │      AgencyDevelopCourse.vue
│  │  │      GuildList.vue
│  │  │      GuildSwiperList.vue
│  │  │      
│  │  ├─Agent                               //代理中心的组件目录
│  │  │      AgentBetDetail.vue             //下级注单
│  │  │      AgentCenter.vue                //代理中心
│  │  │      Calculation.vue                //赔率计算
│  │  │      CaptailDetail.vue                                                  //交易记录（未知从何处进入），有配路由
│  │  │      Codemanagement.vue             //邀请码管理
│  │  │      Createsubordinate.vue          //下级开户
│  │  │      default.vue                                                        //查看详情（未知从何处进入）
│  │  │      Filtrate.vue                                                       //疑似废弃组件，有配路由
│  │  │      MyEarnings.vue                 //查看详情（转到我的收益）
│  │  │      scroll.vue                                                         //疑似废弃组件，有配路由
│  │  │      SearchRebates.vue                                                  //疑似废弃组件，未配路由
│  │  │      SearchRecord.vue                                                   //账户记录（未知从何处进入），有配路由
│  │  │      SubFinance.vue                 //下级财务
│  │  │      Subreports.vue                 //下级报表
│  │  │      VipCenter.vue                  //下级列表
│  │  │      
│  │  ├─Betting                             //投注中心组件目录
│  │  │  │  Bjpk10.vue                      //赛车系列投注组件
│  │  │  │  Cp11.vue                        //11选5系列
│  │  │  │  Cp3.vue                         //快3系列
│  │  │  │  gdklsf.vue                      //快乐十分系列
│  │  │  │  hk6.vue                         //六合彩（跳转特码A）
│  │  │  │  LotIndex.vue                    //彩票入口
│  │  │  │  SSC.vue                         //时时彩系列
│  │  │  │  
│  │  │  ├─gameDetails
│  │  │  │      BetDetail.vue
│  │  │  │      gameLong.vue
│  │  │  │      OpenResult.vue
│  │  │  │      
│  │  │  ├─gameRule
│  │  │  │      11x5_rule.vue
│  │  │  │      bjpk10_rule.vue
│  │  │  │      cqssc_rule.vue
│  │  │  │      gdklsf_rule.vue
│  │  │  │      hk6_rule.vue
│  │  │  │      kuaisan_rule.vue
│  │  │  │      
│  │  │  ├─hk6
│  │  │  │      HeXiao.vue
│  │  │  │      LianMa.vue
│  │  │  │      QuanBuZhong.vue
│  │  │  │      ShengXiaoLian.vue
│  │  │  │      TemaA.vue
│  │  │  │      TeMaShengXiao.vue
│  │  │  │      WeiShuLian.vue
│  │  │  │      YiXiaoWeiShu.vue
│  │  │  │      ZhengMa.vue
│  │  │  │      ZhengMaTe.vue
│  │  │  │      ZongHe.vue
│  │  │  │      
│  │  │  └─template                             //彩票公用组件
│  │  │          ActionSheet.vue
│  │  │          Footer.vue
│  │  │          Header.vue
│  │  │          
│  │  └─Center                                  //会员中心站组件目录
│  │      │  AboutUs.vue                        
│  │      │  Account.vue
│  │      │  AccountBalance.vue
│  │      │  AccountInformation.vue
│  │      │  BankCard.vue
│  │      │  BettingRecord.vue
│  │      │  BettingRecordDetail.vue
│  │      │  BindingBankCard.vue
│  │      │  CellMe.vue
│  │      │  Center.vue
│  │      │  Collect.vue
│  │      │  Complaint.vue
│  │      │  Complaints.vue
│  │      │  contact.vue
│  │      │  DepositWithdraw.vue
│  │      │  ElectronicGame.vue
│  │      │  ElectronicGameDtail.vue
│  │      │  Flowdetails.vue
│  │      │  Home.vue
│  │      │  Information.vue
│  │      │  LotteryGame.vue
│  │      │  LotteryGameReturnWater.vue
│  │      │  password.vue
│  │      │  Promotions.vue
│  │      │  PromotionsDtail.vue
│  │      │  p_informatio.vue
│  │      │  QuotaConversion.vue
│  │      │  Rechargeonline.vue
│  │      │  ReturnWaterRecord.vue
│  │      │  TransactionRecord.vue
│  │      │  TransferAccount.vue
│  │      │  UserMsg.vue
│  │      │  VideoGame.vue
│  │      │  WeChatRecharge.vue
│  │      │  WithdrawMoney.vue
│  │      │  
│  │      ├─Payment                         //支付组件目录
│  │      │      Alipay.vue
│  │      │      QQpay.vue
│  │      │      UnionPay.vue
│  │      │      WeChat.vue
│  │      │      
│  │      └─template                        //会员中心公用组件
│  │              ActionSheet.vue
│  │              GameHot.vue
│  │              NavigationDefult.vue
│  │              SpecialOffers.vue
│  │              
│  ├─router                                 //路由
│  │      index.js
│  │      
│  └─store                                 //状态管理仓库 
│          actions.js
│          getters.js
│          mutations.js
│          mutation_types.js
│          state.js
│          store.js
│          
└─static                                    //静态文件目录
    │  
    ├─css
    │      mui.min.css
    │      mui.picker.min.css
    │      mui.poppicker.css
    │      public.css
    │      reset.css
    │      
    ├─fonts
    │      mui.ttf
    │      
    ├─img
    │  ├─download
    │  │      and.png
    │  │      download.png
    │  │      ios.png
    │  │      
    │  ├─ge
    │  │      
    │  ├─guildimgs
    │  │      
    │  ├─index
    │  │      
    │  ├─loading
    │  │      
    │  ├─public
    │  │  │  
    │  │  ├─chouj
    │  │  │      
    │  │  ├─k3
    │  │  │      
    │  │  └─pk10
    │  │          
    │  └─temp
    │          
    ├─json
    │  │  
    │  └─temp
    │              
    ├─sass
    │      default.scss
    │      public.scss
    │      
    └─script
            awardRotate.js
            clipboard.min.js
            config.js
            jquery.min.js
            mui.min.js
            mui.picker.min.js
            mui.poppicker.js
            
