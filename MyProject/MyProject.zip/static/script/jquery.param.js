/*
 * @URL__  			接口路径 
 * @Theme 			主题
 * @Skin			站点皮肤
 * @ServiceLink		客服链接
 * @ImageUrl		资源图片路径
 * @Resouce			下载资源
 * @IsApp			APP还是wap站(app站点导航栏会高一些)					[true , false]
 * @CopyRight		版权信息
 * @gameUrl 		APP端打开浏览器，跳转到服务端的游戏静态页
 * @payUrl			APP端跳转支付页面
 * @WEB_TYPE__		网站类型    											[credit , money]
 * @ME_URL___		注册接口获取用户地址
 * @device			当前设备类型											[wap , web , android , ios]
 * @WebSocketUrl    websocket 链接地址  :配置为字符串'false' 则不访问websocekt;
 */

const lib = {
	URL__:'http://172.16.10.88:8004',
	Theme:'',
	Skin:'',
	ServiceLink:'http://www.zhihu.com',
	imgUrl: 'http://ab.fighting-ttfc.com',
	electronImgUrl: 'http://res.am01.com',
	Resouce:'',
	IsApp:true,
	CopyRight:'CopyRight © 优博科技出品  Reserved',
	WEB_TYPE__: 'credit', //[ money、credit] 
	CUST_SERVICES_URI: 'https://static.meiqia.com/dist/standalone.html?_=t&eid=91229',
	ME_URL___: 'http://' + window.location.host,
	device:'wap',
	gameUrl:'',
	payUrl:'',
	WebSocketUrl:'false',
}
