<template>
	<div class="lastTitle">
		<p>{{innerText}}</p>
	</div>
</template>

<script>
	export default {
		name: 'copyRight',
		data(){
			return{
				innerText:lib.CopyRight
			}
		}
	}
</script>

<style scoped lang="scss">
	.lastTitle {
		padding: .2rem;
		p{
			font-size: 0.24rem;
			color: #ccc;
		}
	}
</style>