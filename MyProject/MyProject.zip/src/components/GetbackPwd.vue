<template>
	<div id="GetBackPwd">
		<div class="mode">
			<div class="left">
				<div>
					<img src="static/img/public/e_mail.png"/>
					<p>邮箱找回</p>
				</div>
			</div>
			<div class="right">
				<div>
					<img src="static/img/public/kf.png"/>		
					<p>客服找回</p>
				</div>
			</div>
		</div>
		<div class="describe">
			<div class="emailadd">				
				<i class="iconfont icon-icon-6"></i>
				<input type="text" name="" id="" placeholder="邮箱地址" />
			</div>
			<div class="text">
				<textarea name="" rows="" cols="" placeholder="请输入账号和问题描述"></textarea>
				<span class="tip">200字以内</span>
				<!--<div class="textarea" contenteditable="true"></div>-->
			</div>
		</div>
		<button class="mybtn">提交</button>
		
	</div>
</template>

<script>
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.mode{
		margin-top: 0.24rem;
		background:#fff;
		display:flex;
		padding:0.2rem 0;
		p{
			font-size:0.28rem;
			padding-top:0.16rem;
			color:$normalFontColor;
		}
		div{
			flex:1;
			
			img{
				width: 0.88rem;
				height: auto;
			}
		}
		.left{
			float:right;
			padding-right:0.46rem;
			div{
				float: right;
				border-radius:3px;
				padding:0.24rem 0.46rem;
				background:$bgColor;
			}
		}
		.right{
			float:left;
			padding-left:0.46rem;
			div{
				float:left;
				border-radius:3px;
				padding:0.24rem 0.46rem;
				background:$bgColor;				
			}
		}
	}
	.describe{
		margin-top:0.24rem;
		background:#fff;
		.emailadd{
			padding:0.24rem;
			padding-left:0;
			border-bottom:1px solid #eee;
			input{
				height:0.4rem;
				margin: 0;
				font-size:0.28rem;
				color:$assistFontColor;
				width: 80%;
				border:0;
			}
			.iconfont{
				font-size:0.36rem;
				color:$assistFontColor;
				vertical-align:middle;
			}
		}
		.text{
			background: #fff;
			padding: 0.14rem 0.24rem;
			position: relative;
			textarea{
				border:1px solid $tipsFontColor;
				border-radius:3px;
				text-align:left;
				color:$tipsFontColor;
				font-size:0.28rem;
				padding:0.12rem;
				height: 2.5rem;
			}
			.tip{
				position:absolute;
				right: 0.4rem;
				bottom:0.4rem;
				color:$tipsFontColor;
				font-size:0.28rem;
			}
		}
	}
	.mybtn{
		margin-top:0.38rem;
		width: 94%;
		height: 0.88rem;
		font-size:0.28rem;
		color: #fff;
		background-color:$blueColor;
		border: 0;
	}
</style>