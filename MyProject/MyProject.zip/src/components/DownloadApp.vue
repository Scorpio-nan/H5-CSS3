<template>
	<div class="contentbox">
		<div class="mui-scroll-wrapper">
		    <div class="mui-scroll">
		        <div class="download">
					<div class="topbox">
						<h3>
							{{title}}
						</h3>
						<div class="tipbox" v-for="(a,i) in arr" :key="i">
							<span class="num">{{a.text}}</span>
							<div class="text" v-html="a.value"></div>						
						</div>
						<button class="look">详细图文说明</button>
		
						<div class="bottombox" v-for="(a,index) in arrTips" >
							<p>{{a.value}}</p>
							<div class="imgbox">
								<img :src="'static/img/public/'+a.text+'.png'"/>
							</div>
						</div>
						
					</div>
				</div>
		    </div>
		</div>
		<div class="btnbox">
			<button class="downloadapp">{{btntxt}}</button>
		</div>
	</div>
</template>

<script>
	export default {
		data(){
			return {
				arr:[],
				arrTips:[],
				title:"",
				btntxt:""
			}
		},
		mounted() {
			const that = this;
			mui.init();

			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});
		},
		created(){
			var queryType = this.$route.query.type;
			switch(queryType){
				case 'ios':
					this.arr = [{text:1,value:"点击iOS版下载安装"},
					{text:2,value:"<p class='iostext'>打开APP显示“未受信任的企业级开发者”</p><p class='red'>弹窗点击取消</p>"},
					{text:3,value:"打开手机<span>【设置】—【通用】</span>"},
					{text:4,value:"选择<span>【设备管理】</span>选项"},
					{text:5,value:"点击按钮<span>【信任】</span>按钮"}];
					this.arrTips = [{text:"1",value:"步骤1：点击iOS下载"},
					{text:"2",value:"步骤2：选择设置"},
					{text:"3",value:"步骤3：选择通用"},
					{text:"4",value:"步骤4：设备管理"},
					{text:"5",value:"步骤5：选择信任"}];
					this.title="iOS安装步骤";
					this.btntxt="点击下载IOS端"
					break;
				default:
					this.arr = [{text:1,value:"点击Android版下载安装"},
					{text:2,value:"选择桌面<span>“设置”</span>"},
					{text:3,value:"点击<span>“更多设置”</span>"},
					{text:4,value:"选择<span>“系统安全”</span>"},
					{text:5,value:"打开<span>“未知来源”</span>"}];
					this.arrTips = [{text:"01",value:"步骤1：点击andriod版下载"},
					{text:"02",value:"步骤2：桌面设置步骤"},
					{text:"03",value:"步骤3：选择更多设置"},
					{text:"04",value:"步骤4：选择系统安全"},
					{text:"05",value:"步骤5：打开未知来源"}];
					this.title="Android安装步骤";
					this.btntxt="点击下载Android端"
					break;
			}
		}
	}
</script>

<style lang="scss" >
	@import '~static/sass/public.scss';
	.contentbox{
		background:#fff !important;
		position:relative !important;
		width: 100% !important;
		height: 100% !important;		
	}
	.red{
		color: $warnColor !important;
		font-size:0.28rem;
	}
	.iostext{
		font-size:0.28rem;
		color:$normalFontColor;
	}
	.download{
		background:#fff;
		width:6.5rem;
		margin:auto;
		text-align:center;
		.topbox{
			padding-bottom:1rem;
			h3{
				font-size:0.36rem;
				color:$importFontColor;
				font-weight:normal;
				padding:0.4rem 0 0.3rem 0;
			}
			.tipbox{
				border:1px solid $tipsFontColor;
				border-radius:3px;
				margin-bottom:0.3rem;
				height: 0.9rem;
				display:table;
				width:100%;
				text-align: center;
				background:$bgColor;
				position:relative;
				.num{
					position:absolute;
					left: 0;
					top: 0;
					padding:0.3rem 0.2rem;
					font-size:0.5rem;
					color:#ff1a18;
				}
				.text{
					background:none;
					height: 0.9rem;
					display:table-cell;
					vertical-align:middle;
					/*width: 85%;*/
					font-size:0.28rem;
					color:$normalFontColor;
					span{
						color:$warnColor !important;
					}
				}
			}
			.look{
				color:#fff;
				background:#000;
				margin-top: 0.25rem;
				margin-bottom:0.4rem;
				width: 100%;
				height: 0.7rem;
				font-size:0.32rem;
			}
		}
	}
	.bottombox{
		background: #fff;
		p{
			font-size:0.32rem;
			color:$importFontColor;
			padding-bottom:0.2rem;
			text-align:left;
		}
		.imgbox{
			/*border-right:1px solid #797474;
			border-bottom:1px solid #797474;*/
			margin-bottom:0.4rem;
			img{
				width: 100%;
				height:auto;
			}
		}
	}
	.btnbox{
		position: absolute;
		bottom:0;
		left: 0;
		background:#f2f2f2;
		width: 100%;
		z-index:100;
		padding:0.2rem 0;
		.downloadapp{		
			/*margin-top:0.3rem;
			margin-bottom:0.2rem;*/
			color:#fff;
			background:#ff181a;
			width: 7rem;
			height: 0.7rem;
			font-size:0.32rem;
		}
	}

</style>