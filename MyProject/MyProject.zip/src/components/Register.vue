<template>
	<div id="Register">
		<form class="mui-input-group">
			<div class="mui-input-row">
				<label class="mui-text-justify"><span class="iconfont icon-icon-22"></span></label>
				<input type="text" class="mui-input-clear" placeholder="请输入11位手机号码" v-model="checkRegister.mobile" oninput='this.value = this.value.replace(/\D+/g, "")'>
			</div>
			<div class="mui-input-row">
				<label class="mui-text-justify"><span class="iconfont icon-icon-29"></span></label>
				<input type="password" class="mui-input-clear" placeholder="密码（6-20位数字和字母）" v-model="checkRegister.password">
			</div>
			<div class="mui-input-row">
				<label class="mui-text-justify"><span class="iconfont icon-icon-32"></span></label>
				<input type="password" class="mui-input-clear" placeholder="请再次输入密码" v-model="password2">
			</div>
			<div class="mui-input-row">
				<label class="mui-text-justify"><span class="iconfont icon-icon-43"></span></label>
				<input type="text" class="mui-input-clear" placeholder="请输入推荐邀请码" v-model="checkRegister.INVITE_CODE">
			</div>
			<div class="mui-input-row CheckCode">
				<label class="mui-text-justify"><span class="iconfont icon-icon-31"></span></label>
				<input type="text" class="mui-input-clear CodeImg" placeholder="请输入验证码" v-model="checkRegister.code">
				<img class="checkCodeImg CodeImg" :src="CheckImg" />
			</div>
		</form>
		<div class="btn-group">
			<button type="button" class="mui-btn mui-btn-blue mui-btn-block register-btn">立即开户，享受8元现金红包</button>
		</div>
		<div class="account mui-clearfix">
			<span class="mui-pull-left">已有账号?</span>
			<router-link to="Login" class="mui-pull-right color-blue">立即登录</router-link>
		</div>
	</div>
</template>

<script>
	import api from '@/api/userUtil';
	export default {
		name: 'Register',
		data() {
			return {
				checkRegister: {
					mobile: '',
					password: '',
					code: '',
					agent_create_ind: '0',
					parent_user_agent_id: '',
					ATTR1: '',
					ATTR2: '',
					USER_TYPE_CD: lib.WEB_TYPE__,
					REGISTER_ADR: lib.ME_URL___ + '/m',
					mob: '1',
					INVITE_CODE: '',
				},
				password2:'',
				CheckImg:'static/img/public/checkCode.png',
			}
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.btn-group').on('tap', '.register-btn', function() {
					mui(this).button('loading');
					//点击按钮会变高，需改loading图片大小
					$('.mui-btn-block .mui-spinner').css({
						'width': '18px',
						'height': '18px'
					})
					that.handleRegister();
					setTimeout(function() {
						mui(this).button('reset');
					}.bind(this), 2000);
				});
				
				//换验证码
				mui('.mui-input-group').on('tap','.CodeImg',function(){
					that.getCheckImg();
				})
				
			})
		},
		methods:{
			//表单验证
			fromCheck(){
				let phoneReg = /^1[34578]\d{9}$/;
				let pwdReg = /^[a-zA-Z]\w{5,11}$/;
				if(this.checkRegister.mobile == '' || this.checkRegister.mobile == undefined){
					this.$alert('手机号不能为空！');
					return false;
				}else if(!phoneReg.test(this.checkRegister.mobile)){
					this.$alert('请输入正确的手机号码！');
					return false;
				}
				if(this.checkRegister.password == '' || this.checkRegister.password == undefined){
					this.$alert('密码不能为空！');
						return false;
				}else if(!pwdReg.test(this.checkRegister.password)){
					this.$alert('密码以字母开头，且长度在6-12位之间！');
					return false;
				}
				if(this.password2 != this.checkRegister.password){
					this.$alert('两次输入的密码不一致哦！');
					return false;
				}
				if(this.checkRegister.code == '' || this.checkRegister.code == undefined || this.checkRegister.code ==null){
					this.$alert('验证码不能为空！');
					return false;
				}
				if(this.checkRegister.INVITE_CODE == '' || this.checkRegister.INVITE_CODE == undefined){
					this.$alert('邀请码不能为空！');
						return false;
				}
				return true;
			},
			//表单提交
			handleRegister(){
				const that = this;
				if(this.fromCheck()){
					this.checkRegister.ATTR1 = this.checkRegister.password;
					this.checkRegister.password = $.md5(this.checkRegister.password);
					console.log(this.checkRegister)
					api.Register(this.checkRegister,(data)=>{
						if(data.state == 'success'){
							that.$alert('注册成功！');
							that.$store.dispatch('checkLoginState');
							that.$router.push({
								path:'/'
							})
							var t = setTimeout(()=>{
								$.ajax({
									url: lib.URL__ + '/User/CheckLoginSecondStep',
									data: {
										login_www: lib.device,
										usertype: '',
										device_type:lib.device
									},
									type: "post",
									dataType: "json",
									xhrFields: {
										withCredentials: true
									},
									success: function(data) {
										//获取账户余额要延迟，保证会员账户创建完成后再调用接口
										that.$store.dispatch('getAccount');
									},
									error: function(err) {}
								});
							},3000)
						}else{
							that.$alert(data.message);
						}
					},(err)=>{
						that.$alert(err);
					})
				}
			},
			//更换验证码
			getCheckImg() {
				this.CheckImg = lib.URL__ + '/User/GetAuthCode?rd=' + Math.random();
			},
		}
	}
</script>

<style lang="scss" scoped>
@import '../../static/sass/public.scss';
	input {
		font-size: 0.28rem;
	}
	
	.mui-input-row {
		font-size: 0.28rem;
		color: $normalFontColor;
		.iconfont{
			font-size: 0.4rem;
			vertical-align: -2px;
			color: $blueColor;
			margin-right: 0.08rem;
		}
	}
	.CheckCode{
		position: relative;
		.checkCodeImg{
			display:block;
			height: 30px;
			width: auto;
			position: absolute;
			right: 0.24rem;
			top: 5px;
		}
	}
	.mui-input-row label{
		width: 15%;
	}
	.mui-input-row label~input, .mui-input-row label~select, .mui-input-row label~textarea{
		width: 85%;
	}
	#Register {
		padding-top: 1rem;
	}
	.account{
		margin-top: 0.85rem;
		padding: 0 2rem;
		font-size: 0.28rem;
		.color-blue{
			color: $blueColor;
		}
	}
	.mr-r {
		margin-right: 0.36rem;
	}
	.mui-input-group{
		background: $whiteColor;
	}
	.mui-input-group:after,
	.mui-input-group:before {
		display: none;
	}
	
	.btn-group {
		margin-top: 0.8rem;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.28rem;
	}
</style>