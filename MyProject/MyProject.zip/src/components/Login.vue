<template>
	<div id="Login">
		<form class="mui-input-group">
			<div class="mui-input-row">
				<label class="mui-text-justify"><span class="iconfont icon-icon-22" ></span></label>
				<input type="text" class="mui-input-clear" placeholder="请输入用户名" v-model="username">
			</div>
			<div class="mui-input-row">
				<label class="mui-text-justify"><span class="iconfont icon-icon-29" ></span></label>
				<input type="password" class="mui-input-clear" placeholder="请输入密码" v-model="password">
			</div>
		</form>
		<div class="btn-group">
			<div class="mui-clearfix switch-padding">
				<div class="miss-password mui-pull-left mui-font">
					<a href="javascript:;" class="mui-btn-link mui-font">忘记密码</a>
				</div>
				<div class="switch mui-pull-right mui-font mui-clearfix">
					<a href="javascript:;" class="mui-btn-link mui-font mui-pull-left mr-r-8">记住密码</a>
					<div class="mui-switch mui-switch-mini mui-pull-right" id="mySwitch" :class="remenber ?'mui-active': ''">
						<div class="mui-switch-handle"></div>
					</div>
				</div>
			</div>
			<button type="button" class="mui-btn mui-btn-blue mr-t login-btn mui-btn-block">登录</button>
			<button type="button" class="mui-btn mui-btn-primary mr-t-17 mui-btn-block mui-btn-outlined register-btn">没有账号？点击注册</button>
		</div>
		
	</div>
</template>

<script>
	import api from '@/api/userUtil';
	export default {
		name: 'Login',
		components: {
			
		},
		data() {
			return {
				IsShow: false,
				username: '',
				password: '',
				checkCode:'',
				login_www:lib.ME_URL___ + '/m',
				usertype:lib.WEB_TYPE__,
				remenber:true,
			}
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.btn-group').on('tap', '.login-btn', function() {
					mui(this).button('loading');
					//点击按钮会变高，需改loading图片大小
					$('.mui-btn-block .mui-spinner').css({
						'width': '18px',
						'height': '18px'
					})
					if(that.formCheck()){
						api.CheckLoginFirstStep(that,function(res){
							if(res.state == 'success'){
								//如果用户勾选了记住密码就存cookie;
								if(that.remenber){
									that.setCookie();
								}else{
									that.clerCookie();
								}
								that.$toast('登入成功！');
								var t = setTimeout(()=>{
									that.$router.push({
										path:'/'
									})
									clearTimeout(t);
								},1000)
							}else{
								that.$toast(res.message);
							}
						})
					}
					setTimeout(function() {
						mui(this).button('reset');
					}.bind(this), 1500);
				})

				mui('.btn-group').on('tap', '.register-btn', function() {
					that.$router.push({
						path: 'Register'
					})
				})

				mui('.btn-group').on('tap', '.miss-password', function() {
					that.$router.push({
						path: 'GetbackPwd'
					}) //找回密码
				})

				mui('.btn-group').on('tap', '.mui-switch', function(event) {
					that.remenber = !that.remenber;
				})

			})
			
		},
		methods: {
			//表单验证
			formCheck() {
				if(this.username == '' || this.username == undefined){
					this.$toast('用户名不能为空！');
					return false;
				}
				if(this.password == '' || this.password == undefined){
					this.$toast('密码不能为空！');
					return false;
				}
				return true;
			},
			//设置cookie
			setCookie(){
				$.cookie('username',this.username,{expires:15});
				$.cookie('password',this.password,{expires:15});
			},
			//清除cookie
			clerCookie(){
				$.cookie('username',null);
				$.cookie('password',null);
			},
		},
		created(){
			if($.cookie('username')){
				this.username = $.cookie('username');
				this.password = $.cookie('password');
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '../../static/sass/public.scss';
	input {
		font-size: 0.28rem;
	}
	
	.mui-input-group {
		background: $whiteColor;
		.mui-text-justify {
			position: relative;
		}
		.iconfont {
			color: $blueColor;
			font-size: 0.4rem;
			vertical-align: -2px;
			margin-right: 0.08rem;
		}
	}
	
	.mui-input-row label {
		width: 15%;
	}
	
	.mui-input-row label~input,
	.mui-input-row label~select,
	.mui-input-row label~textarea {
		width: 85%;
	}
	
	.mr-r-8 {
		margin-right: 0.16rem;
		color: $assistFontColor;
	}
	
	.mr-t-15 {
		margin-top: 0.64rem;
	}
	
	.mr-t-17 {
		margin-top: 0.4rem !important;
	}
	
	#Login {
		padding-top: 1rem;
	}
	
	.mr-r {
		margin-right: 0.36rem;
	}
	
	.mr-t {
		margin-top: 0.16rem !important;
	}
	
	.mui-input-group:after,
	.mui-input-group:before {
		display: none;
	}
	
	.btn-group {
		/*margin-top: 20px;*/
	}
	
	.mui-input-row {
		font-size: 0.28rem;
		color: $normalFontColor;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.mui-btn-link {
		padding: 0;
	}
	
	.mui-switch {
		display: inline-block;
		height: 0.6rem;
	}
	
	.mui-switch .mui-switch-handle {
		width: 0.56rem;
		height: 0.56rem;
	}
	
	.mui-switch-mini.mui-active .mui-switch-handle {
		transform: translate(0.6rem, 0);
	}
	
	.mui-switch-mini {
		width: 1.2rem;
	}
	
	.mui-font {
		font-size: 0.28rem;
	}
	
	.switch-padding {
		padding: 0.36rem 0.3rem;
		line-height: 0.64rem;
	}
</style>