<template>
	<div id="Download">
		<div class="mui-content conten">
			<img src="static/img/download/download.png">
		</div>
		<div class="lin">
			<button type="button" class="mui-btn mui-btn-block ios_button"><span class="ios-ico"></span>IOS下载</button>
			<div class="onclick ios" data-type="ios">点击查看苹果安装教程</div>
		</div>
		<button type="button" class="mui-btn mui-btn-block and_button"><span class="android-ico"></span>Android下载</button>
		<div class="onclick android" data-type="android">点击查看安卓安装教程</div>
	</div>
	
</template>

<script>
	export default{
		data(){
			return{
				
			}
		},
		mounted(){
			const that = this;
			mui('#Download').on('tap','.onclick',function(){
				var type = $(this).data('type');
				that.$router.push({
					path:'DownloadApp',
					query:{
						type:type
					}
				})
			})
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
.conten img{
	width: 100%;
	height: auto;
}
.lin{
	margin: auto;
}
.ios_button{
	background: $titleBgColor;
	margin: auto;
	margin-top: 0.5rem;
	&:active{
		background: rgba($titleBgColor,0.6);
	}
}
.onclick{
	margin-top: 0.25rem;
	font-size: 0.32rem;
	color: #6e6e6e;
}
.and_button{
	background: #09b609;
	margin: auto;
	margin-top: 0.5rem;
	&:active{
		background: rgba(#09b609,0.6);
	}
}
.ios_button,.and_button{
	font-size: 0.42rem;
	padding: 0.20rem;
	width: 90%;
	width: 90%;
	border: 0 none;
	position: relative;
	color: $whiteColor;
	text-indent: 0.24rem;
}

.ios-ico,.android-ico{
	display: inline-block;
	width: 0.36rem;
	height: 0.42rem;
	transform: translateY(2px);
	margin-right: 0.1rem;
}
.ios-ico{
	background: url('~static/img/download/ios.png') no-repeat;
	background-size:100% 100%;
}
.android-ico{
	background: url('~static/img/download/and.png') no-repeat;
	background-size:100% 100%;
}


</style>