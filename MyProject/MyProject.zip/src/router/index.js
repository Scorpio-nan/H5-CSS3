import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

Router.prototype.goBack = function () {
  this.isBack = true
  window.history.go(-1)
} //扩展的返回上一次路由
export default new Router({
  routes: [{
    path: '/',
    name: '',
    component: resolve => require(['@/page/Index'], resolve),
    children: [{
      path: '',
      name: 'Home',
      meta: {
        title: '首页',
        IsShow: true
      },
      component: resolve => require(['@page/Center/Home'], resolve)
    },
      {
        path: 'ReturnWaterRecord',
        name: 'ReturnWaterRecord',
        meta: {
          title: '返水记录',
          IsShow: true
        },
        component: resolve => require(['@page/Center/ReturnWaterRecord'], resolve)
      }, {
        path: 'WithdrawMoney',
        name: 'WithdrawMoney',
        meta: {
          title: '取款',
          IsShow: true
        },
        component: resolve => require(['@page/Center/WithdrawMoney'], resolve)
      }, {
        path: 'ReturnWaterDetail',
        name: 'ReturnWaterDetail',
        meta: {
          title: '返水明细',
          IsShow: false
        },
        component: resolve => require(['@page/Center/ReturnWaterDetail'], resolve)
      }, {
        path: 'TransactionRecord',
        name: 'TransactionRecord',
        meta: {
          title: '交易记录',
          IsShow: true
        },
        component: resolve => require(['@page/Center/TransactionRecord'], resolve)
      }, {
        path: 'AccountBalance',
        name: 'AccountBalance',
        meta: {
          title: '账户余额',
          IsShow: true
        },
        component: resolve => require(['@page/Center/AccountBalance'], resolve)
      },{
        path: 'AccountInformation',
        name: 'AccountInformation',
        meta: {
          title: '账户信息',
          IsShow: true
        },
        component: resolve => require(['@page/Center/AccountInformation'], resolve)
      },{
        path: 'QuotaConversion',
        name: 'QuotaConversion',
        meta: {
          title: '额度转换',
          IsShow: true
        },
        component: resolve => require(['@page/Center/QuotaConversion'], resolve)
      }, {
        path: 'BindingBankCard',
        name: 'BindingBankCard',
        meta: {
          title: '绑定银行卡',
          IsShow: false
        },
        component: resolve => require(['@page/Center/BindingBankCard'], resolve)
      },

      {
        path: 'Center',
        name: 'Center',
        meta: {
          title: '个人中心',
          IsShow: true
        },
        component: resolve => require(['@page/Center/Center'], resolve)
      }, {
        path: 'Login',
        name: 'Login',
        meta: {
          title: '登录',
          IsShow: false
        },
        component: resolve => require(['@/components/Login'], resolve)
      },{
        path: 'Download',
        name: 'Download',
        meta: {
          title: 'APP下载',
          IsShow: false
        },
        component: resolve => require(['@/components/Download'], resolve)
      },{
      	path: 'DownloadApp',
        name: 'DownloadApp',
        meta: {
          title: 'App安装教程',
          IsShow: false
        },
        component: resolve => require(['@/components/DownloadApp'], resolve)
      },{
      	path: 'Turntable',
        name: 'Turntable',
        meta: {
          title: '幸运转盘',
          IsShow: false
        },
        component: resolve => require(['@/page/Activity/Turntable'], resolve)
      },{
      	path: 'Turntables',
        name: 'Turntables',
        meta: {
          title: '中奖纪录',
          IsShow: false
        },
        component: resolve => require(['@/page/Activity/Turntableresult'], resolve)
      },{
				path: 'UserMsg',
				name: 'UserMsg',
				meta: {
					title: '个人资料',
					IsShow: true
				},
				component: resolve => require(['@/page/Center/UserMsg'], resolve)
			}, {
				path: 'CellMe',
				name: 'CellMe',
				meta: {
					title: '联系我们',
					IsShow: false
				},
				component: resolve => require(['@/page/Center/CellMe'], resolve)
			}, {
				path: 'Complaint',
				name: 'Complaint',
				meta: {
					title: '投诉建议',
					IsShow: false
				},
				component: resolve => require(['@/page/Center/Complaint'], resolve)
			}, {
        path: 'Register',
        name: 'Register',
        meta: {
          title: '注册',
          IsShow: false
        },
        component: resolve => require(['@/components/Register'], resolve)
      }, {
        path: 'GetbackPwd',
        name: 'GetbackPwd',
        meta: {
          title: '找回密码',
          IsShow: false
        },
        component: resolve => require(['@/components/GetbackPwd'], resolve)
      }, {
        path: 'BankCard',
        name: 'BankCard',
        meta: {
          title: '添加银行卡',
          IsShow: true
        },
        component: resolve => require(['@page/Center/BankCard'], resolve)
      }, {
        path: 'BettingRecord',
        name: 'BettingRecord',
        meta: {
          title: '投注记录',
          IsShow: true
        },
        component: resolve => require(['@page/Center/BettingRecord'], resolve)
      }, {
        path: 'AgentBetDetail',
        name: 'AgentBetDetail',
        meta: {
          title: '下级注单',
          IsShow: false
        },
        component: resolve => require(['@page/Center/BettingRecord'], resolve)
      }, {
        path: 'BettingRecordDetail',
        name: 'BettingRecordDetail',
        meta: {
          title: '投注记录详情',
          IsShow: false
        },
        component: resolve => require(['@page/Center/BettingRecordDetail'], resolve)
      }, {
        path: 'AgentCenter',
        name: 'AgentCenter',
        meta: {
          title: '代理中心',
          IsShow: false
        },
        component: resolve => require(['@page/Agent/AgentCenter'], resolve)
      }, {
        path: 'Subreports',
        name: 'Subreports',
        meta: {
          title: '代理报表',
          IsShow: false
        },
        component: resolve => require(['@page/Agent/Subreports'], resolve)
      }, {
        path: 'SubFinance',
        name: 'SubFinance',
        meta: {
          title: '下级财务',
          IsShow: false
        },
        component: resolve => require(['@page/Agent/SubFinance'], resolve)
      }, {
        path: 'Createsubordinate',
        name: 'Createsubordinate',
        meta: {
          title: '创建下级',
          IsShow: false
        },
        component: resolve => require(['@page/Agent/Createsubordinate'], resolve)
      }, {
        path: 'Codemanagement',
        name: 'Codemanagement',
        meta: {
          title: '邀请码管理',
          IsShow: false
        },
        component: resolve => require(['@page/Agent/Codemanagement'], resolve)
      },{
				path: '/Flowdetails',
				name: 'Flowdetails',
				meta: {
					title: '流水明细',
					IsShow: false
				},
				component: resolve => require(['@/page/Center/Flowdetails'], resolve)
			},
      {
        path: 'Promotions',
        name: 'Promotions',
        meta: {
          title: '优惠活动',
          IsShow: false
        },
        component: resolve => require(['@page/Center/Promotions'], resolve)
      }, {
        path: 'PromotionsDtail',
        name: 'PromotionsDtail',
        meta: {
          title: '优惠活动详情',
          IsShow: false
        },
        component: resolve => require(['@page/Center/PromotionsDtail'], resolve)
      }, {
        path: 'Account',
        name: 'Account',
        meta: {
          title: '账户安全',
          IsShow: false
        },
        component: resolve => require(['@page/Center/Account'], resolve)
      }, {
        path: 'ElectronicGame',
        name: 'ElectronicGame',
        meta: {
          title: '电子游艺',
          IsShow: false
        },
        component: resolve => require(['@page/Center/ElectronicGame'], resolve)
      },{
        path: 'SportsGame',
        name: 'SportsGame',
        meta: {
          title: '体育赛事',
          IsShow: false
        },
        component: resolve => require(['@page/Center/SportsGame'], resolve)
      }, {
        path: 'VideoGame',
        name: 'VideoGame',
        meta: {
          title: '真人视讯',
          IsShow: false
        },
        component: resolve => require(['@page/Center/VideoGame'], resolve)
      }, {
        path: 'LotteryGame',
        name: 'LotteryGame',
        meta: {
          title: '彩票游戏',
          IsShow: false
        },
        component: resolve => require(['@page/Center/LotteryGame'], resolve)
      }, {
        path: 'ElectronicGameDtail',
        name: 'ElectronicGameDtail',
        meta: {
          title: '电子游艺',
          IsShow: false
        },
        component: resolve => require(['@page/Center/ElectronicGameDtail'], resolve)
      }, {
        path: 'Rechargeonline',
        name: 'Rechargeonline',
        meta: {
          title: '存款',
          IsShow: true
        },
        component: resolve => require(['@page/Center/Rechargeonline'], resolve)
      }, {
        path: 'Information',
        name: 'Information',
        meta: {
          title: '我的消息',
          IsShow: false
        },
        component: resolve => require(['@page/Center/Information'], resolve)
      }, {
        path: 'Collect',
        name: 'Collect',
        meta: {
          title: '我的收藏',
          IsShow: false
        },
        component: resolve => require(['@page/Center/Collect'], resolve)
      },{
        path: 'SearchRecord',
        name: 'SearchRecord',
        meta: {
          title: '账户记录',
          IsShow: false
        },
        component: resolve => require(['@page/Agent/SearchRecord'], resolve)
      },
      {
        path: 'AboutUs',
        name: 'AboutUs',
        meta: {
          title: '关于我们',
          IsShow: false
        },
        component: resolve => require(['@page/Center/AboutUs'], resolve)
      }, {
        path: 'VipCenter',
        name: 'VipCenter',
        meta: {
          title: '下级列表',
          IsShow: false
        },
        component: resolve => require(['@page/Agent/VipCenter'], resolve)
      },{
      	path: '/CaptailDetail',
        name: 'CaptailDetail',
        component: resolve => require(['@/page/Center/CaptailDetail'], resolve),
        meta:{
        	title:"资金明细",
        	IsShow:false
        }
      },{
      	path: '/Calculation',
        name: 'Calculation',
        component: resolve => require(['@/page/Agent/Calculation'], resolve),
        meta:{
        	title:"返点赔率",
        	IsShow:false
        }
      },{
      	path: '/MyEarnings',
        name: 'MyEarnings',
        component: resolve => require(['@/page/Agent/MyEarnings'], resolve),
        meta:{
        	title:"我的收益",
        	IsShow:false
        }
      },{
      	path: '/AgencyDevelopCourse',
        name: 'AgencyDevelopCourse',
        component: resolve => require(['@/page/Agency/AgencyDevelopCourse'], resolve),
        meta:{
        	title:"代理加盟",
        	IsShow:true
        }
      },{
      	path: '/GuildList',
        name: 'GuildList',
        component: resolve => require(['@/page/Agency/GuildList'], resolve),
        meta:{
        	title:"金字塔教程",
        	IsShow:true
        }
      },{
      	path: '/GuildSwiperList',
        name: 'GuildSwiperList',
        component: resolve => require(['@/page/Agency/GuildSwiperList'], resolve),
        meta:{
        	title:"金字塔教程",
        	IsShow:true
        }
      },
      {
      	path: '/DiscountsActivity',
        name: 'DiscountsActivity',
        component: resolve => require(['@/page/Activity/DiscountsActivity'], resolve),
        meta:{
        	title:"优惠活动",
        	IsShow:true
        }
      }
    ]
  }, 
  //彩票
  {
    path: '/LotIndex',
    name: 'LotIndex',
    component: resolve => require(['@/page/Betting/LotIndex'], resolve),
    children: [{
      path: '/SSC',
      name: 'SSC',
      component: resolve => require(['@/page/Betting/SSC'], resolve)
    }, {
      path: '/cp3',
      name: 'cp3',
      component: resolve => require(['@/page/Betting/Cp3'], resolve)
    }, {
      path: '/cp11',
      name: 'cp11',
      component: resolve => require(['@/page/Betting/cp11'], resolve)
    }, {
      path: '/gdklsf',
      name: 'gdklsf',
      component: resolve => require(['@/page/Betting/gdklsf'], resolve)
    }, {
      path: '/bjpk10',
      name: 'bjpk10',
      component: resolve => require(['@/page/Betting/Bjpk10'], resolve)
    }, {
      path: '/HK6',
      name: 'HK6',
      component: resolve => require(['@/page/Betting/HK6'], resolve),
      redirect: '/TemaA',
      children: [{
        path: '/TemaA',
        name: 'TemaA',
        component: resolve => require(['@/page/Betting/hk6/TemaA'], resolve)
      },{
        path: '/QuanBuZhong',
        name: 'QuanBuZhong',
        component: resolve => require(['@/page/Betting/hk6/QuanBuZhong'], resolve)
      },{
        path: '/TeMaShengXiao',
        name: 'TeMaShengXiao',
        component: resolve => require(['@/page/Betting/hk6/TeMaShengXiao'], resolve)
      },{
        path: '/ZhengMaTe',
        name: 'ZhengMaTe',
        component: resolve => require(['@/page/Betting/hk6/ZhengMaTe'], resolve)
      },{
        path: '/ZhengMa',
        name: 'ZhengMa',
        component: resolve => require(['@/page/Betting/hk6/ZhengMa'], resolve)
      },{
        path: '/ZongHe',
        name: 'ZongHe',
        component: resolve => require(['@/page/Betting/hk6/ZongHe'], resolve)
      },{
        path: '/HeXiao',
        name: 'HeXiao',
        component: resolve => require(['@/page/Betting/hk6/HeXiao'], resolve)
      },{
        path: '/LianMa',
        name: 'LianMa',
        component: resolve => require(['@/page/Betting/hk6/LianMa'], resolve)
      },{
        path: '/YiXiaoWeiShu',
        name: 'YiXiaoWeiShu',
        component: resolve => require(['@/page/Betting/hk6/YiXiaoWeiShu'], resolve)
      },{
        path: '/WeiShuLian',
        name: 'WeiShuLian',
        component: resolve => require(['@/page/Betting/hk6/WeiShuLian'], resolve)
      },{
        path: '/ShengXiaoLian',
        name: 'ShengXiaoLian',
        component: resolve => require(['@/page/Betting/hk6/ShengXiaoLian'], resolve)
      }]
    }, {
      path: '/cqssc_rule',
      name: 'cqssc_rule',
      component: resolve => require(['@/page/Betting/gameRule/cqssc_rule'], resolve)
    },
      {
        path: '/bjpk10_rule',
        name: 'bjpk10_rule',
        component: resolve => require(['@/page/Betting/gameRule/bjpk10_rule'], resolve)
      }, {
        path: '/gdklsf_rule',
        name: 'gdklsf_rule',
        component: resolve => require(['@/page/Betting/gameRule/gdklsf_rule'], resolve)
      }, {
        path: '/kuaisan_rule',
        name: 'kuaisan_rule',
        component: resolve => require(['@/page/Betting/gameRule/kuaisan_rule'], resolve)
      }, {
        path: '/11x5_rule',
        name: '11x5_rule',
        component: resolve => require(['@/page/Betting/gameRule/11x5_rule'], resolve)
      }, {
        path: '/hk6_rule',
        name: 'hk6_rule',
        component: resolve => require(['@/page/Betting/gameRule/hk6_rule'], resolve)
      },{
      	path: '/gameLong',
        name: 'gameLong',
        component: resolve => require(['@/page/Betting/gameDetails/gameLong'], resolve)
      }, {
      	path: '/OpenResult',
        name: 'OpenResult',
        component: resolve => require(['@/page/Betting/gameDetails/OpenResult'], resolve),
      }, {
        path: '/BetDetail',
        name: 'BetDetail',
        component: resolve => require(['@/page/Betting/gameDetails/BetDetail'], resolve)
      }
    ]
  }]
})
