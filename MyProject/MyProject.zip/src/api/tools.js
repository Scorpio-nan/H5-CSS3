export default {
	//获取支付路劲图标；
	getPayIcon2: function(val) {
		switch(val) {
			case 'bank':
				return 'static/img/upay.png'
				break;
		    case 'bank_quick':
				return 'static/img/bank_quick.png'
				break;
			case 'alipay':
				return 'static/img/alipay.png'
				break;
			case 'alipay_bank':
				return 'static/img/alipay_bank.png'
				break;	
			case 'wechat':
				return 'static/img/wechat.png'
				break;
			case 'qq':return 'static/img/qq.png'
			case 'qq_scan':return 'static/img/qq.png'
			case 'qq_wallet':
				return 'static/img/qq.png'
				break;
			case 'tranAccount':
				return 'static/img/remittance.png'
				break;
			case 'wechat_wallet':
				return 'static/img/wechat-wall.png'
				break;
		    case 'wechat_bank':
				return 'static/img/wechat_bank.png'
				break;
			case 'aliapy_wallet':
				return 'static/img/alipay-wall.png'
				break;
		}
	},
	
	GetshipinUrl: function(val) {//获取开奖视频网站
		switch(val) {
			case 'cqssc':
				return 'http://nb9999.com/cp_m/html/ssc_cq/index.html'
				break;
			case 'bjpk10':
				return 'http://nb9999.com/cp_m/html/pk10/index.html'
				break;  
			case 'tjssc':
				return 'http://nb9999.com/cp_m/html/ssc_tj/index.html'
				break;
			case 'xjssc':
				return 'http://nb9999.com/cp_m/html/ssc_xj/index.html'
				break;
			case 'gdklsf':
				return 'http://nb9999.com/cp_m/html/gdklsf/index.html'
				break;
			case 'hk6':
				return 'http://nb9999.com/6hc_m/'
				break;
		}
	},
	GetResultUrl: function(val) {//获取开奖结果网站
		switch(val) {
			case 'cqssc':
				return 'http://nb9999.com/cp_m/html/ssc_cq/index.html'
				break;
			case 'bjpk10':
				return 'http://nb9999.com/cp_m/html/pk10/index.html'
				break;  
			case 'tjssc':
				return 'http://nb9999.com/cp_m/html/ssc_tj/index.html'
				break;
			case 'xjssc':
				return 'http://nb9999.com/cp_m/html/ssc_xj/index.html'
				break;
			case 'gdklsf':
				return 'http://nb9999.com/cp_m/html/gdklsf/index.html'
				break;
			case 'hk6':
				return 'http://nb9999.com/6hc_m/'
				break;
		}
	},
	
	getBankIcon: function(val){
        switch (val) {
            case '建设银行':
                return 'static/img/bank/js_bankicon.png';
                break;
            case '农业银行':
                return 'static/img/bank/ny_bankicon.png';
                break;
            case '招商银行':
                return 'static/img/bank/zs_bankicon.png';
                break;
            case '中国银行':
                return 'static/img/bank/zg_bankicon.png';
                break;
            case '兴业银行':
                return 'static/img/bank/xy_bankicon.png';
                break;
            case '工商银行':
                return 'static/img/bank/gs_bankicon.png';
                break;
            case '北京银行':
                return 'static/img/bank/bj_bankicon.png';
                break;
            case '光大银行':
                return 'static/img/bank/gd_bankicon.png';
                break;
            case '广发银行':
                return 'static/img/bank/gf_bankicon.png';
                break;
            case '华夏银行':
                return 'static/img/bank/hx_bankicon.png';
                break;
            case '交通银行':
                return 'static/img/bank/jt_bankicon.png';
                break;
            case '民生银行':
                return 'static/img/bank/ms_bankicon.png';
                break;
            case '宁波银行':
                return 'static/img/bank/nb_bankicon.png';
                break;
            case '平安银行':
                return 'static/img/bank/pa_bankicon.png';
            case '浦发银行':
                return 'static/img/bank/pf_bankicon.png';
                break;
            case '上海银行':
                return 'static/img/bank/sh_bankicon.png';
                break;
            case '深圳银行':
                return 'static/img/bank/sz_bankicon.png';
                break;
            case '邮政储蓄':
                return 'static/img/bank/yz_bankicon.png';
                break;
            case '中信银行':
                return 'static/img/bank/zx_bankicon.png';
                break;
        }
},
	//获取几天前的日期
	getDateBefore: function(n) {
		var uom = new Date(new Date() - 0 - n * 86400000);
		if(uom.getDate() >= 0 && uom.getDate() <= 9) {
			uom = uom.getFullYear() + "-" + (uom.getMonth() + 1) + "-0" + uom.getDate();
		} else {
			uom = uom.getFullYear() + "-" + (uom.getMonth() + 1) + "-" + uom.getDate();
		}
		return uom;
	},

	//获取当前时间
	getTodayBegin: function() {
		var date = new Date();
		var month = date.getMonth() + 1;
		var strDate = date.getDate();
		if(month >= 1 && month <= 9) {
			month = "0" + month;
		}
		if(strDate >= 0 && strDate <= 9) {
			strDate = "0" + strDate;
		}
		var currentdate = date.getFullYear() + "-" + month + "-" + strDate + " 00:00:00";
		return currentdate;
	},

	//获取当前时间
	getTodayEnd: function() {
		var date = new Date();
		var seperator1 = "-";
		var seperator2 = ":";
		var month = date.getMonth() + 1;
		var strDate = date.getDate();
		if(month >= 1 && month <= 9) {
			month = "0" + month;
		}
		if(strDate >= 0 && strDate <= 9) {
			strDate = "0" + strDate;
		}
		var currentdate = date.getFullYear() + "-" + month + "-" + strDate + " 23:59:59";
		return currentdate;
	},
};