export default {
	/** 获取个人消息列表**/
	GetMessageList: function(callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetMessageList?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			data: {
				page:1,
				rows:15,
				sord: "desc",
				sidx: "PUBLISH_DTT",
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(callback) {
					callback(data);
				}
			},
			error: function(err) {

			}
		});
	},
	UpdMessageState: function(msgid, callback) {
		$.ajax({
			url: lib.URL__ + '/User/UpdMessageState?MsgID=' + msgid,
			type: "get",
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {

			}
		});
	},
	DelMessage: function(msgid, callback) {
		$.ajax({
			url: lib.URL__ + '/User/DelMessage?detail_id=' + msgid,
			type: "get",
			dataType: "json",
			data: {},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(callback) {
					callback(data);
				}
			},
			error: function(err) {

			}
		});
	},
	//获取会员咨询回复信息列表
	GetUserMsgConsultList: function(msgid, callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetUserMsgConsultList?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			data: {
				msg_id:msgid,				
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {

			}
		});
	},
	//插入一条会员咨询信息
	AddUserMsgConsult: function(msgid,content, callback) {
		$.ajax({
			url: lib.URL__ + '/User/AddUserMsgConsult?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			data: {
				msg_id:msgid,
				content:content
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {

			}
		});
	},

};