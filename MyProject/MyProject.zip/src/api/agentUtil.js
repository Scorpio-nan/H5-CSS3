export default {
	//获取代理信息
	GetAgent: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/GetAgent?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			type: 'get',
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//代理申请
	SubAgentApply: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/SubAgentApply?rd=' + Math.random(),
			data: postData,
			xhrFields: {
				withCredentials: true
			},
			type: 'post',
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取代理底下的所有会员
	GetAgentLowMemberList: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/GetAgentLowMemberList?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			dataType: "json",
			type: 'get',
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},

	//获取代理的反水明细
	GetRebateDetail: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/GetRebateDetail?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			type: 'get',
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},	
	//获取资金流向
	GetMoneyFlow: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/GetMoneyFlow?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},	
	//删除代理银行卡
	DeleteBankCard: function(id, callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/DeleteBankCard?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data:{CardID:id},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//添加代理银行卡
	SubAgentBankInfo:function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/SubAgentBankInfo?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//代理银行卡信息
	GetAgentBankInfo:function(callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/GetAgentBankInfo?rd=' + Math.random(),
			type: 'get',
			xhrFields: {
				withCredentials: true
			},			
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//代理取款
	SubAgentWithDraw:function(postdata,callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/SubAgentWithDraw?rd=' + Math.random(),
			type: 'post',
			xhrFields: {
				withCredentials: true
			},
			data:postdata,
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//代理汇款
	SubAgentDeposit:function(postdata,callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/SubAgentDeposit?rd=' + Math.random(),
			type: 'post',
			xhrFields: {
				withCredentials: true
			},
			data:postdata,
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取取款收费费
	GetAgentPayFees: function(DrawMoney, callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/GetAgentPayFees',
			type: "get",
			data: {
				"fee_type": 1,
				"amt": DrawMoney
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},	
	//代理下级会员财务报表
	GetAgentReportList: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/GetAgentReportList',
			type: "get",
			dataType: "json",
			data: postData,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//代理下线会员投注报表
	GetAgentLowMemberReportList: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/GetAgentLowMemberReportList',
			type: "get",
			dataType: "json",
			data: postData,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
}