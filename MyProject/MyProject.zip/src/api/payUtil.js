export default {
	GetOnlinePayDetailLineList: function(pmc, callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetOnlinePayDetailLineList',
			type: "get",
			dataType: "json",
			data: {
				payModeCd: pmc,
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(callback) {
					callback(data);
				}
			},
			error: function(err) {}
		});
	},
	//支付方式改造，按支付渠道分
	GetOnlinePayChannelListNew: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetOnlinePayChannelListNew',
			type: "get",
			dataType: "json",
			data: {
				type: 'MB',
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(callback) {
					callback(data);
				}
			},
			error: function(err) {
				//alert(err.responseText);
			}
		});
	},

	//手机转账汇款列表获取
	GetPayChannelList: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetPayChannelList?rd=' + Math.random(),
			type: 'get',
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(callback) {
					callback(data);
				}
			},
			error: function(err) {}
		});
	}

};