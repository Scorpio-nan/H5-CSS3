export default {
	arrayCombine(callback, itemNum, targetArr) {

		if(!targetArr || !targetArr.length) {
			return [];
		}
		var len = targetArr.length;
		var resultArrs = [];

		if(len == itemNum) {
			resultArrs.push(targetArr);
			return callback(resultArrs);
		} else if(len < itemNum) {
			return callback(resultArrs);
		}
		// 所有组合 
		//for(var n = 1; n < len; n++) {

		var flagArrs = this.getFlagArrs(len, itemNum);

		while(flagArrs.length) {

			var flagArr = flagArrs.shift();

			var combArr = [];

			for(var i = 0; i < len; i++) {

				flagArr[i] && combArr.push(targetArr[i]);
			}
			resultArrs.push(combArr);
		}

		callback(resultArrs);

	}, //获得从m中取n的所有组合
	getFlagArrs(m, n) {

		if(!n || n < 1) {
			return [];
		}
		var resultArrs = [],

			flagArr = [],

			isEnd = false,

			i, j, leftCnt;

		for(i = 0; i < m; i++) {
			flagArr[i] = i < n ? 1 : 0;
		}
		resultArrs.push(flagArr.concat());

		while(!isEnd) {

			leftCnt = 0;

			for(i = 0; i < m - 1; i++) {

				if(flagArr[i] == 1 && flagArr[i + 1] == 0) {

					for(j = 0; j < i; j++) {

						flagArr[j] = j < leftCnt ? 1 : 0;

					}
					flagArr[i] = 0;

					flagArr[i + 1] = 1;

					var aTmp = flagArr.concat();

					resultArrs.push(aTmp);

					if(aTmp.slice(-n).join("").indexOf('0') == -1) {

						isEnd = true;

					}
					break;
				}

				flagArr[i] == 1 && leftCnt++;
			}
		}
		return resultArrs;
	},
	ballGroup(callback, hm, checked) {
		var permutatedArray = [];
		var betstr;
		if(hm == 4) {
			for(var a = 0; a < checked.length - 3; a++) {
				for(var b = a + 1; b < checked.length - 2; b++) {
					for(var c = b + 1; c < checked.length - 1; c++) {
						for(var d = c + 1; d < checked.length; d++) {

							betstr = checked[a] + ', ' + checked[b] + ', ' + checked[c] + ', ' + checked[d];
							permutatedArray.push(betstr);
						}
					}
				}
			}
		}
		if(hm == 3) {
			for(var a = 0; a < checked.length - 2; a++) {
				for(var b = a + 1; b < checked.length - 1; b++) {
					for(var c = b + 1; c < checked.length; c++) {

						betstr = checked[a] + ', ' + checked[b] + ', ' + checked[c];
						permutatedArray.push(betstr);
					}
				}
			}
		}
		if(hm == 2) {
			for(var a = 0; a < checked.length - 1; a++) {
				for(var b = a + 1; b < checked.length; b++) {

					betstr = checked[a] + ', ' + checked[b];
					permutatedArray.push(betstr);
				}
			}
		}
		callback(permutatedArray);
	},
	myTimeStamp(second_time) {

		var time = parseInt(second_time);
		if(parseInt(second_time) >= 60) {
			var second = parseInt(second_time) % 60;
			if(second < 10) {
				second = '0' + second;
			}
			var min = parseInt(second_time / 60);
			time = min + ":" + second + "";
			if(min > 60) {
				min = parseInt(second_time / 60) % 60;
				var hour = parseInt(parseInt(second_time / 60) / 60);
				time = hour + ":" + min + ":" + second;
				if(hour > 24) {
					hour = parseInt(parseInt(second_time / 60) / 60) % 24;
					min = parseInt(second_time / 60) % 60;
					var day = parseInt(parseInt(parseInt(second_time / 60) / 60) / 24);
					time = day + "天" + hour + "时" + min + ":" + second + "";
				}
			}

		} else {
			var second = parseInt(second_time) % 60;
			if(second < 10) {
				second = '0' + second;
			}
			time = '0:' + second;
		}

		return time;
	},
	luhmCheck(nums, callback) {
		console.log(nums)
		var bankno = nums.replace(/\s+/g, "");
		console.log(bankno)
		var msg = "";
		var msg1 = "";
		var rs = false;
		var num = /^\d*$/; //全数字
		var strBin = "10,18,30,35,37,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,58,60,62,65,68,69,84,87,88,94,95,98,99"; //开头6位
		var lastNum = bankno.substr(bankno.length - 1, 1); //取出最后一位（与luhm进行比较）
		var first15Num = bankno.substr(0, bankno.length - 1); //前15或18位
		var newArr = new Array();
		for(var i = first15Num.length - 1; i > -1; i--) { //前15或18位倒序存进数组
			newArr.push(first15Num.substr(i, 1));
		}
		var arrJiShu = new Array(); //奇数位*2的积 <9
		var arrJiShu2 = new Array(); //奇数位*2的积 >9
		var arrOuShu = new Array(); //偶数位数组
		for(var j = 0; j < newArr.length; j++) {
			if((j + 1) % 2 == 1) { //奇数位
				if(parseInt(newArr[j]) * 2 < 9)
					arrJiShu.push(parseInt(newArr[j]) * 2);
				else
					arrJiShu2.push(parseInt(newArr[j]) * 2);
			} else //偶数位
				arrOuShu.push(newArr[j]);
		}
		var jishu_child1 = new Array(); //奇数位*2 >9 的分割之后的数组个位数
		var jishu_child2 = new Array(); //奇数位*2 >9 的分割之后的数组十位数
		for(var h = 0; h < arrJiShu2.length; h++) {
			jishu_child1.push(parseInt(arrJiShu2[h]) % 10);
			jishu_child2.push(parseInt(arrJiShu2[h]) / 10);
		}
		var sumJiShu = 0; //奇数位*2 < 9 的数组之和
		var sumOuShu = 0; //偶数位数组之和
		var sumJiShuChild1 = 0; //奇数位*2 >9 的分割之后的数组个位数之和
		var sumJiShuChild2 = 0; //奇数位*2 >9 的分割之后的数组十位数之和
		var sumTotal = 0;
		for(var m = 0; m < arrJiShu.length; m++) {
			sumJiShu = sumJiShu + parseInt(arrJiShu[m]);
		}
		for(var n = 0; n < arrOuShu.length; n++) {
			sumOuShu = sumOuShu + parseInt(arrOuShu[n]);
		}
		for(var p = 0; p < jishu_child1.length; p++) {
			sumJiShuChild1 = sumJiShuChild1 + parseInt(jishu_child1[p]);
			sumJiShuChild2 = sumJiShuChild2 + parseInt(jishu_child2[p]);
		}
		//计算总和
		sumTotal = parseInt(sumJiShu) + parseInt(sumOuShu) + parseInt(sumJiShuChild1) + parseInt(sumJiShuChild2);
		//计算Luhm值
		var k = parseInt(sumTotal) % 10 == 0 ? 10 : parseInt(sumTotal) % 10;
		var luhm = 10 - k;
		console.log("值" + luhm + "-----" + k + "最后一位数" + lastNum)
		if(bankno.length < 16 || bankno.length > 20) {
			//$("#banknoInfo").html("银行卡号长度必须在16到19之间");
			msg = "银行卡号长度必须在16到20之间";
		} else if(!num.test(bankno)) {
			//$("#banknoInfo").html("银行卡号必须全为数字");
			msg = "银行卡号必须全为数字";
		} else if(strBin.indexOf(bankno.substring(0, 2)) == -1) {
			//$("#banknoInfo").html("银行卡号开头6位不符合规范");
			msg = "银行卡号开头6位不符合规范";
		} else if(lastNum == luhm) {
			//$("#banknoInfo").html("Luhm验证通过");
			rs = true;
			msg = "success";
		} else if(lastNum != luhm) {
			//$("#banknoInfo").html("银行卡号必须符合Luhm校验");
			msg = "银行卡号不符合Luhm校验";
		}
		callback(msg);
		return {
			math: rs,
			msg: msg
		};
	},
	getDateSpan: function(action) {
		var star_time, end_time;
		if(action == "today") {
			star_time = this.getDateBefore(0) + " 00:00:00"
			end_time = this.getDateBefore(0) + " 23:59:59"
		}
		if(action == "yesterday") {
			star_time = this.getDateBefore(1) + " 00:00:00"
			end_time = this.getDateBefore(1) + " 23:59:59"
		}
		if(action == "lastweek") {
			star_time = this.getDateBefore(7) + " 00:00:00"
			end_time = this.getDateBefore(0) + " 23:59:59"
		}
		if(action == "lastmonth") {
			star_time = this.getDateBefore(30) + " 00:00:00"
			end_time = this.getDateBefore(0) + " 23:59:59"
		}
		//console.log({star_time:star_time,end_time:end_time});
		return {
			star_time: star_time,
			end_time: end_time
		};
	},

	//获取支付路劲图标；
	getPayIcon2: function(val) {
		switch(val) {
			case 'bank':
				return 'static/img/upay.png'
				break;
			case 'bank_quick':
				return 'static/img/bank_quick.png'
				break;
			case 'alipay':
				return 'static/img/alipay.png'
				break;
			case 'alipay_bank':
				return 'static/img/alipay_bank.png'
				break;
			case 'wechat':
				return 'static/img/wechat.png'
				break;
			case 'qq':
				return 'static/img/qq.png'
			case 'qq_scan':
				return 'static/img/qq.png'
			case 'qq_wallet':
				return 'static/img/qq.png'
				break;
			case 'tranAccount':
				return 'static/img/remittance.png'
				break;
			case 'wechar_wallet':
				return 'static/img/wechat-wall.png'
				break;
			case 'wechat_bank':
				return 'static/img/wechat_bank.png'
				break;
			case 'aliapy_wallet':
				return 'static/img/alipay-wall.png'
				break;
		}
	},

	getBankIcon: function(val) {
		switch(val) {
			case '建设银行':
				return 'static/img/bank/jianshe.png';
				break;
			case '农业银行':
				return 'static/img/bank/nongye.png';
				break;
			case '招商银行':
				return 'static/img/bank/zhaoshang.png';
				break;
			case '中国银行':
				return 'static/img/bank/zhongguo.png';
				break;
			case '兴业银行':
				return 'static/img/bank/xingye.png';
				break;
			case '工商银行':
				return 'static/img/bank/gongshang.png';
				break;
			case '北京银行':
				return 'static/img/bank/beijing.png';
				break;
			case '光大银行':
				return 'static/img/bank/guangda.png';
				break;
			case '广发银行':
				return 'static/img/bank/guangda.png';
				break;
			case '华夏银行':
				return 'static/img/bank/huaxia.png';
				break;
			case '交通银行':
				return 'static/img/bank/jiaotong.png';
				break;
			case '民生银行':
				return 'static/img/bank/minsheng.png';
				break;
			case '宁波银行':
				return 'static/img/bank/ningbo.png';
				break;
			case '平安银行':
				return 'static/img/bank/pingan.png';
			case '浦发银行':
				return 'static/img/bank/pufa.png';
				break;
			case '上海银行':
				return 'static/img/bank/shanghai.png';
				break;
			case '深圳银行':
				return 'static/img/bank/shenzhen.png';
				break;
			case '邮政储蓄':
				return 'static/img/bank/youzheng.png';
				break;
			case '中兴银行':
				return 'static/img/bank/zhongxin.png';
				break;
		}
	},
	//获取几天前的日期
	getDateBefore: function(n) {
		var uom = new Date(new Date() - 0 - n * 86400000);
		if(uom.getDate() >= 0 && uom.getDate() <= 9) {
			uom = uom.getFullYear() + "-" + (uom.getMonth() + 1) + "-0" + uom.getDate();
		} else {
			uom = uom.getFullYear() + "-" + (uom.getMonth() + 1) + "-" + uom.getDate();
		}
		return uom;
	},

	//获取当前时间
	getTodayBegin: function() {
		var date = new Date();
		var month = date.getMonth() + 1;
		var strDate = date.getDate();
		if(month >= 1 && month <= 9) {
			month = "0" + month;
		}
		if(strDate >= 0 && strDate <= 9) {
			strDate = "0" + strDate;
		}
		var currentdate = date.getFullYear() + "-" + month + "-" + strDate + " 00:00:00";
		return currentdate;
	},

	//获取当前时间
	getTodayEnd: function() {
		var date = new Date();
		var seperator1 = "-";
		var seperator2 = ":";
		var month = date.getMonth() + 1;
		var strDate = date.getDate();
		if(month >= 1 && month <= 9) {
			month = "0" + month;
		}
		if(strDate >= 0 && strDate <= 9) {
			strDate = "0" + strDate;
		}
		var currentdate = date.getFullYear() + "-" + month + "-" + strDate + " 23:59:59";
		return currentdate;
	}
}