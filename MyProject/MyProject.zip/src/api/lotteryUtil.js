export default {
	/** 获取游戏列表**/
	GetGameLevelCode: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetGameLevelCode?parent_id=2&mob=1',
			type: "get",
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(data.length > 0) {
					callback(data);
				}
			},
			error: function(err) {}
		});
	},
	/** 获取游戏设置信息**/
	GetLotOddsDictList: function(callback, id) {
		if(window.localStorage.getItem(id + '_Racing_series') != null) {
					var data = eval('(' + window.localStorage.getItem(id + '_Racing_series') + ')');
					callback(data)
			} else{
		
		$.ajax({
			url: lib.URL__ + '/Lot/GetLotOddsDictList?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: {
				p_id: id
			},
			dataType: 'json',
			type: 'get',
			success: function(data) {
				if(callback) callback(data)
					window.localStorage.setItem(id + '_Racing_series', JSON.stringify(data));
			},
			error: function(err) {}
		})
		}
	},
	GetHk6OddsDictList: function(callback, postData,this_) {
		$.ajax({
			url: lib.URL__ + '/Hk6/GetHk6OddsDictList?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			dataType: 'json',
			type: 'get',
			success: function(data) {
				if(callback) callback(data)
			},
			error: function(err) {}
		})
	},
	GetHk6OddsDict2List: function(callback, postData,this_) {
		$.ajax({
			url: lib.URL__ + '/Hk6/GetHk6OddsDict2List?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			dataType: 'json',
			type: 'get',
			success: function(data) {
				if(callback) callback(data);
				window.localStorage.setItem(27+'tamaArray', JSON.stringify(data));
			},
			error: function(err) {}
		})
	},
	/** 下注**/
	AppendLotBetDetail: function(callback, _subObj) {
		var _subJson = JSON.stringify(_subObj);

		$.ajax({
			url: lib.URL__ + '/Lot/AppendLotBetDetail?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: {
				json: escape(_subJson)
			},
			type: 'post',
			success: function(data) {
				if(callback) callback(data);
			},
			error: function(err) {
				var obj = {
					status: '2',
					msg: '亲,您的下注频率太快啦,1秒钟只限一次哦~'
				}
				callback(obj);
			}
		})
	},
	/** 六合彩下注**/
	AppendHk6LotBetDetail: function(callback, _subObj) {
		var _subJson = JSON.stringify(_subObj);
		$.ajax({
			url: lib.URL__ + '/Hk6/AppendHk6LotBetDetail?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: {
				json: escape(_subJson)
			},
			type: 'post',
			success: function(data) {
				if(callback) callback(data);
			},
			error: function(err) {
				var obj = {
					status: '2',
					msg: '亲,您的下注频率太快啦,1秒钟只限一次哦~'
				}
				callback(obj);
			}
		})
	},
	//六合彩开奖结果；**/
	Hk6openresult: function(callback, postdata) {
		$.ajax({
			url: lib.URL__ + '/Hk6/Hk6openresult?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postdata,
			type: 'get',
			dataType: 'json',
			success: function(data) {
				if(callback) callback(data);
			},
			error: function(err) {

			}
		})
	},
	GetOpenTime: function(callback, tid, tcode) { //下期开盘时间

		var __url = lib.URL__ + '/Lot/GetOpenTime?rd=' + Math.random();
		if(tcode == 'hk6' || tcode == 'undefined' || tcode == null) {
			__url = lib.URL__ + '/Hk6/GetOpenTime?rd=' + Math.random();
			tid = 27;
		}
		$.ajax({
			url: __url,
			xhrFields: {
				withCredentials: true
			},
			data: {
				game_id: tid
			},
			type: 'get',
			timeout: 10000,
			success: function(data) {
				var r_data = eval('(' + data + ')');
				if(callback) callback(r_data);

			},
			error: function(err) {
				var _obj = {
					state: 'error'
				}
				callback(_obj);
			}
		});
	},
	GetLotteryData: function(callback, classCode) { //开奖结果

		$.ajax({
			url: lib.URL__ + '/Lot/GetLotteryData?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: {
				code: classCode
			},
			type: 'get',
			timeout: 10000,
			beforeSend: function() {

			},
			success: function(data) {
				var resultNo = eval('(' + data + ')');
				if(callback) callback(resultNo);
			},
			error: function(err) {
				var _obj = {
					state: 'error'
				}
				callback(_obj);
				//				console.log(lib.URL__ + '/Lot/GetLotteryData?rd=' + Math.random());
				//				console.log(err)
			}
		});
	},
	getTicTime: function(callback, tid, tcode) { //下期开盘时间

		var __url = lib.URL__ + '/Lot/GetOpenTime?rd=' + Math.random();
		if(tcode == 'hk6' || tcode == 'undefined' || tcode == null) {
			__url = lib.URL__ + '/Hk6/GetOpenTime?rd=' + Math.random();
			tid = 27;
		}
		$.ajax({
			url: __url,
			xhrFields: {
				withCredentials: true
			},
			data: {
				game_id: tid
			},
			type: 'get',
			timeout: 10000,
			success: function(data) {
				var r_data = eval('(' + data + ')');
				if(callback) callback(r_data);

			},
			error: function(err) {
				var _obj = {
					state: 'error'
				}
				callback(_obj);
			}
		});
	},
	GetLotteryData_DB: function(callback, __p_id, classCode) { //开奖结果

		$.ajax({
			url: lib.URL__ + '/Lot/GetLotteryData_DB?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: {
				p_id: __p_id,
				code: classCode
			},
			type: 'get',
			timeout: 10000,
			beforeSend: function() {

			},
			success: function(data) {
				var resultNo = eval('(' + data + ')');
				if(callback) callback(data);
			},
			error: function(err) {
				var _obj = {
					state: 'error'
				}
				callback(_obj);
			}
		});
	},
	//获取彩票历史记录
	GetWinResult: function(callback, postData) {
		$.ajax({
			url: lib.URL__ + '/Lot/GetWinResult?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			dataType: 'json',
			type: 'get',
			success: function(data) {
				if(callback) callback(data)
			},
			error: function(err) {}
		})
	},
	// 获取彩票2面长龙统计数据
	GetLotClongCN: function(callback, id) {
		$.ajax({
			url: lib.URL__ + '/Lot/GetLotClongCN?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: {
				parent_id: id
			},
			dataType: 'json',
			type: 'get',
			success: function(data) {
				if(callback) callback(data)
			},
			error: function(err) {}
		})
	},

	Getuserwin: function(callback) {
		$.ajax({
			type: "GET",
			url: lib.URL__ + '/User/Getuserwin',
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(data.length > 0) {
					callback(data);
				}
			},
			error: function(err) {

			}

		});
	},
	hk6animal: function(callback) {
		$.ajax({
			type: "GET",
			url: lib.URL__ + '/Hk6/GetHk6ModeDicJson?modeCd=hk6_animal_cd|Group',
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
				window.localStorage.setItem('AnimalArray', JSON.stringify(data));
			},
			error: function(err) {

			}

		});
	},
	hk6Color: function(callback) {
		$.ajax({
			type: "GET",
			url: lib.URL__ + '/Hk6/GetHk6ModeDicJson?modeCd=hk6_cd|num',
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
				window.localStorage.setItem('numColors', JSON.stringify(data));
				if(data.length > 0) {
					//	callback(data);
				}

			},
			error: function(err) {

			}

		});
	},
	GetHk6ModeDicJson: function(callback) {
		$.ajax({
			type: "GET",
			url: lib.URL__ + '/Hk6/GetHk6ModeDicJson?modeCd=hk6_animal_cd|Group',
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
				window.localStorage.setItem('AnimalArray', JSON.stringify(data));
			},
			error: function(err) {

			}

		});
	},

	// 获取6合彩过关数据,
	GetHk6LotGgOddsList: function(callback, code) {
		$.ajax({
			type: "GET",
			url: lib.URL__ + '/Hk6/GetHk6LotGgOddsList',
			dataType: "json",
			data: {
				code: code
			},
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
		});
	},
};