export default {
	//获取轮播图片
	GetIndexBannerList: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetIndexBannerList',
			xhrFields: {
				withCredentials: true
			},
			data: {
				type_id: 2
			},
			success: function(data) {
				var data = eval('(' + data + ')');
				if(callback)
					callback(data);
			},
			error: function(err) {
				console.log('网络连接失败');
			}
		});
	},
	//获取HOME页面的游戏列表大类 by Ay
	GetGameClassBig: function(__id, callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetMobileList?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: {
				parent_id: __id,
				para_type: ''
			},
			type: 'get',
			beforeSend: function() {},
			success: function(data) {
				callback(data);
			},
			error: function(err) {
				console.log('网络连接失败');
			}
		})
	},
	//获取HOME页面的游戏列表大类 by Ay
	GetGameClassBig2: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetGameClassBig?rd=' + Math.random(),
			success: function(data) {
				callback(data)
			},
			error: function(err) {
				console.log('网络连接失败');
			}
		});
	},
	//获取手机端游戏子类
	GetMobileList: function(__id, callback) {
		// if(window.localStorage.getItem(__id+'Gamelist') != null) {
		// 	var data = eval('(' + window.localStorage.getItem(__id+'Gamelist') + ')');
		// 	callback(data);
		// } else {
		
		$.ajax({
			url: lib.URL__ + '/Web/GetMobileList?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: {
				parent_id: __id,
				para_type: ''
			},
			type: 'get',
			dataType: "json",
			beforeSend: function() {},
			success: function(data) {
				callback(data);
				// window.localStorage.setItem(__id+'Gamelist', JSON.stringify(data));
			},
			error: function(err) {
				alert('网络连接失败');
			}
		})
		// }
	},
	//获取借贷类型
	GetDebitList: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetDebitList?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			type: 'get',
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	
	GetBankList: function(callback) {//获取银行列表
		$.ajax({
                url:lib.URL__ +'/Web/GetBankList?rd='+ Math.random(),
                xhrFields: {
                     withCredentials: true
                },
                type:'get',
                success:function(data){
                    callback(data);
                },
                error:function(err){  
                }
            })
	},
	
	TransferGameURL:function(__gamecd,__ismobile,gameid,callback) {
		$.ajax({
			url: lib.URL__ + '/Api/TransferGameURL?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: {
				gamecd: __gamecd,
				game_id:gameid,
				ismobile: __ismobile
			},
			type: 'post',
			success: function(data) {
				callback(data);
			},
			error: function(err) {
			}
		});
	},
	GetMobileFavoriteList:function(id,callback){//获取收藏列表
		$.ajax({
            url:lib.URL__ + '/Web/GetMobileFavoriteList?rd='+ Math.random(),
            xhrFields: {
                withCredentials: true
			},
			data:{
				user_id:id
			},
            type:'get',
            success:function(data){
                callback(data);
            },
            error:function(err){
            }
       })
	},
	AddGameFavorite:function(gmLev,parntGmId,gmId,callback){//设置收藏
		$.ajax({
            url:lib.URL__ + '/Web/AddGameFavorite?rd='+ Math.random(),
            xhrFields: {
                withCredentials: true
			},
			data:{
				gmLev: gmLev,
				parntGmId:parntGmId,
				gmId: gmId
			},
            type:'get',
            success:function(data){
                callback(data);
            },
            error:function(err){
            }
       })
	},
	GetEGamesList:function(postData,callback) {
		$.ajax({
            url:lib.URL__ + '/Web/GetEGamesList?rd='+ Math.random(),
            xhrFields: {
                withCredentials: true
            },
            data:  postData,
            type:'get',
            success:function(data){
                callback(data);
            },
            error:function(err){
            }
       })
	},
}

