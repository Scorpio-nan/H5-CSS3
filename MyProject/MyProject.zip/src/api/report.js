export default {
	//获取体育驻单报表
	GetSptList: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/Spt/GetSptList?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			data: postData,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//游戏列表查看
	GetLotHk6List:function(postdata,callback){
		$.ajax({
			url: lib.URL__ + '/Agent/GetLotHk6List',
			type: 'get',
			cache: false,
			data: postdata,
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
		//游戏点数计算
		GetLotHk6OddsList:function(postdata,callback){
		$.ajax({
			url: lib.URL__ + '/Agent/GetLotHk6OddsList',
			type: 'get',
			cache: false,
			data: postdata,
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	GetGameBetData: function(postData, callback) { //add 20170327
		$.ajax({
			url: lib.URL__ + '/User/GetGameBetData?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			data: postData,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取所有活动列表信息
	GetActList: function(dataQuery, callback) {
		var _self = this;
		$.ajax({
			url: lib.URL__ + '/Web/GetActList',
			type: "get",
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			data: dataQuery,
			success: function(data) {
				for(var i = 0; i < data.rows.length; i++) {
					data.rows[i].TITLE_IMG_URL = lib.imgUrl + data.rows[i].TITLE_IMG_URL;
					data.rows[i].TITLE_CONTENT_URL = lib.imgUrl + data.rows[i].TITLE_CONTENT_URL;
					if(data.rows[i].CONTENT != null) {
						data.rows[i].CONTENT = _self.html_decode(data.rows[i].CONTENT);
					}
				}
				callback(data.rows);
			},
			error: function(err) {}
		});
	},
	html_decode: function(str) {
		var arrEntities = {
			'lt': '<',
			'gt': '>',
			'nbsp': ' ',
			'amp': '&',
			'quot': '"'
		};
		return str.replace(/&(lt|gt|nbsp|amp|quot);/ig, function(all, t) {
			return arrEntities[t];
		});
	},
	//获取公告
	GetNotice: function(content, type,callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetNotice?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			//async: false,
			data: {
				"top": 1,
				"notice_type":type.notice_type,
				"window": type.window_ind,
				"code": lib.TARGET_WEB_CODE_,
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				
				var showhtml = '';
				for(var i = 0; i < data.length; i++) {
					// showhtml += showhtml + '     ' + data[i].CONTENT;//内容
					if(type.notice_type == "1") {
						var con = data[i].CONTENT.replace(/<.*?>/ig,"");//干掉标签
						var _html = '';
						for(var k = 0; k < con.length; k++) {
							_html += con[k];
						}
						showhtml += '     ' + _html; //内容					
					} else {
						showhtml += '     ' + data[i].NOTICES_TITLE + "<br/>" + data[i].CONTENT; //标题+内容
					}

				}
				content.html(showhtml);
				if(callback) callback(data);
			},
			error: function(err) {

			}
		});
	},
	//获取星级活动奖项配置列表
	GetActStarLevelConfig: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Act/GetActStarLevelConfig',
			type: 'get',
			dataType: "json",
			data: {
				mob: 1
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取本周会员的星级数据
	GetUserActStarLevel: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Act/GetUserActStarLevel',
			type: 'get',
			dataType: "json",
			data: {
				mob: 1
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//点击领取彩金按钮
	PostActStarLevelIn: function(amt, id, callback) {
		$.ajax({
			url: lib.URL__ + '/Act/PostActStarLevelIn',
			type: 'post',
			cache: false, //默认值true 
			dataType: "json",
			data: {
				AMT: amt,
				ACT_STAR_LEVEL_CONFIG_ID: id
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//优惠活动列表 
	GetWebActYouhuiDatingList: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/Act/GetWebActYouhuiDatingList',
			type: 'get',
			cache: false, //默认值true 
			dataType: "json",
			data: postData,
			jsonp: "callback",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//表单数据 
	GetActTemplatesFormAttr: function(__Templates_Id, callback) {
		$.ajax({
			url: lib.URL__ + '/Act/GetActTemplatesFormAttr',
			type: 'get',
			cache: false,
			dataType: "json",
			data: {
				"ID": __Templates_Id
			},
			jsonp: "callback",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//申请提交按钮
	PostActYouhuiDatingAdd: function(Content, webId, callback) {
		$.ajax({
			url: lib.URL__ + '/Act/PostActYouhuiDatingAdd',
			type: 'post',
			cache: false,
			dataType: "json",
			data: {
				webId: webId,
				Content: Content
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//优惠活动申请进度
	GetActYouhuiDating: function(postdata, callback) {
		$.ajax({
			url: lib.URL__ + '/Act/GetActYouhuiDating',
			type: 'get',
			cache: false,
			dataType: "json",
			data: postdata,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {
				alert('暂无该活动申请记录!')
			}
		});
	},
	//轮盘活动—统计当前会员每日参与轮盘活动的信息
	GetUserActSlyder: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Act/GetUserActSlyder',
			type: 'get',
			cache: false,
			dataType: "json",
			data: {
				mob: 1
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {

			}
		});
	},
	//轮盘活动—活动参与记录列表
	GetActSlyderResult: function(obj, callback) {
		$.ajax({
			url: lib.URL__ + '/Act/GetActSlyderResult',
			type: 'get',
			cache: false,
			dataType: "json",
			data: obj,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {

			}
		});
	},
	//轮盘活动—领奖及提交联系人地址信息  
	PostActSlyderResultAddress: function(obj, callback) {
		$.ajax({
			url: lib.URL__ + '/Act/PostActSlyderResultAddress',
			type: 'post',
			cache: false,
			dataType: "json",
			data: obj,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {
				alert('暂无抽奖记录！')
			}
		});
	},
	//红包活动统计接口   
	GetActRedEnvelopesConfig: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Act/GetActRedEnvelopesConfig',
			type: 'get',
			cache: false,
			dataType: "json",
			data: {
				mob: 1
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		})
	},
	//红包活动抽奖返回金额
	PostActRedEnvelopesResult: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Act/PostActRedEnvelopesResult',
			type: 'post',
			cache: false,
			dataType: "json",
			data: {
				mob: 1
			},
			jsonp: "callback",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//红包活动中奖记录查询 
	GetActRedEnvelopesResult: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/Act/GetActRedEnvelopesResult',
			type: 'get',
			cache: false,
			dataType: "json",
			data: postData,
			jsonp: "callback",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//轮盘活动—抽奖  /
	GetActSlyderAdventuresConfig: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Act/GetActSlyderAdventuresConfig',
			type: 'get',
			cache: false,
			dataType: "json",
			data: {
				mob: 1
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//轮盘活动—抽奖  
	GetActSlyderPrize: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Act/GetActSlyderPrize',
			type: 'get',
			cache: false,
			dataType: "json",
			data: {
				mob: 1
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
		//所有开启的活动列表//新的
		GetActWebActivityList : function(callback){
		$.ajax({
			url: lib.URL__ + '/Act/GetActWebActivityList',
			type: 'get',
			cache: false,
			dataType: "json",
			data: {
				mob: 1
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取活动图片列表，新优惠活动模块
	GetActImgList : function(postdata,callback){
		$.ajax({
			url: lib.URL__ + '/Act/GetActImgList',
			type: 'get',
			cache: false,
			dataType: "json",
			data: postdata,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
};