export default {
	/** 获取登入状态**/
	CheckSession: function(cb) {
		$.ajax({
			url: lib.URL__ + '/User/CheckSession?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(data.state == 'success') {
					cb(true);

				} else {
					cb(false);
				}
			},
			error: function(err) {

			}
		});
	},
	/** 获取投诉建议类型**/
	GetSugesstionType: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetSugesstionType?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(data.length > 0) {
					callback(data);
				}
			},
			error: function(err) {

			}
		});
	},
		/** 获取红包**/
		GetRedEnvelopes: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Api/GetRedEnvelopes',
			type: "get",
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
					callback(data);
			},
			error: function(err) {
					var obj = {
                    state:'error',
                    message:'亲,刚刚已经抢过红包了，一分钟以后再来哦~~~' 
				}
				callback(obj);
			}
		});
	},
	GetIntBet: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetIntBet?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			type: 'get',
			data: postData,
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		})
	},
	GetLotterList: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetLotterList?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			type: 'get',
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		})
	},
	/*意见投诉提交*/
	SubSugesstion: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/User/SubSugesstion?rd=' + Math.random(),
			type: "post",
			dataType: "json",
			data: postData,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	/*登录*/
	CheckLogin: function(vm_obj, callback) {
		$.ajax({
			url: lib.URL__ + '/User/CheckLogin?rd=' + Math.random(),
			data: {
				username: vm_obj.username,
				password: $.md5($.trim(vm_obj.password)), //$.md5($.trim(pw)),
				code: vm_obj.checkCode,
				login_www: vm_obj.login_www,
				usertype: vm_obj.usertype,
				mob:'1',
			},
			type: 'post',
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data, status, xhr) {
				if(callback)
					callback(data);
				if(data.state == 'success') {

					if(typeof(data.data) != 'undefined' && typeof(data.data.a) != 'undefined') {
						var cookietime = new Date();
						cookietime.setTime(cookietime.getTime() + (30 * 60 * 1000)); //coockie保存一小时
						$.cookie("ploginkey", data.data.a, {
							path: "/",
							expires: cookietime
						});
					}
					vm_obj.$store.dispatch('checkLoginState');
					vm_obj.$store.dispatch('getUserInfo');
					vm_obj.$store.dispatch('getAccount');
				} else {
					//					alert('账号或密码不正确,请重新输入');
					vm_obj.checkCode = '';
					vm_obj.checkImg = lib.URL__ + '/User/GetAuthCode?rd=' + Math.random();
				}
			},
			error: function(err) {
				alert(err.responseText + '---------登录错误');
			}
		});
	},
	/*分歩登录--20171111--add by gene begin*/
	CheckLoginFirstStep: function(vm_obj, callback) {
		$.ajax({
			url: lib.URL__ + '/User/CheckLoginFirstStep?r',
			data: {
				username: vm_obj.username,
				password: $.md5($.trim(vm_obj.password)),
			},
			type: 'post',
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data, status, xhr) {
				if(callback) {
					callback(data);
				}
				if(data.state == 'success') {
					if(typeof(data.data) != 'undefined' && typeof(data.data.a) != 'undefined') {
						var cookietime = new Date();
						cookietime.setTime(cookietime.getTime() + (30 * 60 * 1000)); //coockie保存一小时
						$.cookie("ploginkey", data.data.a, {
							path: "/",
							expires: cookietime
						});
					}
					var UserCommond = {
						user:vm_obj.username,
						pass:$.md5($.trim(vm_obj.password))
					}
					localStorage.setItem('UserCommond',JSON.stringify(UserCommond));
					//console.log(UserCommond)
					var t = setTimeout(() => {
						vm_obj.$store.dispatch('checkLoginState');
						vm_obj.$store.dispatch('getAccount');
						vm_obj.$store.dispatch('getUserInfo');
					}, 500)
					//异步调用缓存数据接口
					var t = setTimeout(() => {
						$.ajax({
							url: lib.URL__ + '/User/CheckLoginSecondStep',
							data: {
								login_www: lib.device,
								usertype: vm_obj.usertype,
								device_type:lib.device
							},
							type: "post",
							dataType: "json",
							xhrFields: {
								withCredentials: true
							},
							success: function(data) {},
							error: function(err) {

							}
						});
					}, 4000)

				} else {
					//alert(data.message);
					vm_obj.checkCode = '';
					vm_obj.checkImg = lib.URL__ + '/User/GetAuthCode?rd=' + Math.random();
				}

			},
			error: function(err) {
				alert(err.responseText);
			}
		});
	},
	/*登出*/
	OutLogin: function(vm_obj) {
		$.ajax({
			type: "get",
			url: lib.URL__ + '/User/OutLogin?rd=' + Math.random(),
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(data.state == 'success') {
					vm_obj.$store.dispatch('checkLoginState');
					vm_obj.$store.dispatch('getUserInfo');
					vm_obj.$store.dispatch('getAccount');
					localStorage.removeItem('UserCommond');
				}
			}
		});
	},
	getDateBefore: function(n) {
		var uom = new Date(new Date() - 0 - n * 86400000);
		if(uom.getDate() >= 0 && uom.getDate() <= 9) {
			uom = uom.getFullYear() + "-" + (uom.getMonth() + 1) + "-0" + uom.getDate();
		} else {
			uom = uom.getFullYear() + "-" + (uom.getMonth() + 1) + "-" + uom.getDate();
		}
		return uom;
	},
	//用户输赢
	Getuserwin: function(callback) {
		$.ajax({
			type: "GET",
			url: lib.URL__ + '/User/Getuserwin',
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(data.length > 0) {
					callback(data);
				}
			},
			error: function(err) {

			}

		});
	},
	
	/*
	 * 获取账户余额信息
	 */
	GetAccount: function(acc_bal_cd, callback) {
		var accBal = {};
		var accBalArray = [];
		acc_bal_cd = acc_bal_cd || '';
		$.ajax({
			url: lib.URL__ + '/User/GetAccount?Acc_bal_cd=' + acc_bal_cd,
			type: "get",
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(data && data.length > 0) {
					var allmoney = 0;
					for(var i = 0; i < data.length; i++) {
						if(data[i].ACC_BAL_CD != "star_level") {
							allmoney += parseFloat(data[i].ACC_BAL);
							data[i].ACC_BAL = parseFloat(data[i].ACC_BAL).toFixed(2) + '';
							accBalArray.push(data[i]);
						}
					};
					allmoney = parseFloat(allmoney).toFixed(2);
				}
				accBal['allmoney'] = allmoney;
				accBal['accBalInfo'] = accBalArray;
				if(callback)
					callback(accBal);

			},
			error: function(err) {}
		});
	},

	GetPayBankList: function(type, callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetPayBankList?channeltype=' + type,
			type: "get",
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取额度转换明细金额
	GetBalance: function(acc_bal_cd, callback) {
		$.ajax({
			url: lib.URL__ + '/Api/GetBalance',
			type: "POST",
			dataType: "json",
			data: {
				'gamecd': acc_bal_cd
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {

			}
		});
	},
	setDrawPass: function(postData, callback) {//设置取款密码
		$.ajax({
			url: lib.URL__ + '/User/setDrawPass',
			type: "post",
			dataType: "json",
			data: postData,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {
				//alert(err);
			}
		});
	},
	/**获取取款银行列表*/
	GetDrawBankList: function(callback) {//已绑定银行卡列表
		$.ajax({
			url: lib.URL__ + '/User/GetDrawBankList?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			data: {},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {				
					callback(data);				
			},
			error: function(err) {

			}
		});
	},
	/**新增取款银行*/
	SubBankInfo: function(form, callback) {
		$.ajax({
			url: lib.URL__ + '/User/SubBankInfo',
			type: "post",
			dataType: "json",
			data: form, //$("#form1").formSerialize(),
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(data.state == 'success') {} else {
					alert('异常，请联系管理员');
				}
				if(callback) {
					callback(data);
				}
			},
			error: function(err) {
				alert('异常，请联系管理员');
			}
		});
	},
	/**提交取款申请*/
	SubWithDraw: function(form, callback) {
		$.ajax({
			url: lib.URL__ + '/User/SubWithDraw',
			type: "post",
			dataType: "json",
			data: form,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {
				alert('网络连接错误');
			}
		});
	},
	/**账户类型*/
	GetAccountList: function(callback) {
		$.ajax({
			url: lib.URL__ + '/Web/GetAccountList',
			type: "get",
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {

			}
		});
	},
	/** 用户线上存款交易列表 */
	SubDeposit: function(postdata, callback) {
		$.ajax({
			url: lib.URL__ + '/User/SubDeposit',
			type: "post",
			dataType: "json",
			data: postdata,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				if(data.state == 'success') {
					alert('您的信息已经提交，我们的客服人员会尽快处理');
					window.location = window.location;
				} else {
					alert(data.message);
				}
				callback(data);
			},
			error: function(err) {}
		});
	},

	/**用户交易列表*/
	TransferOperate: function(postdata, callback) {
		$.ajax({
			url: lib.URL__ + '/User/TransferOperate',
			type: "post",
			dataType: "json",
			data: postdata,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {
				//              var  errData= eval('(' + err.responseText + ')')
				//		
				var obj = {
					state: 'error',
					message: '亲,您的转账频率太快啦,1分钟只限一次哦~'
				}
				callback(obj);
				// alert('亲,您的转账频率太快啦,1分钟只限一次哦~');
			}
		});
	},
	ExistUserName: function(username, callback) {
		$.ajax({
			url: lib.URL__ + '/User/ExistUserName?username=' + username,
			type: "get",
			dataType: "json",
			data: "",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				var isExist = data.state == 'success' ? true : false;
				callback(isExist);
			},
			error: function(err) {}
		});
	},
	Register: function(postData, callback,err) {
		$.ajax({
			url: lib.URL__ + '/User/Register',
			data: postData,
			xhrFields: {
				withCredentials: true
			},
			type: "post",
			dataType: "json",
			success: function(data) {
				callback(data);
			},
			error: function(err) {
				err(err)
			},
			beforeSend: function() {

			},
			complete: function() {

			}
		});
	},
	GetNoReadMessageCount: function(callback) {

		$.ajax({
			url: lib.URL__ + '/User/GetNoReadMessageCount?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			data: {},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {

				//$('#msg_num').text(data);

				if(callback)
					callback(data);
			},
			error: function(err) {

			}
		});
	},
	/**通过缓存代理id获取代理账号*/
	GetAgentInfo: function(agent_id, callback) {
		$.ajax({
			url: lib.URL__ + '/agent/GetAgentInfo',
			type: "get",
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			data: {
				id: agent_id
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取取款收费费
	GetPayFees: function(DrawMoney, callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetPayFees',
			type: "get",
			data: {
				"fee_type": 1,
				"amt": DrawMoney
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取存取款相关记录
	GetOrderList: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetOrderList?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
		//获取代理下级的账务记录
		GetAgentOrderList: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetAgentOrderList?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	
	//获取金额转换信息
	GetTransList: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetTransList?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//修改密码
	UpdPass: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/User/UpdPass?rd=' + Math.random(),
			type: 'post',
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			success: function(data) {
				callback(data);
			},
			error: function(err) {

			}
		});
	},
	//积分兑换
	ExchangeScore: function(vm_obj, callback) {
		$.ajax({
			url: lib.URL__ + '/User/ExchangeScore?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: {
				score: vm_obj.exchangeCount,
				drawpass: $.md5($.trim(vm_obj.exchangePwd)),
				code: vm_obj.exchangeCode,
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {

			}
		});
	},
	getMinExchangeScore: function(callback) {
		$.ajax({
			url: lib.URL__ + '/User/getMinExchangeScore?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	GetUserbetRpt: function(postData,callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetUserbetRpt?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	PostAgentUser: function(postdata, callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/PostAgentUser?rd' + Math.random(),
			data:postdata,
			xhrFields: {
				withCredentials: true
			},
			type: "post",
			dataType: "json",
			success: function(data) {
				callback(data);
			},
			error: function() {},
			beforeSend: function() {

			},
			complete: function() {

			}
		});
	},
	GetUserInviteCodeList: function(postdata, callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetUserInviteCodeList?rd' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postdata,
			type: "get",
			dataType: "json",
			success: function(data) {
				callback(data);
			},
			error: function(err) {},

		});
	},

	PostModifyUserInviteCode: function(postdata, callback) {
		$.ajax({
			url: lib.URL__ + '/User/PostModifyUserInviteCode?rd' + Math.random(),
			data: postdata,
			xhrFields: {
				withCredentials: true
			},
			type: "post",
			dataType: "json",
			success: function(data) {
				callback(data);
			},
			error: function() {},
			beforeSend: function() {

			},
			complete: function() {

			}
		});
	},

	PostShareRed: function(postdata, callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/PostShareRed?rd' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postdata,
			type: "post",
			dataType: "json",
			success: function(data) {
				callback(data);
			},
			error: function(err) {},

		});
	},
	
	GetUserLeavesbetRpt: function(postData, callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetUserLeavesbetRpt?rd=' + Math.random(),
			xhrFields: {
				withCredentials: true
			},
			data: postData,
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取当前代理会员分润记录列表
	GetShareRecord:function(postdata,callback){
		$.ajax({
			url: lib.URL__ + '/Agent/GetShareRecord',
			type: 'get',
			dataType: "json",
			data: postdata,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取当前代理会员的分润记录
	GetRebateResult:function(postdata,callback){
		$.ajax({
			url: lib.URL__ + '/Agent/GetRebateResult?rd=' + Math.random(),
			type: 'get',
			dataType: "json",
			data: postdata,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	GetDelUserInviteCode:function(postdata,callback){
		$.ajax({
			url: lib.URL__ + '/User/GetDelUserInviteCode?rd=' + Math.random(),
			type: 'get',
			cache: false,
			data: postdata,
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//下级会员升级代理会员
	PostUpAgent:function(postdata, callback){
			$.ajax({
			url: lib.URL__ + '/Agent/PostUpAgent',
			type: 'post',
			dataType: "json",
			data:postdata ,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取当前代理会员分润点数详情
	GetShareList: function(id,callback) {
		$.ajax({
			url: lib.URL__ + '/Agent/GetShareList',
			type: 'get',
			dataType: "json",
			data: {
				user_id:id
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取我的抽取点数
	GetUpShareCount : function (user_id,callback){
		$.ajax({
			url: lib.URL__ + '/Agent/GetUpShareCount',
			type: 'get',
			dataType: "json",
			data: {
				user_id:user_id
			},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//更新（完善）个人资料
	UpdateUserInfo : function (postdata,callback){
		$.ajax({
			url: lib.URL__ + '/User/UpdateUserInfo',
			type: 'get',
			dataType: "json",
			data: postdata,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//代理反水统计
	getAgentFeedbackResult: function(postdata, callback) {
		$.ajax({
			url: lib.URL__ + '/agent/getAgentFeedbackResult?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			data: postdata,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},	
	//反水金额转账户余额
	GetReturnAmtToWallet:function(callback){
		$.ajax({
			url: lib.URL__ + '/User/GetReturnAmtToWallet?rd=' + Math.random(),
			type: "get",
			dataType: "json",
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取账户余额    （不带真人，电子余额）
	GetAccountNew:function(callback){
		$.ajax({
			url: lib.URL__ + '/User/GetAccountNew',
			type: "get",
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success:function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//返水明细列表
	GetReturnAmtList:function(params,callback){
		$.ajax({
			url: lib.URL__ + '/User/GetReturnAmtList',
			type: "get",
			dataType: "json",
			data:params,
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success:function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//总返水条目			
	GetSumUserReturnAmt:function(callback){
		$.ajax({
			url: lib.URL__ + '/User/GetSumUserReturnAmt',
			type: "get",
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success:function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	//获取用户信息
	GetUserInfo: function(cb) {
		$.ajax({
			type: "GET",
			url: lib.URL__ + '/User/GetUserInfo',
			dataType: "json",
			async: false,
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {

				if(data && data.ID > 0) {
					cb(data);
				}
			}
		});
	},
	//获取会员分组列表
	GetUserGroup:function(callback) {
		$.ajax({
			url: lib.URL__ + '/User/GetUserGroup?rd=' + Math.random(),
			type: 'get',
			xhrFields: {
				withCredentials: true
			},			
			success: function(data) {
				callback(data);
			},
			error: function(err) {}
		});
	},
	getquestion:function(callback){
		$.ajax({
			url: lib.URL__ + '/User/RegQuestions?rd=' + Math.random(),
			type: 'get',
			success: function(data) {
				callback(data)
			},
			error: function(err) {}
		})
	},
	/**删除取款银行*/
	delDrawBank: function(id, callback) {
		$.ajax({
			url: lib.URL__ + '/User/DeleteBankCard?CardID=' + id,
			type: "get",
			dataType: "json",
			data: {},
			xhrFields: {
				withCredentials: true
			},
			success: function(data) {
				callback(data);
			},
			error: function(err) {

			}
		});
	},
}

