<template>
	<div id="Account">
		<div class="stiky-box">
			<div class="main">
				<nav class="navbar">
					<a href="javascript:;" class="tab tableft" :class="AgentCd == 0? 'active':''" data-index="0">下级会员</a>
					<a href="javascript:;" class="tab tabright" :class="AgentCd == 1? 'active':''" data-index="1">下级代理</a>
				</nav>
				<div class="mui-input-row mar16">
					<nav class="nav">
						<div class="mui-input-row mui-radio mui-left changeRadio" data-zindex="0" :class="zindex == 0? 'active':''">
							邀请码开户
						</div>
						<div class="mui-input-row mui-radio mui-left changeRadio" data-zindex="1" :class="zindex == 1? 'active':''">
							分润设置开户
						</div>
					</nav>
				</div>
				<form class="mui-input-group mr-t-2 animated">
					<div class="mui-input-row">
						<label class="mui-text-justify">手机号码</label>
						<input type="tel" class="mui-input-clear" placeholder="请输入11位手机号码" v-model="phoneNum">
						<i class="iconfont icon-delete cleartext" v-if="phoneNum"></i>
					</div>
					<div class="mui-input-row">
						<label class="mui-text-justify">密码</label>
						<input type="password" class="mui-input-clear" placeholder="6-20位英文、数字组合" v-model="password">
					</div>
					<div class="mui-input-row seeting" v-show="zindex == 0">
						<label class="mui-text-justify">邀请码</label>
						<input type="tel" class="mui-input-clear" v-model="InviteCode" placeholder="设置邀请码" :disabled="$route.query.numbers ? 'disabled': false">
					</div>
					<div class="mui-input-row title" v-show="zindex == 1">
						<span>分润设置</span>
					</div>
					<div class="mui-input-row" v-for="item in subShere" v-show="zindex == 1">
						<label class="mui-text-justify">{{item.GAME_NAME}}</label>
						<input type="text" class="mui-input-clear" v-model="item.BASE_PERCENT" :placeholder="'可抽取返点：0%-'+item.MY_PERCENT +'%'">
					</div>
				</form>
			</div>
		</div>
		<div class="stiky-footer">
			<div class="btn-con mr-t-10">
				<button class="mui-btn mui-btn-block mui-btn-blue mui-font my-btn">确定</button>
			</div>
		</div>
	</div>
</template>

<script>
	import userapi from '@/api/userUtil';
	export default {
		name: 'createsub',
		data() {
			return {
				AgentCd: 0,
				zindex: 0,
				phoneNum: '',
				password: '',
				InviteCode: '',
				subShere: [{
					"SYS_GAME_LEVEL_CODE_ID": 1,
					"GAME_NAME": "皇冠体育",
					"BASE_PERCENT": '',
					"MY_PERCENT": ''
				}, {
					"SYS_GAME_LEVEL_CODE_ID": 3,
					"GAME_NAME": "真人视讯",
					"BASE_PERCENT": '',
					"MY_PERCENT": ''
				}, {
					"SYS_GAME_LEVEL_CODE_ID": 2,
					"GAME_NAME": "彩票游戏",
					"BASE_PERCENT": '',
					"MY_PERCENT": ''
				}, {
					"SYS_GAME_LEVEL_CODE_ID": 9,
					"GAME_NAME": "电子游艺",
					"BASE_PERCENT": '',
					"MY_PERCENT": ''
				}, {
					"SYS_GAME_LEVEL_CODE_ID": 27,
					"GAME_NAME": "六合彩",
					"BASE_PERCENT": '',
					"MY_PERCENT": ''
				}], //分给下级的分润点数
			}
		},
		created() {
			this.InviteCode = this.$route.query.numbers
			this.GetUpShareCount();
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.navbar').on('tap', '.tab', function() {
					var index = $(this).data('index');
					that.AgentCd = index;
				})

				mui('.nav').on('tap', '.changeRadio', function() {
					var index = $(this).data('zindex');
					that.zindex = index;
				})

				mui('.mui-input-row').on('tap', '.cleartext', function() {
					that.phoneNum = '';
				})
				mui('.btn-con').on('tap', '.my-btn', function() {
					mui(this).button('loading');
					$('.mui-btn-block .mui-spinner').css({
						'width': '18px',
						'height': '18px'
					})
                    that.SubmitButton();
					setTimeout(() => {
						mui(this).button('reset');
					}, 1000)
				})

			})
		},
		methods: {

			GetUpShareCount() {
				var that = this;
				var ID = 0;
				userapi.GetUpShareCount(ID, function(res) {
					var _rows = res;
					var _array = [];
					for(var i = 0; i < that.subShere.length; i++) {
						for(var x = 0; x < _rows.length; x++) {
							if(that.subShere[i].SYS_GAME_LEVEL_CODE_ID == _rows[x].SYS_GAME_LEVEL_CODE_ID) {
								var __obj = {
									BASE_PERCENT: that.subShere[i].BASE_PERCENT,
									GAME_NAME: that.subShere[i].GAME_NAME,
									MY_PERCENT: parseFloat(_rows[x].BASE_PERCENT * 100).toFixed(2),
									SYS_GAME_LEVEL_CODE_ID: that.subShere[i].SYS_GAME_LEVEL_CODE_ID,
								}
								_array.push(__obj)
								break;
							}
						}
					}
					that.subShere = _array
				});
			},
			SubmitButton() {
				var that = this;
				var postdata = {
					PASSWORD: that.PASSWORD,
					MOBILE: that.phoneNum,
				}
				
				if(!that.getCheckWarn()){
					return;
				}
				if(that.zindex == 0) { //邀请码开户
					if(that.InviteCode==null||that.InviteCode==''||that.InviteCode.length!=6||typeof(that.InviteCode)=='undefined'){
							that.$alert('请输入正确邀请码');
							return
					}
					postdata.CODE = parseInt(that.InviteCode)
					
				} else {
					var _data = new Array();
					var isTure = false;
					var base =/^(-?\d+)(\.\d+)?$/;
					for(var i = 0; i < that.subShere.length; i++) {
						that.subShere[i].BASE_PERCENT=that.subShere[i].BASE_PERCENT.replace('%','') ;
						if(!base.test(that.subShere[i].BASE_PERCENT)||that.subShere[i].MY_PERCENT < that.subShere[i].BASE_PERCENT  || that.subShere[i].BASE_PERCENT < 0 || that.subShere[i].BASE_PERCENT == '') {
							that.$alert(that.subShere[i].GAME_NAME+'分润设置出错');
							that.subShere[i].BASE_PERCENT = '';
							isTure = true;
							break;
						}
						var _obj = {
							SYS_GAME_LEVEL_CODE_ID: that.subShere[i].SYS_GAME_LEVEL_CODE_ID,
							GAME_NAME: that.subShere[i].GAME_NAME,
							BASE_PERCENT: that.subShere[i].BASE_PERCENT / 100,
						}
						_data.push(_obj)
					}
					if(isTure){
						return;
					}
					postdata.AGENT_IND = that.AgentCd;
					postdata.jsonParm = JSON.stringify(_data);
				}
				userapi.PostAgentUser(postdata, function(res) {
					if(res.state == 'success') {
						that.$alert('创建成功');
						setTimeout(() => {
							that.$router.push({
								path: '/VipCenter',
							});
						}, 500);
					} else {
						that.$alert(res.message);
					}
				});
			},
			getCheckWarn() {
				var that = this;
				var tel = /^[0-9]*$/; 
			     if(that.phoneNum == "" || that.phoneNum == null) {
					that.$alert('手机号码不能为空');
					return false
				}  else if(!tel.test(that.phoneNum)) {
					that.$alert('请输入纯数字正确的电话号码');
					return false
				}else if(that.password == "" || that.password == null) {
					that.$alert('密码不能为空');
					return false
				} else if(that.password.length < 6) {
					that.$alert('密码长度最低6位');
					return false
				} else{
					return true
				}
			},
		},
		watch: {
			
		}
	}
</script>

<style lang="scss" scoped>
	@import '../../../static/sass/public.scss';
	.stiky-box {
		min-height: 100%;
		padding-bottom: 1.8rem;
	}
	
	.stiky-footer {
		margin-top: -1.8rem;
	}
	
	.navbar {
		padding: 0.16rem 0.24rem;
		display: flex;
		.tableft {
			border-radius: 3px 0 0 3px;
		}
		.tabright {
			border-radius: 0 3px 3px 0;
		}
		a {
			flex: 1;
			background: #fff;
			border: 1px solid $blueColor;
			box-sizing: border-box;
			color: $blueColor;
			text-align: center;
			font-size: 0.28rem;
			padding: 0.19rem 0;
		}
		.active {
			background: $blueColor;
			color: #fff;
		}
	}
	
	.mui-input-group:after {
		display: none;
	}
	
	.cleartext {
		color: $normalFontColor;
		font-size: 0.46rem;
		position: absolute;
		right: 0.3rem;
		top: 0.2rem;
	}
	
	.mui-input-row label {
		padding: 0.15rem 0.24rem;
		width: 25%;
		line-height: inherit;
	}
	
	.mui-input-group .mui-input-row:after {
		left: 0;
	}
	
	.mui-input-row {
		background-color: #fff;
	}
	
	.mui-input-group {
		background: none;
	}
	
	.mui-input-group:before {
		display: none;
	}
	
	.mui-input-group .mui-input-row:after {
		background-color: $bgColor;
	}
	
	.seeting {
		margin-top: 0.16rem;
	}
	
	.mui-input-row label~input {
		float: left;
		padding: 0.15rem 0;
	}
	
	.mar16 {
		margin-bottom: 0.16rem;
	}
	
	.mui-input-row,
	input {
		font-size: 0.28rem;
		color: $importFontColor;
	}
	
	.mr-t-2 {
		margin-top: 2px;
	}
	
	.mr-t-10 {
		margin-top: 0.24rem;
	}
	
	.my-btn {
		width: 91%;
		margin: 0 auto;
		padding: 0.28rem 0;
		font-size: 0.32rem;
		color: #fff;
		background-color: $blueColor;
		border: none;
	}
	
	.nav {
		background: #fff;
		display: flex;
		div {
			flex: 1;
			padding: 0.15rem 0;
			font-size: 0.28rem;
			background: #fff;
			color: $importFontColor;
			position: relative;
		}
		.active {
			color: $blueColor;
			&:after {
				display: block;
				content: '';
				height: 1px;
				background: $blueColor;
				width: 45%;
				position: absolute;
				left: 50%;
				bottom: 0;
				-webkit-transform: translate(-50%, -50%);
				transform: translate(-50%, -50%);
			}
		}
	}
	
	.title {
		margin-top: 0.16rem;
		font-size: 0.32rem;
		padding-top: 0.2rem;
	}
</style>