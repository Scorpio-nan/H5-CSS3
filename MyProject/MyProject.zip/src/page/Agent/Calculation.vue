<template>
	<div class="oddsChart">
		<div class="wrapper">
			<!--头部Tab区块 START-->
			<div class="mui-content">
				<div id="segmentedControl" class="mui-segmented-control mui-segmented-control-inverted mui-segmented-control-primary">
					<a class="mui-control-item mui-active" href="javascript:;" data-type="cpyx">彩票彩票</a>
					<a class="mui-control-item" href="javascript:;" data-type="hk6">香港六合彩</a>
				</div>
				<!--END-->
				<!--中间导航区块START-->
				<div class="mui-content">
					<div class="mui-row">
						<div class="mui-col-sm-6  item">
							<div class="select">
								<a class="mui-navigate-right btn1" v-model='select1'>{{select1}}</a>
							</div>
						</div>
						<div class="mui-col-sm-6 item">
							<div class="select">
								<a class="mui-navigate-right" v-model="select2">{{select2}}</a>
							</div>
						</div>
					</div>
				</div>
				<div>
					<div class="inputBox">
						<input type="text" placeholder="抽取下级的点数( % )" v-model="SheraVal">
						<button class="btn">搜索</button>
					</div>
				</div>
				<!--END-->
				<!--数据区块-->
				<div>
					<div id="item2" class="mui-control-content mui-active">
						<ul class="mui-table-view">
							<li class="mui-table-view-cell">游戏玩法</li>
							<li class="mui-table-view-cell">下级点数</li>
							<li class="mui-table-view-cell">下级赔率</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="table-content">
			<Scroller>
				<table border="0" cellspacing="0" cellpadding="0">
					<tr v-for="(item,index) in initData">
						<td>{{item.NUM}}</td>
						<td>{{SheraVal}}%</td>
						<td>{{item.ODDS1}}</td>
					</tr>
				</table>
			</Scroller>
		</div>
	</div>
</template>

<script>
	import Scroller from '@/components/Scroller';
	import api from '@/api/report';
	export default {
		name: 'Calculation',
		components: {
			Scroller
		},
		data() {
			return {
				dataList: [],
				select1: '北京赛车',
				select2: '冠亚和',
				initData: [],
				SheraVal:'',
				gameType:'cpyx',
				GameID:'',
			}
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {

				//记录类型切换tap事件
				mui('.mui-row').on('tap', '.item', function() {
					const CardPiker = new mui.PopPicker({
						layer: 2
					});
					CardPiker.setData(that.dataList);
					CardPiker.show(function(items) {
						that.select1 = items[0]['text'];
						that.select2 = items[1]['text'];
						that.GameID = items[1]['value'];
						CardPiker.dispose();
					});
				});

				mui('.oddsChart').on('tap', '.mui-control-item', function() {
					var type = $(this).data('type');
					that.gameType = type;
					that.initData = [];
					that.init(type)
				});
				
				//搜索
				mui('.wrapper').on('tap','.btn',function(){
					that.getShareList();
				})
				
			})
		},
		created() {
			const that = this;
			this.init();
		},
		methods: {
			init(type = 'cpyx') {
				const that = this;
				that.dataList = [];
				var param = {
					Code: type
				}
				api.GetLotHk6List(param, (res) => {
					if(res.state == 'error') {
						that.$alert(res.message);
					}
					res.forEach(function(item, index, arr) {
						var obj = {
							value: item['ID'],
							text: item['PARA_NAME'],
							children: []
						}
						var arrs = JSON.parse(item['CHILDREN'])
						for(let i = 0; i < arrs.length; i++) {
							let objects = {
								value: arrs[i].ID,
								text: arrs[i].PARA_NAME
							}
							obj.children.push(objects);
						}
						that.dataList.push(obj);
						that.select1 = that.dataList[0].text;
						that.select2 = that.dataList[0].children[0].text;
						that.GameID = that.dataList[0].children[0].value;
					})
				})
			},
			//获取分润点数
			getShareList(){
				const that = this;
				var reg = /^\d+(\.\d+)?$/;
				if(this.SheraVal == '' || this.SheraVal == null || this.SheraVal == undefined){
					that.$alert('请输给下级的分润点数后计算赔率！');
					return false;
				}
				if(!reg.test(this.SheraVal)){
					that.$alert('请输入正确的分润点数！');
					return false;
				}
				var param = {
					gameId: this.GameID,
					Share: this.SheraVal / 100,
					Code: this.gameType
				}
				api.GetLotHk6OddsList(param,res =>{
					that.initData = res;
				})
			}
		}
	}
</script>
<style scoped lang="scss">
	@import '~static/sass/public.scss';
	.mui-table-view-cell {
		list-style: none;
		background-color: #FFFFFF;
	}

	.oddsChart {
		height: 100%;
		display: flex;
		flex-direction: column;
		.table-content {
			flex: 1;
			position: relative;
			table {
				width: 100%;
				background: #fff;
				tr {
					td {
						font-size: 0.24rem;
						height: 0.8rem;
						@include border-1px(#ccc, bottom);
						width: 20%;
					}
				}
			}
		}
		#item2 {
			@include border-1px(#ccc, bottom);
		}
	}
	
	#segmentedControl {
		display: table;
		width: 100%;
		background: #fff;
		/*margin-bottom:0.2rem;*/
		.mui-control-item {
			display: table-cell;
			height: 0.88rem;
			font-size: 0.28rem;
		}
	}
	
	.mui-row {
		display: flex;
		.item {
			flex: 1;
			padding: 0.16rem 0.24rem;
			.select {
				background: #fff;
				a {
					display: block;
					font-size: 0.28rem;
					padding: 0.16rem 0;
					border: 1px solid $blueColor;
				}
			}
		}
	}
	
	.border-right {
		border-right: 3px solid #eee;
	}
	
	.mui-segmented-control.mui-segmented-control-inverted .mui-control-item.mui-active {
		color: $blueColor;
		border-bottom: 2px solid $blueColor;
	}
	
	.mui-input-group .mui-input-row:after {
		height: 0;
	}
	
	.mui-table-view {
		display: flex;
	}
	
	.mui-table-view li {
		display: inline-block;
		flex: 1;
		text-align: center;
		white-space: nowrap;
		font-size: .3rem;
		color: #000
	}
	
	.mui-table-view:after {
		height: 0;
	}
	
	.mui-table-view:before {
		height: 0;
	}
	
	.mui-table-view-cell:after {
		height: 0;
	}
	
	.inputBox {
		padding: 0 0.24rem;
		display: flex;
		margin-bottom: 0.16rem;
	}
	
	.inputBox input {
		flex: 1;
		float: right;
		border-right: 0;
		border-radius: 0;
		margin: 0;
	}
	
	.inputBox input[type='text'] {
		vertical-align: middle;
		height: .7rem;
		border: 1px solid $blueColor;
		font-size: .28rem;
	}
	
	.inputBox button {
		width: 1.5rem;
		height: .7rem;
		background-color: $blueColor;
		color: #fff;
		border-radius: 0;
		&:active{
			background-color: rgba($blueColor,0.6);
		}
	}
	
	.mui-table-view li {
		font-size: 0.24rem;
		padding: 0.12rem 0;
	}
</style>