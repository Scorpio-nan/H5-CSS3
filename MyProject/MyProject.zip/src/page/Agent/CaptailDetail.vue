<template>
	<div id="BettingRecord">
		<div class="contorl-nav">
			<div id="segmentedControl" class="mui-segmented-control mui-segmented-control-inverted">
				<a class="mui-control-item" :class="index == 0 ? 'mui-active' : ''" href="javascript:;" data-index="0">存款</a>
				<a class="mui-control-item" :class="index == 1 ? 'mui-active' : ''" href="javascript:;" data-index="1">取款</a>
				<a class="mui-control-item" :class="index == 2 ? 'mui-active' : ''" href="javascript:;" data-index="2">赠金返点</a>
				<a class="mui-control-item" :class="index == 3 ? 'mui-active' : ''" href="javascript:;" data-index="3">额度转账</a>
				<a class="mui-control-item other" :class="index == 4 ? 'mui-active' : ''" href="javascript:;" data-index="4">其他</a>
			</div>
		</div>
		<div class="segmented-Select">
			<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="btn mui-btn mui-btn-mini BeginTime mr-r">{{beginTime}}</button>
			<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="btn mui-btn mui-btn-mini EndTime mr-r">{{endTime}}</button>
			<button class="btn mui-btn mui-btn-mini game-type mui-ellipsis">{{btnName}}</button>
		</div>
		<div class="status-Select">
			<a href="javascript:;">时间</a>
			<a href="javascript:;">类型</a>
			<a href="javascript:;">状态</a>
			<a href="javascript:;">金额</a>
		</div>
		<div class="mui-content">
			<div class="nodata" v-show="!dataList">
				当前查询条件下暂无交易记录
			</div>
		</div>
		
	</div>
</template>

<script>
	export default {
		name: 'BettingRecord',
		data() {
			return {
				index: 0,
				beginTime: '2018-03-07',
				endTime: '2018-03-07',
				btnName: '确定筛选',
				dataList:[]
			}
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('#segmentedControl').on('tap', '.mui-control-item', function() {
					var index = $(this).data('index');
					that.index = index;
				})

				mui('.segmented-Select').on('tap', '.BeginTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {
							console.log(res);
						})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.beginTime = res['text'];
						})
					}
				})

				mui('.segmented-Select').on('tap', '.EndTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {
							console.log(res);
						})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.endTime = res['text'];
						})
					}
				})

				mui('.segmented-Select').on('tap', '.game-type', function() {
					console.log('确定筛选')
					
				});

				mui('.contorl-nav').on('tap', '.other', function() {
                	that.$router.push({
                   	 	path: 'Flowdetails'
                	})
           		 })//跳转到流水明细
				
				mui('#segmentedControl').on('tap','a',function(){
						var index = $(this).data('index')
						that.index = index;
						console.log(that.index)
						
						
//						根据index值获取不同的数据
						if(that.index ==4){
//							跳转到资金明细页面
						}


					})
				
				
				

			})
		},
		created() {
			const that = this;
//			$.getJSON('static/json/lotterylist.json', function(res) {
//				res.forEach(function(item, index, arr) {
//					var obj = {
//						value: item['id'],
//						text: item['text'].replace(/\s+/, '')
//					}
//					that.GameList.push(obj);
//				})
//			})
		}
	}
</script>

<style lang="scss" scoped>
	@import '../../../static/sass/public.scss';
	
	
	#segmentedControl{
		display: flex;
	}
	#segmentedControl a{
		flex: 1;
	}
	.mui-segmented-control {
		font-size: 0.28rem;
	}
	
	.contorl-nav {
		padding: 0.1rem 0.2rem 0 0.2rem;
	}
	
	.segmented-Select {
		padding: 0.2rem 0.24rem;
		display: flex;
		.btn {
			background: #eee;
			flex: 1;
		}
		.mr-r {
			margin-right: 0.1rem;
		}
	}
	
	.mui-btn,
	button,
	input[type=button],
	input[type=reset],
	input[type=submit] {
		border: 0 none;
	}
	
	.status-Select {
		padding: 0.12rem 0.24rem;
		display: table;
		width: 100%;
		border-bottom: 1px solid #eee;
		a {
			display: table-cell;
			font-size: 0.28rem;
			color: $assistFontColor;
		}
		.s-active {
			color: #3399ff;
		}
	}
</style>