<template>
	<div class="tabcon">
		<div class="mui-content">
			<div id="slider" class="mui-slider mui-fullscreen">

				<div class="navbar">
					<div class="mui-control-item tab" :class="index == 0? 'active':''" data-index="0">下级会员财务报表</div>
					<div class="mui-control-item tab" :class="index == 1? 'active':''" data-index="1">下级会员投注报表</div>
				</div>

				<div class="slider-box">
					<div class="box" v-show="index == 1">
						<ul class="Betting">
							<li>
								<h3 class="title">皇冠体育</h3>
								<ul>
									<li>投注</li>
									<li>{{'¥ ' +BReportData.SPORT_BET_AMT}}</li>
									<li>盈亏</li>
									<li class="Profit" :class="parseFloat(BReportData.SPORT_WIN_AMT) >= 0 ? 'red': 'green'">¥ {{BReportData.SPORT_WIN_AMT}}</li>
								</ul>
							</li>
							<li>
								<h3 class="title">真人视讯</h3>
								<ul>
									<li>投注</li>
									<li>{{'¥ ' +BReportData.INT_ZBET_AMT}}</li> 
									<li>盈亏</li>
									<li class="Profit" :class="parseFloat(BReportData.INT_ZWIN_AMT) >= 0 ? 'red': 'green'">¥ {{BReportData.INT_ZWIN_AMT}}</li>
								</ul>
							</li>
							<li>
								<h3 class="title">彩票游戏</h3> 
								<ul>
									<li>投注</li>
									<li>{{'¥ ' +BReportData.SSC_BET_AMT}}</li> 
									<li>盈亏</li>
									<li class="Profit" :class="parseFloat(BReportData.SSC_WIN_AMT) >= 0 ? 'red': 'green'">¥ {{BReportData.SSC_WIN_AMT}}</li>
								</ul>
							</li>
							<li>
								<h3 class="title">电子游艺</h3> 
								<ul>
									<li>投注</li>
									<li>{{'¥ ' +BReportData.INT_DBET_AMT}}</li>
									<li>盈亏</li>
									<li class="Profit" :class="parseFloat(BReportData.INT_DWIN_AMT) >= 0 ? 'red': 'green'">¥ {{BReportData.INT_DWIN_AMT}}</li>
								</ul>
							</li>
							<li>
								<h3 class="title">六合彩</h3>
								<ul>
									<li>投注</li>
									<li>{{'¥ ' + BReportData.HK6_BET_AMT}}</li>  
									<li>盈亏</li>
									<li class="Profit" :class="parseFloat(BReportData.HK6_WIN_AMT) >= 0 ? 'red': 'green'">¥ {{BReportData.HK6_WIN_AMT}}</li>
								</ul>
							</li>
							<li>
								<h3 class="title">合计</h3>
								<ul>
									<li>总投注</li>
									<li>{{'¥ ' +BReportData.TOTAL_BET_AMT}}</li>   
									<li>总盈亏</li>
									<li class="Profit" :class="parseFloat(BReportData.TOTAL_WIN_AMT) >= 0 ? 'red': 'green'">¥ {{BReportData.TOTAL_WIN_AMT}}</li>
								</ul>
							</li>
						</ul>
					</div>

					<div class="mui-card box" v-show="index == 0">
						<ul class="mui-table-view mui-table-view-chevron mr-t-8">
							<li class="mui-table-view-cell">
								<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">会员存款
									<p><span class="price">{{FReportData.TOTAL_ONLINE_DEPOSIT_AMT}}</span><span>元</span></p>
								</a>
							</li>
							<li class="mui-table-view-cell">
								<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">会员提款
									<p><span class="price">{{FReportData.TOTAL_DRAW_AMT}}</span><span>元</span></p>
								</a>
							</li>
							<li class="mui-table-view-cell">
								<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">会员返水
									<p><span class="price">{{FReportData.TOTAL_REBATE_AMT}}</span><span>元</span></p>
								</a>
							</li>
							<li class="mui-table-view-cell">
								<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">代理返水
									<p><span class="price">{{FReportData.TOTAL_AGENT_REBATE_AMT}}</span><span>元</span></p>
								</a>
							</li>
							<li class="mui-table-view-cell">
								<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">公司总盈利
									<p><span class="price">{{FReportData.TOTAL_WIN}}</span><span>元</span></p>
								</a>
							</li>
						</ul>
					</div>
				</div>
				<button type="button" class="mui-btn mui-btn-primary search">查询会员</button>

				<Actionsheet :show="show" @hide="onActionhide">
					<div class="mui-card timer" slot="action">
						<ul class="mui-table-view mui-table-view-chevron mr-t-8">
							<li class="mui-table-view-cell btn" data-options='{}'>
								<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">开始日期
									<div class="segmented-Select">
										<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="btn mui-btn mui-btn-block BeginTime mr-r">{{beginTime}}</button>
									</div>
								</a>
							</li>
							<li class="mui-table-view-cell btn" data-options='{}'>
								<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">结束日期
									<div class="segmented-Select">
										<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="btn mui-btn mui-btn-block EndTime mr-r">{{endTime}}</button>
									</div>
								</a>
							</li>
							<li class="mui-table-view-cell">
								<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">会员账号
									<input type="text" class="mui-input-clear" placeholder="请输入会员账号" v-model="user_name">
									
								</a>
							</li>
						</ul>
						<button type="button" class="mui-btn mui-btn-primary Search-btn">立即查询</button>
					</div>
				</Actionsheet>

			</div>
		</div>
	</div>
</template>

<script>
	import agentApi from '@/api/agentUtil'
	import Actionsheet from '@page/Center/template/ActionSheet'
	export default {
		name: 'Center',
		components: {
			Actionsheet
		},
		data() {
			return {
				beginTime: new Date().Format('yyyy-MM-dd'),
				endTime: new Date().Format('yyyy-MM-dd'),
				user_name: '',
				index: 0,
				num: 5000,
				num2: -3000,
				//				change:false,
				show: false,
				FReportData: {
					TOTAL_AGENT_REBATE_AMT: 0,
					TOTAL_DRAW_AMT: 0,
					TOTAL_ONLINE_DEPOSIT_AMT: 0,
					TOTAL_REBATE_AMT: 0,
					TOTAL_WIN: 0,
				},
				BReportData: {
					HK6_BET_AMT: 0,
					HK6_WIN_AMT: 0,
					SSC_BET_AMT: 0,
					SSC_WIN_AMT: 0,
					INT_DBET_AMT: 0,
					INT_DWIN_AMT: 0,
					INT_ZBET_AMT: 0,
					INT_ZWIN_AMT: 0,
					SPORT_BET_AMT: 0,
					SPORT_WIN_AMT: 0,
					TOTAL_BET_AMT: 0,
					TOTAL_WIN_AMT: 0,
				},
			}
		},
		created() {
			this.Init();
		},
		mounted() {
			const that = this;
			mui.init();

			mui.ready(function() {
				// Scroll 区域
				//				mui('.box').scroll({
				//					deceleration: 0.0005
				//				});

				mui('.segmented-Select').on('tap', '.BeginTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {
						})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.beginTime = res['text'];
						})
					}
				})

				mui('.segmented-Select').on('tap', '.EndTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {
						})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.endTime = res['text'];
						})
					}
				})

				mui('.navbar').on('tap', '.tab', function() {
					var index = $(this).data('index');
					that.index = index;
					that.Init();

				})

				mui('.tabcon').on('tap', '.search', function() {
					that.show = !that.show;
					that.user_name='';
					that.beginTime= new Date().Format('yyyy-MM-dd');
				    that.endTime= new Date().Format('yyyy-MM-dd');
				})
				mui('body').on('tap', '#actionsheet', function() {
					that.show = false;
				})
				mui('body').on('tap', '.timer', function() {
					return false;
				})
				mui('.timer').on('tap', '.Search-btn', function() {
					mui(this).button('loading');
					that.show = false;
					that.Init();
					setTimeout(function() {
						mui(this).button('reset');
					}.bind(this), 1000);
					
				})

			})

		},
		computed: {

		},
		methods: {
			Init() {
				var that = this;
				if(that.index == 0) {
					that.loadingDataXUserFReport();
				} else {
					that.loadingDataXUserBReport();
				}
			},
			loadingDataXUserFReport() { //下级财务报表
				var that = this;
				var startime = that.beginTime + " 00:00";
				var endtime = that.endTime + " 23:59";
				var postData = {
					star_time: startime,
					end_time: endtime,
					sord: "Desc",
					sidx: "AGENT_ID",
				};
				if(that.user_name.trim() != '') {
					postData.user_name = that.user_name
				}
				setTimeout(() => {
					agentApi.GetAgentReportList(postData, function(data) {
						if(data.length > 0) {
							that.FReportData = data[0];
							for(var x in that.FReportData) {
								if(that.FReportData[x] == null) {
									that.FReportData[x] = 0;
								}
							}
						}
					});
				}, 100)
			},
			/*获取代理下级会员投注报表*/
			loadingDataXUserBReport() {
				var that = this;
				var startime = that.beginTime + " 00:00";
				var endtime = that.endTime + " 23:59";
				var postData = {
					star_time: startime,
					end_time: endtime,
					sord: "Desc",
					sidx: "AGENT_ID",
				};
				if(that.user_name.trim() != '') {
					postData.user_name = that.user_name
				}
				setTimeout(() => {
					agentApi.GetAgentLowMemberReportList(postData, function(data) {
						if(data.length > 0) {
							that.BReportData = data[0];
							for(var x in that.BReportData) {
								if(that.BReportData[x] == null) {
									that.BReportData[x] = 0;
								}
							}
						}
					});
				}, 100)
			},
			onActionhide() {
				this.show = !this.show;
			}
		}
	}
</script>

<style scoped lang="scss">
	@import '../../../static/sass/public.scss';
	div.mui-content {
		background-color: #fff;
	}
	
	p {
		margin-bottom: 0px;
	}
	
	.mui-slider-indicator.mui-segmented-control {
		padding: 5px 0;
		background: $bgColor;
		.mui-scroll {
			width: 100%;
		}
	}
	
	.box {
		background: #ffffff;
	}
	
	.mui-slider-indicator.mui-segmented-control {
		padding: 0;
	}
	
	.navbar {
		display: flex;
		background: #fff;
		div {
			flex: 1;
			font-size: 0.28rem;
			position: relative;
			line-height: 0.88rem;
		}
		.active {
			color: $blueColor;
			&:after {
				display: block;
				content: '';
				height: 1px;
				background: $blueColor;
				width: 60%;
				position: absolute;
				left: 50%;
				bottom: 0;
				-webkit-transform: translate(-50%, -50%);
				transform: translate(-50%, -50%);
			}
		}
	}
	
	.mui-segmented-control.box {
		height: 50px;
	}
	
	.mui-segmented-control.box .mui-control-item {
		width: 50%;
	}
	
	.mui-segmented-control.box .mui-scroll {
		a {
			position: relative;
		}
		.mui-active {
			color: #158bff;
			&:after {
				display: block;
				content: '';
				height: 1px;
				background: #158bff;
				width: 100%;
				position: absolute;
				left: 0;
				bottom: 0;
			}
		}
	}
	
	.slider-box .box {
		margin-top: 0.16rem;
	}
	
	.mui-table-view-cell {
		p {
			float: right;
		}
	}
	
	.mui-navigate-right:after,
	.mui-push-right:after {
		content: ''
	}
	
	.mui-table-view-cell>a:not(.mui-btn) {
		padding-right: 15px;
	}
	
	.mui-card {
		margin: 0;
	}
	
	.mui-table-view-cell:after {
		left: 0;
	}
	
	.mui-btn-primary {
		width: 95%;
		height: 0.88rem;
		font-size: 0.32rem;
		background: $blueColor;
		border: 0;
	}
	
	.search {
		margin-top: 0.88rem;
	}
	
	.timer {
		padding-top: 0.88rem;
		padding-bottom: 0.24rem;
		box-shadow: none;
		background: $bgColor;
		a {
			padding: 0 0 0 0.15rem;
		}
		.mui-table-view-cell:after {
			content: '';
			height: 0;
		}
		/*.mui-btn-primary {
			width: 95%;
			height: 0.88rem;
			font-size:0.32rem;
			background: $blueColor;
			border:0;
		}*/
		.segmented-Select {
			display: inline-block;
			button {
				font-size: 0.24rem;
				padding: 0.2rem 2rem;
				border: none;
				margin: 0;
			}
		}
		.mui-input-clear {
			border: none;
			padding-left: 2rem;
			font-size: 0.24rem;
			margin: 0;
		}
	}
	
	.Betting {
		overflow: hidden;
		li {
			width: 50%;
			background: #fff;
			padding: 0.36rem 0.24rem;
			box-sizing: border-box;
			border-right: 1px solid $bgColor;
			border-bottom: 1px solid $bgColor;
			float: left;
			.title {
				font-weight: normal;
				text-align: left;
				padding-bottom: 0.24rem;
				font-size: 0.28rem;
			}
			li {
				text-align: left;
				font-size: 0.24rem;
				padding: 0;
				border: none;
			}
			.red {
				color: $warnColor
			}
			.green {
				color: #4cbe00;
			}
			li:nth-child(2n) {
				padding-left: 0.2rem;
			}
		}
		li:nth-child(2n) {
			border-right: none;
		}
	}
	
	.box {
		background: $bgColor;
	}
	
	.scle-enter-active {
		animation: scle-in .35s;
		transform-origin: 300% 0%;
	}
	
	.scle-leave-active {
		animation: scle-out .35s;
		transform-origin: 0 0;
	}
	
	@keyframes scle-in {
		from {
			transform: scale3d(0, 0, 0) translate(-50%, -50%);
			opacity: 0;
		}
		to {
			transform: scale3d(1, 1, 1) translate(-50%, -50%);
			opacity: 1
		}
	}
	
	@keyframes scle-out {
		from {
			transform: scale3d(1, 1, 1) translate(-50%, -50%);
			opacity: 1
		}
		to {
			transform: scale3d(0, 0, 0) translate(-50%, -50%);
			opacity: 0;
		}
	}
</style>