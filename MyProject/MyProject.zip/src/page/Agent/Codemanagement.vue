<template>
	<div id="Account">
		<div class="stiky-box">
			<div class="main">
				<nav class="navbar">
					<a href="javascript:;" class="mui-text-center tab tableft" :class="index == 0? 'active':''" data-index="0">添加邀请码</a>
					<a href="javascript:;" class="mui-text-center tab tabright" :class="index == 1? 'active':''" data-index="1">邀请码管理</a>
				</nav>
				<div class="mui-input-row mar16">
					<nav class="nav">
						<div class="mui-input-row mui-radio mui-left changeRadio" data-zindex="0" :class="zindex == 0? 'active':''">
							会员
						</div>
						<div class="mui-input-row mui-radio mui-left changeRadio" data-zindex="1" :class="zindex == 1? 'active':''">
							代理
						</div>
					</nav>
				</div>
				<form class="mui-input-group mr-t-2 animated" :class="index == 0 ? 'fadeIn':''" v-show="index == 0">
					<div class="mui-input-row" v-for="item in subShere">
						<label class="mui-text-justify">{{item.GAME_NAME}}</label>
						<input type="number" class="mui-input-clear" v-model="item.BASE_PERCENT" :placeholder="'可抽取返点：0%~'+item.MY_PERCENT +'%'" oninput='this.value = this.value.replace(/\D+\./g, "")'>
					</div>
				</form>

				<form class="mui-input-group mr-t-2 animated" :class="index == 1 ? 'fadeIn':''" v-show="index == 1">
					<ul class="table-header">
						<li>邀请码</li>
						<li>生成时间</li>
						<li>创建</li>
					</ul>
					<ul class="table-header table-tr" v-for="(item,nm) in CodeList">
						<li class="number" :data-item="JSON.stringify(item)">
							<a href="#">{{('00000000'+item.ID).substr( -6 )}}</a>
						</li>
						<li>{{item.CREATE_DTT}}</li>
						<li class="register" :data-num="('00000000'+item.ID).substr( -6 )">注册（{{item.USE_NUM}}）</li>
					</ul>
				</form>
			</div>
		</div>

		<div class="stiky-footer">
			<div class="btn-con mr-t-10" v-show="index == 0">
				<button class="mui-btn mui-btn-block mui-btn-blue mui-font my-btn">生成邀请码</button>
			</div>
		</div>
		<Actionsheet :show="show" @hide="onActionhide">
			<div class="picture" slot="action">
				<ul class="mui-table-view">
					<li class="mui-table-view-cell look">
						<a href="#">查看返点</a>
					</li>
					<li class="mui-table-view-cell remove">
						<a href="#">删除邀请码</a>
					</li>
				</ul>
				<ul class="mui-table-view">
					<li class="mui-table-view-cell close">
						<a href="#"><b>取消</b></a>
					</li>
				</ul>
			</div>
		</Actionsheet>
		<div class="Mask" v-show="alert">
			<transition name="scle">
				<div class="alert" v-show="alert">
					<ul>
						<li>
							<p>真人</p>
							<p>{{(ZR_SHARE_RATE*100).toFixed(2)}}%</p>
						</li>
						<li>
							<p>电子</p>
							<p>{{(DZ_SHARE_RATE*100).toFixed(2)}}%</p>
						</li>
						<li>
							<p>体育</p>
							<p>{{(PE_SHARE_RATE*100).toFixed(2)}}%</p>
						</li>
						<li>
							<p>彩票</p>
							<p>{{(CP_SHARE_RATE*100).toFixed(2)}}%</p>
						</li>
						<li>
							<p>香港六合彩</p>
							<p>{{(HK6_SHARE_RATE*100).toFixed(2)}}%</p>
						</li>
					</ul>
				</div>
			</transition>

		</div>

	</div>
</template>

<script>
	import Actionsheet from '@page/Center/template/ActionSheet'
	import userapi from '@/api/userUtil';
	import Scroller from '@/components/Scroller'
	export default {
		name: 'Account',
		components: {
			Actionsheet
		},
		data() {
			return {
				index: 0,
				zindex: 0,
				show: false,
				alert: false,
				CodeList: '',
				CodeId: '',
				subShere: [{
					"SYS_GAME_LEVEL_CODE_ID": 1,
					"GAME_NAME": "皇冠体育",
					"BASE_PERCENT": '',
					"MY_PERCENT": ''
				}, {
					"SYS_GAME_LEVEL_CODE_ID": 3,
					"GAME_NAME": "真人视讯",
					"BASE_PERCENT": '',
					"MY_PERCENT": ''
				}, {
					"SYS_GAME_LEVEL_CODE_ID": 2,
					"GAME_NAME": "彩票游戏",
					"BASE_PERCENT": '',
					"MY_PERCENT": ''
				}, {
					"SYS_GAME_LEVEL_CODE_ID": 9,
					"GAME_NAME": "电子游艺",
					"BASE_PERCENT": '',
					"MY_PERCENT": ''
				}, {
					"SYS_GAME_LEVEL_CODE_ID": 27,
					"GAME_NAME": "六合彩",
					"BASE_PERCENT": '',
					"MY_PERCENT": ''
				}], //分给下级的分润点数
				CP_SHARE_RATE: 0,
				DZ_SHARE_RATE: 0,
				HK6_SHARE_RATE: 0,
				PE_SHARE_RATE: 0,
				ZR_SHARE_RATE: 0,
			}
		},
		created() {
			this.GetUpShareCount();
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.navbar').on('tap', '.tab', function() {
					var index = $(this).data('index');
					that.index = index;
					that.clean();
					that.GetUserInviteCodeList();
				})

				mui('.nav').on('tap', '.changeRadio', function() {
					var index = $(this).data('zindex');
					that.zindex = index;
					that.GetUserInviteCodeList();
				})

				mui('.mui-input-group').on('tap', '.number', function() {
					var item = $(this).data('item');
					that.CodeId = item.ID;
					that.CP_SHARE_RATE = item.CP_SHARE_RATE;
					that.DZ_SHARE_RATE = item.DZ_SHARE_RATE;
					that.HK6_SHARE_RATE = item.HK6_SHARE_RATE;
					that.PE_SHARE_RATE = item.PE_SHARE_RATE;
					that.ZR_SHARE_RATE = item.ZR_SHARE_RATE;
					that.show = !that.show;
				})

				mui('body').on('tap', '.Mask', function() {
					that.alert = false;
				})
				mui('.Mask').on('tap', '.alert', function() {
					return false;
				})

				mui('.picture').on('tap', '.look', function() {
					that.show = false
					that.alert = true;
				}) //点击查看返点
				
				mui('.picture').on('tap', '.remove', function() {
					that.show = false;
					var arr = ['取消', '确认'];
					that.$confirm('确定删除该邀请码？', '温馨提示', arr, function(e) {
						if(e.index == 1) {
							that.OnDelete();
						}
					})
				}) //点击删除邀请码
				
				mui('.picture').on('tap', '.close', function() {
					that.show = false;
				}) //点击取消遮罩层

				mui('.btn-con').on('tap', '.my-btn', function() { //点击生成邀请码
					mui(this).button('loading');
					that.SubmitButton();
					setTimeout(() => {
						mui(this).button('reset');
					}, 1000)
				})

				mui('.mui-input-group').on('tap', '.register', function() {
					var path = $(this).data('path');
					var num = $(this).data('num');

					that.$router.push({
						path: 'Createsubordinate',
						query: {
							numbers: num
						}
					})
				}) //点击注册跳转到创建下级页面

			})
		},
		methods: {
			OnDelete() {
				var that = this;
				let postdata = {
					keyValue: that.CodeId
				}
				userapi.GetDelUserInviteCode(postdata, function(res) {
					if(res.state == "success") {
						that.$alert('删除成功');
						that.CodeList = that.CodeList.filter(function(x) {
							return x.ID != that.CodeId
						})
					} else {
						that.$alert(res.message);
					}
				})
			},
			clean() {
				var that = this;
				for(var i = 0; i < that.subShere.length; i++) {
					that.subShere[i].BASE_PERCENT = '';
				}
			},
			GetUserInviteCodeList() { //获取邀请码详情
				var that = this;
				if(that.index == 0) { //添加邀请码界面无需操作
					return
				}
				var postData = {
					IS_PROXY: that.zindex,
					rows: 1000,
					page: 1,
					sidx: 'ID',
					sord: 'DESC'
				};
				userapi.GetUserInviteCodeList(postData, function(res) {
					that.CodeList = res.rows;
				});
			},

			GetUpShareCount() { //获取分润基数；
				var that = this;
				var ID = 0;
				userapi.GetUpShareCount(ID, function(res) {
					var _rows = res;
					var _array = [];
					for(var i = 0; i < that.subShere.length; i++) {
						for(var x = 0; x < _rows.length; x++) {
							if(that.subShere[i].SYS_GAME_LEVEL_CODE_ID == _rows[x].SYS_GAME_LEVEL_CODE_ID) {
								var __obj = {
									BASE_PERCENT: that.subShere[i].BASE_PERCENT,
									GAME_NAME: that.subShere[i].GAME_NAME,
									MY_PERCENT: parseFloat(_rows[x].BASE_PERCENT * 100).toFixed(2),
									SYS_GAME_LEVEL_CODE_ID: that.subShere[i].SYS_GAME_LEVEL_CODE_ID,
								}
								_array.push(__obj)
								break;
							}
						}
					}
					that.subShere = _array
				});
			},
			SubmitButton() { //提交申请邀请码
				var that = this;
				var postdata = {
					IS_PROXY: that.zindex,
					ZR_SHARE_RATE: 0,
					DZ_SHARE_RATE: 0,
					PE_SHARE_RATE: 0,
					CP_SHARE_RATE: 0,
					HK6_SHARE_RATE: 0,
				};
				var isTure = false;
				var base = /^(-?\d+)(\.\d+)?$/;
				for(var i = 0; i < that.subShere.length; i++) {
					that.subShere[i].BASE_PERCENT = that.subShere[i].BASE_PERCENT.replace('%', '');
					if(that.subShere[i].BASE_PERCENT == ''){
						that.$alert(that.subShere[i].GAME_NAME + '抽取点数不能为空');
						return false
					}

					if(!base.test(that.subShere[i].BASE_PERCENT) || that.subShere[i].MY_PERCENT < that.subShere[i].BASE_PERCENT || that.subShere[i].BASE_PERCENT < 0 || that.subShere[i].BASE_PERCENT == '') {
						that.$alert(that.subShere[i].GAME_NAME + '抽取点数出错');
						that.subShere[i].BASE_PERCENT = '';
						isTure = true;
						break;
					}
					if(that.subShere[i].SYS_GAME_LEVEL_CODE_ID == 1) {
						postdata.PE_SHARE_RATE = that.subShere[i].BASE_PERCENT / 100
					} else if(that.subShere[i].SYS_GAME_LEVEL_CODE_ID == 2) {
						postdata.CP_SHARE_RATE = that.subShere[i].BASE_PERCENT / 100
					} else if(that.subShere[i].SYS_GAME_LEVEL_CODE_ID == 3) {
						postdata.ZR_SHARE_RATE = that.subShere[i].BASE_PERCENT / 100
					} else if(that.subShere[i].SYS_GAME_LEVEL_CODE_ID == 9) {
						postdata.DZ_SHARE_RATE = that.subShere[i].BASE_PERCENT / 100
					} else if(that.subShere[i].SYS_GAME_LEVEL_CODE_ID == 27) {
						postdata.HK6_SHARE_RATE = that.subShere[i].BASE_PERCENT / 100
					}
				}
				if(isTure) {
					return;
				}
				userapi.PostModifyUserInviteCode(postdata, function(res) {
					if(res.state == "success") {
						that.$alert('生成成功');
						that.index = 1;
						that.GetUserInviteCodeList();

					} else {
						that.$alert(res.message);
					}
				});
			},

			onActionhide() {
				this.show = !this.show;
			}
		},
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.mui-input-row,
	input {
		font-size: 0.28rem;
		color: $normalFontColor;
	}
	
	.mr-t-2 {
		margin-top: 2px;
	}
	
	.mui-input-row {
		.nav {
			background: #fff;
		}
	}
	
	.mr-t-10 {
		margin-top: 0.24rem;
	}
	
	.stiky-box {
		min-height: 100%;
		padding-bottom: 1.8rem;
	}
	
	.stiky-footer {
		margin-top: -1.8rem;
	}
	
	.number {
		a {
			color: $blueColor;
			text-decoration: underline;
		}
	}
	
	.Mask {
		background: rgba(0, 0, 0, 0.3);
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		.alert {
			width: 80%;
			background: #fff;
			border-radius: 3px;
			position: absolute;
			left: 50%;
			top: 50%;
			transform: translate(-50%, -50%);
			ul {
				li {
					overflow: hidden;
					padding: 0.2rem;
					p {
						float: left;
						width: 50%;
						text-align: left;
					}
				}
			}
		}
	}
	
	.picture {
		.mui-table-view-cell:after {
			display: none;
		}
		ul {
			font-size: 0.28rem;
		}
		ul:nth-child(1) {
			li:nth-child(2) {
				border-top: 2px solid $bgColor;
			}
		}
		ul:nth-child(2) {
			margin-top: 0.24rem;
			font-weight: normal;
			color: $warnColor;
		}
	}
	
	.table-header {
		font-size: 0.24rem;
		color: #666;
		display: flex;
		overflow: hidden;
		margin-top: 0.16rem;
		@include border-1px(#ccc, bottom);
		li {
			float: left;
			line-height: 0.66rem;
			text-align: center;
		}
		li:nth-child(1) {
			width: 20%;
		}
		li:nth-child(2) {
			width: 50%;
		}
		li:nth-child(3) {
			width: 30%;
		}
	}
	
	.table-tr {
		margin-top: 0;
		li {
			line-height: 0.88rem;
		}
	}
	
	.my-btn {
		width: 91%;
		margin: 0 auto;
		padding: 0.28rem 0;
		font-size: 0.32rem;
		color: #fff;
		background-color: $blueColor;
		border: none;
	}
	
	.mui-input-group:before {
		display: none;
	}
	
	.mui-input-group .mui-input-row:after {
		left: 0;
	}
	
	.navbar {
		padding: 0.16rem 0.24rem;
		display: flex;
		.tableft {
			border-radius: 3px 0 0 3px;
		}
		.tabright {
			border-radius: 0 3px 3px 0;
		}
		a {
			flex: 1;
			background: #fff;
			border: 1px solid $blueColor;
			box-sizing: border-box;
			color: $blueColor;
			text-align: center;
			font-size: 0.28rem;
			padding: 0.19rem 0;
		}
		.active {
			background: $blueColor;
			color: #fff;
		}
	}
	
	.nav {
		background: #fff;
		display: flex;
		div {
			flex: 1;
			padding: 0.15rem 0;
			font-size: 0.28rem;
			background: #fff;
			color: $importFontColor;
			position: relative;
		}
		.active {
			color: $blueColor;
			&:after {
				display: block;
				content: '';
				height: 1px;
				background: $blueColor;
				width: 45%;
				position: absolute;
				left: 50%;
				bottom: 0;
				-webkit-transform: translate(-50%, -50%);
				transform: translate(-50%, -50%);
			}
		}
	}
	
	.scle-enter-active {
		animation: scle-in .35s;
		transform-origin: 0 0;
	}
	
	.scle-leave-active {
		animation: scle-out .35s;
		transform-origin: 0 0;
	}
	
	@keyframes scle-in {
		from {
			transform: scale3d(0, 0, 0) translate(-50%, -50%);
		}
		to {
			transform: scale3d(1, 1, 1) translate(-50%, -50%);
		}
	}
	
	@keyframes scle-out {
		from {
			transform: scale3d(1, 1, 1) translate(-50%, -50%);
		}
		to {
			transform: scale3d(0, 0, 0) translate(-50%, -50%);
		}
	}
	
	.mui-input-group {
		background: $whiteColor;
	}
</style>