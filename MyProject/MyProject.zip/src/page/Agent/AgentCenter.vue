<template>
	<div id="AgentCenter">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="Agent-text">
					<img src="static/img/public/agentcenter.png"/>
				</div>
				<div class="Income-Details">
					<ul class="mui-table-view mui-table-view-chevron mr-t-8">
						<li class="mui-table-view-cell">
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">今日收益<span class="user-count">0.00</span>元<i class="mui-pull-right tips">查看详情</i></a>
						</li>
					</ul>
				</div>
				<div class="mui-table-view mr-t-8">
					<ul class="flex-box">
						<li class="list-font border-right border-bottom mui-text-left">
							<a href="javascript:;" class="mui-text-left list-font">下级代理  <span id="subAgent">12</span>人</a>
							<!--<span class="mui-icon mui-icon-forward"> </span>-->
						</li>
						<li class="list-font border-bottom mui-text-left">
							<a href="javascript:;" class="mui-text-left list-font">下级会员  <span id="subVip">20</span>人</a>
							<!--<span class="mui-icon mui-icon-forward"> </span>-->
						</li>
					</ul>
				</div>
				<div class="mui-content">
			        <ul>
			            <li class="subopen">
			            	<a href="#">
		                    	<span class="iconfont icon-icon-62"></span>
		                    	<div class="mui-media-body">下级开户</div>
		                    	<p>&nbsp;</p>
			            	</a>
			            </li>
			            <li class="sublist">
			            	<a href="#">
		                    	<span class="iconfont icon-icon-61"></span>
		                    	<div class="mui-media-body">下级列表</div>
		                    	<p>查询下级人数</p>
			            	</a>
			            </li>
			            <li class="subfinance">
			            	<a href="#">
		                    	<span class="iconfont icon-icon-64"></span>
		                    	<div class="mui-media-body">下级财务</div>
		                    	<p>查询会员财务流水</p>
			            	</a>
			            </li>
			            <li class="invite">
			            	<a href="#">
		                    	<span class="iconfont icon-icon-65"></span>
		                    	<div class="mui-media-body">邀请码管理</div>
		                    	<p>邀请码开户</p>
			            	</a>
			            </li>
			            <li class="subreports">
			            	<a href="#">
		                    	<span class="iconfont icon-icon-63"></span>
		                    	<div class="mui-media-body">下级报表</div>
		                    	<p>查询下级人数</p>
			            	</a>
			            </li>
			            <li class="calculation">
			            	<a href="#">
		                    	<span class="iconfont icon-icon-67"></span>
		                    	<div class="mui-media-body">赔率计算</div>
		                    	<p>查询会员财务流水</p>
			            	</a>
			            </li>
			            <li class="subfrom">
			            	<a href="#">
		                    	<span class="iconfont icon-icon-66"></span>
		                    	<div class="mui-media-body">下级注单</div>
		                    	<p>邀请码开户</p>
			            	</a>
			            </li>
			        </ul> 
				</div>
				
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: 'Center',
		data() {
			return {
				
			}
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				// Scroll 区域
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				
				mui('.mui-scroll').on('tap','.Income-Details',function(){
					that.$router.push({
						path:'/MyEarnings'
					})
				})//今日收益路由
				mui('.mui-scroll').on('tap','.subopen',function(){
					var path = $(this).data('path');
					that.$router.push({
						path:'Createsubordinate'
					})
				})//下级开户
				mui('.mui-scroll').on('tap','.sublist',function(){
					var path = $(this).data('path');
					that.$router.push({
						path:'/VipCenter'
					})
				})//下级列表
				mui('.mui-scroll').on('tap','.invite',function(){
					var path = $(this).data('path');
					that.$router.push({
						path:'Codemanagement'
					})
				})//邀请码
				mui('.mui-scroll').on('tap','.subfinance',function(){
					var path = $(this).data('path');
					that.$router.push({
						path:'SubFinance'
					})
				})//下级财务
				mui('.mui-scroll').on('tap','.subreports',function(){
					var path = $(this).data('path');
					that.$router.push({
						path:'Subreports'
					})
				})//下级报表
				mui('.mui-scroll').on('tap','.calculation',function(){
					var path = $(this).data('path');
					that.$router.push({
						path:'/Calculation'
					})
				})//赔率计算
				mui('.mui-scroll').on('tap','.subfrom',function(){
					var path = $(this).data('path');
					that.$router.push({
						path:'/AgentBetDetail'
					})
				})//下级注单
				
				
			})
		}
	}
</script>

<style scoped lang="scss">
	@import '../../../static/sass/public.scss';
	.mr-t-8{
		margin-top: 0.2rem;
	}
	.mui-scroll{
		background: $bgColor;
	}
	.mui-table-view-cell>a:not(.mui-btn).mui-active{
		background: $titleBgColor;
	}
	.mui-content>.mui-table-view:first-child{
		margin-top:0.2rem;
	}
	.user-count{
		color: $warnColor;
	}
	.tranparentChild{
		background: $titleBgColor;
		li{
			&:after{
				display: none;
			}
		}
		&:before{
			display: none;
		}
	}
	.tips{
		font-size: 0.22rem;
		color: $assistFontColor;
	}
	.border-right,{
		border-right: 1px solid #eee;
	}
	.border-bottom{
		border-bottom: 1px solid #eee;
	}
	.mui-right-icon{
		position: relative;
		&:after{
			display: block;
			content: '\e583';
			font-family: Muiicons;
		    font-size: inherit;
		    line-height: 1;
		    position: absolute;
		    top: 50%;
		    display: inline-block;
		    -webkit-transform: translateY(-50%);
		    transform: translateY(-50%);
		    text-decoration: none;
		    color: #bbb;
		    -webkit-font-smoothing: antialiased;
		    right: 38px;
		}
	}
	#AgentCenter {
		width: 100%;
		height: 100%;
		.padding{
			padding: 0.1rem 0;
		}
		.Agent-text{
			/*background:#fff;
			padding:16px;
			
			p:nth-child(1){
				color: $tipsFontColor;
			}
			p:nth-child(2){
				color: $importFontColor;
				font-size: 17px;
			}
			p:nth-child(3){
				color: $normalFontColor;
			}*/
			img{
				width: 100%;
				height: auto;
			}
			
		}
		.Income-Details{			
			.mui-icon-email{
				font-size: 0.36rem;
			}
		}
		.mui-table-view{
			
			.mui-icon-forward{
				float: right;
				color: $assistFontColor;
			}
		}
		
		.mui-content{
			
			ul{
				background: #fff;
				overflow: hidden;
				margin-top: 0.2rem;
				li{
					float: left;
					width: 33.3%;
					/*height: 1.6rem;*/
					border-right: 1px solid #EEEEEE;
					border-bottom:1px solid #EEEEEE;
					padding: 0.2rem 0;
					.mui-media-body{
						color: $importFontColor;
						font-size:0.28rem;
					}
					p{
						font-size: 0.24rem;
						color: $assistFontColor;
					}
				}
			}
		}
		.user-count{
			font-size: 0.3rem;
			padding: 0 5px;
			color: $warnColor;
		}
		.list-font{
			font-size: 0.28rem;
			color: $normalFontColor;
		}
		.flex-box{
			display: flex;
			li{
				flex: 1;
				padding: 0.2rem 0.24rem;
				&:active{
					background: #f2f2f2;
				}
			}
		}

	}
	.mui-table-view-chevron .mui-table-view-cell>a:not(.mui-btn){
		margin-right: -95px;
	}
	.mui-navigate-right:after, .mui-push-right:after{
		right: 40px;
	}
	.mui-table-view:before{
		background: none;
	}
	.mui-table-view:after{
		background: none;
	}
	.iconfont{
		font-size: 0.46rem;
		color: #19B4F5;
	}
</style>