<template>
  <div class="SearchRebates">
    <!--MUI的滚动模块 START-->
    <header class="mui-bar mui-bar-nav">
      <div>
        <div id="segmentedControl"
             class="mui-segmented-control mui-segmented-control-inverted mui-segmented-control-primary">
          <a class="mui-control-item  mui-active" href="#item2">添加邀请码</a>
          <a class="mui-control-item" href="#item3">邀请码管理</a>
        </div>
      </div>
    </header>
    <scroll>
      <div class="mui-content">
        <div class="flex-container">
          <!--头部导航 添加邀请码区块 START-->
          <div id="item2" class="mui-control-content mui-active">
            <ul class="mui-table-view">
              <li class="mui-table-view-cell">
                <div class="mui-content-padded buttonBox">
                  <button type="button" class="mui-btn mui-btn-primary mui-btn-block">返点赔率表</button>
                  <button type="button" class="mui-btn mui-btn-success mui-btn-block">生成邀请码</button>
                </div>
              </li>
            </ul>
          </div>
          <!--END-->
          <!--tab邀请码管理区块的数据部分 类型、代理、会员） START-->
          <div id="item3" class="mui-control-content">
            <div class="SearchRebates-item">
              <div class="item-one lineH">
                <div class="mui-input-row mui-radio mui-left">
                  <label>类型</label>
                </div>
              </div>
              <div class="item-two lineH">
                <div class="mui-input-row mui-radio mui-left">
                  <label>代理</label>
                  <input name="radio1" type="radio" checked="">
                </div>
              </div>
              <div class="item-two lineH">
                <div class="mui-input-row mui-radio mui-left">
                  <label>会员</label>
                  <input name="radio1" type="radio" checked="">
                </div>
              </div>
            </div>
            <!--END-->
            <ul class="mui-table-view">
              <li class="mui-table-view-cell clearBorder">
                <span class="id">邀请码</span>
                <span>生成时间</span>
                <span>创建</span>
              </li>
            </ul>
            <!--END-->
            <!--邀请码、生成时间、创建数据导入部分 START-->
            <!--判断数据的长度 不然会报错Cannot read property 'list' of undefined"-->
            <div>
              <ul class="mui-table-view flex" v-if="dataList.length">
                <!-- 遍历数据然后导入区块 -> data ->dataList:[]-->
                <li class="mui-table-view-cell" v-for="item in dataList[0].list" :key="item.index">
                  <span>{{item.code}}</span>
                  <span>{{item.time}}</span>
                  <span>注册（{{item.created}}）</span>
                </li>
              </ul>
              <!--END-->
              <!--底部数据部分-->
              <!--判断数据的长度 不然会报错Cannot read property 'list' of undefined"-->
              <div class="fixedBottom" v-if="dataList1.length">
                <!-- 遍历数据然后导入区块 -> data ->dataList:[]-->
                <ul v-for="(item, index) in dataList1[0].list" :key="index">
                  <li>{{item.name}}：</li>
                  <li>{{item.mount}}%</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </scroll>
  </div>
</template>

<script>
  import Scroll from './scroll.vue'

  export default {
    name: "SearchRebates",
    data() {
      return {
        dataList: [], //把接收到的数据导入到空数组
        dataList1: [],
        isShow: false
      }
    },
    created() {
      //接收数据 START
      const _this = this;
      $.getJSON('static/json/temp/Ace/AceMooc.json', function (res) {
        _this.dataList = res //把数据导入到这个dataList数组里面
        console.log(_this.dataList)
      })

      $.getJSON('static/json/temp/Ace/1.json', function (res) {
        _this.dataList1 = res //把数据导入到这个dataList数组里面
        console.log(_this.dataList1)
      })
      //END
    },
    methods: {},
    components: {
      Scroll
    }
  }
</script>

<style scoped type="text/css" lang="scss">
  @import '~static/sass/public.scss';
  @import '~static/sass/default.scss';

  * {
    width: 100%;
    color: #000;
    background-color: #f2f2f2;
  }

  /* 让MUIscroll页面滚动生效 */
  .SearchRebates {
    position: relative;
    width: 100%;
    height: 100%;
  }

  /* 顶部tab导航（添加邀请码、邀请码管理） */
  .mui-control-item {
    width: 100%;
    height: 1rem;
    line-height: 1rem;
  }

  .mui-segmented-control.mui-segmented-control-inverted .mui-control-item.mui-active {
    color: #000;
    border-bottom-color: #999
  }

  /* 类型选择的样式 */
  .SearchRebates-item {
    display: flex;
  }

  .lineH {
    flex: 1;
    height: .90rem;
    line-height: .90rem;
  }

  .mui-checkbox.mui-left input[type=checkbox], .mui-radio.mui-left input[type=radio] {
    margin-top: .12rem;
    font-size: .28rem;
  }

  .mui-checkbox input[type=checkbox]:checked:before, .mui-radio input[type=radio]:checked:before {
    color: #000000;
  }

  .mui-checkbox.mui-left label, .mui-radio.mui-left label {
    font-size: .28rem;
  }

  .mui-checkbox.mui-left label, .mui-radio.mui-left label {
    padding-left: .2rem;
    background-color: #fff
  }

  .mui-table-view:before {
    height: 0;
  }

  .clearBorder {
    margin-top: .08rem !important;
  }

  .SearchRebates-item {
    background-color: #fff
  }

  .mui-table-view-cell {
    display: flex;
    margin-top: 0.04rem;
    width: 100%;
    white-space: nowrap;
    font-size: .12rem;
    margin-top: 0.08rem;
    background-color: #fff
  }

  .mui-table-view-cell:nth-child(1) {
    margin-top: 0.04rem;
  }

  .mui-table-view-cell span {
    flex: 1;
    background-color: #fff;
  }

  .mui-table-view:after {
    height: 0;
  }

  .mui-table-view-cell:after {
    height: 0px;
    left: 0;
  }

  .mui-table-view {
    background-color: #f2f2f2;
  }

  .flex .mui-table-view-cell:after {
    height: 1px;
  }

  .fixedBottom {
    width: auto;
    margin: .2rem 1.88rem;
    background-color: #fff;
    font-size: .12rem;
    padding: .30rem .30rem;
    margin-bottom: 1.2rem;
  }

  .fixedBottom ul {
    display: flex;
    margin: .04rem 0;
    margin-left: 0.28rem;
    background-color: #fff;
  }

  .fixedBottom li {
    text-align: left;
    background-color: #fff;
  }

  .mui-bar-nav {
    height: auto;
  }

  .mui-bar .mui-segmented-control {
    top: 0
  }

  .flex-container {
    margin-top: .3rem;
  }

  .buttonBox {
    margin-top: 2rem;
  }

  #item3 {
    margin-top:1rem;
  }

  .mui-bar-nav {
    box-shadow: none;
  }

</style>
