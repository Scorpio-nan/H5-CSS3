<template>
	<div id="SearchRecond">
		<form class="mui-input-group">
		    <div class="mui-input-row searchBar" >
		        <label>记录类型</label>
		    	<input type="text" class="mui-input-clear recordtype" v-model="recordType" placeholder='请选择记录类型'>	
		    </div>
		    <div class="mui-input-row searchBar" >
		        <label>时间范围</label>
		        <input type="text" class="mui-input-password timetype" v-model="timeselect" placeholder="请选择时间范围">
		    </div>
		</form>
		<div class="cen_conet">
			<button type="button" class="mui-btn mui-btn-lg mui-btn-primary click_onck btn">查询</button>
		</div>
	</div>
</template>

<script>
	export default{
		name:'SearchRecord',
		data(){
			return {
				typeList:[],
				timeList:[],
				recordType:'彩票游戏',
				timeselect:'一个月'
			}
		},
		mounted(){
			const that = this;
			mui.init();
			mui.ready(function(){
				
//				记录类型切换tap事件
				mui('.searchBar').on('tap', '.recordtype', function() {
					console.log('记录类型')
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.typeList);
					CardPiker.show(function(items) {
						that.recordType = items[0]['text'];
					});
				});
				
				
//				时间范围选择tap事件
				mui('.searchBar').on('tap', '.timetype', function() {
					console.log('时间类型')
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.timeList);
					CardPiker.show(function(items) {
						that.timeselect = items[0]['text'];
					});
				});
				//			点击确定查询,发送请求
				mui('.cen_conet').on('tap', '.btn', function() {
					console.log('确定查询')
					
//					发送请求
					
					
				});
				
				
			})
			


			
		},
		created(){
			const that = this;
			
//			获取记录类型数据
			$.getJSON('../../../static/json/lotterylist.json', function(res) {
				res.forEach(function(item, index, arr) {
					var obj = {
						value: item['id'],
						text: item['text'].replace(/\s+/, '')
					}
					that.typeList.push(obj);
				})
			})
			
//			获取事件类型数据
			$.getJSON('../../../static/json/lotterylist.json', function(res) {
				res.forEach(function(item, index, arr) {
					var obj = {
						value: item['id'],
						text: item['text'].replace(/\s+/, '')
					}
					that.timeList.push(obj);
				})
			})
		}
	}
</script>


<style lang="scss" scoped>
	@import '../../../static/sass/public.scss';
	#SearchRecond{
		margin-top: 0.20rem;
	}
.mui-input-row label {
    float: left;
    width: 35%;
	padding: 0.21rem;
	font-size: .28rem;
}
.mui-input-row label~input, .mui-input-row label~select, .mui-input-row label~textarea {
    float: right;
    width: 65%;
    margin-bottom: 0;
    padding-left: 0;
	border: 0;
	font-size: .28rem;
}	
.cen_conet{
	padding: 0.24rem;
}
.click_onck{
	width: 100%;
}
</style>