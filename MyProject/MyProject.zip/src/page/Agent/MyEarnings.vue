<template>
	<div class="BetttingRecods">
		<nav class="seconde-nav">
			<a href="javascript:;" class="border-right-none" :class="typeSelect === 0?'active':''" data-index="0">分润记录</a>
			<a href="javascript:;" class="border-right-none" :class="typeSelect === 1?'active':''" data-index="1">分润详情</a>
			<a href="javascript:;" class="border-right-none" :class="typeSelect === 2?'active':''" data-index="2">我的红包</a>
		</nav>
		<nav class="third-nav" v-if="typeSelect === 0">
			<a href="javascript:;" class="border-right-none">日期</a>
			<a href="javascript:;" class="border-right-none">投注额(直属)</a>
			<a href="javascript:;" class="border-right-none">分润额(直属)</a>
		</nav>

		<nav class="third-nav" v-if="typeSelect === 1">
			<a href="javascript:;" class="border-right-none">游戏/时间</a>
			<a href="javascript:;" class="border-right-none">会员账号</a>
			<a href="javascript:;" class="border-right-none">详情</a>
			<a href="javascript:;" class="border-right-none">返佣金额</a>
		</nav>

		<nav class="third-nav" v-if="typeSelect === 2">
			<a href="javascript:;" class="border-right-none">账号</a>
			<a href="javascript:;" class="border-right-none">状态</a>
			<a href="javascript:;" class="border-right-none">金额</a>
			<a href="javascript:;" class="border-right-none">时间</a>
		</nav>
		<div class="main">
			<scroller ref="Scroll" :loadingShow="loadingShow" :on-infinite="infinite">
				<table border="0" cellspacing="0" cellpadding="0" v-if="typeSelect === 0" ref="betArray">
					<tr class="urlDateil" v-for="(item,index) in betArray" :key="index" :data-times="item.RPT_DATE" :data-money="item.DOWN_AMT+item.AMT" data-index="1">
						<td>{{item.RPT_DATE}}</td>
						<td :style="item.DOWN_AMT>0||item.AMT?'color:red':''">{{(item.DOWN_AMT+item.AMT).toFixed(2)}}({{item.DOWN_AMT.toFixed(2)}})</td>
						<td :style="item.DOWN_AMT>0||item.AMT?'color:red':''">{{(item.DOWN_REBATE_AMT+item.REBATE_AMT).toFixed(2)}}({{ item.DOWN_REBATE_AMT.toFixed(2)}})</td>
					</tr>
				</table>

				<table border="0" cellspacing="0" cellpadding="0" v-if="typeSelect === 1" id="table1" ref="shareDetails">
					<tr v-for="(item, index) in shareDetails" :key="index">
						<td>{{item.PARA_NAME}}</br>{{item.REBATE_DTT.substr(0,10)}}</td>
						<td>{{item.UNDER_USER_NAME}}</br>{{item.UNDER_IND=='1'?'直属会员':'非直属会员'}}</td>
						<td>有效投注:{{item.BET_AMT}}</br>返佣比例:{{item.REBATE_RATE}}</td>
						<td>{{item.CONFIRM_REBATE_AMT}}</td>
					</tr>
				</table>

				<table border="0" cellspacing="0" cellpadding="0" v-if="typeSelect === 2" ref="redBag">
					<tr v-for="(item, index) in redBag" :key="index">
						<td>{{item.REMARK}}</td>
						<td>
							<span style="color: red;" v-if="item.TRANSFER_TYPE_CD == '1'">转出</span>
							<span style="color: green;" v-else>转入</span>/
							<span style="color: green;" v-if="item.STATUS_CD == '1'">成功</span>
							<span style="color: red;" v-else>失败</span>
						</td>
						<td>{{item.TRANSFER_AMT}}</td>
						<td>{{item.CREATE_DTT}}</td>
					</tr>
				</table>
			</scroller>
		</div>
		<div class="btn-box">
			<button class="mui-btn mui-btn-blue mui-btn-block querybtn">立即查询</button>
		</div>
		<ActionSheet :show="actionShow" @hide="handleAction">
			<div class="mui-card timer" slot="action">
				<ul class="mui-table-view mui-table-view-chevron mr-t-8">
					<li class="mui-table-view-cell btn fixedBox" data-options='{}'>
						<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">开始日期
							<div class="segmented-Select">
								<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="btn mui-btn mui-btn-block BeginTime mr-r">
									{{startTime}}
            					</button>
							</div>
						</a>
					</li>
					<li class="mui-table-view-cell btn fixedBox" data-options='{}'>
						<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">结束日期
							<div class="segmented-Select">
								<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="btn mui-btn mui-btn-block EndTime mr-r">
									{{end_time}}
                				</button>
							</div>
						</a>
					</li>
					<li class="mui-table-view-cell gametype fixedBox" v-if="typeSelect === 1">
						<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">游戏类型
							<input type="text" class="mui-input-clear" placeholder="请选择游戏类型" readonly="readonly" v-model="currentGame">
						</a>
					</li>
					<li class="mui-table-view-cell" v-if="typeSelect === 1">
						<ul class="fixText">
							<li>
								<label>会员账号</label><span></span>
							</li>
						</ul>
						<input type="search" class="fixSearch" placeholder="下级会员账号查询" v-model="query.user_acc" />
					</li>
				</ul>
				<p class="gray-line"></p>
				<button type="button" class="mui-btn mui-btn-primary Search-btn mui-btn-block">立即查询</button>
			</div>
		</ActionSheet>
	</div>
</template>

<script>
	import api from '@/api/userUtil';
	import ActionSheet from '@/page/Center/template/ActionSheet';
	import Scroller from '@/components/Scroller';
	import web from '@/api/webUtil';
	export default {
		components: {
			ActionSheet,
			Scroller
		},
		data() {
			return {
				original: false, //默认从小到大排列
				actionShow: false, //底部查询按钮
				startTime: this.$Utils.getDateBefore(9),
				endTime: new Date().Format('yyyy-MM-dd'),
				star_time: new Date().Format('yyyy-MM-dd'),
				end_time: new Date().Format('yyyy-MM-dd'),
				typeSelect: 0, //tab切换的页码
				loadingShow: true, //等待显示
				loadMore: true, //加载更多
				page: 1,
				rows: 15,
				sys_id: 0,
				user_name: '',
				betArray: [], //储存分润记录
				shareDetails: [], //存储分润详情
				redBag: [], //存储我的红包
				GameList: [], //获取游戏大类
				currentPageIndex: 0,
				query: {
					currCode: '',
					curr_Big_Game_Id: '',
					user_acc: '',
					user_name: '',
				},
				currentGame: null,
				selectedgame: null,
			}
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				//底部查询按钮
				mui('.btn-box').on('tap', '.querybtn', function() {
					that.actionShow = true;
				})
				//开始时间
				mui('.timer').on('tap', '.BeginTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.startTime = res['text'];
						})
					}
				})
				//结束时间
				mui('.timer').on('tap', '.EndTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.end_time = res['text'];
						})
					}
				})
				//弹出菜单查询
				mui('.timer').on('tap', '.Search-btn', function() {
					that.actionShow = false;
					that.querySubmit();
				})
				mui('.main').on('tap', '.urlDateil', function() {
					var times = $(this).data('times');
					var money = $(this).data('money');
					var index = $(this).data('index');
					that.goRebateDetail(times, money, index);
				})

				//第一层tab(分润记录, 分润详情, 我的红包)切换
				mui('.seconde-nav').on('tap', 'a', function() {
					var index = $(this).data('index');
					that.typeSelect = index;
					that.querySubmit();
				})

				//选择游戏类型
				mui('.timer').on('tap', '.gametype', function() {
					const CardPiker = new mui.PopPicker({});
					CardPiker.setData(that.GameList);
					CardPiker.show(function(items) {
						that.currentGame = items[0]['text'];
						that.selectedgame = items[0]['value'];
					});
				})
			})

		},
		methods: {
			handleAction() {
				this.actionShow = !this.actionShow;
			},
			querySubmit() {
				let that = this;
				if(that.typeSelect == 0) {
					that.betArray = [];
					that.init(that.startTime, that.end_time);
				}
				if(that.typeSelect == 1) {
					that.shareDetails = [];
					that.init1(that.star_time + ' 00:00', that.endTime + ' 23:59', that.selectedgame);
				}
				if(that.typeSelect == 2) {
					that.redBag = [];
					that.init2(that.star_time + ' 00:00', that.endTime + ' 23:59')
				}
			},
			goRebateDetail(_time, _value, selNum) {
				var that = this;
				if(_value > 0) {
					this.star_time = _time;
					this.endTime = _time;
					that.typeSelect = 1;
					that.querySubmit();
				}
			},

			//分润记录数据初始化
			init(sttd, enddt) {
				var param = {
					page: this.page,
					rows: this.rows,
					sidx: 'rpt_date',
					sord: 'DESC',
					star_time: sttd,
					end_time: enddt
				}
				api.getAgentFeedbackResult(param, res => {
					for(let i = 0; i < res.rows.length; i++) {
						this.betArray.push(res.rows[i]);
					}
					if(res.rows.length == 0) {
						this.loadMore = false;
						this.$toast('暂无更多数据...');
					}
					//					this.page++;
				})
			},

			//分润详情数据初始化
			init1(sttd, enddt, sys_id = this.query.curr_Big_Game_Id) {
				const that = this
				var param = {
					page: that.page,
					rows: that.rows,
					sidx: 'ID',
					sord: 'Desc',
					star_dtt: sttd,
					end_dtt: enddt,
					sys_id: that.selectedgame,
					user_name: that.query.user_acc
				}
				api.GetRebateResult(param, res => {
					that.shareDetails = res.rows
					if(res.rows.length == 0) {
						this.loadMore = false;
						this.$toast('暂无更多数据...');
					}
					//					this.page++;
				})
			},
			//我的红包数据初始化
			init2(sttd, enddt) {
				const that = this
				var param = {
					page: this.page,
					rows: this.rows,
					sidx: 'CREATE_DTT',
					sord: 'DESC',
					star_dtt: sttd,
					end_dtt: enddt,
				}
				api.GetShareRecord(param, res => {
					that.redBag = res.rows
					if(res.rows.length == 0) {
						this.$toast('暂无更多数据...')
					}
				})
			},
			//加工时间格式
			makedate(vals) {
				var val = new Date(vals);
				var month = val.getMonth() + 1;
				var strDate = val.getDate();
				if(month >= 1 && month <= 9) {
					month = "0" + month;
				}
				if(strDate >= 0 && strDate <= 9) {
					strDate = "0" + strDate;
				}
				var dateTemp = val.getFullYear() + "-" + month + "-" + strDate;
				return dateTemp
			},
			//上拉加载
			infinite(finish) {
				const that = this
				//				if(!that.loadMore) {
				//					setTimeout(() => {
				//						that.loadingShow = false;
				//						this.$refs.Scroll.finishInfinite(2);
				//						finish(true);
				//					}, 1500)
				//					return;
				//				}
				setTimeout(() => {
					//					that.init(this.startTime, this.endTime);
					//					that.init1(this.star_dtt, this.enddt);
					//					that.GetUserInfo()
					setTimeout(() => {
						finish();
					})
				}, 1500)
			},
			//获取游戏大类
			getGameList() {
				var GameList = localStorage.getItem('GameList');
				if(GameList != null && GameList != undefined) {
					this.GameList = JSON.parse(GameList);
				} else { //如果缓存中没有这个值
					web.GetGameClassBig2(res => {
						res = JSON.parse(res);
						res.forEach(ele => {
							var obj = {
								text: ele.LOTTERY_TICKET_NAME,
								value: ele.ID,
								code: ele.CODE
							}
							this.GameList.push(obj);
						})
						localStorage.setItem('GameList', JSON.stringify(this.GameList));
					})
				}
			}
		},
		computed: {
			UserInfo() {
				return this.$store.getters.getUserInfo;
			}
		},
		created() {
			this.getGameList();
			this.$store.dispatch('getUserInfo');
			this.init(this.startTime, this.end_time);
		}
	}
</script>

<style lang="scss" rel="stylesheet/scss" scoped>
	@import '~static/sass/public.scss';
	a {
		color: #333
	}
	
	table {
		color: #666
	}
	
	._v-content p {
		font-size: .24rem;
		color: #666
	}
	
	.fixSearch {
		display: inline-block;
		width: 60%;
	}
	
	.fixText {
		display: inline-block;
		text-align: left;
		width: 2.1rem;
	}
	
	.searchInput {
		display: inline-block;
		vertical-align: middle;
		background-color: rebeccapurple;
		span {
			width: 2rem;
			display: inline-block;
			vertical-align: middle;
			background-color: #2ac845;
			margin-right: .3rem;
			text-align: left;
		}
		input {
			width: 60%;
			border: none;
			margin-bottom: 0;
		}
	}
	
	.fixedBox {
		padding: .3rem !important;
		padding-bottom: 0;
	}
	
	.activeNav {
		display: flex;
	}
	
	.btn {
		padding: .1rem;
	}
	
	.mui-table-view-cell {
		padding: 0;
	}
	
	.mui-btn-block {
		padding: .2rem;
		font-size: .36rem;
	}
	
	.activeNav {
		display: flex;
		padding: .2rem;
		li {
			flex: 1;
			list-style: none;
			padding-bottom: 0;
			button {
				font-size: .24rem;
				margin-bottom: 0;
				padding: .2rem;
			}
			button:first-child {
				margin-right: .1rem;
			}
		}
		li:last-child {
			margin-left: .1rem;
		}
		li:first-child {
			margin-right: .1rem;
		}
	}
	
	.mui-table-view-cell:after {
		height: 0;
	}
	
	.GameListBlock {
		margin-bottom: .2rem;
		div {
			display: flex;
			flex-wrap: wrap;
			span {
				display: inline-block;
				flex: 0 0 33.33%;
				padding: .1rem;
				text-align: center;
				position: relative;
			}
			.active {
				background-color: #19b4f5;
				color: #fff
			}
		}
	}
	
	.segmented-Select {
		width: 100%;
	}
	
	.BetttingRecods {
		height: 100%;
		display: flex;
		flex-direction: column;
		.first-nav {
			padding: 0.24rem;
			display: flex;
			a {
				flex: 1;
				font-size: 0.28rem;
				background: #fff;
				padding: 0.1rem 0;
				@include border1px($blueColor)
			}
			a:first-child {
				border-radius: 3px 0 0 3px;
			}
			a:first-child::after {
				border-radius: 3px 0 0 3px;
			}
			a:last-child {
				border-radius: 0 3px 3px 0;
			}
			a:last-child::after {
				border-radius: 0 3px 3px 0;
			}
			.active {
				background: $blueColor;
				color: #fff;
			}
		}
		.seconde-nav {
			background: #fff;
			display: flex;
			a {
				flex: 1;
				font-size: 0.28rem;
				padding: 0.2rem;
			}
			.active {
				color: $blueColor;
				position: relative;
				&:after {
					content: '';
					height: 1px;
					width: 1.2rem;
					background: $blueColor;
					position: absolute;
					left: 50%;
					bottom: 0;
					transform: translate(-50%, -50%);
				}
			}
		}
		.third-nav {
			margin-top: 0.16rem;
			background: #fff;
			display: flex;
			a {
				flex: 1;
				font-size: 0.24rem;
				padding: 0.1rem 0;
				@include border-1px(#ccc, bottom);
			}
		}
		.main {
			flex: 1;
			position: relative;
			table {
				width: 100%;
				background: #fff;
				tr {
					td {
						font-size: 0.24rem;
						height: 0.8rem;
						@include border-1px(#ccc, bottom);
						width: 20%;
					}
				}
			}
		}
		.Record-detail {
			.iconfont {
				font-size: 0.4rem;
				color: #19b4f5;
			}
			&:active .iconfont {
				color: rgba(#19b4f5, 0.6);
			}
		}
		.btn-box {
			padding: 0.24rem;
			.querybtn {
				margin: 0;
				padding: 0.2rem 0;
				background: #19b4f5;
				border: 0 none;
				&:active {
					background: rgba(#19b4f5, 0.6);
				}
			}
		}
		.timer {
			box-shadow: none;
			a {
				padding: 0 0 0 15px;
			}
			.mui-table-view-cell:after {
				content: '';
				height: 0;
			}
			.segmented-Select {
				display: inline-block;
				button {
					font-size: 0.24rem;
					padding: 0.2rem 2rem;
					border: none;
					margin: 0;
					&:active {
						background: rgba(255, 255, 255, 0.4);
					}
				}
			}
			.mui-input-clear {
				border: none;
				padding-left: 2rem;
				font-size: 0.24rem;
				margin: 0;
			}
			.mui-table-view-cell>a:not(.mui-btn) {
				padding-right: 15px;
			}
			.mui-card {
				margin: 0;
			}
			.mui-table-view-cell:after {
				left: 0;
			}
			.mui-btn-primary {
				font-size: 0.32rem;
				background: $blueColor;
				border: 0;
				margin: 0;
				padding: 0.2rem 0;
			}
			.gray-line {
				height: 0.2rem;
				background: $bgColor;
			}
		}
	}
	
	.mui-icon-checkmarkempty {
		position: absolute;
		right: 0;
		bottom: 0;
		color: #fff
	}
	
	.btn {
		width: 100%;
	}
</style>