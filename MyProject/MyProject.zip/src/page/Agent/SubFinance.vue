<template>
	<div class="finance">
		<div class="navbar">
			<a class="mui-control-item tab" :class="index == 0? 'active':''" :data-index="0">存款</a>
			<a class="mui-control-item tab" :class="index == 1? 'active':''" :data-index="1">取款</a>
			<a class="mui-control-item tab" :class="index == 2? 'active':''" :data-index="2">赠金返点</a>
			<a class="mui-control-item tab" :class="index == 3? 'active':''" :data-index="3">其他</a>
		</div>
		<div class="thead">
			<a class="mui-control-item tab">存款</a>
			<a class="mui-control-item tab">取款</a>
			<a class="mui-control-item tab">赠金返点</a>
			<a class="mui-control-item tab">其他</a>
		</div>
		<div class="main">
			<Scroller :on-infinite="infinite" ref="Scroll" :loadingShow="loadingShow">
				<table border="0" cellspacing="0" cellpadding="0">
					<tr v-for="(item,index) in initData">
						<td>
							<p>{{item.USER_NAME}}</p>
							<p>{{item.REAL_NAME}}</p>
						</td>
						<td>{{paraDebit[item.LOAN_TYPE_CD].FULLNAME}}</td>
						<td v-if="item.STATUS_CD == 0"><span class="error">失败</span></td>
						<td v-else-if="item.STATUS_CD == 1"><span class="success">成功</span></td>
						<td v-else-if="item.STATUS_CD == 2"><span class="await">待审核</span></td>
						<td v-else-if="item.STATUS_CD == 3"><span class="await">预下单</span></td>
						<td v-else><span class="success">充值成功</span></td>
						<td>&yen;{{item.AMT.toFixed(1)}}</td>
					</tr>
				</table>
			</Scroller>
		</div>
	</div>
</template>

<script>
	import Scroller from '@/components/Scroller';
	import api from '@/api/userUtil';
	export default {
		name: 'finance',
		components:{
			Scroller
		},
		data() {
			return {
				index: 0,
				loadingShow:true,
				loadMore:true,
				paraDebit: {
					"2-12": {
						"ENCODE": "2-12",
						"FULLNAME": "在线存款[QQ钱包]"
					},
					"2-0": {
						"ENCODE": "2-0",
						"FULLNAME": "在线存款[银联]"
					},
					"2-1": {
						"ENCODE": "2-1",
						"FULLNAME": "在线存款[微信]"
					},
					"2-2": {
						"ENCODE": "2-2",
						"FULLNAME": "在线存款[支付宝]"
					},
					"2-4": {
						"ENCODE": "2-4",
						"FULLNAME": "填单存款[银联]"
					},
					"2-13": {
						"ENCODE": "2-13",
						"FULLNAME": "填单存款[支付宝]"
					},
					"2-14": {
						"ENCODE": "2-14",
						"FULLNAME": "填单存款[微信]"
					},
					"2-15": {
						"ENCODE": "2-15",
						"FULLNAME": "填单存款[QQ钱包]"
					},
					"2-16": {
						"ENCODE": "2-16",
						"FULLNAME": "预留"
					},
					"2-17": {
						"ENCODE": "2-17",
						"FULLNAME": "预留"
					},
					"2-18": {
						"ENCODE": "2-18",
						"FULLNAME": "预留"
					},
					"2-19": {
						"ENCODE": "2-19",
						"FULLNAME": "预留"
					},
					"2-20": {
						"ENCODE": "2-20",
						"FULLNAME": "预留"
					},
					"2-21": {
						"ENCODE": "2-21",
						"FULLNAME": "预留"
					},
					"2-22": {
						"ENCODE": "2-22",
						"FULLNAME": "预留"
					},
					"2-24": {
						"ENCODE": "2-24",
						"FULLNAME": "预留"
					},
					"2-5": {
						"ENCODE": "2-5",
						"FULLNAME": "人工加款"
					},
					"2-6": {
						"ENCODE": "2-6",
						"FULLNAME": "代理转入"
					},
					"2-7": {
						"ENCODE": "2-7",
						"FULLNAME": "代理分润转入"
					},
					"2-8": {
						"ENCODE": "2-8",
						"FULLNAME": "代理存款"
					},
					"2-9": {
						"ENCODE": "2-9",
						"FULLNAME": "兑换积分"
					},
					"1-0": {
						"ENCODE": "1-0",
						"FULLNAME": "会员取款"
					},
					"1-1": {
						"ENCODE": "1-1",
						"FULLNAME": "返水派送"
					},
					"1-2": {
						"ENCODE": "1-2",
						"FULLNAME": "充值优惠"
					},
					"1-3": {
						"ENCODE": "1-3",
						"FULLNAME": "注册赠送"
					},
					"1-4": {
						"ENCODE": "1-4",
						"FULLNAME": "代理提款"
					},
					"1-5": {
						"ENCODE": "1-5",
						"FULLNAME": "彩金派送"
					},
					"1-6": {
						"ENCODE": "1-6",
						"FULLNAME": "人工减款"
					},
					"1-8": {
						"ENCODE": "1-8",
						"FULLNAME": "代理转出"
					},
					"2-23": {
						"ENCODE": "2-23",
						"FULLNAME": "代理转入"
					},
					"1-7": {
						"ENCODE": "1-7",
						"FULLNAME": "代理返水"
					},
					"1-9": {
						"ENCODE": "1-9",
						"FULLNAME": "代理分润代理转出"
					},
					"1-10": {
						"ENCODE": "1-10",
						"FULLNAME": "代理分润会员转出"
					}
				},
				queryJson:{type_cd:'2-12,2-0,2-1,2-2,2-16,2-17,2-18,2-19,2-4,2-15,2-13,2-14,2-20,2-21,2-22,2-24'},	//默认查询条件	
				page:1,
				rows:15,
				initData:[],
			}
		},
		mounted() {
			const that = this;
			this.init();
			mui.init();
			mui.ready(function() {

				mui('.navbar').on('tap', '.tab', function() {
					var index = $(this).data('index')
					that.index = index;
					that.page = 1;
					switch(index){
						case 0:
							//存款
							that.queryJson = {type_cd:'2-12,2-0,2-1,2-2,2-16,2-17,2-18,2-19,2-4,2-15,2-13,2-14,2-20,2-21,2-22,2-24'};
							break;
						case 1:
							//取款
							that.queryJson = {type_cd:'1-0'};
							break;
						case 2:
							//赠金返点
							that.queryJson = {type_cd:'1-1,1-2,1-3,1-5,2-23'};
							break;
						default:
							//其他
							that.queryJson = {type_cd:'1-4,1-6,1-8,1-7,1-9,1-10,2-5,2-6,2-7,2-8,2-9'};
							break;
					}
					that.init();
				})
			})
		},
		methods:{
			//上拉加载
			infinite(finish) {
				const that = this;
				if(!that.loadMore) {
					setTimeout(() => {
						that.loadingShow = false;
						finish(true);
					}, 1500)
					return;
				}
				setTimeout(() => {
					that.init();
					setTimeout(() => {
						finish();
					})
				}, 1500)
			},
			init(){
				const that = this;
				var param = {
					type_cd:this.queryJson.type_cd,
					rows: this.rows,
					page: this.page,
					sidx: 'ID',
					sord: 'DESC'
				}
				api.GetAgentOrderList(param,(res)=>{
					var res = JSON.parse(res);
					if(res.rows.length == 0){
						that.loadMore = false;
						that.$toast('没有更多数据...');
					}
					that.initData=[];
					for(let i = 0; i < res.rows.length; i++){
						that.initData.push(res.rows[i]);
					}
					that.page++;
				})
			}
		}
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	.finance{
		display: flex;
		flex-direction: column;
		.navbar{
			display:flex;
			background:#fff;
			a{
				flex: 1;
				padding: 0.2rem 0;
				font-size: 0.28rem;
			}
			.active{
				color: $blueColor;
				position: relative;
				&:after{
					display: block;
					content: '';
					width: 100%;
					height: 1px;
					background: $blueColor;
					position: absolute;
					bottom: 0;
					left: 0;
				}
			}
		}
		.thead{
			margin-top: 0.16rem;
			background: #fff;
			display: flex;
			@include border-1px(#ccc,bottom);
			a{
				flex: 1;
				padding: 0.1rem;
				font-size: 0.24rem;
				font-weight: 600;
			}
		}
		.main{
			flex: 1;
			position: relative;
			table{
				width: 100%;
				background: #fff;
				color: #666;
				tr{
					height: 0.66rem;
					td{
						font-size: 0.24rem;
						@include border-1px(#ccc,bottom);
						width: 25%;
					}
				}
			}
		}
	}
</style>