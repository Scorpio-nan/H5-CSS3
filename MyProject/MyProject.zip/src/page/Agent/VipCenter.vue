<template>
	<div class="VipCenter">
		<nav class="nav">
			<a :class="index == 0? 'active':''" data-index="0">全部</a>
			<a :class="index == 1? 'active':''" data-index="1">代理</a>
			<a :class="index == 2? 'active':''" data-index="2">会员</a>
		</nav>

		<div class="serch-box">
			<button class="mui-btn mui-btn-blue mui-btn-left backbtn">返回上级</button>
			<div class="serch-right">
				<input type="search" v-model="user_name" required="" placeholder="会员账号">
				<button class="mui-btn mui-btn-blue serch-btn">搜索</button>
			</div>
		</div>

		<div class="thead">
			<a href="javascript:;">会员账号</a>
			<a href="javascript:;">会员姓名</a>
			<a href="javascript:;">是否代理</a>
			<a href="javascript:;">操作</a>
		</div>
		<div class="list-warpper">
			<scroller :on-infinite="infinite" v-model="accessStat" ref="dataTrans" @on-pullup-loading="getAgentLowMemberList" :loadingShow="loadingShow">
				<table border="0" cellspacing="0" cellpadding="0">
					<tr v-for="(user,index) in userList">
						<td>
							<span class="color-font" :data-index="index" :data-ID="user.ID">{{user.USER_NAME}}</span>
						</td>
						<td> {{user.REAL_NAME == null ? '无' : user.REAL_NAME}}</td>
						<td> {{user.AGENT_IND==1?'是':'否'}}</td>
						<td>
							<span class="handleBtn" :class="selectIndex===index?'backscss':''" :data-index="index" :data-ID="user.ID">操作</span>
						</td>
					</tr>
				</table>
				<div slot="pullup" class="xs-plugin-pullup-container xs-plugin-pullup-up pullstyle">
					<span v-show="accessStat.pullupStatus === 'default'"></span>
					<span class="pullup-arrow" v-show="accessStat.pullupStatus === 'default' || accessStat.pullupStatus === 'up' || accessStat.pullupStatus === 'down'" :class="{'rotate': accessStat.pullupStatus === 'down'}">↑</span>
					<span v-show="accessStat.pullupStatus === 'loading'"></span>
				</div>
			</scroller>
		</div>

		<Actionsheet :show="isShow" @hide="hideisShow" id="popup_box">
			<div slot='action' class="popup">
				<label class="label-box">
						<div class="label-name">
							<span>额度分享：</span>
						</div>
						<div class="sharNum">
							<input type="number" v-model="shareamt"/>
						</div>
						<span class="sharbtn">
							<a href="javascript:;" class="share">确认</a>
						</span>
					</label>
				<span class="line"></span>
				<button class="UptoAgent upteAgent" v-show="agncyBtn">升级为代理</button>
				<button class="UptoAgent chekNext" v-show="!agncyBtn">查看下级</button>
				<span class="hen"></span>
				<button class="isShow">取消</button>
			</div>
		</Actionsheet>

		<TransferDom :show="Sharlist" @handleHide="hideSharlist">
			<div slot='' class="Sharlist">
				<h3 class="title">当前会员详情</h3>
				<div class="main">
					<p class="conten">
						<span>邀请码：</span><span>{{USER.INVITE_CODE == null ? '暂无邀请码': (Array(6).join('0') + USER.INVITE_CODE).slice(-6) }}</span>
					</p>
					<p class="conten">
						<span>注册时间：</span><span>{{USER.REGISTER_DTT}}</span>
					</p>
					<p class="conten">
						<span>最近登录：</span><span>{{USER.LAST_LOGIN_DTT === null ? '暂未登录': USER.LAST_LOGIN_DTT}}</span>
					</p>
					<p class="conten">
						<span>在线状态：</span><span v-if="USER.ACCOUNT_STATUS === '0'" style="color:red;">离线</span>
						<span v-else class="green">在线</span>
					</p>
					<p class="conten mr-b">
						<span>当前余额：</span><span>¥ {{USER.BALANCE_AMT}}</span>
					</p>
					<p class="conten" v-for="(item,i) in alertContentArr">
						<span>{{item.GAME_NAME}}：</span>
						<span>{{(item.BASE_PERCENT*100).toFixed(2)}} %</span>
					</p>
				</div>
			</div>
		</TransferDom>

		<TransferDom :show="UpdataAgency" @handleHide="hideUpdata">
			<div slot='' class="Sharlist">
				<h3 class="title">抽取下级点数(%)</h3>
				<div class="main">
					<div class="form-line" v-for="(item,i) in getUserper">
						<label>{{item.GAME_NAME}}：</label>
						<input type="text" class="mui-input-clear" v-model="item.BASE_PERCENT" />
					</div>
					<div class="mui-button-row">
						<button type="button" class="mui-btn mui-btn-danger">取消</button>
						<button type="button" class="mui-btn mui-btn-blue serch-btn">确认</button>
					</div>
				</div>
			</div>
		</TransferDom>
	</div>
</template>

<script>
	import agentApi from '@/api/agentUtil'
	import userapi from '@/api/userUtil'
	import Scroller from '@/components/Scroller'
	import TransferDom from '@/components/TransferDom'
	import Actionsheet from '@page/Center/template/ActionSheet'
	export default {
		name: 'VipCenter',
		components: {
			Scroller,
			Actionsheet,
			TransferDom
		},
		data() {
			return {
				index: 0,
				Sub_ID: 0,
				agent_ind: '',
				USER: '',
				shareamt: '',
				user_name: null,
				selectIndex: null,
				userList: [],
				alertContentArr: [],
				storeUser: [], //存储用户信息
				getUserper: [],
				postArr: [],
				Sharlist: false,
				isShow: false,
				UpdataAgency: false,
				agncyBtn: true,
				loadingShow: true,
				accessStat: {
					pullupStatus: 'default'
				},
				accessPage: { //存取款參數
					total: 0, //总页数
					page: 1, //当前页数
					rows: 20, //每页显示记录数
					records: 0, //总记录数
					isDataLoading: false, //加载时显示
					pullupStatus: 'default',
					isdata: true,
				},
			}
		},
		created() {
			this.$store.dispatch('getUserInfo');
			this.$store.dispatch('getAccount', ' ');
		},
		computed: {
			myWallet() {
				var objItem = this.$store.getters.getAccount.data;
				if(objItem != null && typeof(objItem.my_wallet) != 'undefined') {
					return objItem.my_wallet;
				} else {
					return 0;
				}
			},
			UserInfo() {
				return this.$store.getters.getUserInfo;
			}

		},
		mounted() {
			const that = this;
			this.getAgentLowMemberList();
			this.storeUser.push({
				userName: this.UserInfo.USER_NAME,
				userID: this.UserInfo.ID
			});
			mui.init();
			mui.ready(function() {
				//页签切换
				mui('.nav').on('tap', 'a', function() {
					var index = $(this).data('index');
					that.index = index;
				})

				//搜索查询
				mui('.serch-box').on('tap', '.serch-btn', function() {
					that.Serch();
				});

				//返回上级
				mui('.serch-box').on('tap', '.backbtn', function() {
					that.backprev();
				});

				//额度分享确认按钮
				mui('.label-box').on('tap', '.sharbtn', function() {
					that.Share();
				});

				//升级为代理
				mui('.popup').on('tap', '.upteAgent', function() {
					that.UptoAgent();
				});

				//查看下级
				mui('.popup').on('tap', '.chekNext', function() {
					that.chekNext();
				});
				//取消按钮
				mui('.popup').on('tap', '.isShow', function() {
					that.isShow = false;
				});
				
				mui('.mui-content').on('tap', '.action_mask', function() {
					that.isShow = false;
				});

				//查看下级会员详情
				mui('.list-warpper').on('tap', '.color-font', function() {
					var ID = $(this).data().id;
					var index = $(this).data().index;
					that.checkSharList(ID, that.userList[index])
				});

				//操作按钮
				mui('.list-warpper').on('tap', '.handleBtn', function() {
					var ID = $(this).data().id;
					var index = $(this).data().index;
					that.Manual(ID, index, that.userList[index].AGENT_IND, that.userList[index]);
				});

				//抽取下级点数确认
				mui('.mui-button-row').on('tap', '.serch-btn', function() {
					that.onConfirm();
				});

				//抽取下级点数取消
				mui('.mui-button-row').on('tap', '.mui-btn-danger', function() {
					that.onCancel();
				});
			});
			
		},
		methods: {
			//查看当前会员详情
			hideSharlist() {
				this.Sharlist = !this.Sharlist;
			},

			//抽取下级点数
			hideUpdata() {
				if(this.Sharlist) {
					this.UpdataAgency = false;
					this.Sharlist = false;
				}
			},

			//额度分享
			hideisShow() {
				this.isShow = !this.isShow;
			},

			//点击额度分享取消按钮
			onCancel() {
				this.isShow = false;
				this.UpdataAgency = false;
			},

			//返回上级
			backprev() {
				let that = this;
				that.resetPulldown();
				if(that.storeUser.length == 0) {
					that.getAgentLowMemberList();
				} else {
					that.storeUser = that.storeUser.splice(0, that.storeUser.length - 1);
					let user = that.storeUser[that.storeUser.length - 1];
					if(user == undefined) {
						that.getAgentLowMemberList();
					} else {
						that.getAgentLowMemberList(user.userID);
					}
				}
			},

			//查看下级
			chekNext() {
				var obj = {
					userName: this.USER.USER_NAME,
					userID: this.USER.ID
				}
				this.userList = [];
				this.storeUser.push(obj);
				this.getAgentLowMemberList(this.USER.ID);
			},

			resetPulldown() {
				this.userList = [];
				this.accessPage.isdata = true;
				this.accessPage.page = 1;
			},
			//升级为代理
			UptoAgent() {
				var that = this;
				that.isShow = false;
				this.UpdataAgency = true;
				userapi.GetShareList(this.Sub_ID, function(res) {
					for(let i = 0; i < res.length; i++) {
						res[i].BASE_PERCENT = parseFloat(res[i].BASE_PERCENT) * 100;
					}
					that.getUserper = res;
				});
			},

			//弹出消息
			onConfirm() {
				let that = this;
				let arr = this.getUserper
				this.postArr = [];
				for(let i = 0; i < arr.length; i++) {
					if(parseFloat(arr[i].BASE_PERCENT) < 0) {
						that.$alert('请设置抽取点数');
						return;
					} else if(parseFloat(arr[i].BASE_PERCENT) == null ||
						parseFloat(arr[i].BASE_PERCENT) == '' ||
						parseFloat(arr[i].BASE_PERCENT) == undefined) {
						arr[i].BASE_PERCENT = 0;
					}
					let obj = {
						SYS_GAME_LEVEL_CODE_ID: arr[i].SYS_GAME_LEVEL_CODE_ID,
						GAME_NAME: arr[i].GAME_NAME,
						BASE_PERCENT: parseFloat(arr[i].BASE_PERCENT) / 100
					}
					this.postArr.push(obj);
				}
				let postdata = {
					user_id: this.Sub_ID,
					jsonParm: escape(JSON.stringify(this.postArr))
				}
				userapi.PostUpAgent(postdata, function(res) {
					if(res.state == 'success') {
						that.$alert('升级成功！');
						that.UpdataAgency = false;
						for(let i = 0; i < that.userList.length; i++) {
							that.userList[that.arrIndex].AGENT_IND = '1';
						}
					} else {
						that.$alert(res.message);
						that.UpdataAgency = false;
					}
				})
			},

			//操作按钮
			Manual(userid, index, state, user) {
				var that = this;
				that.selectIndex = index;
				that.isShow = true;
				this.USER = user;
				that.Sub_ID = userid;
				this.arrIndex = index;
				if(state === '1') {
					this.agncyBtn = false;
				} else {
					this.agncyBtn = true;
				}
			},

			//搜索查询
			Serch() {
				var that = this;
				that.userList = [];
				that.accessPage.isdata = true;
				that.accessPage.page = 1;
				that.getAgentLowMemberList();
			},

			//获取列表
			getAgentLowMemberList(user_id = '', ) {
				var that = this;
				let user = that.storeUser[that.storeUser.length - 1];
				if(user == undefined) {} else {
					user_id = user.userID
				}
				if(!that.accessPage.isdata) {
					that.accessStat.pullupStatus = 'disable';
					return;
				}
				var postData = {
					rows: that.accessPage.rows,
					page: that.accessPage.page,
					sord: "Desc",
					sidx: "ONLINE_STATUS",
					user_name: '',
					user_id: user_id
				};
				if(that.user_name != undefined && that.user_name != null && that.user_name != '') {
					postData.user_name = that.user_name;
				}
				setTimeout(() => {
					agentApi.GetAgentLowMemberList(postData, function(res) {
						that.isShow = false;
						//无数据
						if(res.rows.length == 0) {
							that.accessPage.isdata = false //没有更多数据
						} else {
							that.accessPage.isdata = true;
							that.accessStat.pullupStatus = 'default'
						}
						that.accessPage.page++;
						for(var i = 0; i < res.rows.length; i++) {
							that.userList.push(res.rows[i]);
						}
					});
				}, 100)
			},

			//额度分享确认按钮
			Share() {
				var that = this;
				that.isShow = false;
				if(parseFloat(that.shareamt) > parseFloat(that.myWallet)) {
					that.$alert('余额不足');
					return;
				}
				if(that.shareamt <= 0 || that.shareamt == null || that.shareamt == '') {
					that.$alert('请输入正确金额');
					return;
				}
				var postdata = {
					user_id: that.Sub_ID,
					amt: that.shareamt,
				};
				userapi.PostShareRed(postdata, function(res) {
					if(res.state == "success") {
						that.$alert(res.message);
						that.$store.dispatch('getAccount');
						that.shareamt = '';
					} else {
						that.$alert(res.message);
					}
				});
			},

			//查看下级会员详情
			checkSharList(ID, user) {
				let that = this;
				this.Sharlist = true;
				that.alertContentArr = [];
				this.USER = user;
				userapi.GetShareList(ID, function(res) {
					that.alertContentArr = res;
				})
			},

			infinite(finish) {
				const that = this;
				if(this.list >= 40) {
					setTimeout(() => {
						that.loadingShow = false;
						finish(true);
					}, 1500)
					return;
				}
				setTimeout(() => {
					this.list = this.list + 10;
					setTimeout(() => {
						finish();
					})
				}, 1500)
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.VipCenter {
		height: 100%;
		width: 100%;
		display: flex;
		flex-direction: column;
		.nav {
			display: flex;
			background: #fff;
			padding: 0.2rem 0;
			a {
				flex: 1;
				text-align: center;
				font-size: 0.28rem;
			}
			.active {
				position: relative;
				color: $blueColor;
				&:after {
					position: absolute;
					content: '';
					bottom: -0.2rem;
					left: 50%;
					transform: translate(-50%, 0);
					width: 1rem;
					height: 0.02rem;
					background: $blueColor;
				}
			}
		}
		.color-font {
			color: #85d7fc;
			text-decoration: underline;
		}
		.backscss {
			background: #19b4f5;
			color: #ffffff;
		}
		.handleBtn {
			padding: 0.06rem 0.1rem;
			border: 0.02rem solid #cccccc;
			border-radius: 0.08rem;
		}
		.serch-box {
			padding: 0.24rem;
			display: flex;
			.mui-btn-left {
				width: 2rem;
				margin-right: 0.16rem;
				font-size: 0.28rem;
				background: $blueColor;
				border: 0 none;
			}
			.serch-right {
				flex: 1;
				display: flex;
			}
			input[type=search] {
				margin: 0;
				border: 0 none;
				border-radius: 0;
				border: 0.02rem solid $blueColor;
				background: #fff;
				flex: 1;
				height: 0.7rem;
			}
			.serch-btn {
				border: 0 none;
				border-radius: 0 0.06rem 0.06rem 0;
				width: 1.2rem;
				font-size: 0.28rem;
				background: $blueColor;
			}
		}
		.thead {
			display: flex;
			background: #fff;
			padding: 0.1rem 0;
			@include border-1px(#ccc, bottom);
			a {
				flex: 1;
				font-size: 0.24rem;
				color: #282828;
			}
		}
		.list-warpper {
			flex: 1;
			overflow: auto;
			position: relative;
			table {
				width: 100%;
				background: #fff;
				tr {
					height: 0.8rem;
					td {
						width: 25%;
						@include border-1px(#ccc, bottom);
						font-size: 0.24rem;
					}
				}
			}
		}
		.label-box {
			display: table;
			width: 100%;
			background: #eee;
			height: 0.8rem;
			vertical-align: middle;
			.label-name {
				display: table-cell;
				width: 25%;
				vertical-align: middle;
				text-align: center;
				font-size: 0.28rem;
				color: #00a0e9;
				font-weight: 600;
				padding-left: 0.12rem;
			}
			.sharNum {
				display: table-cell;
				vertical-align: middle;
				height: 100%;
				width: 55%;
				padding: 0 0.12rem;
				input {
					border: 0;
					outline: none;
					width: 100%;
					height: 0.52rem;
					border: 0.02rem solid rgba(0, 0, 0, 0.24);
					border-radius: 0.08rem;
					text-indent: 0.2rem;
					margin: 0;
					padding: 0;
				}
			}
			.sharbtn {
				width: 20%;
				display: table-cell;
				vertical-align: middle;
				text-align: center;
				a {
					padding: 0.1rem 0.18rem;
					background: #00a0e9;
					color: #fff;
					border-radius: 0.08rem;
					font-size: 0.24rem;
				}
			}
		}
		.Sharlist {
			background: rgba(255, 255, 255, 1);
			width: 5rem;
			height: auto;
			font-size: 0.28rem;
			.title {
				font-size: 0.3rem;
				border-bottom: 0.02rem solid rgba(0, 0, 0, 0.2);
				padding: 0.12rem 0.4rem;
				text-align: center;
			}
			.form-line {
				display: table;
				width: 100%;
				height: 0.64rem;
				padding-left: 0.16rem;
				label {
					display: table-cell;
					width: 1.96rem;
				}
				input {
					display: table-cell;
					margin: 0;
					padding: 0;
					border: 0;
					width: 2.5rem;
					outline: none;
					border: 0.02rem solid rgba(0, 0, 0, 0.21);
					border-radius: 0.08rem;
					height: 0.52rem;
					text-indent: 0.12rem;
					font-size: 0.26rem;
				}
			}
			.mui-button-row {
				padding-top: 0.16rem;
			}
			.main {
				padding: 0.12rem 0.06rem;
				.conten {
					display: table;
					width: 100%;
					font-size: 0.28rem;
					span {
						display: table-cell;
					}
					span:first-child {
						width: 1.6rem;
						text-align: left;
					}
					span:last-child {
						text-align: left;
					}
				}
			}
		}
		.hen {
			background: #ffff;
			height: .2rem;
			display: block;
		}
		.line {
			border: 0.02rem solid #ffff;
			display: block;
		}
		.UptoAgent {
			width: 100%;
			height: 0.8rem;
			background: #eee;
			border: 0;
			color: #00a0e9;
			font-weight: 700;
			font-size: 0.28rem;
		}
		.isShow {
			width: 100%;
			height: 0.8rem;
			background: #eee;
			border: 0;
			color: #ff0006;
			font-weight: 700;
			font-size: 0.28rem;
		}
		.pullstyle {
			position: absolute;
			width: 100%;
			height: 0.8rem;
			bottom: -0.8rem;
			text-align: center;
		}
		#popup_box {
			background: #FFFFFF;
		}
	}
</style>