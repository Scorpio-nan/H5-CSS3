<template>
	<div id="Rechargeonline">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="area2">
					<ul class="mui-table-view mui-grid-view mui-grid-9 top_Lists">
						<li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3 list newLiStyle" :class="[index == i ? 'mui-active2': '']" :data-id="i" :data-object="JSON.stringify(list)" v-for="(list,i) in ChannelShow">
							<a href="#">
								<span class="mui-icon iconfont icon-tianmao">
				                <img :src="'static/img/ge/'+list.GLOBAL_TYPE+'.png'">
				                </span>
								<div class="mui-media-body">
									{{list.GLOBAL_TYPE == 'global_bank_pay'? '银行卡支付' : (list.GLOBAL_TYPE == 'global_qq_pay' ? 'QQ支付' : (list.GLOBAL_TYPE == 'global_wechat_pay' ? '微信支付' : (list.GLOBAL_TYPE == 'global_alipay_pay' ? '支付宝支付' : '')))}}
								</div>
							</a>
						</li>
					</ul>
				</div>
				<component ref="vChild" is="UnionPay" :Cardlist="Cardlist" :ChanelList="ChanelList"></component>
			</div>
		</div>
	</div>
</template>

<script>
	import UnionPay from "./Payment/UnionPay.vue";
	import api from '@/api/payUtil';
	export default {
		name: "Rechargeonline",
		components: {
			UnionPay
		},
		data() {
			return {
				Cardlist: [],
				codeType: "", //选中的大类
				index: 0,
				ChannelJson: [], //支付列表json
				ChanelList: [], //支付子类
				ChannelShow: [] //显示大类
			};
		},
		created() {
			const that = this;
			this.GetOnlinePayChannelListNew();
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui(".mui-scroll-wrapper").scroll({
					deceleration: 0.0005
				});
				//循环下的点击事件
				mui(".top_Lists").on("tap", ".list", function() {
					var index = $(this).data("id");
					var obj = $(this).data("object");
					that.index = index;
					that.codeType = obj.GLOBAL_TYPE
					that.filter2();
				});
			});
		},
		methods: {
			//筛选显示支付大类方法
			filter: function() {
				var this_ = this;
				var temp = [];
				for(var i = 0; i < this_.ChannelJson.length; i++) {
					var sj = this_.ChannelJson[i];
					var type = sj.GLOBAL_TYPE;
					if(!this_.hasType(temp, type)) {
						temp.push(sj);
					}
				}
				this_.ChannelShow = temp;
			},
			//筛选显示支付路线方法;
			filter2: function() {
				var this_ = this;
				var temp = [];
				for(var i = 0; i < this_.ChannelJson.length; i++) {
					var sj = this_.ChannelJson[i];
					var type = this_.codeType;
					if(sj.GLOBAL_TYPE == type) {
						temp.push(sj)
					}
				}
				this_.ChanelList = temp;
			},
			hasType(arr, type) {
				for(var i in arr) {
					var sj = arr[i].GLOBAL_TYPE;
					if(sj == type) {
						return true;
					}
				}
				return false;
			},
			GetOnlinePayChannelListNew() {
				var this_ = this;
				api.GetOnlinePayChannelListNew(function(data) {
					if(data.state == 'error') {
						this_.$alert('获取存款列表错误，请联系在线客服！');
						this_.$router.push({
							path: '/',
						});
					} else {
						this_.ChannelJson = data;
						this_.codeType = data[0].GLOBAL_TYPE
						this_.filter();
						this_.filter2();
					}
				})
			},
			init() {

			}
		},
		watch: {}
	};
</script>

<style scoped lang="scss">
	@import "~static/sass/public.scss";
	#Rechargeonline {
		background: $bgColor;
	}
	
	.transfer1 {
		display: none;
	}
	
	.UnionPay_yin1 {
		display: none;
	}
	.mui-table-view.mui-grid-view .mui-table-view-cell .mui-media-body {
		font-size: 0.24rem;
		line-height: inherit;
		display: block;
		width: 100%;
		height: inherit;
		margin-top: 0.15rem;
		text-overflow: ellipsis;
		color: $importFontColor;
		border-radius: 0.03rem;
	}
	
	.mui-grid-view.mui-grid-9 {
		border-top: 0;
		border-left: 0;
		background-color: $whiteColor;
		text-align: left;
		display: flex;
		justify-content: center;
	}
	
	.mui-icon img {
		width: 0.66rem;
		display: block;
		height: 0.66rem;
	}
	
	.ke {
		margin-left: 0.36rem;
	}
	
	.grayLine {
		height: 0.18rem;
		background: #e9e9e9;
	}
	
	.mui-checkbox input[type="checkbox"],
	.mui-radio input[type="radio"] {
		position: absolute;
		top: 0.5rem;
		right: 20px;
		display: inline-block;
		width: 28px;
		height: 26px;
		border: 0;
		outline: 0 !important;
		background-color: transparent;
		-webkit-appearance: none;
		left: 2.9rem;
	}
	
	.mui-checkbox input[type="checkbox"] {
		top: 3px;
	}
	
	.mui-blank {
		width: 48%;
		height: 1.08rem;
	}
	
	.mui-checkbox.mui-left label {
		padding-top: 0.12rem;
		padding-bottom: 0.12rem;
	}
	
	.mui-input-row {
		clear: none;
	}
	
	.mui-blank_a {
		float: left;
		background: $bgColor;
	}
	
	.mui-blank_b {
		margin-left: 0.22rem;
		float: right;
		background: $bgColor !important;
	}
	
	.mui-grid-view.mui-grid-9 .mui-table-view-cell {
		margin: 0;
		padding: 0;
		margin: .18rem;
		vertical-align: top;
		border-right: 0;
		border-bottom: 0;
	}
	
	.mui-grid-view.mui-grid-9 .mui-table-view-cell>a:not(.mui-btn) {
		margin: 0;
		padding: 0;
	}
	
	.mui-col-xs-3 {
		width: 21%;
	}
	
	.pay_img {
		width: 0.66rem;
		height: 0.66rem;
		position: absolute;
		top: 0.2rem;
		display: inline-block;
		left: 0.2rem;
	}
	
	.mui-grid-view.mui-grid-9 .mui-media .mui-icon {
		font-size: 0.67rem;
		position: relative;
		top: 0.2rem;
	}
	
	.mui-content {
		padding: 0 0.24rem;
		background: $bgColor;
		margin-top: 0.2rem;
		margin-bottom: 0.2rem;
	}
	
	.mui-ellipsis {
		font-size: 0.24rem;
		color: #999999;
	}
	
	.mui_size {
		font-size: 0.28rem;
		color: #333333;
		text-align: left;
		margin-top: 0.08rem;
	}
	
	.title {
		width: 100%;
		margin: auto;
		padding: 0.22rem 0.22rem 0.22rem 0;
	}
	
	.title_size {
		font-size: 0.28rem;
		color: $importFontColor;
	}
	
	.sim {
		font-size: 0.28rem;
		color: #999;
		padding-left: 0.19rem;
		width: 50%;
		padding: 0 0 0 0.19rem;
		height: initial;
		margin-bottom: inherit;
		border: 0;
	}
	
	.mui-container-fluid {
		padding-top: 0.2rem;
	}
	
	.mui-container-fluid2 {
		padding-top: 0.15rem;
	}
	
	.customize {
		width: 31.5%;
		float: left;
		text-align: left;
	}
	
	.mui-btn-block {
		font-size: 0.25rem;
		display: inline-block;
		width: 100%;
		margin-bottom: 0;
		padding: 0.09rem;
		color: $normalFontColor;
	}
	
	.distance {
		margin-top: 0.2rem;
	}
	
	.mui-btn-zidingyi {
		font-size: 0.3rem;
		display: inline-block;
		width: 100%;
		margin-bottom: 0;
		padding: 0.22rem;
		text-indent: 0.34rem;
		background: url("/static/img/public/down.png")$tipsFontColor no-repeat;
		background-position: right;
		color: $normalFontColor;
		display: none;
	}
	
	.mui-btn-ti {
		font-size: 0.32rem;
		display: inline-block;
		width: 100%;
		margin-top: 0.29rem;
		padding: 0.23rem;
		border: 0;
		background: $blueColor;
	}
	
	.out {
		margin-top: 0.2rem;
		padding-bottom: 0.2rem;
	}
	
	.out p {
		height: initial;
		line-height: initial;
		font-size: 0.24rem;
		color: $warnColor;
		text-align: left;
	}
	
	.mui-radio input[type="radio"]:checked:before {
		content: "\e442";
	}
	
	.mui-table-view-cell:after {
		position: absolute;
		right: 0;
		bottom: 0;
		left: 0px;
		height: 1px;
		content: "";
		-webkit-transform: scaleY(0.5);
		transform: scaleY(0.5);
		background-color: #c8c7cc;
	}
	
	.left {
		text-align: left;
		font-size: 0.28rem;
		padding: 0.3rem 0 0.3rem 0.24rem;
	}
	
	.mui-checkbox input[type="checkbox"]:before,
	.mui-radio input[type="radio"]:active {
		background: rebeccapurple;
	}
	
	.mui-table-view:before {
		position: static;
		right: 0;
		left: 0;
		height: 1px;
		content: "";
		-webkit-transform: scaleY(0.5);
		transform: scaleY(0.5);
		background-color: #c8c7cc;
		top: -1px;
	}
	
	.mui-content>.mui-table-view:first-child {
		margin-top: 0;
	}
	
	.mui-btn-xuanze {
		font-size: 0.24rem;
		display: inline-block;
		width: 100%;
		margin-bottom: 0;
		padding: 0.21rem 0;
		text-indent: 0.19rem;
		background: url("/static/img/public/down.png")no-repeat;
		background-position: 96%;
		color: $importFontColor;
	}
	
	.balk {
		padding-left: 0.39rem;
	}
	
	.balk2 {
		padding-left: 0.4rem;
	}
	
	.lists {
		background: #fff;
		.ul {
			padding: 0 0.24rem;
			li {
				width: 100%;
				float: left;
				height: 0.9rem;
				.left {
					float: left;
					span {
						font-size: 0.15rem;
					}
					span:nth-child(2) {}
				}
				.right {
					float: right;
					button {
						background: $titleBgColor;
						color: $whiteColor;
						margin-top: 0.12rem;
					}
				}
			}
		}
		.add {
			border-bottom: 1px solid #eeeeee;
		}
	}
	
	.mui-btn-right {
		font-size: 0.24rem;
		font-weight: 400;
		position: relative;
		display: inline-block;
		margin-bottom: 0;
		padding: 0.1rem 0.18rem;
		cursor: pointer;
		-webkit-transition: all;
		transition: all;
		-webkit-transition-timing-function: linear;
		transition-timing-function: linear;
		-webkit-transition-duration: 0.2s;
		transition-duration: 0.2s;
		text-align: center;
		vertical-align: top;
		white-space: nowrap;
		color: #333;
		border: 1px solid #ccc;
		border-radius: 3px;
		border-top-left-radius: 3px;
		border-top-right-radius: 3px;
		border-bottom-right-radius: 3px;
		border-bottom-left-radius: 3px;
		background-color: #fff;
		background-clip: padding-box;
	}
	
	.mui-checkbox input[type="checkbox"]:before,
	.mui-radio input[type="radio"]:before {
		font-family: Muiicons;
		font-size: 0.34rem;
		font-weight: 400;
		line-height: 1;
		text-decoration: none;
		// color: #aaa;
		border-radius: 0;
		background: 0 0;
		-webkit-font-smoothing: antialiased;
	}
	
	.mui-input-row label {
		padding-top: 0.22rem;
		padding-bottom: 0.22rem;
		background: $whiteColor;
		padding-left: 1rem;
	}
	
	.area {
		padding: 0 0.24rem;
		background: $whiteColor;
	}
	
	.area2 {
		padding: 0 .44rem;
		background: $whiteColor;
	}
	
	.mui_jiange {
		margin-left: 0.2rem;
	}
	
	.right_con {
		float: right;
	}
	
	.content_list {
		height: 1.4rem;
		background: rebeccapurple;
	}
	
	.left_conten {
		height: 0.98rem;
		width: 2.4rem;
		background: $titleBgColor;
		font-size: 0.24rem;
		color: white;
		text-align: left;
		box-sizing: border-box;
		padding-left: 0.13rem;
		padding-top: 0.1rem;
		display: inline-block;
	}
	
	.area6 {
		padding: 0.2rem 0.24rem;
		background: $whiteColor;
		text-align: left;
	}
	
	.tui {
		color: $warnColor;
		font-size: 0.23rem;
	}
	
	.mui-content2 {
		background: $whiteColor;
		margin-top: 0.2rem;
	}
	
	.left_code {
		display: inline-block;
		float: left;
		font-size: 0.24rem;
		color: $importFontColor;
		padding-top: 0.18rem;
	}
	
	.mui-blank_c {
		margin-top: 0.2rem;
	}
	
	.mui-grid-view.mui-grid-9 .mui-table-view-cell.mui-active2 {
		background-color: #f5f6f7;
		border: 1px solid #f07377;
		position: relative;
		border-radius:.03rem; 
		&::after {
			display: block;
			position: absolute;
			content: "";
			right: 0.1rem;
			bottom: 0.3rem;
			width: 0.34rem;
			height: 0.68rem;
			background: url("../../../static/img/public/right.png") no-repeat;
			background-size: 100% 100%;
			left: 57%;
		}
	}
	.mui-grid-view.mui-grid-9 .mui-table-view-cell{
		border: 1px solid transparent;
		flex: 1;
	}
	.replace{
		height: 2.75rem;
	}
</style>