<template>
	<div id="AccountBalance">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="ab_content bgColor ">
					<div class="item bg_j ma_t16  mui-clearfix">
						<div class="boryx_j pat_24 mui-col-xs-4 mui-col-sm-3 mui-pull-left" v-for="(item,index) in Account" :data-type="item.ACC_BAL_CD">
							<div class="text45_xj zyjuz_j">
								{{item.FULLNAME}}
							</div>
							<div class="text45_xj zyjuz_j">
								<CountUp :start-val="1" :end-val="item.ACC_BAL ? parseFloat(item.ACC_BAL) : 0" :duration="2" :decimals="2"></CountUp>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	import CountUp from '@/components/CountUp';
	export default {
		name: 'TransactionRecord',
		components: {
			CountUp
		},
		data() {
			return {
				
			}
		},
		beforeMount: function() {

		},
		created() {
			const that = this;
			this.$store.dispatch('getAccount','all');
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
			})
		},
		watch: {},
		computed: {
			Account(){
				var UserArr = this.$store.getters.getAccount;
				return UserArr.accBalInfo;
			}
		},
		methods: {

		},
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	input {
		font-size: .28rem;
	}
	
	.mui-input-row {
		font-size: .28rem;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.text_cscolor {
		color: $warnColor !important;
	}
	
	.borr_j {
		border-right: .02rem solid $whiteColor;
	}
	
	.hb {
		height: 100%;
	}
	
	.ovhide {
		overflow: hidden;
	}
	
	.i_conten {
		height: 3rem;
		display: flex;
		align-items: center;
	}
	
	.i_conten .c_text {}
	
	.bgColor {
		background: $bgColor;
	}
	
	.bg_j {
		background: $whiteColor;
	}
	
	.hui_j {
		background: $tipsFontColor;
	}
	
	.t_list {
		height: .5rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .26rem;
		color: $normalFontColor;
	}
	
	.juz_j {
		display: flex;
		align-items: center;
	}
	
	.ma_t24 {
		margin: .24rem 0;
	}
	
	.ma_t30 {
		margin-top: .3rem;
	}
	
	.ma_t40 {
		margin-top: .4rem;
	}
	
	.bg_j_color {
		background: $blueColor;
	}
	
	.boa_5 {
		border-radius: .1rem;
	}
	
	.ma_t16 {
		margin-top: .16rem;
	}
	
	.bor_b {
		border-bottom: .02rem solid $tipsFontColor;
	}
	
	.boryn_j {
		border-right: none !important;
	}
	
	.boryx_j {
		border-right: 0.02rem solid $bgColor;border-bottom: 0.02rem solid $bgColor;
		&:active{
			background: rgba($tipsFontColor,0.3);
		}
	}
	
	.borsz_j {
		border-top: .02rem solid $tipsFontColor;
		border-left: .02rem solid $tipsFontColor;
	}
	
	.bor_a {
		border: .02rem solid $tipsFontColor;
	}
	
	.bor_color {
		border: .02rem solid $blueColor;
	}
	
	.text_big_j {
		font-size: .55rem !important;
	}
	
	.zyjuz_j {
		display: flex;
		display: -webkit-flex;
		justify-content: space-around;
	}
	
	.imp_j {
		width: 100%;
		height: 100%;
		height: 1rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .32rem;
		color: $importFontColor;
	}
	
	.nav_j {
		width: 100%;
		height: 100%;
		height: .98rem;
		padding: .2rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.title_j {
		width: 100%;
		height: .92rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.list_j {
		width: 100%;
		height: .88rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .26rem;
		color: $normalFontColor;
		label {
			width: 100%;
			height: .88rem;
			padding: 0 .24rem;
			display: flex;
			display: -webkit-flex;
			align-items: center;
			font-size: .26rem;
			color: $normalFontColor;
		}
		input {
			width: 100%;
			height: .88rem;
			padding: 0 .24rem;
			display: flex;
			display: -webkit-flex;
			align-items: center;
			font-size: .26rem;
			color: $normalFontColor;
		}
	}
	
	.list:last-child {
		border-bottom: none;
	}
	
	.text_xj {
		width: 100%;
		height: .7rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.text45_xj {
		width: 100%;
		height: .45rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .24rem;
		color: $importFontColor;
	}
	
	.text35_xj {
		width: 100%;
		height: .35rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .22rem;
		color: $normalFontColor;
	}
	
	.paz_24 {
		padding: 0 .24rem;
	}
	
	.pat_24 {
		padding: .24rem 0;
	}
	
	.fz_j {
		height: .8rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.paa_24 {
		padding: .24rem;
	}
</style>