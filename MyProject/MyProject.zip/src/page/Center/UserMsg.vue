<template>
  <div id="UserMsg">
      <div class="stiky-box">
        <form action="">
            <div class="tr">
                    <label for="">会员名：</label>
                    <input type="text" placeholder="" v-model="UserInfo.USER_NAME" disabled>
            </div>    
            <div class="tr">
                    <label for="">真实姓名：</label>
                    <input v-if="isname" type="text" placeholder="请输入真实姓名" v-model="UserInfo.REAL_NAME" readonly="readonly">
                    <input v-else type="text" placeholder="请输入真实姓名" v-model="UserInfo.REAL_NAME">
            </div>    
            <div class="tr">
                    <label for="">电子邮箱：</label>
                    <input type="text" placeholder="请输入电子邮箱"  v-model="UserInfo.EMAIL">
            </div>    
            <div class="tr">
                <label class="mui-text-justify">密保问题</label>
				<input type="text" class="mui-input-clear Select" placeholder="请选择密保问题" v-model="CardVal" readonly="readonly">
            </div>    
            <div class="tr">
                    <label for="">密保：</label>
                    <input type="text" placeholder="密保答案" v-model="UserInfo.ANSWER">
            </div>    
            <div class="tr">
                    <label for="">微信：</label>
                    <input type="text" placeholder="选填"  v-model="UserInfo.WECHAT">
            </div>    
            <div class="tr">
                    <label for="">Q Q：</label>
                    <input type="text" placeholder="选填" v-model="UserInfo.QQ">
            </div>    
        </form>
      </div>
      <div class="stiky-footer">
          <button class="mybtn">修改</button>
      </div>

  </div>
</template>

<script>
import api from '@/api/userUtil';
export default {
    data () {
        return {
            question:[],//问题集合
            CardVal:"",
            info:{},
            suc:"",
            isname:true,
        }
    },
    mounted(){
        const that = this;
        that.isusername(that.UserInfo.REAL_NAME)
        this.getquestion()
        mui.init();
        mui.ready(function(){
            mui('.stiky-footer').on('tap','.mybtn',function(){
                that.info.ASK=that.CardVal;
                that.info.ANSWER=that.UserInfo.ANSWER;
                that.info.QQ=that.UserInfo.QQ;
                that.info.WECHAT=that.UserInfo.WECHAT;
                that.info.EMAIL=that.UserInfo.EMAIL;
                that.info.REAL_NAME=that.UserInfo.REAL_NAME;				
                that.Verify()   
            })

            mui('.tr').on('tap', '.Select', function() {
                const CardPiker = new mui.PopPicker();
                CardPiker.setData(that.question);
                CardPiker.show(function(items) {
                    that.CardVal = items[0]['text'];
                });
            })

        })



    },
    computed: {
        UserInfo(){
            return this.$store.getters.getUserInfo;
        },
    },
    methods: {
        getquestion() {//获取密保问题
            var that=this
            api.getquestion(function(data) {
                var data = JSON.parse(data);
                // that.CardVal = data[0].FULLNAME;
                that.CardVal = that.UserInfo.ASK;
                data.forEach((ele,index,arr) => {
                    var obj = {
                        value:ele.FULLNAME,
                        text:ele.ENCODE
                    }
                    that.question.push(obj);
                });
                // console.log( that.question)
            });
        },
        upuserinfo(postdata) {//修改个人资料
            var that=this;

            api.UpdateUserInfo(postdata,function(data) {
                if(data.state == "success"){
                    that.$toast("资料修改成功")
                    that.$store.dispatch('getUserInfo');
                }
            });
        },
        Verify(){
            var that=this;
            var reg = /^[a-zA-Z\u4e00-\u9fa5]/g;
            var eml = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/g;
            if(that.info.REAL_NAME == '' || that.info.REAL_NAME == undefined || that.info.REAL_NAME == null) {
                that.$alert('真实姓名不能为空！')
                return false;
            }
            if(!reg.test(that.UserInfo.REAL_NAME)){
                that.$alert('真实姓名不能含有数字空格等特殊符号！')
                return false;
            }
            if(that.UserInfo.EMAIL == '' || that.UserInfo.EMAIL == undefined || that.UserInfo.EMAIL == null){
                that.$alert('邮箱地址不能为空！')
                return false;
            }
            if(!eml.test(that.info.EMAIL)){
                that.$alert('邮箱格式错误！')
                return false;
            }
            if(that.info.ASK == '' || that.info.ASK == null ||that.info.ASK == undefined){
                that.$alert('密保问题不能为空')
                return false;
            }
            if(that.info.ANSWER == '' || that.info.ANSWER == null || that.info.ANSWER == undefined){
                that.$alert('密保答案不能为空')
                return false;
            }
            that.upuserinfo(that.info)
            return true
        },
        isusername(name){
            if(name == null || name == '' || name == undefined){
                this.isname=false
            }else{
                this.isname=true
            }
        }
    },
    created () {
    }
}
</script>

<style lang="scss" scoped>
    @import '../../../static/sass/public.scss';
    .tr{
        display:flex;
        font-size:0.28rem;
        padding:0.24rem;
        background:#fff;
        border-top: 1px solid #eee;
        label{
            flex:2;
            text-align: left;
        }
        input{
            flex:7;
            font-size:0.28rem;
            margin: 0;
            padding: 0;
            border:0;
            height: 0.4rem;
        }
    }
    .mybtn{
        width:95%;
        height: 0.88rem;
        background: $blueColor;
        font-size:0.32rem;
        color: #fff;
    }
    .stiky-box{
		min-height: 100%;
		padding-bottom: 1.8rem;
	}
	.stiky-footer{
		margin-top: -1.8rem;
    }
</style>

