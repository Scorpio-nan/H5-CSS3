<template>
	<!--  Flowdetails  -->
	<div id="CaptailDetail">
		<nav class="nav">
			<a href="javascript:;" class="nav-item" data-index="0" :class="index == 0?'active':''">存款</a>
			<a href="javascript:;" class="nav-item" data-index="1" :class="index == 1?'active':''">取款</a>
			<a href="javascript:;" class="nav-item" data-index="2" :class="index == 2?'active':''">赠金返点</a>
			<a href="javascript:;" class="nav-item" data-index="3" :class="index == 3?'active':''">额度转换</a>
		</nav>
		<div class="main">
			<nav class="thead">
				<a href="javascript:;" class="nav-item" v-for="val in thead">{{val}}</a>
			</nav>
			<!--  存款类型   -->
			<div class="table-flex">
				<Scroller :on-infinite="infinite" ref="Scroll" :loadingShow="loadingShow">
					<div class="table-content" v-show="index == 0">
						<table border="0" cellspacing="0" cellpadding="0">
							<tr v-for="(item,index) in accessMoneyData">
								<td>{{item.ORDER_MAKE_DTT.substr(5,11)}}</td>
								<td>{{paraDebit[item.LOAN_TYPE_CD].FULLNAME}}</td>
								<td v-if="item.STATUS_CD == 0"><span class="error">失败</span></td>
								<td v-else-if="item.STATUS_CD == 1"><span class="success">成功</span></td>
								<td v-else-if="item.STATUS_CD == 2"><span class="await">待审核</span></td>
								<td v-else-if="item.STATUS_CD == 3"><span class="await">预下单</span></td>
								<td v-else><span class="success">充值成功</span></td>
								<td>&yen;{{item.AMT.toFixed(1)}}</td>
							</tr>
						</table>
					</div>
					<!-- 取款类型   -->
					<div class="table-content" v-show="index == 1">
						<table border="0" cellspacing="0" cellpadding="0">
							<tr v-for="(item,index) in drawMoneyData">
								<td>{{item.ORDER_MAKE_DTT.substr(5,11)}}</td>
								<td>{{paraDebit[item.LOAN_TYPE_CD].FULLNAME}}</td>
								<td v-if="item.STATUS_CD == 0"><span class="error">失败</span></td>
								<td v-else-if="item.STATUS_CD == 1"><span class="success">成功</span></td>
								<td v-else-if="item.STATUS_CD == 2"><span class="await">待审核</span></td>
								<td v-else-if="item.STATUS_CD == 3"><span class="await">预下单</span></td>
								<td v-else><span class="success">充值成功</span></td>
								<td>&yen;{{item.AMT.toFixed(1)}}</td>
							</tr>
						</table>
					</div>
					<!-- 返点类型  -->
					<div class="table-content" v-show="index == 2">
						<table border="0" cellspacing="0" cellpadding="0">
							<tr v-for="(item,index) in returnMoneyData">
								<td>{{item.ORDER_MAKE_DTT.substr(5,11)}}</td>
								<td>{{paraDebit[item.LOAN_TYPE_CD].FULLNAME}}</td>
								<td v-if="item.STATUS_CD == 0"><span class="error">失败</span></td>
								<td v-else-if="item.STATUS_CD == 1"><span class="success">成功</span></td>
								<td v-else-if="item.STATUS_CD == 2"><span class="await">待审核</span></td>
								<td v-else-if="item.STATUS_CD == 3"><span class="await">预下单</span></td>
								<td v-else><span class="success">充值成功</span></td>
								<td>&yen;{{item.AMT.toFixed(1)}}</td>
							</tr>
						</table>
					</div>
					<!-- 额度转换类型  -->
					<div class="table-content" v-show="index == 3">
						<table border="0" cellspacing="0" cellpadding="0">
							<tr v-for="(item,index) in transformData">
								<td>{{item.TRANSFER_DTT.substr(5,11)}}</td>
								<td>{{getAcclib(item.ACC_BAL_CD)}}</td>
								<td v-if="item.TRANSFER_TYPE_CD == 1"><span class="success">转入</span></td>
								<td v-else><span class="error">转出</span></td>
								<td>&yen;{{item.TRANSFER_AMT.toFixed(1)}}</td>
							</tr>
						</table>
					</div>
				</Scroller>
			</div>
		</div>
	</div>
</template>

<script>
	import Scroller from '@/components/Scroller';
	import api from '@/api/userUtil';
	export default {
		name: 'CaptailDetail',
		components: {
			Scroller
		},
		data() {
			return {
				index: 0,
				loadingShow: true,
				accessMoneyData: [], 	//存款数组集合
				drawMoneyData: [], 		//取款数组集合
				returnMoneyData: [], 	//反水数集合
				transformData: [], 		//额度转换数组集合
				queryJson: {
					type_cd: '2-12,2-0,2-1,2-2,2-16,2-17,2-18,2-19,2-4,2-15,2-13,2-14,2-20,2-21,2-22,2-24' //默认查询方式
				},
				total: 0, 				//总页数
				page: 1, 				//当前页
				rows: 15, 				//每页显示的条数
				records: 0, 			//总记录数
				loadMore: false, 		//默认接口有数据，下拉加载用
				paraDebit: {
					"2-12": {
						"ENCODE": "2-12",
						"FULLNAME": "在线存款[QQ钱包]"
					},
					"2-0": {
						"ENCODE": "2-0",
						"FULLNAME": "在线存款[银联]"
					},
					"2-1": {
						"ENCODE": "2-1",
						"FULLNAME": "在线存款[微信]"
					},
					"2-2": {
						"ENCODE": "2-2",
						"FULLNAME": "在线存款[支付宝]"
					},
					"2-4": {
						"ENCODE": "2-4",
						"FULLNAME": "填单存款[银联]"
					},
					"2-13": {
						"ENCODE": "2-13",
						"FULLNAME": "填单存款[支付宝]"
					},
					"2-14": {
						"ENCODE": "2-14",
						"FULLNAME": "填单存款[微信]"
					},
					"2-15": {
						"ENCODE": "2-15",
						"FULLNAME": "填单存款[QQ钱包]"
					},
					"2-16": {
						"ENCODE": "2-16",
						"FULLNAME": "预留"
					},
					"2-17": {
						"ENCODE": "2-17",
						"FULLNAME": "预留"
					},
					"2-18": {
						"ENCODE": "2-18",
						"FULLNAME": "预留"
					},
					"2-19": {
						"ENCODE": "2-19",
						"FULLNAME": "预留"
					},
					"2-20": {
						"ENCODE": "2-20",
						"FULLNAME": "预留"
					},
					"2-21": {
						"ENCODE": "2-21",
						"FULLNAME": "预留"
					},
					"2-22": {
						"ENCODE": "2-22",
						"FULLNAME": "预留"
					},
					"2-24": {
						"ENCODE": "2-24",
						"FULLNAME": "预留"
					},
					"2-5": {
						"ENCODE": "2-5",
						"FULLNAME": "人工加款"
					},
					"2-6": {
						"ENCODE": "2-6",
						"FULLNAME": "代理转入"
					},
					"2-7": {
						"ENCODE": "2-7",
						"FULLNAME": "代理分润转入"
					},
					"2-8": {
						"ENCODE": "2-8",
						"FULLNAME": "代理存款"
					},
					"2-9": {
						"ENCODE": "2-9",
						"FULLNAME": "兑换积分"
					},
					"1-0": {
						"ENCODE": "1-0",
						"FULLNAME": "会员取款"
					},
					"1-1": {
						"ENCODE": "1-1",
						"FULLNAME": "返水派送"
					},
					"1-2": {
						"ENCODE": "1-2",
						"FULLNAME": "充值优惠"
					},
					"1-3": {
						"ENCODE": "1-3",
						"FULLNAME": "注册赠送"
					},
					"1-4": {
						"ENCODE": "1-4",
						"FULLNAME": "代理提款"
					},
					"1-5": {
						"ENCODE": "1-5",
						"FULLNAME": "彩金派送"
					},
					"1-6": {
						"ENCODE": "1-6",
						"FULLNAME": "人工减款"
					},
					"1-8": {
						"ENCODE": "1-8",
						"FULLNAME": "会员分润"
					},
					"2-23": {
						"ENCODE": "2-23",
						"FULLNAME": "代理转入"
					},
					"1-7": {
						"ENCODE": "1-7",
						"FULLNAME": "代理返水"
					},
					"1-9": {
						"ENCODE": "1-9",
						"FULLNAME": "代理分润代理转出"
					},
					"1-10": {
						"ENCODE": "1-10",
						"FULLNAME": "代理分润会员转出"
					}
				},
				thead: ['时间', '类型', '状态', '金额'], //列表表头
			}
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {

				mui('.nav').on('tap', '.nav-item', function() {
					var index = $(this).data('index');
					that.index = index;
					switch(index) {
						case 3:
							that.restRefresh();
							that.getTransferData();
							that.thead = ['时间', '平台', '类型', '金额'];
							break;
						default:
							that.init();
							that.thead = ['时间', '类型', '状态', '金额'];
							break;
					}
				})
			})
		},
		created() {
			const that = this;
			this.$store.dispatch('getAccountList');
			this.init();
		},
		computed: {
			getAccountList() {
				return this.$store.getters.getAccountList;
			}
		},
		methods: {
			//下拉加载更多
			infinite(finish) {
				const that = this;
				if(this.loadMore) {
					setTimeout(() => {
						that.loadingShow = false;
						finish(true);
					}, 1500)
					return;
				}
				setTimeout(() => {
					this.getDataJson();
					setTimeout(() => {
						finish();
					})
				}, 1500)
			},
			//初始化页面
			init() {
				switch(this.index) {
					case 0:
						this.restRefresh();
						this.queryJson = {
							type_cd: '2-12,2-0,2-1,2-2,2-16,2-17,2-18,2-19,2-4,2-15,2-13,2-14,2-20,2-21,2-22,2-24'
						};
						this.getDataJson();
						break;
					case 1:
						this.restRefresh();
						this.queryJson = {
							type_cd: '1-0'
						};
						this.getDataJson();
						break;
					case 2:
						this.restRefresh();
						this.queryJson = {
							type_cd: '1-1,1-2,1-3,1-5,1-8,2-23'
						};
						this.getDataJson();
						break;
					case 3:
						this.restRefresh();
						this.getDataJson();
						break;
				}
			},
			//数据加载
			getDataJson() {
				const that = this;
				var param = {
					type_cd: this.queryJson.type_cd,
					rows: this.rows,
					page: this.page,
					sidx: 'ID',
					sord: 'DESC'
				}
				api.GetOrderList(param, (res) => {
					var res = JSON.parse(res);
					if(res.rows.length > 0){
						this.loadMore = false;
						for(let i = 0; i < res.rows.length; i++) {
							if(that.index == 2) {
								that.returnMoneyData.push(res.rows[i]);
							} else if(that.index == 0) {
								that.accessMoneyData.push(res.rows[i]);
							} else {
								that.drawMoneyData.push(res.rows[i]);
							}
						}
						this.page++;
					}else{
						this.loadMore = true;
					}
					
				})
			},
			//重置加载数据
			restRefresh() {
				this.accessMoneyData = []; 	//存款数组集合
				this.drawMoneyData = []; 	//取款数组集合
				this.returnMoneyData = []; 	//反水数集合
				this.transformData = []; 	//额度转换数组集合
				this.total = 0; 			//总页数
				this.page = 1; 				//当前页
				this.rows = 15; 			//每页显示的条数
				this.records = 0; 			//总记录数
				this.loadMore = false; 		//下拉加载是否有更多数据
			},
			//获取额度转换类数据
			getTransferData() {
				var param = {
					rows: this.rows,
					page: this.page,
					sidx: 'ID',
					sord: 'DESC'
				}
				api.GetTransList(param, (res) => {
					var res = JSON.parse(res);
					if(res.rows.length > 0){
						this.loadMore = false;
						for(let i = 0; i < res.rows.length; i++) {
							res.rows[i].IN_INT_IDENT_CD = this.tranPlaType(res.rows[i].IN_INT_IDENT_CD);
							res.rows[i].OUT_INT_IDENT_CD = this.tranPlaType(res.rows[i].OUT_INT_IDENT_CD);
							this.transformData.push(res.rows[i])
						}
						this.page++;
					}else{
						this.loadMore = true;
					}
				})
			},
			//额度转换科目
			tranPlaType(val) {
				for(var x in this.getAccountList) {
					if(this.getAccountList[x].ENCODE == val) {
						return this.getAccountList[x].FULLNAME;
						break;
					}
				}
			},
			//通过额度转换类型返回转换名称
			getAcclib(type) {
				for(var i = 0; i < this.getAccountList.length; i++) {
					if(this.getAccountList[i]['ENCODE'] == type) {
						return this.getAccountList[i].FULLNAME;
					}
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	#CaptailDetail {
		display: flex;
		flex-direction: column;
		.main {
			flex: 1;
			display: flex;
			flex-direction: column;
		}
		.table-flex{
			flex: 1;
			position: relative;
		}
		.table-content {
			table {
				width: 100%;
				background: #fff;
				tr {
					td {
						font-size: 0.24rem;
						height: 0.66rem;
						@include border-1px(#ccc, bottom);
						width: 20%;
					}
				}
			}
		}
	}
	
	.nav {
		display: table;
		width: 100%;
		background: #fff;
		a {
			padding: 0.24rem 0;
			display: table-cell;
			font-size: 0.28rem;
			width: 20%;
		}
		.active {
			position: relative;
			color: $blueColor;
			&:after {
				display: block;
				content: '';
				height: 1px;
				width: 100%;
				background: $blueColor;
				position: absolute;
				bottom: 0;
				left: 0;
			}
		}
	}
	
	.thead {
		display: table;
		width: 100%;
		background: #fff;
		padding: 0.15rem 0;
		margin-top: 0.16rem;
		@include border-1px(#ccc, bottom);
		a {
			display: table-cell;
			width: 25%;
			font-size: 0.24rem;
			font-weight: 600;
		}
	}
	
	.fade-enter-active,
	.fade-leave-active {
		transition: opacity .35s;
	}
	
	.fade-enter,
	.fade-leave-to {
		opacity: 0;
	}
</style>