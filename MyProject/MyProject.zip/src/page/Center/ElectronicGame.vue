<template>
	<div id="ElectronicGame">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="Gamelist">
					<ul class="list-warpper ">
						<li class="list-item tgpClick" v-for="(glist,i) in game3List" :key="i"  >
							<a href="javascript:;" class="mui-block">  
								<div class="item-img" :data-code="glist.CODE" :data-id="glist.ID"> 
									<img :src="'static/img/temp/' + glist.CODE + '.png'" />
								</div>
								<div class="item-title mui-clearfix">
									<p class="mui-pull-left">{{glist.PARA_NAME}}</p>
									<span class="iconfont mui-pull-right scBtn" :data-id="glist.ID"  :class="glist.DELETE_IND*1 ? 'icon-xin' : 'icon-xin1' "></span>
								</div>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import web from '@/api/webUtil'
	export default {
		name: 'ElectronicGame',
		data() {
			return {
				gamelist:[],
				imgUrl_: lib.imgUrl,
			}
		},
		created(){
			var this_ = this;
			setTimeout(function(){
				if(this_.$store.getters.game33List.length == 0) {
					this_.$store.dispatch('getGame3List');
				}
			},100)
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				mui('.Gamelist').on('tap', '.item-img', function() {
					var code = $(this).data('code');
					var id = $(this).data('id');
					that.onItemClick(code, id);
				})

				mui('#ElectronicGame').on('tap', '.scBtn', function(e) {
					console.log("点击收藏")
					console.log(e)
					var id = $(this).data('id')
					var self = $(this);
					that.shoucang(id,self)
				})
			});
			setTimeout(function(){
				that.init();
			},120);
		},
		methods:{
			onItemClick(code, id){
				var this_=this
					if(code === 'ag_electronic' && id === 6) {
						if(!this_.isLogin) {
							this_.isLoginShowWarn = true;
							this_.LoginShowWarnText = '请先登录';
							return
						}
					} else {
						this.$router.push({
							path: '/ElectronicGameDtail',
							query: {
								gameId: id,
								gameCd: code
							}
						});
					}
			},
			init(){
				var that=this;
				for(var i=0;i<that.game3List.length;i++){
					var list={
						code:that.game3List[i].CODE,
						name:that.game3List[i].LOTTERY_TICKET_NAME
					};
					that.gamelist.push(list)
				}
				that.gamelist=JSON.stringify(that.gamelist)
			},
			shoucang(id,self){
				if(!this.islogin){
					this.$alert('您还未登录哦！请立即登录！');
					return false;
				}
				var that = this
				web.AddGameFavorite(2,9,id,function(data){
					data = JSON.parse(data);
					console.log("收藏接口返回",data)
					if(data.state == "success"){
						self.removeClass("icon-xin1").addClass('icon-xin');
						that.$toast("收藏成功")
					}else{
						self.removeClass("icon-xin").addClass('icon-xin1');
						that.$toast("取消成功")
					}
				})
			},
		},
		computed: {
			game3List() {
				return this.$store.getters.game33List;
			},
			islogin(){
				return this.$store.getters.checkLoginState;
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '../../../static/sass/public.scss';
	/*@media screen and (max-width: 376px) {
		
	}*/
	
	#ElectronicGame {}
	
	.Gamelist {
		padding: 0.24rem;
		padding-right: 0;
	}
	
	.list-warpper {
		text-align: center;
	}
	
	.list-item {
		/*display: inline-block;*/
		margin: 0 0.18rem 0.26rem 0;
		float: left;
	}
	
	.item-img {
		/*width: 3.4rem;
		height: 1.9rem;*/
		background: #fff;
		overflow: hidden;
		border-radius: 3px 3px 0 0;
		background: #fff url('../../../static/img/public/cai.png') no-repeat center;
		background-size: cover;
		img {
			display: block;
			width: 3.4rem;
			height: 1.9rem;
		}
	}
	
	.icon-xin {
		color: $warnColor;
	}
	
	.item-title {
		background: #eee;
		border-radius: 0 0 3px 3px;
		overflow: hidden;
		padding: 0.16rem 0.1rem;
		position: relative;
		p {
			font-size: 0.24rem;
		}
		.scBtn{
			position: absolute;
			right: 0;
			top: 0;
			width: 0.5rem;
			height: 100%;
			padding-top:0.14rem;
		}
	}
	
	@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) {
		.list-item {
			display: inline-block;
			margin: 0 0.18rem 0.26rem 0;
			float: inherit !important;
		}
		/*.item-img {
			background: #fff;
			overflow: hidden;
			border-radius: 3px 3px 0 0;
			background: #fff url('../../../static/img/public/cai.png') no-repeat center;
			background-size: cover;
		}
		.item-img img {
			display: block;
			width: 100%;
			height: auto;
		}*/
	}
	
</style>