<template>
	<div id="WeChatRecharge">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="w_potion">
					<ul>
						<li>
							<div class="potion_item ac">
								<div class="pic">
									<img src="static/img/public/home-hover@2x.png" />
								</div>
								<p>银行卡支付</p>
							</div>
						</li>
						<li>
							<div class="potion_item">
								<div class="pic">
									<img src="static/img/public/home-hover@2x.png" />
								</div>
								<p>银行卡支付</p>
							</div>
						</li>
						<li>
							<div class="potion_item">
								<div class="pic">
									<img src="static/img/public/home-hover@2x.png" />
								</div>
								<p>银行卡支付</p>
							</div>
						</li>
						<li>
							<div class="potion_item">
								<div class="pic">
									<img src="static/img/public/home-hover@2x.png" />
								</div>
								<p>银行卡支付</p>
							</div>
						</li>
					</ul>
				</div>
				<form>
					<div class="form_bag" style="margin-bottom:.17rem ;">
						<div class="mui-input-row">
							<label class="mui-text-justify">充值金额</label>
							<input type="text" class="mui-input-clear" placeholder="单笔10000元">
						</div>
						<div class="mui-input-row" style="border: none;">
							<label class="mui-text-justify">支付账号</label>
							<input type="text" class="mui-input-clear" placeholder="请输入真实帐号">
						</div>
					</div>
					<div class="form_bag">
						<div class="mui-input-row">
							<label class="mui-text-justify">选择帐号</label>
							<input type="text" class="mui-input-clear Select" placeholder="请选择开户银行" v-model="CardVal">
						</div>
						<div class="mui-input-row" style="border: none;">
							<label class="mui-text-justify">转账时间</label>
							<input type="text" class="mui-input-clear" placeholder="2018">
						</div>
					</div>
				</form>
				<div class="lists clearfix">
					<ul class="clearfix ul">
						<li>
							<div class="left"><span>户名：</span><span>{{huname}}</span></div>
							<div class="right"><button type="button" class="mui-btn">复制</button></div>
						</li>
						<li>
							<div class="left"><span>帐号：</span><span>{{accounts}}</span></div>
							<div class="right"><button type="button" class="mui-btn">复制</button></div>
						</li>
						<li>
							<div class="left"><span>地址：</span><span>{{address}}</span></div>
							<div class="right"><button type="button" class="mui-btn">复制</button></div>
						</li>
					</ul>
					<div class="prompt">
						<div class="wrap_content">
							<div class="p">微信转账步骤</div>
							<ul class="clearfix">
								<li>1、点击进入你的微信</li>
								<li>2、付款</li>
								<li>3、专项银行卡</li>
								<li>4、银行卡号</li>
							</ul>
							<p>温馨提示：使用小数点</p>
						</div>
					</div>
				</div>
				<div class="btn-group">
					<button type="button" class="mui-btn mui-btn-blue mui-btn-block mr-t-20 add-btn">提交</button>
				</div>
				<div class="out">
					<p>温馨提示</p>
					<p>若无法支付请更换通道</p>
				</div>

			</div>
		</div>

	</div>
</template>

<script>
	export default {
		name: 'BankCard',
		data() {
			return {
				huname: '呵呵',
				accounts: '呵呵',
				address: '菲律宾',
				Cardlist: [],
				CardVal: '--请选择银行--'
			}
		},
		beforeMount: function() {
			
		},
		created() {
			const that = this;
			$.getJSON('static/json/bankcard.json', function(res) {
				that.Cardlist = res;
			})
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				mui('.form_bag').on('tap', '.Select', function() {
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.Cardlist);
					CardPiker.show(function(items) {
						that.CardVal = items[0]['text'];
					});
				})
				mui('.btn-group').on('tap', '.add-btn', function() {
					mui(this).button('loading');
					$('.mui-btn-block .mui-spinner').css({
						'width': '18px',
						'height': '18px'
					})
					setTimeout(function() {
						mui(this).button('reset');
					}.bind(this), 2000);
				})

			})
		},
		watch: {},
		computed: {},
		methods: {
			
		},
	}
</script>

<style scoped lang="scss">
@import '../../../static/sass/public.scss';
	#WeChatRecharge {
		background: $bgColor;
		/*padding-top: 1rem;*/
	}
	
	input {
		font-size: 0.28rem;
	}
	
	.mui-input-row {
		font-size: 0.28rem;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.mr-t-20 {
		margin-top: 0.7rem;
	}
</style>