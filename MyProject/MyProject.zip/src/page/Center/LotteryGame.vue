<template>
	<div id="LotteryGame">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<ul class="mui-clearfix game-list">
					<li class="mui-pull-left mui-item" v-for="(item,index) in arr">
						<a href="javascript:;" class="inline-block">
							<div class="item-img" :data-object="JSON.stringify(item)">
								<img :src="'static/img/temp/'+ item.CODE+'.png'" />
							</div>
							<div class="item-title mui-clearfix">
								<p class="mui-pull-left">{{item.PARA_NAME}}</p>
								<span class="iconfont  mui-pull-right scBtn" :data-id="item.ID" :class="item.DELETE_IND*1 ? 'icon-xin' : 'icon-xin1' "></span>
							</div>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</template>

<script>
	import WebApi from '@/api/webUtil.js';
	export default {
		name: 'LotteryGame',
		data() {
			return {
				arr: []
			}
		},
		mounted() {
			const that = this;
			mui.init();

			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			})

			mui.ready(function() {
				mui('#LotteryGame').on('tap', '.item-img', function() {
					var obj = $(this).data('object');
					that.Routerpath(obj.CODE)
					that.$router.push({
						path: that.Routerpath(obj.CODE),
						query: {
							id: obj.ID,
							code: obj.CODE,
							name: obj.PARA_NAME,
							title: obj.PARA_NAME,
							Value: Math.random()
						}
					});

				})
				mui('#LotteryGame').on('tap', '.scBtn', function() {
					var id = $(this).data('id')
					var self = $(this);
					that.shoucang(id, self)
				})

			})
			that.init();
		},
		methods: {
			init() {
				var that = this;
				WebApi.GetMobileList(2, function(data) {
					that.arr = data
				})
			},
			shoucang(id, self) {
				if(!this.islogin) {
					this.$alert('您还未登录哦！请立即登录！');
					return false;
				}
				var that = this
				WebApi.AddGameFavorite(2, 2, id, function(data) {
					data = JSON.parse(data);
					if(data.state == "success") {
						self.removeClass("icon-xin1").addClass('icon-xin');
						that.$toast("收藏成功")
					} else {
						self.removeClass("icon-xin").addClass('icon-xin1');
						that.$toast("取消成功")
					}
				})
			},
			Routerpath(code) {
				if(code == 'cqssc' || code == 'xjssc' || code == 'jsssc' || code == 'tjssc') {
					return '/ssc';
				} else if(code.indexOf("k3") >= 0) {
					return '/cp3';
				} else if(code.indexOf("11x5") >= 0) {
					return '/cp11';
				} else if(code == 'tjklsf' || code == 'gdklsf' || code == 'cqklsf') {
					return '/gdklsf';
				} else if(code == 'mlaft' || code == 'jspk10' || code == 'bjpk10') {
					return '/bjpk10';
				} else if(code == 'hk6' || code == 'jisuhk6') {
					return '/hk6';
				} else {
					return '/' + code;
				}
			},
		},
		computed: {
			islogin() {
				return this.$store.getters.checkLoginState;
			},
		}
	}
</script>

<style scoped lang="scss">
	@import '../../../static/sass/public.scss';
	.mui-in-block {
		width: 100%;
		padding: 0.24rem;
		text-align: center;
		padding-right: 0;
	}
	
	.game-list {
		padding: 0.24rem;
		padding-right: 0;
	}
	
	.item-img {
		width: 2.2rem;
		height: 1.6rem;
		background: #fff;
		border-radius: 3px 3px 0 0;
		padding-top: 10px;
		background: #fff url('../../../static/img/public/cai.png') no-repeat center;
		background-size: cover;
		img {
			display: inline-block;
			height: 1.2rem;
			width: 1.2rem;
			margin: 0 auto;
		}
	}
	
	.icon-xin {
		color: red;
	}
	
	.item-title {
		background: #eee;
		border-radius: 0 0 3px 3px;
		padding: 0.12rem 0.1rem;
		position: relative;
		p {
			font-size: 0.24rem;
		}
		.scBtn {
			position: absolute;
			right: 0;
			top: 0;
			width: 0.5rem;
			height: 100%;
			padding-top: 0.14rem;
		}
	}
	
	.mui-item {
		margin: 0 0.19rem 0.28rem 0;
	}
</style>