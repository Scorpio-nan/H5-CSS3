<template>
	<div id="TransferAccount" class="hei_toum_j wh100 posia z_index tc">
		<div id="item" class="item  tc_item posia  paz_24  mui-clearfix">

			<div  class="boryx_huicolor_j  bg_j pat_24 mui-col-xs-4 mui-col-sm-3 mui-pull-left">
				<div class="text45_xj">
					我的钱包
				</div>
			</div>
			<div class="boryx_huicolor_j bg_j_color bg_j pat_24 mui-col-xs-4 mui-col-sm-3 mui-pull-left">
				<div class="text45_xj">
					体育
				</div>
			</div>
			<div class="boryx_huicolor_j bg_j pat_24 mui-col-xs-4 mui-col-sm-3 mui-pull-left">
				<div class="text45_xj">
					AG真人额度
				</div>
			</div>
			<div class="boryx_huicolor_j bg_j pat_24 mui-col-xs-4 mui-col-sm-3 mui-pull-left">
				<div class="text45_xj">
					BBIN真人额度
				</div>
			</div>
			<div class="boryx_huicolor_j bg_j pat_24 mui-col-xs-4 mui-col-sm-3 mui-pull-left">
				<div class="text45_xj">
					我的钱包
				</div>
			</div>
			<div class="boryx_huicolor_j  bg_j pat_24 mui-col-xs-4 mui-col-sm-3 mui-pull-left">
				<div class="text45_xj">
					体育
				</div>
			</div>
			<div class="boryx_huicolor_j bg_j pat_24 mui-col-xs-4 mui-col-sm-3 mui-pull-left">
				<div class="text45_xj">
					AG真人额度
				</div>
			</div>
			<div class="boryx_huicolor_j bg_j pat_24 mui-col-xs-4 mui-col-sm-3 mui-pull-left">
				<div class="text45_xj">
					BBIN真人额度
				</div>
			</div>

		</div>
	</div>
</template>
<script>
	export default {
		name: 'TransferAccount',
		data() {
			return {
				Wallet: 666,
				Wallet1: 66,
				accounts: '呵呵',
				address: '菲律宾',
				datalist1: [],
				CardVal: '工商银行'
			}
		},
		beforeMount: function() {

		},
		created() {
			const that = this;
			$.getJSON('static/json/LotteryGameReturnWater.json', function(res) {
				that.datalist1 = res;
			});
			$.getJSON('static/json/bankcard.json', function(res) {
				that.Cardlist = res;
			})
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				mui('#item').on('tap', '.bg_j', function() {
					that.$store.commit('transferaccount');
					that.$emit("type_xiab",$(this).children('.text45_xj').html())
				});
				mui('.btn-group').on('tap', '.add-btn', function() {
					mui(this).button('loading');
					$('.mui-btn-block .mui-spinner').css({
						'width': '18px',
						'height': '18px'
					})
					setTimeout(function() {
						mui(this).button('reset');
					}.bind(this), 2000);
				})
			})
		},
		watch: {},
		computed: {},
		methods: {

		},
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	input {
		font-size: .28rem;
		padding: 0;
		height: inherit;
		margin: 0;
	}
	
	.width_80 {
		width: 80% !important;
	}
	
	.mui-input-row {
		font-size: .28rem;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.tc {
		top: 0;
	}
	
	.tc_item {
		width: 100%;
		bottom: 2rem;
	}
	
	.z_index {
		z-index: 1111;
	}
	
	.bgColor {
		background: $bgColor;
	}
	
	.bg_j {
		background: $whiteColor;
	}
	
	.hui_j {
		background: $tipsFontColor;
	}
	
	.hei_toum_j {
		background: rgba(0, 0, 0, .6);
	}
	
	.bg_j_color {
		background: $blueColor;
	}
	
	.text_cscolor {
		color: $warnColor !important;
	}
	
	.text_lscolor {
		color: $blueColor !important;
	}
	
	.ma_t16 {
		margin-top: .16rem;
	}
	
	.ma_tx24 {
		margin: .24rem 0;
	}
	
	.ma_t30 {
		margin-top: .3rem;
	}
	
	.ma_t40 {
		margin-top: .4rem;
	}
	
	.paz_24 {
		padding: 0 .24rem;
	}
	
	.pat_24 {
		padding: .24rem 0;
	}
	
	.paa_24 {
		padding: .24rem;
	}
	
	.boa_5 {
		border-radius: .1rem;
	}
	
	.boa_50 {
		border-radius: 50%;
	}
	
	.wh120 {
		width: 1.2rem;
		height: 1.2rem;
	}
	
	.wh100 {
		width: 100%;
		height: 100%;
	}
	
	.posif {
		position: fixed;
	}
	
	.posia {
		position: absolute;
	}
	
	.posir {
		position: relative;
	}
	
	.borr_j {
		border-right: .02rem solid $whiteColor;
	}
	
	.bor_b {
		border-bottom: .02rem solid $tipsFontColor;
	}
	
	.boryn_j {
		border-right: none !important;
	}
	
	.born_j {
		border: none !important;
	}
	
	.boryx_j {
		border-right: .02rem solid $tipsFontColor;
		border-bottom: .02rem solid $tipsFontColor;
	}
	
	.boryx_color_j {
		border-right: .07rem solid $bgColor;
		border-bottom: .07rem solid $bgColor;
	}
	
	.boryx_huicolor_j {
		border-right: .07rem solid rgba(0, 0, 0, .6);
		border-bottom: .07rem solid rgba(0, 0, 0, .6);
	}
	
	.borsz_j {
		border-top: .02rem solid $tipsFontColor;
		border-left: .02rem solid $tipsFontColor;
	}
	
	.bor_a {
		border: .02rem solid $tipsFontColor;
	}
	
	.bora10_j {
		border: .1rem solid $tipsFontColor;
	}
	
	.bor_color {
		border: .02rem solid $blueColor;
	}
	
	.hb {
		height: 100%;
	}
	
	.ovhide {
		overflow: hidden;
	}
	
	.i_conten {
		height: 3rem;
		display: flex;
		align-items: center;
	}
	
	.sxdq_j {
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	
	.sxzyjuz_j {
		display: -webkit-flex;
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	
	.sxjuz_j {
		display: flex;
		display: -webkit-flex;
		align-items: center;
	}
	
	.zyjuz_j {
		display: flex;
		display: -webkit-flex;
		justify-content: space-around;
	}
	
	.h98 {
		height: .98rem !important;
	}
	
	.h180 {
		height: 1.8rem !important;
	}
	
	.text_big_j {
		font-size: .55rem !important;
		font-weight: bold;
	}
	
	.imp_j {
		width: 100%;
		height: 100%;
		height: 1rem;
		padding: 0 .24rem;
		font-size: .32rem;
		color: $importFontColor;
	}
	
	.nav_j {
		width: 100%;
		height: 100%;
		height: .98rem;
		padding: .2rem;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.title_j {
		width: 100%;
		height: .92rem;
		padding: 0 .24rem;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.list_j {
		width: 100%;
		height: .88rem;
		padding: 0 .24rem;
		font-size: .26rem;
		color: $normalFontColor;
		label {
			height: .88rem;
			padding: 0 .24rem;
			font-size: .26rem;
			color: $normalFontColor;
		}
		input {
			height: .88rem;
			padding: 0 .24rem;
			font-size: .26rem;
			color: $normalFontColor;
		}
	}
	
	.t_list {
		height: .5rem;
		font-size: .26rem;
		color: $normalFontColor;
	}
	
	.text_xj {
		width: 100%;
		height: .7rem;
		padding: 0 .24rem;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.text45_xj {
		width: 100%;
		height: .45rem;
		font-size: .24rem;
		color: $importFontColor;
	}
	
	.text35_xj {
		width: 100%;
		height: .35rem;
		font-size: .22rem;
		color: $normalFontColor;
	}
	
	.fz_j {
		height: .8rem;
		padding: 0 .24rem;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.list:last-child {
		border-bottom: none;
	}
</style>