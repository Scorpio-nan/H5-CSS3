<template>
	<div id="UserMsg">
		<div class="stiky-box">
			<ul class="mui-table-view mui-table-view-chevron mr-t-8">
				<li class="mui-table-view-cell ">
					<a href="javascript:;" class="mui-text-left list-font">投诉标题:<input type="text" placeholder="请输入标题" v-model="title"></a>
				</li>
				<li class="mui-table-view-cell click1">
					<a href="javascript:;" class="mui-text-left list-font">投诉类型:<span class="cls">{{inputVal}}</span><span class="iconfont icon-xiangxia1 mui-pull-right mr-r " :class="hide?'rotate1':'rotate2'"></span></a>
				</li>
				<li class="mui-table-view-cell ">
					<a href="javascript:;" class="mui-text-left list-font">联系电话:<input type="text" placeholder="请输入您的手机号以便我们跟您联系" v-model="tel"></a>
				</li>
			</ul>
			<div class="text">
				<textarea name="" rows="" cols="" placeholder="请输入您遇到的问题或宝贵的建议..." v-model="content"></textarea>
				<span class="tip">500字以内</span>
			</div>

			<!-- <ul class="mui-table-view mui-table-view-chevron mr-t-8 yijian">
            <li class="mui-table-view-cell" v-for="(item,i) in arr" :key="i">
                <a href="javascript:;" class="mui-text-left list-font">{{item.text}}</a>
            </li>
        </ul> -->
		</div>
		<div class="stiky-footer">
			<button class="mybtn">提交</button>
		</div>

	</div>
</template>

<script>
	import UserApi from '@/api/userUtil.js';
	export default {
		data() {
			return {
				arr: [],
				hide: false,
				inputVal: '',
				content: "", //内容
				tel: "",
				title: "",
				type: "",
				form: {}
			}
		},
		mounted() {
			const that = this;
			that.getSugesstionType()
			mui.init();
			mui.ready(function() {
				// Scroll 区域
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});

				// mui('.stiky-box').on('tap', '.click5', function() {
				//     that.$router.push({
				//         path: '/'
				//     })
				// })

				mui('.stiky-footer').on('tap', '.mybtn', function() {
					console.log("1111")
					that.subSugesstion();

					// console.log(that.form)
				})

				mui('.stiky-box').on('tap', '.click1', function() {
					that.hide = !that.hide
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.arr);
					CardPiker.show(function(items) {
						that.inputVal = items[0]['text'];
						that.type = items[0]['value'];
					});
				})
			})
		},
		watch: {
			inputVal(val) {
				if(val) {
					this.hide = false
				}
			}
		},
		methods: {
			getSugesstionType() { //获取意见类型
				var that = this;
				UserApi.GetSugesstionType((data) => {
					data.forEach((ele, index, arr) => {
						var obj = {
							text: ele.FULLNAME,
							value: ele.ENCODE
						}
						that.arr.push(obj);
					});
				})
			},
			subSugesstion() { //提交意见
				var that = this;
					
					var param = {
						attr1:that.type,
						title:that.title,
						TELPHONE:that.tel,
						complain_content:that.content
					}
					
					if(this.checkForm()){
						UserApi.SubSugesstion(param, (data) => {
							if(data.state == 'success') {
								that.$alert("提交成功")
								that.content= "" //内容
								that.tel=""
								that.title=""
							}
						})
					}
			},
			checkForm: function() {
				var that = this;
				var telReg = /^\d{11}$/;
				if(that.title == '' || that.title == null) {
					that.$toast("标题不能为空")
					return false;
				} else if(that.title.length < 5) {
					that.$toast("标题长度不能小于5个字")
					return false;
				} else if(that.title.length > 20) {
					that.$toast("标题长度不能超过20位")
					return false;
				} else if(that.inputVal == '' || that.inputVal == null) {
					that.$toast("请选择提交类型")
					return false;
				} else if(that.tel == null || that.tel == '') {
					that.$toast('联系方式不能为空');
					return false;
				} else if(telReg.test(that.tel) == false) {
					that.$toast('手机号码格式不正确');
					return false;
				} else if(that.content == '' || that.content == null) {
					that.$toast('内容不能为空');
					return false;
				} else if(that.content.length < 5) {
					that.$toast('内容不能少于5个字');
					return false;
				}
				return true;
			},
		}
	}
</script>

<style lang="scss" scoped>
	@import '../../../static/sass/public.scss';
	.mui-table-view-cell {
		a {
			font-size: 0.28rem;
		}
	}
	
	.iconfont {
		font-size: 0.36rem;
		color: $blueColor;
		margin-right: 0.16rem;
		color: #ccc;
	}
	
	.rotate1 {
		transform: rotate(0deg);
	}
	
	.rotate2 {
		transform: rotate(-90deg);
	}
	
	.click1>a {
		padding-right: 0.24rem;
	}
	
	.cls {
		padding-left: 0.24rem;
	}
	
	.yijian {
		position: fixed;
		width: 100%;
		left: 0;
		bottom: 0;
		// transform: translate(-50%,-50%);
	}
	
	ul {
		background: $bgColor;
		margin-top: 0.16rem;
		input {
			border: 0;
			height: 0.4rem;
			margin: 0;
			font-size: 0.28rem
		}
		li {
			a {
				background: #fff;
			}
		}
	}
	
	.mui-table-view-cell:after {
		left: 0;
		background-color: #eee;
	}
	
	.mui-navigate-right:after,
	.mui-push-left:after,
	.mui-push-right:after {
		font-size: 0.46rem;
		color: $normalFontColor;
	}
	
	.stiky-box {
		min-height: 100%;
		padding-bottom: 1.8rem;
	}
	
	.stiky-footer {
		margin-top: -1.8rem;
		p {
			font-size: 0.24rem;
			color: $normalFontColor;
		}
	}
	
	.text {
		background: #fff;
		padding: 0.14rem 0.24rem;
		margin-top: 0.2rem;
		position: relative;
		textarea {
			border-radius: 3px;
			text-align: left;
			color: $importFontColor;
			font-size: 0.28rem;
			padding: 0.12rem;
			height: 2.5rem;
		}
		.tip {
			position: absolute;
			right: 0.4rem;
			bottom: 0.2rem;
			color: $tipsFontColor;
			font-size: 0.28rem;
		}
	}
	
	.mybtn {
		margin-top: 0.38rem;
		width: 94%;
		height: 0.88rem;
		font-size: 0.28rem;
		color: #fff;
		background-color: $blueColor;
		border: 0;
	}
	
	.mui-table-view:before {
		display: none;
	}
</style>