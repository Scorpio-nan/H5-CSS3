<template>
	<div id="Promotions">
		<div class="mui-scroll-wrapper" id="mui-Scroll">
			<div class="mui-scroll">
				<div class="promotion-container">
					<div class="promotion-item">
						<div class="pro-img">
							<img src="static/img/public/sale1.png" />
						</div>
						<div class="pro-discciption">
							<p class="pro-tit mui-text-left">女忧荷官:存100送100优惠大奖送不停</p>
							<p class="pro-txt mui-clearfix">
								<span class="pro-time mui-pull-left"><span class="iconfont icon-icon-26"></span>2018-02-16~2018-03-16</span>
								<span class="pro-icon mui-pull-right mui-icon mui-icon-arrowright"></span>
							</p>
						</div>
					</div>
				</div>
				<div class="promotion-container">
					<div class="promotion-item">
						<div class="pro-img">
							<img src="static/img/public/sale2.png" />
						</div>
						<div class="pro-discciption">
							<p class="pro-tit mui-text-left">女忧荷官:存100送100优惠大奖送不停</p>
							<p class="pro-txt mui-clearfix">
								<span class="pro-time mui-pull-left"><span class="iconfont icon-icon-26"></span>2018-02-16~2018-03-16</span>
								<span class="pro-icon mui-pull-right mui-icon mui-icon-arrowright"></span>
							</p>
						</div>
					</div>
				</div>
				<div class="promotion-container">
					<div class="promotion-item">
						<div class="pro-img">
							<img src="static/img/public/sale1.png" />
						</div>
						<div class="pro-discciption">
							<p class="pro-tit mui-text-left">女忧荷官:存100送100优惠大奖送不停</p>
							<p class="pro-txt mui-clearfix">
								<span class="pro-time mui-pull-left"><span class="iconfont icon-icon-26"></span>2018-02-16~2018-03-16</span>
								<span class="pro-icon mui-pull-right mui-icon mui-icon-arrowright"></span>
							</p>
						</div>
					</div>
				</div>
				<div class="promotion-container">
					<div class="promotion-item">
						<div class="pro-img">
							<img src="static/img/public/sale2.png" />
						</div>
						<div class="pro-discciption">
							<p class="pro-tit mui-text-left">女忧荷官:存100送100优惠大奖送不停</p>
							<p class="pro-txt mui-clearfix">
								<span class="pro-time mui-pull-left"><span class="iconfont icon-icon-26"></span>2018-02-16~2018-03-16</span>
								<span class="pro-icon mui-pull-right mui-icon mui-icon-arrowright"></span>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: 'Promotions',
		data() {
			return {

			}
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				// Scroll 区域
				mui('#mui-Scroll').scroll({
					deceleration: 0.0005
				});

				mui('.mui-scroll').on('tap', '.promotion-item', function() {
					that.$router.push({
						path: '/PromotionsDtail'
					})
				})
			})
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	/*	@import '~static/css/fonts.css';*/
	
	#Promotions {
		.promotion-container {
			padding: 0.24rem;
		}
		.promotion-item {
			border-radius: 3px;
			overflow: hidden;
		}
		.pro-img {
			height: auto;
			img {
				display: block;
				width: 100%;
				height: 100%;
			}
		}
		.pro-time {
			color: #5da9ff;
		}
		.pro-discciption {
			padding: 0.16rem 0.16rem 0.1rem 0.16rem;
			background: $whiteColor;
			p {
				font-size: 0.24rem;
				line-height: 0.32rem;
			}
			.mui-icon {
				font-size: 14px;
			}
		}
	}
	.icon-icon-26{
		margin-right: .15rem;
		vertical-align: text-top;
	}
	.pro-time{
		margin-top: .1rem;
	}
</style>