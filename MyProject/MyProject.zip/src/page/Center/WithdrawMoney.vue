<template>
	<div id="WithdrawMoney">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="wm_content mui-text-left">
					<div class="item ma_t16">
						<div class="list_j bor_b">
							<div class="mui-col-xs-4 mui-text-left mui-pull-left leftcolor">
								提款银行
							</div>
							<div class="mui-col-xs-6 mui-text-left Select mui-pull-left">
								<div class=" mui-text-left mui-pull-left ">
									<div class="">{{CardVal.bank}}</div>
								</div>
							</div>
							<div class="mui-col-xs-2 mui-text-right mui-pull-right">
								<span class="mui-icon mui-icon-arrowdown Select"></span>
							</div>
						</div>
						<div class="list_j bor_b border-1px">
							<div class="mui-col-xs-4 mui-text-left mui-pull-left leftcolor">
								银行账号
							</div>
							<div class="mui-col-xs-6 mui-text-left mui-pull-left">
								<div class="mui-col-xs-8 mui-text-left mui-pull-left ">
									<div class="">{{CardVal.accounts}}</div>
								</div>
							</div>
						</div>
						<div class="list_j bor_b">
							<div class="mui-col-xs-4 mui-text-left mui-pull-left leftcolor">
								账户名
							</div>
							<div class="mui-col-xs-8 mui-text-left mui-pull-left">
								<div class="mui-col-xs-6 mui-text-left mui-pull-left ">
									<div class="">{{CardVal.username}}</div>
								</div>
							</div>
						</div>
					</div>
					<div class="tie bor_b ma_t16 bg_j ovhide zindex">
						<div class="title_j leftcolor">
							提现金额
						</div>
						<div class="mui-text-left text_big_j title_j ovhide">
							<sub class="mui-col-xs-2 mui-pull-left thisrmb">¥</sub>
							<input type="number" class="mui-pull-left mui-col-xs-10 width_80 mui-input-clear born_j text_big_j placeholderColor" placeholder="请输入提款金额" v-model="entryMoney">
							<a id="reset" href="javascript:;" class="iconfont icon-delete clear" v-if="resetBtn"></a>
						</div>
					</div>
					<div class="text_xj bg_j">
						<div class="mui-col-xs-6 mui-text-left mui-pull-left maxtotle">
							最大可取现金额{{maxDraw}}
						</div>
						<div class="mui-col-xs-6 mui-text-right mui-pull-left text_lscolor">
							全部提现
						</div>
					</div>
					<div class="item bg_j ma_t16">
						<div class="list_j bor_b ">
							<div class="mui-input-row">
								<label class="leftcolor padlef">取款密码:</label>
								<input type="password" class="mui-input-password" placeholder="请输入取款密码" v-model="password">
							</div>
						</div>
						<div class="list_j bor_b ">
							<div class="mui-input-row">
								<label class="leftcolor padlef answerLast">备注:</label>
								<input type="text" class="mui-input-clear1 " placeholder="取款备注" v-model="Remarks">
							</div>
						</div>
					</div>
					<div class="btn-group ma_t40">
						<button type="button" class="mui-btn mui-btn-blue mui-btn-block  add-btn">提交</button>
					</div>
					<div class=" fz_j">
						*温馨提示：最低取款额度{{userGroup.MIN_DRAW_AMT}}
					</div>
					<div class=" fz_j" v-if="freeCount<=0&&userGroup.WITHDRAWAL_RATE>0">
						需收取手续费{{(userGroup.WITHDRAWAL_RATE*100).toFixed(2)}}%
					</div>
					<div class=" fz_j" v-if="userGroup.WIT_ADMINISTRATIVE_AMT>0">
						需行政费用{{userGroup.WIT_ADMINISTRATIVE_AMT}}
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	import UserApi from '@/api/userUtil.js';
	export default {
		name: 'WithdrawMoney',
		props: {
			Value: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				resetBtn: false,
				entryMoney: null,
				maxDraw: 0, //最大可取现金额
				freeCount: 3, //免费取款次数
				CardVal: {
					ID: '',
					username: '',
					accounts: '',
					bank: '',
				},
				Cardlist: '',
				CardlistShow: [],
				Remarks: '',
				password: '',
				isShow: false,
				entryMoney: '' //输入提款input框的内容
			}
		},
		beforeMount: function() {},
		created() {
			const that = this;
			that.GetDrawBankList(); //获取取款银行卡信息
			that.GetPayFees();
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {

				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				mui('.list_j').on('tap', '.Select', function() {
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.CardlistShow);
					CardPiker.show(function(items) {
						var id = items[0]['value']
						for(var i = 0; i < that.Cardlist.length; i++) {
							if(that.Cardlist[i].ID == id) {
								that.CardVal.username = Array(that.Cardlist[i].PAY_NAME.length).join('*') + that.Cardlist[i].PAY_NAME.substr(-1); //默认取第一张银行卡
								that.CardVal.accounts = '**** **** **** ' + that.Cardlist[i].PAY_ACCOUNT.substr(that.Cardlist[i].PAY_ACCOUNT.length - 4);
								that.CardVal.bank = that.Cardlist[i].PAY_BANK;
								that.CardVal.ID = that.Cardlist[i].ID;
							}
						}
					});
				});

				mui('.btn-group').on('tap', '.add-btn', function() {
					mui(this).button('loading');
					$('.mui-btn-block .mui-spinner').css({
						'width': '18px',
						'height': '18px'
					})
					that.SubWithDraw();
					setTimeout(function() {
						mui(this).button('reset');
					}.bind(this), 2000);
				});

				mui('.text_xj').on('tap', '.text_lscolor', function() {
					that.entryMoney = that.maxDraw;
				});

				mui('body').on('tap', '.icon-delete', function() {
					that.entryMoney = ''
				}); //清空请输入提款金额的内容

			})
		},
		watch: {
			entryMoney(val) {
				if(val != '') {
					this.resetBtn = true;
				} else {
					this.resetBtn = false;
				}
			}
		},
		computed: {
			userGroup() {
				return this.$store.getters.getUserGroup;
			},
		},
		methods: {
			onchange() {
				console.log(this.entryMoney)
				//				if(this.entryMoney){
				//					this.isShow = true
				//				}
			},
			initNativeObjects() {
				if(mui.os.android) {
					var main = plus.android.runtimeMainActivity();
					var Context = plus.android.importClass("android.content.Context");
					InputMethodManager = plus.android.importClass("android.view.inputmethod.InputMethodManager");
					imm = main.getSystemService(Context.INPUT_METHOD_SERVICE);
				} else {
					nativeWebview = plus.webview.currentWebview().nativeInstanceObject();
				}
			},
			showSoftInput() {
				if(mui.os.android) {
					imm.toggleSoftInput(0, InputMethodManager.SHOW_FORCED);
				} else {
					nativeWebview.plusCallMethod({
						"setKeyboardDisplayRequiresUserAction": false
					});
				}
				setTimeout(function() {
					var inputElem = document.querySelector('input');
					inputElem.focus();
					inputElem.parentNode.classList.add('mui-active'); //第一个是search，加上激活样式
				}, 200);
			},
			SubWithDraw() { //提交提款
				const that = this;
				if(that.validate() == false) {
					return;
				};
				var postdata = {
					DrawPass: $.md5($.trim(that.password)),
					DrawMoney: parseFloat(that.entryMoney),
					Desc: that.Remarks,
					CardID: that.CardVal.ID
				};
				UserApi.SubWithDraw(postdata, function(data) {
					if(data.state == 'success') {
						that.$alert('您的信息已经提交，我们的客服人员会尽快处理');
						that.GetPayFees(); //刷新金额咯
					} else {
						that.$toast(data.message);
						that.password = null;
					};
				})
			},
			GetPayFees() { //获取手续费，最大取款金额信息
				var that = this;
				UserApi.GetPayFees(0, function(data) {
					if(data.length > 1) {
						var feeArr = data.split(',');
						that.maxDraw = feeArr[1];
						that.freeCount = feeArr[2];
					}
				});
			},
			validate() {
				var Vreg = /^[0-9]+\.{0,1}[0-9]{0,2}$/;
				if(this.entryMoney == null || this.entryMoney == '' || this.entryMoney <= 0) {
					this.$alert('请输入正确的提款金额！');
					return false;
				} else if(Vreg.test(this.entryMoney) == false) {
					this.$alert('请输入正确的提款金额！12312312');
					return false;
				} else if(parseFloat(this.entryMoney) < this.userGroup.MIN_DRAW_AMT) {
					this.$alert('最低提款额度为' + this.userGroup.MIN_DRAW_AMT);
					return false;
				} else if(this.password == null || this.password == '') {
					this.$alert('请输入提款密码！');
					return false;
				} else if(parseFloat(this.entryMoney) > this.maxDraw) {
					this.$alert('最多可取现额度为' + this.maxDraw);
					return false;
				}
			},
			GetDrawBankList() {
				const that = this;
				UserApi.GetDrawBankList(function(data) {
					that.Cardlist = data;
					if(data.length == 0) {
						var arr = ['取消', '确认']
						that.$confirm('您尚未添加银行卡！', '提示', arr, function(e) {
							if(e.index == 0) {
								that.$router.push({
									path: '/Center',
								});
							} else if(e.index == 1) {
								that.$router.push({
									path: '/BankCard',
								});
							}
						})
					} else {
						//that.CardVal.username =  '*' +data[0].PAY_NAME.substr(data[0].PAY_NAME.length - 1); //默认取第一张银行卡
						that.CardVal.username = Array(data[0].PAY_NAME.length).join('*') + data[0].PAY_NAME.substr(-1)
						that.CardVal.accounts = '**** **** **** ' + data[0].PAY_ACCOUNT.substr(data[0].PAY_ACCOUNT.length - 4);
						that.CardVal.bank = data[0].PAY_BANK;
						that.CardVal.ID = data[0].ID;
						for(var i = 0; i < data.length; i++) { //把读取数据格式改为 mui.PopPicker() 要求的；
							var obj = {
								value: data[i].ID,
								text: data[i].PAY_BANK + '*' + data[i].PAY_ACCOUNT.substr(data[i].PAY_ACCOUNT.length - 4),
							}
							that.CardlistShow.push(obj)
						}
					}
				})
			}
		},
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	#reset {
		font-size: .6rem;
	}
	
	.thisrmb {
		font-size: .28rem;
		width: .25rem;
		margin-top: .13rem;
		font-weight: bold;
		color: #333;
		position: relative;
		top: .05rem;
	}
	
	#WithdrawMoney {
		background: #eee;
	}
	
	.leftcolor {
		font-size: .28rem;
		color: #333;
	}
	
	input {
		font-size: .28rem;
		height: inherit;
		margin: 0;
	}
	
	.width_80 {
		width: 80% !important;
	}
	
	.mui-input-row {
		font-size: .28rem;
		width: 100%;
		display: flex;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 97%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.bgColor {
		background: $bgColor;
	}
	/*.bg_j {
		background: $whiteColor;
	}
	*/
	
	.hui_j {
		background: $tipsFontColor;
	}
	
	.bg_j_color {
		background: $blueColor;
	}
	
	.text_cscolor {
		color: $warnColor !important;
	}
	
	.text_lscolor {
		color: $blueColor;
		font-size: .24rem;
		margin-top: .02rem;
		height: 1rem;
		line-height: 1rem;
	}
	
	.text_lscolor:active {
		color: #62c9f5 !important;
	}
	
	.ma_t16 {
		margin-top: .16rem;
	}
	
	.ma_tx24 {
		margin: .24rem 0;
	}
	
	.ma_t30 {
		margin-top: .3rem;
	}
	
	.ma_t40 {
		margin-top: .4rem;
	}
	
	.boa_5 {
		border-radius: .1rem;
	}
	
	.boa_50 {
		border-radius: 50%;
	}
	
	.wh120 {
		width: 1.2rem;
		height: 1.2rem;
	}
	
	.borr_j {
		border-right: .02rem solid $whiteColor;
	}
	/*.bor_b {
		border-bottom: .02rem solid $tipsFontColor;
	}*/
	
	.boryn_j {
		border-right: none !important;
	}
	
	.born_j {
		border: none !important;
	}
	
	.boryx_j {
		border-right: .02rem solid $tipsFontColor;
		border-bottom: .02rem solid $tipsFontColor;
	}
	
	.boryx_color_j {
		border-right: .07rem solid $bgColor;
		border-bottom: .07rem solid $bgColor;
	}
	
	.borsz_j {
		border-top: .02rem solid $tipsFontColor;
		border-left: .02rem solid $tipsFontColor;
	}
	
	.bor_a {
		border: .02rem solid $tipsFontColor;
	}
	
	.bora10_j {
		border: .1rem solid $tipsFontColor;
	}
	
	.bor_color {
		border: .02rem solid $blueColor;
	}
	
	.hb {
		height: 100%;
	}
	
	.zindex {
		z-index: 2;
	}
	
	.ovhide {
		overflow: hidden;
	}
	
	.i_conten {
		height: 3rem;
		display: flex;
		align-items: center;
	}
	
	.sxdq_j {
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	
	.juz_j {
		display: flex;
		align-items: center;
	}
	
	.text_big_j {
		font-size: .48rem !important;
		/*		font-weight: bold;*/
		color: #ccc
	}
	
	.t_list {
		height: .5rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .26rem;
		color: $normalFontColor;
	}
	
	.imp_j {
		width: 100%;
		height: 100%;
		height: 1rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .32rem;
		color: $importFontColor;
	}
	
	.nav_j {
		width: 100%;
		height: 100%;
		height: .98rem;
		padding: .2rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.title_j {
		width: 100%;
		height: 1.05rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .24rem;
		color: $importFontColor;
		background-color: #fff;
	}
	
	.mui-input-password {
		padding-left: 0 !important;
	}
	
	.mui-input-clear1 {
		padding-left: 0 !important;
	}
	
	.list_j {
		width: 100%;
		height: .88rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .28rem;
		color: $normalFontColor;
		background-color: $whiteColor;
		margin-bottom: .01rem;
		label {
			width: 1.3rem;
			height: .88rem;
			padding: 0 .24rem;
			display: flex;
			display: -webkit-flex;
			align-items: center;
			font-size: .26rem;
			color: $normalFontColor;
		}
		input {
			flex: 1;
			height: .88rem;
			padding: 0 .24rem;
			display: flex;
			display: -webkit-flex;
			align-items: center;
			font-size: .26rem;
			color: $normalFontColor;
		}
	}
	
	.list_j:last-child {
		margin-bottom: 0;
	}
	
	.answerLast {
		width: .8rem !important;
	}
	
	.list:last-child {
		border-bottom: none;
	}
	
	.text_xj {
		width: 100%;
		height: 1rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .24rem;
		color: $assistFontColor;
		margin-top: .01rem;
		background-color: #fff;
	}
	
	.text45_xj {
		width: 100%;
		height: .45rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .24rem;
		color: $importFontColor;
	}
	
	.text35_xj {
		width: 100%;
		height: .35rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .22rem;
		color: $normalFontColor;
	}
	
	.paz_24 {
		padding: 0 .24rem;
	}
	
	.pat_24 {
		padding: .24rem 0;
	}
	
	.fz_j {
		height: .6rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .24rem;
		color: #f07377;
		margin-top: .16rem;
	}
	
	.paa_24 {
		padding: .24rem;
	}
	
	.maxtotle {
		margin-top: .02rem;
	}
	
	.padlef {
		padding-left: 0 !important;
		padding-right: 0 !important;
	}
	
	.mui-btn-blue,
	.mui-btn-primary,
	input[type=submit] {
		border: 1px solid #19b4f6;
		background: #19b4f6;
	}
	
	.placeholderColor {
		color: #333
	}
	
	.removeBtn {
		font-size: .28rem !important;
	}
	
	sub {
		padding: 0 !important;
	}
</style>