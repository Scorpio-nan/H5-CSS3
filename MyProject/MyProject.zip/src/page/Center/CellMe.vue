<template>
  <div id="UserMsg">
      <div class="stiky-box">
        <ul class="mui-table-view mui-table-view-chevron mr-t-8">
            <li class="mui-table-view-cell click1">
                <a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-53 mui-pull-left"></span>在线客服</a>
            </li>
            <li class="mui-table-view-cell click2">
                <a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-49 mui-pull-left"></span>在线QQ</a>
            </li>
            <!--<li class="mui-table-view-cell click3">
                <a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-59 mui-pull-left"></span>电话回访</a>
            </li>-->
            <!--<li class="mui-table-view-cell click4">
                <a href="javascript:;" class=" mui-text-left list-font"><span class="iconfont icon-icon-55 mui-pull-left"></span>反馈邮箱 <span class="email mui-pull-right">YouBo@888.com</span></a>
            </li>-->
            <li class="mui-table-view-cell click5">
                <a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-56 mui-pull-left"></span>投诉建议</a>
            </li>
            <li class="mui-table-view-cell click6">
                <a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-60 mui-pull-left"></span>公司简介</a>
            </li>
            <!--<li class="mui-table-view-cell click7">
                <a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-58 mui-pull-left"></span>游戏规则</a>
            </li>-->
        </ul>   

      </div>
      <div class="stiky-footer">
          <p>由菲律宾马尼拉（GICC）颁发合法执照并受其监督</p>
          <p>Copyright@2016-2022 Reserved</p>
      </div>

  </div>
</template>

<script>
export default {
    data() {
        return {
        }
    },
    mounted() {
        const that = this;
        mui.init();
        mui.ready(function() {
            // Scroll 区域
            mui('.mui-scroll-wrapper').scroll({
                deceleration: 0.0005
            });

            mui('.stiky-box').on('tap', '.click5', function() {
                that.$router.push({
                    path: 'Complaint'
                })
            })
            mui('.stiky-box').on('tap', '.click6', function() {
                that.$router.push({
                    path: 'AboutUs'
                })
            })
            //进入客服
            mui('.stiky-box').on('tap', '.click1', function() {
                if(lib.IsApp) {
                    mui.plusReady(function() {
                        plus.runtime.openURL(lib.ServiceLink);
                    });
                } else {
                    var wi = window.open('target:about', '_blank');
                    wi.location.href = lib.ServiceLink;
                }
            })
            //进入QQ
            mui('.stiky-box').on('tap', '.click2', function() {
                if(lib.IsApp) {
                    mui.plusReady(function() {
                        plus.runtime.openURL(lib.ServiceLink);
                    });
                } else {
                    var wi = window.open('target:about', '_blank');
                    wi.location.href = lib.ServiceLink;
                }
            })
        })
    }
}
</script>

<style lang="scss" scoped>
    @import '../../../static/sass/public.scss';
    .mui-table-view-cell{
        a{
            font-size:0.28rem;
        }
    }
    .iconfont{
        font-size:0.46rem;
        color: $blueColor;
        margin-right: 0.16rem;
    }
    .click4>a{
        padding-right:0.24rem;
    }
    .email{
        font-size:0.24rem;
        color:tipsFontColor;
    }
    .click6{
        margin-top:0.16rem;
    }
    ul{
        background:$bgColor;
        li{
            a{
                background:#fff;
            }
        }
    }
    .mui-table-view-cell:after{
        left:0;
        background-color:#eee;
    }
    .mui-navigate-right:after, .mui-push-left:after, .mui-push-right:after{
        font-size:0.46rem;
        color: $normalFontColor;
    }
    .stiky-box{
		min-height: 100%;
		padding-bottom: 1.8rem;
	}
	.stiky-footer{
        margin-top: -1.8rem;
        p{
            font-size:0.24rem;
            color: $normalFontColor;
        }
	}
</style>

