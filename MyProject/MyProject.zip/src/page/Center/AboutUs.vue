<template>
	<div id="CompanyProfile">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<!-- 公司简介文字部分  -->
				<div class="profileText">
					<ul>
						<li class="topic">关于我们</li>
						<li class="topicText">
							品牌信誉-最具公信力的博彩公司、更有高质量的游戏平台、打造在线博彩第一品牌，<span class="colorRed">澳门新葡京</span>为哥斯达黎加合法注册之博彩公司之一。公司不仅拥有市场上最多样化的游戏投注平台，同时为客户提供实时、刺激、高信誉的服务保证、高质量的游戏平台，也是公司的首要宗旨。在日渐热络、成熟的网络博彩市场中，除了多样化的游戏外，网络安全最为客户注重，公司针对现阶段网络安全问题，成立了网络安全维护中心，彻底为客户的网络安全解决了后顾之忧，诺顿分级评级审核"澳门新葡京"为最安全网站之一，并获得GEOTRUST国际认证，确保网站公平公正性，所有会员数据均经过加密，保障玩家所有隐私。
						</li>
					</ul>
					<ul>
						<li class="topic">诚信为本：</li>
						<li class="topicText">
							全网最高信誉，作为国际专业的网上博彩游戏运营商，我们承诺，为每一位客户提供最安全、最公平的博彩游戏，以及全方位的服务。所有游戏共同的优点 — 不须耗时下载；接口简单明了；操作功能齐全；画面精致优雅；游戏结果公平、公正、公开！
						</li>
					</ul>
					<ul>
						<li class="topic">多样化游戏：</li>
						<li class="topicText">
							除了体育游戏项目多样化外，全方位提供：真人娱乐，时时彩，和六合彩等。精挑细选各种在线游戏，给您提供最好的选择。真人荷官及现场娱乐也是无可挑剔的，信誉可靠：设有 7×24小时进行在线监测，确保每一局游戏结果均为现场真实的游戏结果，而不是计算机默认的游戏结果。
						</li>
					</ul>
					<ul>
						<li class="topic">大赢家</li>
						<li class="topicText">
							我们将不间断的推出更多有利新老会员的优惠条款，天天有惊喜、周周大回馈。
						</li>
					</ul>
					<ul>
						<li class="topic">慈善公益：</li>
						<li class="topicText">
							<span class="colorRed">澳门新葡京娱乐</span>更肩负起对社会、对慈善公益的责任，也将永不磨灭的针对社会的需要作出更多的贡献。
						</li>
					</ul>
					<ul>
						<li class="topic">客户服务：</li>
						<li class="topicText">
							在竞争激烈的博彩市场中，<span class="colorRed">澳门新葡京</span>向来是众多玩家一致的明理选择，除了有多样化的娱乐产品使人流连忘返、更有高质量的服务以及<span class="colorRed">澳门新葡京</span>长久以来的良好信誉在广大玩家群众之间建立了口碑。
						</li>
					</ul>
						<ul>
						<li class="topic">我们为客户提供最专业的娱乐服务：</li>
						<li class="topicText">
							1、365天×24小时专业的客户服务，全天候处理会员出入款的相关事宜，严格训练的客服团队，以专业、亲切的态度，让每位玩家有宾至如归的感觉!
						</li>
						<li class="topicText">
							2、多渠道的与客户的互动交流，了解客户的需求，随时关注客户的意见及建议；
						</li>
						<li class="topicText">
							3、举办更多的优惠及促销活动，给客户提供更多的回馈及惊喜。
						</li>
					</ul>
						<ul>
						<li class="topic">游戏责任：</li>
						<li class="topicText">
							<span class="colorRed">澳门新葡京</span>提倡有节制的赌博。我们建议阁下遵守以下一些基本规则：
						</li>
						<li class="topicText">
							? 禁止未满18岁的人士参与赌博游戏。在加入游戏之前，请您确定您已年满18周岁。
						</li>
						<li class="topicText">
							? 自定博彩预算，幷按预算下注。
						</li>
					</ul>
						<ul>
						<li class="topic">账户与资金：</li>
						<li class="topicText">
							玩家网上支付和所有银行交易由国际金融机构在高标准的安全和机密的网络端口（SSL 128 bit encryption Standard）中进行。进入玩家帐户数据也必须有玩家唯一的登录ID和密码，确保客户的资金安全有保障。同时也采用最先进的加密措施来保证玩家的游戏安全，7×24小时的后台检测和监控，确保我们可以提供一个完全公正和安全的网络游戏空间。客户在本平台的所有活动均严格保密，我们绝不会向第三方（包括政府）透露客户数据。
						</li>
					</ul>
						<ul>
						<li class="topic">品牌信誉，首选<span class="colorRed">澳门新葡京</span>！</li>
						<li class="topicText">
							
						</li>
					</ul>
				</div>
			</div>
		</div>
		
	</div>
</template>

<script>
	export default{
		name:'Login',
		data(){
			return{
				
			}
		},
		mounted(){
			const that = this;
			mui.init();
			mui.ready(function(){
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005 //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
				});
			})
		}
	}
</script>

<style lang="scss" scoped>
	/*@import '../../static/sass/public.scss';*/
	/*公司简介文字部分*/
	.profileText{
		font-size: .24rem;
		text-align: left;
		padding: 0 .24rem;
		margin-top: 0.24rem;
		line-height: .34rem;
		ul{
			margin-top: .3rem;
			.topic{
				margin-bottom: .3rem;
			}
		}
		.colorRed{
			color: red;
		}
	}
</style>