<template>
	
	
	<div id="TransactionRecord">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="contorl-nav">
					<div id="segmentedControl" class="mui-segmented-control mui-segmented-control-inverted">
						<a class="mui-control-item" :class="index == 0 ? 'mui-active' : ''" href="javascript:;" data-index="0">存款</a>
						<a class="mui-control-item" :class="index == 1 ? 'mui-active' : ''" href="javascript:;" data-index="1">汇款</a>
						<a class="mui-control-item" :class="index == 2 ? 'mui-active' : ''" href="javascript:;" data-index="2">提款</a>
						<a class="mui-control-item" :class="index == 3 ? 'mui-active' : ''" href="javascript:;" data-index="3">其他</a>
					</div>
				</div>
				<div class="segmented-Select">
					<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="btn mui-btn mui-btn-mini BeginTime mr-r">{{beginTime}}</button>
					<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="btn mui-btn mui-btn-mini EndTime mr-r">{{endTime}}</button>
					<button class="btn mui-btn mui-btn-mini game-type mui-ellipsis">确定筛选</button>
				</div>
				<div class="item bg_j ">
					<div class="i_conten">
						<div class="c_text mui-col-xs-12 ">
							<p class="mui-text-center text_xj zyjuz_j">本页存款成功总金额</p>
							<h2 class="mui-text-center text_big_j">{{Wallet}}RMB</h2>
						</div>
					</div>
					<div class="list_j bor_b">
						<div class="mui-col-xs-6 mui-text-left mui-pull-left">
							手续费（公司支付）
						</div>
						<div class="mui-col-xs-6 mui-text-right  mui-pull-right">
							{{Wallet1.toFixed(2)}}元
						</div>
					</div>
					<div class="list_j bor_b">
						<div class="mui-col-xs-12 mui-text-right">
							2018.6.5-2019.36.5
						</div>
					</div>
				</div>
				<!--<div class="table-content">
					<img src="static/img/loading/loading-bars.svg"/>
					<img src="static/img/loading/loading-spin.svg"/>
					<img src="static/img/loading/loading-spinning-bubbles.svg"/>
				</div>-->
			</div>
		</div>
	</div>
</template>
<script>
	export default {
		name: 'TransactionRecord',
		data() {
			return {
				index : 0,
				beginTime:'2018-03-07',
				endTime:'2018-03-07',
				GameList:[],
				gameIndex:'游戏类型',
				Wallet: 666,
				Wallet1: 66,
				accounts: '呵呵',
				address: '菲律宾',
				datalist1: [],
				CardVal: '工商银行'
			}
		},
		beforeMount: function() {

		},
		created() {
			const that = this;
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function(){
				mui('#segmentedControl').on('tap','.mui-control-item',function(){
					var index = $(this).data('index');
					that.index = index;
				})
				
				mui('.segmented-Select').on('tap','.BeginTime',function(){
					const self = $(this);
					if(self.picker){
						self.piker.show(function(res){
							console.log(res);
						})
					}else{
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res){
							self.picker = null;
							that.beginTime = res['text'];
						})
					}
				})
				
				mui('.segmented-Select').on('tap','.EndTime',function(){
					const self = $(this);
					if(self.picker){
						self.piker.show(function(res){
							console.log(res);
						})
					}else{
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res){
							self.picker = null;
							that.endTime = res['text'];
						})
					}
				})
			})
		},
		watch: {},
		computed: {},
		methods: {

		},
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	.mui-segmented-control{
		font-size: 0.28rem;
	}
	.contorl-nav{
		padding:0.1rem 0.2rem 0 0.2rem;
	}
	.segmented-Select{
		padding: 0.2rem 0.24rem;
		display: flex;
		.btn{
			background: #eee;
			flex: 1;
		}
		.mr-r{
			margin-right: 0.1rem;
		}
	}
	.mui-btn, button, input[type=button], input[type=reset], input[type=submit]{
		border: 0 none;
	}
	.status-Select{
		padding: 0.12rem 0.24rem;
		display: table;
		width: 100%;
		border-bottom: 1px solid #eee;
		a{
			display: table-cell;
			font-size: 0.28rem;
			color: $assistFontColor;
		}
		.s-active{
			color: #3399ff;
		}
	}
	input {
		font-size: .28rem;
	}
	
	.mui-input-row {
		font-size: .28rem;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.borr_j {
		border-right: .02rem solid $whiteColor;
	}
	
	.hb {
		height: 100%;
	}
	
	.l_hb {
		display: flex;
		display: -webkit-flex;
		align-items: center;
	}
	
	.ovhide {
		overflow: hidden;
	}
	
	.i_conten {
		height: 3rem;
		display: flex;
		align-items: center;
	}
	
	.i_conten .c_text {}
	
	.zyjuz_j {
		display: flex;
		display: -webkit-flex;
		justify-content: space-around;
	}
	
	.bgColor {
		background: $bgColor;
	}
	
	.bg_j {
		background: $whiteColor;
	}
	
	.hui_j {
		background: $tipsFontColor;
	}
	
	.t_list {
		height: .5rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .26rem;
		color: $normalFontColor;
	}
	
	.juz_j {
		display: flex;
		align-items: center;
	}
	
	.ma_t24 {
		margin: .24rem 0;
	}
	
	.ma_t30 {
		margin-top: .3rem;
	}
	
	.ma_t40 {
		margin-top: .4rem;
	}
	
	.bg_j_color {
		background: $blueColor;
	}
	
	.boa_5 {
		border-radius: .1rem;
	}
	
	.ma_t16 {
		margin-top: .16rem;
	}
	
	.bor_b {
		border-bottom: .02rem solid $tipsFontColor;
	}
	
	.bor_a {
		border: .02rem solid $tipsFontColor;
	}
	
	.bor_color {
		border: .02rem solid $blueColor;
	}
	
	.text_big_j {
		font-size: .55rem !important;
	}
	
	.imp_j {
		width: 100%;
		height: 100%;
		height: 1rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .32rem;
		color: $importFontColor;
	}
	
	.nav_j {
		width: 100%;
		height: 100%;
		height: .98rem;
		padding: .2rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.title_j {
		width: 100%;
		height: 100%;
		height: .92rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.list_j {
		width: 100%;
		height: 100%;
		height: .88rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .26rem;
		color: $normalFontColor;
		label {
			width: 100%;
			height: 100%;
			height: .88rem;
			padding: 0 .24rem;
			display: flex;
			display: -webkit-flex;
			align-items: center;
			font-size: .26rem;
			color: $normalFontColor;
		}
		input {
			width: 100%;
			height: 100%;
			height: .88rem;
			padding: 0 .24rem;
			display: flex;
			display: -webkit-flex;
			align-items: center;
			font-size: .26rem;
			color: $normalFontColor;
		}
	}
	
	.text_xj {
		width: 100%;
		height: 100%;
		height: .7rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.paz_24 {
		padding: 0 .24rem;
	}
	
	.pat_24 {
		padding: .24rem 0;
	}
	
	.fz_j {
		height: .8rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.paa_24 {
		padding: .24rem;
	}
</style>