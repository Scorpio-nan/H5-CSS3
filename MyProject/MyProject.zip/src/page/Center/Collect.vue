<template>
	<div id="Collect">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="lotCol" v-show="isLenght1">
					<h5 class="mui-h5 mui-text-left lotTit">彩票类</h5>
					<ul class="mui-clearfix game-list">
						<li class="mui-pull-left mui-item" v-for="(item,i) in list1" :key="i">
							<a href="javascript:;" class="inline-block">
								<div class="item-img lot caip" :data-object="JSON.stringify(item)">
									<img :src="'static/img/temp/'+item.CODE+'.png'" alt="">
								</div>
								<div class="item-title mui-clearfix">
									<p class="mui-pull-left">{{item.PARA_NAME}}</p>
									<span class="iconfont mui-pull-right scBtn" :class="item.DELETE_IND == 1 ? 'icon-xin' : 'icon-xin1' " :data-id="item.SYS_GAME_LEVEL_ID" :data-lve="item.GAME_LEVEL" :data-prelve="item.SYS_GAME_LEVEL_PARENT_ID"></span>
								</div>
							</a>
						</li>
					</ul>
				</div>
				<div class="others" v-show="isLenght2">
					<h5 class="mui-h5 mui-text-left lotTit">真人视讯/电子游艺</h5>
					<ul class="mui-clearfix">
						<li class="mui-pull-left list-item" v-for="(item,i) in list2" :key="i">
							<a href="javascript:;" class="mui-block">
								<div class="item-img zrdz" :data-code="item.CODE" :data-id="item.SYS_GAME_LEVEL_ID">
									<img :src="'static/img/'+filterType(item.CODE)+item.CODE+'.png'">
								</div>
								<div class="item-title mui-clearfix">
									<p class="mui-pull-left">{{item.PARA_NAME}}</p>
									<span class="iconfont mui-pull-right scBtn" :class="item.DELETE_IND == 1 ? 'icon-xin' : 'icon-xin1' " :data-id="item.SYS_GAME_LEVEL_ID" :data-lve="item.GAME_LEVEL" :data-prelve="item.SYS_GAME_LEVEL_PARENT_ID"></span>
								</div>
							</a>
						</li>						
					</ul>
				</div>
				<div class="Sports" v-show="isLenght3">
					<h5 class="mui-h5 mui-text-left lotTit">体育赛事</h5>
					<ul class="list-warpper ">
						<li class="list-item tgpClick" v-for="(item,i) in list3" :key="i">
							<a href="javascript:;" class="mui-block">  
								<div class="item-img tyss"  :data-code="item.CODE" :data-gameid="item.SYS_GAME_LEVEL_ID">
									<img :src="'static/img/temp/'+item.CODE+'.png'" alt="">
								</div>
								<div class="item-title mui-clearfix">
									<p class="mui-pull-left">{{item.PARA_NAME}}</p>
									<span class="iconfont mui-pull-right scBtn" :class="item.DELETE_IND == 1 ? 'icon-xin' : 'icon-xin1' "  :data-id="item.SYS_GAME_LEVEL_ID" :data-lve="item.GAME_LEVEL" :data-prelve="item.SYS_GAME_LEVEL_PARENT_ID"></span>
								</div>
							</a>
						</li>
					</ul>
				</div>

			</div>
		</div>
		<div class="noShoucang" v-show="islen0">
			<div class="scimg">
				<p>亲，您还未添加收藏哦~</p>
			</div>
		</div>
	</div>
</template>

<script>
	import webapi from '@/api/webUtil'
	export default {
		name: 'Collect',
		data() {
			return {
				list1:[],//彩票
				list2:[],//真人电子
				list3:[],//体育
				isLenght1:false,
				isLenght2:false,
				isLenght3:false,
				islen0:true
			}
		},
		mounted() {
			const that = this;
			that.GetList()
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			})
			mui.init();
			mui.ready(function() {
				mui('#Collect').on('tap', '.scBtn', function() {
					console.log("点击收藏")
					var id = $(this).data('id')
					var lveid = $(this).data('lve')
					var prelveid = $(this).data('prelve')
					var self = $(this);
					console.log("lveid",lveid,"prelveid",prelveid)
					that.shoucang(id,lveid,prelveid,self)
				})
				mui('#Collect').on('tap', '.caip', function() {
					var obj = $(this).data('object');
					that.Routerpath(obj.CODE)
					that.$router.push({
						path: that.Routerpath(obj.CODE),
						query: {
							id: obj.SYS_GAME_LEVEL_ID,
							code: obj.CODE,
							name: obj.PARA_NAME,
							title: obj.PARA_NAME,
							Value: Math.random()
						}
					});
				})
				mui('#Collect').on('tap', '.zrdz', function() {
					var code = $(this).data('code');
					var id = $(this).data('id');
					that.onItemClick(code, id);
				})
				mui('#Collect').on('tap', '.tyss', function() {
					var code = $(this).data('code');
        			var id = $(this).data('gameid');
        			that.opensprot(code,id);
				})


			})
		},
		methods: {
			GetList(){
				const that = this;
				var id = that.UserInfo.ID
				webapi.GetMobileFavoriteList(id,function(data){
					that.list1=[]
					that.list2=[]
					that.list3=[]
					var arr = JSON.parse(data)	
					console.log("总收藏列表",arr)	
					for(var i=0;i<arr.length;i++){
						if((arr[i].SYS_GAME_LEVEL_PARENT_ID == 27 || arr[i].SYS_GAME_LEVEL_PARENT_ID == 2) && arr[i].DELETE_IND == '1'){		
							that.list1.push(arr[i])
						}else if((arr[i].SYS_GAME_LEVEL_PARENT_ID == 9 || arr[i].SYS_GAME_LEVEL_PARENT_ID == 3) && arr[i].DELETE_IND == '1'){
							that.list2.push(arr[i])
						}else if(arr[i].SYS_GAME_LEVEL_PARENT_ID == 1 && arr[i].DELETE_IND == '1'){
							that.list3.push(arr[i])
						}
					}	
					if(that.list3.length >0 || that.list2.length >0 || that.list1.length >0 ){
						that.islen0 = false
					}
					
					that.isShow()							
				})				
			},
			isShow(){
				const that = this;
				if(that.list1.length >0){
					that.isLenght1 = true
				}
				if(that.list2.length >0){
					that.isLenght2 = true
				}
				if(that.list3.length >0){
					that.isLenght3 = true
				}
			},
			shoucang(id,lveid,prelveid,self){
				var that = this
				webapi.AddGameFavorite(lveid,prelveid,id,function(data){
					data = JSON.parse(data);
					console.log("收藏接口返回",data)
					if(data.state == "success"){
						self.removeClass("icon-xin1").addClass('icon-xin');
						that.$toast("收藏成功")
					}else{
						self.removeClass("icon-xin").addClass('icon-xin1');
						that.$toast("取消成功")
					}
				})
			},
			Routerpath(code) {
				if(code == 'cqssc' || code == 'xjssc' || code == 'jsssc' || code == 'tjssc') {
					return '/ssc';
				} else if(code.indexOf("k3") >= 0) {
					return '/cp3';
				} else if(code.indexOf("11x5") >= 0) {
					return '/cp11';
				} else if(code == 'tjklsf' || code == 'gdklsf' || code == 'cqklsf') {
					return '/gdklsf';
				} else if(code == 'mlaft' || code == 'jspk10' || code == 'bjpk10') {
					return '/bjpk10';
				} else if(code == 'hk6' || code == 'jisuhk6') {
					return '/hk6';
				} else {
					return '/' + code;
				}
			},
			onItemClick(code, id){
				var that=this
					if(code.includes('_live')){
						that.$toast('精彩马上开始...',{duration:'long'});
						webapi.TransferGameURL(code,1,id,res=>{
							res = JSON.parse(res);
							console.log(res);
							if(res.state == 'error'){
								that.$alert(res.message);
								return;
							}
							if(!lib.IsApp){
								var wi = window.open('about:blank','_blank');
							}
							if(code == 'bbin_live' || code == "sa_live"){
								//判断是wap端还是APP端
								if(lib.IsApp){
									mui.plusReady(function(){
										plus.runtime.openURL(lib.gameUrl + "?code=" + code + "&id=" + id + "&userid=" + that.UserInfo.ID);
									})
								}else{
									if(code == 'bbin_live'){
										wi.document.write(res.data.val);
										wi.document.write("<scr" + "ipt> document.post_form.submit();</scr" + "ipt>");
									}else{
										var obj = JSON.parse(res.data.val);
										wi.document.write("<form id='SaLive' name='SaLive' method='POST' action='" + obj.URLS + "'>");
										wi.document.write("<input type='hidden' id='username' name='username' value='" + obj.username + "' />");
										wi.document.write("<input type='hidden' id='token' name='token' value='" + obj.token + "' />");
										wi.document.write("<input type='hidden' id='lobby' name='lobby' value='" + obj.lobby + "' />");
										wi.document.write("<input type='hidden' id='lang' name='lang' value='" + obj.lang + "' />");
										wi.document.write("<input type='hidden' id='mobile' name='mobile' value=" + true + " />");
										wi.document.write("</form>");
										wi.document.write("<scr" + "ipt> document.SaLive.submit();</scr" + "ipt>");
									}
								}
							}else{
								if(lib.IsApp){
									mui.plusReady(function(){
										plus.runtime.openURL(res.data.val);
									})
								}else{
									wi.location.href = res.data.val;
								}
							}
						})
					} else {
						this.$router.push({
							path: '/ElectronicGameDtail',
							query: {
								gameId: id,
								gameCd: code,
//								game3List:this_.gamelist
							}
						});
					}
			},
			opensprot(code,id){
				const that = this;
				that.$toast('精彩马上开始...',{duration:'long'});
        		webapi.TransferGameURL(code,1,id,res=>{
        			res = JSON.parse(res);
        			if(res.state == 'error'){
						that.$alert(res.message);
						return;
					}
        			if(lib.IsApp){
        				mui.plusReady(function(){
        					plus.runtime.openURL(res.data.val);
        				})
        			}else{
        				var wi = window.open('about:blank','_blank');
        				wi.location.href = res.data.val;
        				
        			}
        		})
			},
			filterType(code){
				if(code.includes('live')){
					return 'public/'
				}else{
					return 'temp/'
				}
			}
		},
		computed: {
			UserInfo(){
				return this.$store.getters.getUserInfo;
			},
		},
		created(){
			this.$store.dispatch('getUserInfo');
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.lotCol,
	.others {
		padding-left: 0.24rem;
		padding-top: 0.24rem;
	}
	
	.others {
		padding-top: 0;
		.list-item {
			margin: 0 0.18rem 0.26rem 0;
		}
		.item-img {
			width: 3.4rem;
			height: 1.9rem;
			background: #fff;
			overflow: hidden;
			border-radius: 3px 3px 0 0;
			background:#fff url('../../../static/img/public/cai.png') no-repeat center;
			background-size:cover;
		}
		.icon-xin {
			color: $warnColor;
		}
		.item-title {
			background: #eee;
			border-radius: 0 0 3px 3px;
			overflow: hidden;
			padding: 0.16rem 0.1rem;
			p {
				font-size: 0.28rem;
			}
		}
	}
	
	.item-img {
		width: 2.2rem;
		height: 1.6rem;
		background: #fff;
		border-radius: 3px 3px 0 0;
	}
	
	.icon-xin {
		color: red;
	}
	
	.item-title {
		background: #eee;
		border-radius: 0 0 3px 3px;
		padding: 0.12rem 0.1rem;
		p {
			font-size: 0.28rem;
		}
	}
	
	.mui-item {
		margin: 0 0.19rem 0.28rem 0;
	}
	
	.lotTit {
		padding: 0.2rem 0;
		color: $normalFontColor;
	}

	.Sports {
		padding: 0.24rem;
		padding-right: 0;
		.list-warpper {
			text-align: center;
		}

		.list-item {
			margin: 0 0.18rem 0.26rem 0;
		}
		
		.item-img {
			background: #fff;
			overflow: hidden;
			border-radius: 3px 3px 0 0;
			width: 100%;
			height: 100%;
			background: #fff url('~static/img/public/cai.png') no-repeat center;
			background-size: cover;
			img {
				display: block;
				width: 100%;
				height: auto;
			}
		}
		
		.icon-xin {
			color: $warnColor;
		}
		
		.item-title {
			background: #eee;
			border-radius: 0 0 3px 3px;
			overflow: hidden;
			padding: 0.16rem 0.1rem;
			p {
				font-size: 0.24rem;
			}
		}
	}
	.caip{
		padding-top:0.2rem;
		img{
			width: 1.2rem;
    		height: auto;
		}
	}
	.zrdz{
		img{
			width: 3.4rem;
    		height: 1.9rem;
		}
	}

		.noShoucang{
			width: 100%;
			height: 100%;
			position: relative;
			.scimg{
				position: absolute;
				top: 50%;
				left: 50%;
				transform: translate(-50%,-80%);
				width: 3rem;
				height: 3rem;
				background: url(~static/img/public/cai.png) no-repeat center;
				p{
					position: absolute;
					bottom:0.2rem;
					width: 100%;
					text-align: center;
				}
			}
		}
	
</style>