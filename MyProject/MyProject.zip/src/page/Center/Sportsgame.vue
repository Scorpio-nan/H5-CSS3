<template>
	<div id="ElectronicGame">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="Gamelist">
					<ul class="list-warpper ">
						<li class="list-item tgpClick" v-for="(item,index) in GameList" >
							<a href="javascript:;" class="mui-block">  
								<div class="item-img" :data-code="item.CODE" :data-gameid="item.ID">
									<img :src="'static/img/temp/'+item.CODE+'.png'" />
								</div>
								<div class="item-title mui-clearfix">
									<p class="mui-pull-left">{{item.LOTTERY_TICKET_NAME}}</p>
									<span class="iconfont mui-pull-right scBtn" :data-id="item.ID" :class="item.DELETE_IND*1 ? 'icon-xin' : 'icon-xin1' "></span>
								</div>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		
		<!--  需要手动关闭遮罩添加     @handleHide="handleLodingHide"   -->
		<TransferDom :show="loadingImg">
			<img src="static/img/loading/loading-bars.svg" alt="" class="loading"/>
		</TransferDom>
	</div>
</template>

<script>
	import TransferDom from '@/components/TransferDom';
	import api from '@/api/webUtil';
    export default{
        data() {
            return {
               gameList:[],
               loadingImg:false,
            }
        },
        components: {
			TransferDom
		},
        mounted(){
        	const that = this;
        	mui.init();
        	mui.ready(function(){
        		
        		mui('.Gamelist').on('tap','.item-img',function(){
        			var code = $(this).data('code');
        			var id = $(this).data('gameid');
        			that.openUrl(code,id);
				})
				
				mui('#ElectronicGame').on('tap', '.scBtn', function() {
					var id = $(this).data('id')
					var self = $(this);

					console.log("点击收藏",id)
					that.shoucang(id,self)
				})
        		
        	})
        	console.log(this.GameList)
        },
        created(){
        	this.$store.dispatch('getGame0List');
        },
        methods:{
        	openUrl(code,id){
        		const that = this;
        		if(!this.islogin){
        			this.$alert('您还未登录哦！请立即登录！');
					return false;
        		}
        		that.loadingImg = true;
        		if(!lib.IsApp){
        			var wi = window.open('about:blank','_blank');
        		}
        		api.TransferGameURL(code,1,id,res=>{
        			that.loadingImg = false;
        			res = JSON.parse(res);
        			if(res.state == 'error'){
						that.$alert(res.message);
						return;
					}
        			if(lib.IsApp){
        				mui.plusReady(function(){
        					plus.runtime.openURL(res.data.val);
        				})
        			}else{
        				wi.location.href = res.data.val;
        			}
        		})
			},
			shoucang(id,self){
				if(!this.islogin){
					this.$alert('您还未登录哦！请立即登录！');
					return false;
				}
				var that = this
				api.AddGameFavorite(2,1,id,function(data){
					data = JSON.parse(data);
					console.log("收藏接口返回",data)
					if(data.state == "success"){
						self.removeClass("icon-xin1").addClass('icon-xin');
						that.$toast("收藏成功")
					}else{
						self.removeClass("icon-xin").addClass('icon-xin1');
						that.$toast("取消成功")
					}
				})
			},
        },
        computed:{
        	GameList(){
        		return this.$store.getters.game00List;
        	},
        	islogin() {
				return this.$store.getters.checkLoginState;
			},
        }
    }
</script>

<style lang="scss" scoped>
   @import '~static/sass/public.scss';
	.loading{
		display: block;
		width: 1rem;
		height: 1rem;
	}
	.Gamelist {
		padding: 0.24rem;
		padding-right: 0;
	}
	
	.list-warpper {
		text-align: center;
	}
	
	.list-item {
		margin: 0 0.18rem 0.26rem 0;
	}
	
	.item-img {
		background: #fff;
		overflow: hidden;
		border-radius: 3px 3px 0 0;
		background: #fff url('~static/img/public/cai.png') no-repeat center;
		background-size: cover;
		img {
			display: block;
			width: 100%;
			height: auto;
		}
	}
	
	.icon-xin {
		color: $warnColor;
	}
	
	.item-title {
		background: #eee;
		border-radius: 0 0 3px 3px;
		overflow: hidden;
		padding: 0.16rem 0.1rem;
		position: relative;
		p {
			font-size: 0.24rem;
		}
		.scBtn{
			position: absolute;
			right: 0;
			top: 0;
			width: 0.5rem;
			height: 100%;
			padding-top:0.14rem;
		}
	}
</style>
