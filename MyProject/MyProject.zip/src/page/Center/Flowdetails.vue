<template>
	<div class="tabcon">
		<nav class="nav">
			<a href="#" class="tab" data-index="0" :class="index==0?'active':''">存取款</a>
			<a href="#" class="tab" data-index="1" :class="index==1?'active':''">转账</a>
		</nav>
		<div class="queryCondition">
			<div class="time-group">
				<button data-options='{}' class="btn mui-btn mui-btn-block BeginTime mr-r">{{beginTime}}</button>
				<button data-options='{}' class="btn mui-btn mui-btn-block EndTime">{{endTime}}</button>
			</div>
			<transition name="component-fade" mode="out-in">
				<div class="input-group" v-if="index != 1">
					<input type="text" class="mui-input mr-r gametype mui-ellipsis" placeholder="--选择存取款类型--" readonly="readonly" v-model="currentType"/>
					<input type="text" class="mui-input" placeholder="请输入系统单号" v-model="orderNumber"/>
				</div>
			</transition>
		</div>
		<div class="main">
			<div class="thead">
				<a href="javascript:;" v-for="item in thead">{{item}}</a>
			</div>
			<div class="flex-content" v-show="index == 0">
				<Scroller :on-infinite="infinite" ref="Scroll" :loadingShow="loadingShow">
					<table border="0" cellspacing="0" cellpadding="0">
						<tr v-for="(item,index) in accessMoneyData">
							<td>{{paraDebit[item.LOAN_TYPE_CD].FULLNAME}}</td>
							<td>{{item.ORDER_MAKE_DTT!=null?item.ORDER_MAKE_DTT.substr(5,11):''}}</td>
							<td v-if="item.STATUS_CD == 0"><span class="error">失败</span></td>
							<td v-else-if="item.STATUS_CD == 1"><span class="success">成功</span></td>
							<td v-else-if="item.STATUS_CD == 2"><span class="await">待审核</span></td>
							<td v-else-if="item.STATUS_CD == 3"><span class="await">预下单</span></td>
							<td v-else><span class="success">充值成功</span></td>
							<td>&yen;{{item.AMT.toFixed(1)}}</td>
						</tr>
					</table>
				</Scroller>
			</div>
			<div class="flex-content" v-show="index == 1">
				<Scroller :on-infinite="infinite" ref="Scroll" :loadingShow="loadingShow">
					<table border="0" cellspacing="0" cellpadding="0">
						<tr v-for="(item,index) in transformData">
							<td v-if="item.TRANSFER_TYPE_CD == 1"><span class="success">转入</span></td>
							<td v-else><span class="error">转出</span></td>
							<td>{{getAcclib(item.ACC_BAL_CD)}}</td>
							<td>{{item.TRANSFER_DTT != null ? item.TRANSFER_DTT.substr(5,11) : ''}}</td>
							<td>&yen;{{item.TRANSFER_AMT.toFixed(1)}}</td>
						</tr>
					</table>
				</Scroller>
			</div>
		</div>
		<div class="footer">
			<button class="mui-btn mui-btn-block serchBtn">确认查询</button>
		</div>
	</div>
</template>

<script>
	import webApi from '@/api/webUtil';
	import userApi from '@/api/userUtil';
	import Scroller from '@/components/Scroller';
	export default {
		name: 'Center',
		components: {
			Scroller
		},
		data() {
			return {
				beginTime: new Date().Format('yyyy-MM-dd hh:mm'),
				endTime: new Date().Format('yyyy-MM-dd hh:mm'),
				index: 0,
				paraDebit: {
					"2-12": {
						"ENCODE": "2-12",
						"FULLNAME": "在线存款[QQ钱包]"
					},
					"2-0": {
						"ENCODE": "2-0",
						"FULLNAME": "在线存款[银联]"
					},
					"2-1": {
						"ENCODE": "2-1",
						"FULLNAME": "在线存款[微信]"
					},
					"2-2": {
						"ENCODE": "2-2",
						"FULLNAME": "在线存款[支付宝]"
					},
					"2-4": {
						"ENCODE": "2-4",
						"FULLNAME": "填单存款[银联]"
					},
					"2-13": {
						"ENCODE": "2-13",
						"FULLNAME": "填单存款[支付宝]"
					},
					"2-14": {
						"ENCODE": "2-14",
						"FULLNAME": "填单存款[微信]"
					},
					"2-15": {
						"ENCODE": "2-15",
						"FULLNAME": "填单存款[QQ钱包]"
					},
					"2-16": {
						"ENCODE": "2-16",
						"FULLNAME": "预留"
					},
					"2-17": {
						"ENCODE": "2-17",
						"FULLNAME": "预留"
					},
					"2-18": {
						"ENCODE": "2-18",
						"FULLNAME": "预留"
					},
					"2-19": {
						"ENCODE": "2-19",
						"FULLNAME": "预留"
					},
					"2-20": {
						"ENCODE": "2-20",
						"FULLNAME": "预留"
					},
					"2-21": {
						"ENCODE": "2-21",
						"FULLNAME": "预留"
					},
					"2-22": {
						"ENCODE": "2-22",
						"FULLNAME": "预留"
					},
					"2-24": {
						"ENCODE": "2-24",
						"FULLNAME": "预留"
					},
					"2-5": {
						"ENCODE": "2-5",
						"FULLNAME": "人工加款"
					},
					"2-6": {
						"ENCODE": "2-6",
						"FULLNAME": "代理转入"
					},
					"2-7": {
						"ENCODE": "2-7",
						"FULLNAME": "代理分润转入"
					},
					"2-8": {
						"ENCODE": "2-8",
						"FULLNAME": "代理存款"
					},
					"2-9": {
						"ENCODE": "2-9",
						"FULLNAME": "兑换积分"
					},
					"1-0": {
						"ENCODE": "1-0",
						"FULLNAME": "会员取款"
					},
					"1-1": {
						"ENCODE": "1-1",
						"FULLNAME": "返水派送"
					},
					"1-2": {
						"ENCODE": "1-2",
						"FULLNAME": "充值优惠"
					},
					"1-3": {
						"ENCODE": "1-3",
						"FULLNAME": "注册赠送"
					},
					"1-4": {
						"ENCODE": "1-4",
						"FULLNAME": "代理提款"
					},
					"1-5": {
						"ENCODE": "1-5",
						"FULLNAME": "彩金派送"
					},
					"1-6": {
						"ENCODE": "1-6",
						"FULLNAME": "人工减款"
					},
					"1-8": {
						"ENCODE": "1-8",
						"FULLNAME": "代理转出"
					},
					"2-23": {
						"ENCODE": "2-23",
						"FULLNAME": "代理转入"
					},
					"1-7": {
						"ENCODE": "1-7",
						"FULLNAME": "代理返水"
					},
					"1-9": {
						"ENCODE": "1-9",
						"FULLNAME": "代理分润代理转出"
					},
					"1-10": {
						"ENCODE": "1-10",
						"FULLNAME": "代理分润会员转出"
					}
				},
				thead: ['类型', '时间', '状态', '金额'],
				total: 0, 			//总页数
				page: 1, 			//当前页数
				rows: 15, 			//每页显示记录数
				records: 0, 		//总记录数
				loadMore:true,
				selectTypeList:[],	//借贷类型
				currentType:'',		//借贷类型选中项
				currentCD:'',		//借贷类型科目
				orderNumber:'',		//订单号
				accessMoneyData:[],	//取款类型数据
				transformData:[],	//转账类型数据
				loadingShow:true,
			}
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				
				//选择开始时间
				mui('.queryCondition').on('tap', '.BeginTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {
							console.log(res);
						})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.beginTime = res['text'];
						})
					}
				})
				
				//选择结束时间
				mui('.queryCondition').on('tap', '.EndTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {
							console.log(res);
						})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.endTime = res['text'];
						})
					}
				})

				//选择借贷类型
				mui('.queryCondition').on('tap', '.gametype', function() {
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.selectTypeList);
					CardPiker.show(function(items) {
						that.currentType = items[0]['text'];
						that.currentCD = items[0]['value'];
					});
				})
				
				//头部的tab切换
				mui('.nav').on('tap', '.tab', function() {
					var index = $(this).data('index');
					that.index = index;
					switch(index) {
						case 0:
							that.thead = ['类型', '时间', '状态', '金额'];
							that.accessMoneyData = [];
							that.page = 1;
							that.loadingDataAccess();
							break;
						default:
							that.thead = ['类型', '平台', '时间', '金额'];
							that.transformData = [];
							that.page = 1;
							that.loadingDataTrans();
							break;
					}
				})
				
				
				//点击确认查找按钮
				mui('.footer').on('tap','.serchBtn',function(){
					that.querySubmit();
				})
				

			})

		},
		computed: {
			AccountList(){
				return this.$store.getters.getAccountList;
			}
		},
		methods: {
			//下拉加载更多
			infinite(finish) {
				const that = this;
				if(this.loadMore) {
					setTimeout(() => {
						that.loadingShow = false;
						finish(true);
					}, 1500)
				}else{
					setTimeout(() => {
						this.querySubmit();
						setTimeout(() => {
							finish();
						})
					}, 1500)
				}
			},
			//确认查找
			querySubmit() {
				var that = this;
				switch(that.index) {
					case 0:
						that.page = 1;
						that.accessMoneyData = [];
						that.loadingDataAccess();
						break;
					case 1:
						that.page = 1;
						that.transformData = [];
						this.$store.dispatch('getAccountList');
						that.loadingDataTrans();
						break;
				}
			},
			//数据过滤
			getAcclib(type){
				for(var i = 0; i < this.AccountList.length; i++){
					if(this.AccountList[i]['ENCODE'] == type){
						return this.AccountList[i].FULLNAME;
					}
				}
			},
			//组织数据结构
			makeQueryJson(value, currentType, start, end) {
				if(start && end) {
					start += ':00';
					end += ':59';
				};
				var queryJson = {
					type_cd:value,
					o_no:currentType,
					starttime:start,
					endtime: end
				};
				return queryJson
			},
			//转账类型数据
			TransQueryJson(start, end) {
				if(start && end) {
					start += ':00';
					end += ':59';
				};
				var queryJson = {
					starttime: start,
					endtime: end
				};
				return queryJson
			},
			//下拉菜单类型
			initSelectType() {
				var that = this;
				that.selectTypeList = [];
				webApi.GetDebitList(function(data) {
					var res = eval('(' + data + ')');
					that.currentCD = res[0].ENCODE;
					for(var i = 0; i < res.length; i++) {
						var obj = {
							value: res[i].ENCODE,
							text: res[i].FULLNAME,
						}
						that.selectTypeList.push(obj);
					}
					that.page ++;
				});
			},
			/*获取存取款接口*/
			loadingDataAccess() {
				const that = this;
				var queryJson = that.makeQueryJson(that.currentCD, that.orderNumber, that.beginTime, that.endTime)
				var postData = {
					type_cd:queryJson.type_cd,
					o_no:queryJson.o_no,
					DTT_GEGIN:queryJson.starttime,
					DTT_END:queryJson.endtime,
					rows: that.rows,
					page: that.page,
					sidx: 'ORDER_MAKE_DTT',
					sord: 'DESC'
				};
				setTimeout(() => {
					userApi.GetOrderList(postData, function(data) {
						var res = JSON.parse(data);
						console.log(res);
						//如果读到的接口里面没有数据说明已经加载完成 ，停止上拉加载
						if(res.rows.length == 0){
							that.loadMore = false;
							that.$toast('没有更多数据！');
							return;
						}
						if(res.state == 'error'){
							that.$alert(res.message);
						}else{
							for(var i = 0; i < res.rows.length; i++) {
								that.accessMoneyData.push(res.rows[i]);
							}
						}
						that.page ++;
					});
				}, 100)
			},
			/*获取转账接口*/
			loadingDataTrans() {
				const that = this;
				var queryJson = that.TransQueryJson(that.beginTime, that.endTime)
				var postData = {
					DTT_GEGIN:queryJson.starttime,
					DTT_END:queryJson.end,
					rows: that.rows,
					page: that.page,
					sidx: 'TRANSFER_DTT',
					sord: 'DESC'
				};
				setTimeout(() => {
					userApi.GetTransList(postData, function(data) {
						var res = JSON.parse(data);
						console.log(res);
						//如果读到的接口里面没有数据说明已经加载完成 ，停止上拉加载
						if(res.rows.length == 0){
							that.loadMore = false;
							that.$toast('没有更多数据！');
							return;
						}
						if(res.state == 'error'){
							that.$alert(res.message);
						}else{
							//加载数据
							for(var i = 0; i < res.rows.length; i++) {
								res.rows[i].IN_INT_IDENT_CD = that.tranPlaType(res.rows[i].IN_INT_IDENT_CD);
								res.rows[i].OUT_INT_IDENT_CD = that.tranPlaType(res.rows[i].OUT_INT_IDENT_CD);
								that.transformData.push(res.rows[i]);
							}
						}
						that.page ++;
					});
				}, 100)

			},
			//类型转换
			tranPlaType(val) {
				for(var x in this.AccountList) {
					if(this.AccountList[x].key == val) {
						return this.AccountList[x].value;
						break;
					}
				}
			}
		},
		created(){
			this.$store.dispatch('getAccountList');
			this.initSelectType();
			this.querySubmit();
			//console.log(this.AccountList)
		}
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	.tabcon {
		display: flex;
		flex-direction: column;
		.main {
			flex: 1;
			display:flex;
			flex-direction: column;
			.flex-content{
				flex: 1;
				position: relative;
				table {
					width: 100%;
					background: #fff;
					tr {
						td {
							font-size: 0.24rem;
							height: 0.66rem;
							@include border-1px(#ccc, bottom);
							width: 20%;
						}
					}
				}
			}
		}
		.footer {
			padding: 0.24rem;
		}
	}
	
	.serchBtn {
		margin: 0;
		padding: 10px 0;
		font-size: 0.34rem;
		background: $blueColor;
		color: #fff;
		border: 0 none;
		transform: all .35s;
		&:active {
			background: rgba($blueColor, 0.7);
		}
	}
	
	.thead {
		background: #fff;
		display: flex;
		margin-top: 0.16rem;
		@include border-1px(#ccc, bottom);
		a {
			flex: 1;
			font-size: 0.24rem;
			font-weight: 600;
			padding: 0.1rem 0;
		}
	}
	
	.queryCondition {
		padding: 0.2rem 0.24rem;
		background: #fff;
		margin-top: 0.16rem;
		.time-group {
			display: flex;
			.btn {
				flex: 1;
				margin: 0;
				font-size: 0.24rem;
				padding: 6px 0;
				position: relative;
				text-align: left;
				padding-left: 0.28rem;
				&:after {
					display: block;
					content: '';
					position: absolute;
					@include arrow(bottom, 8px, #666);
					right: 0.2rem;
					top: 50%;
					transform: translate(0, -50%);
				}
			}
			.mr-r {
				margin-right: 0.16rem;
			}
		}
		.input-group {
			display: flex;
			margin-top: 0.16rem;
			input {
				flex: 1;
				height: 0.7rem;
				margin: 0;
				font-size: 0.24rem;
			}
			.mr-r {
				margin-right: 0.16rem;
			}
		}
	}
	
	nav {
		background: #fff;
		display: flex;
		a {
			flex: 1;
			font-size: 0.28rem;
			padding: 0.24rem 0;
			position: relative;
		}
		.active:after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 0;
			width: 100%;
			height: 2px;
			background: $blueColor;
		}
		.active {
			color: $blueColor;
		}
	}
	
	.my-btn {
		width: 91%;
		margin: 0 auto;
		padding: 0.28rem 0;
		font-size: 0.32rem;
		color: #fff;
		background-color: $blueColor;
		border: none;
	}
	.component-fade-enter-active, .component-fade-leave-active {
	  transition: opacity .25s ease;
	}
	.component-fade-enter, .component-fade-leave-to{
	  opacity: 0;
	}
</style>