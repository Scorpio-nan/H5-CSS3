<template>
	<div id="SpecialOffers">
		<h2 class="mui-text-left mui-clearfix m-title"><span class="mui-pull-left iconfont icon-icon-24 mr-r"></span>优惠活动 <span class="slide-tps mui-pull-right">更多</span></h2>
		<div class="activety-container">
			<div id="mui-slider" class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
			    <div class="mui-scroll">
			        <a class="mui-control-item mui-block item">
			        	<img class="mui-block item-img" src="static/img/public/seller1.png"/>
			        </a>
			        <a class="mui-control-item mui-block item">
			        	<img class="mui-block item-img" src="static/img/public/seller2.png"/>
			        </a>
			        <a class="mui-control-item mui-block item">
			        	<img class="mui-block item-img" src="static/img/public/seller1.png"/>
			        </a>
			         <a class="mui-control-item mui-block item">
			        	<img class="mui-block item-img" src="static/img/public/seller2.png"/>
			        </a>
			        <a class="mui-control-item mui-block item last">
			        	<span class="model">点击查看更多</span>
			        </a>
			    </div>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		name:'SpecialOffers',
		data(){
			return{
				
			}
		},
		mounted(){
			const that = this;
			mui.init();
			
			var slider = mui('#mui-slider');
			slider.slider({
				interval: 0
			});
			
			mui.ready(function(){
				mui('.activety-container').on('tap','.item',function(){
					that.$router.push({
						path:'/Promotions'
					})
				})
			})
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.m-title {
		padding: 0.2rem 0.24rem;
		font-size: 0.28rem;
		font-weight: 100;
		vertical-align: middle;
	}
	.mr-r {
		margin-right: 5px;
		font-size: 14px;
		color: #2ea9e1;
	}
	.item-img{
		height: 100%;
		width: auto;
	}
	.slide-tps{
		font-size:0.24rem;
		margin-top: 0.04rem;
		color: $assistFontColor;
	}
	.activety-container{
		padding: 0.1rem 0 0.18rem 0.12rem;
	}
	.mui-segmented-control.mui-scroll-wrapper{
		height: 1.6rem;
	}
	.item{
		display: inline-block !important;
		width: 3.1rem !important;
		height: 1.6rem !important;
		background: #fff !important;
		border-radius: 3px !important;
		margin: 0 !important;
		padding: 0 !important;
		position: relative;
		.model{
			position: absolute;
			left: 50%;
			top: 50%;
			transform: translate(-50%,-50%);
			color: $blueColor;
			font-size: 0.28rem;
		}
	}
	.last{
		background: $bgColor !important;
	}
	.mui-segmented-control.mui-segmented-control-inverted .mui-control-item.mui-active{
		border: 0 none !important;
		background-color:inherit !important;
	}
</style>