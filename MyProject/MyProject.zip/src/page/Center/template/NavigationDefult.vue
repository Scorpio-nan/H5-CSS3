<template>
	<div id="Navigation">
		<!--四宫格布局-->
		<ul class="mui-table-view mui-grid-view mui-grid-9" id="GameGrid" >
			<li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3" >
				<a href="#" class="game-item" data-path="VideoGame">
					<img src="static/img/index/livecasino.png" />
					<div class="mui-media-body">真人视讯</div>
				</a>
			</li>
			<li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3">
				<a href="#" class="game-item" data-path="ElectronicGame">
					<img src="static/img/index/slot.png" />
					<div class="mui-media-body">电子游艺</div>
				</a>
			</li>
			<li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3">
				<a href="#" class="game-item" data-path="LotteryGame">
					<img src="static/img/index/lottery.png" />
					<div class="mui-media-body">彩票游戏</div>
				</a>
			</li>
			<li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3">
				<a href="#" class="game-item" data-path="SportsGame">
					<img src="static/img/index/sport.png" />
					<div class="mui-media-body">体育赛事</div>
				</a>
			</li>
			<li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3">
				<a href="#" class="game-item" data-path="ElectronicGame">
					<img src="static/img/index/mw_slot.png" />
					<div class="mui-media-body">捕鱼达人</div>
				</a>
			</li>
			<li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3">
				<a href="#" class="game-item" data-path="LotIndex">
					<img src="static/img/index/mix_six.png" />
					<div class="mui-media-body">香港六合彩</div>
				</a>
			</li>
			<li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3">
				<a href="#" class="game-item" data-path="ElectronicGame">
					<img src="static/img/index/mg_slot.png" />
					<div class="mui-media-body">老虎机</div>
				</a>
			</li>
			<li class="mui-table-view-cell mui-media mui-col-xs-3 mui-col-sm-3">
				<a href="#" class="game-item" data-path="Collect">
					<img src="static/img/index/collect.png" />
					<div class="mui-media-body">我的收藏</div>
				</a>
			</li>
		</ul>
	</div>
</template>

<script>
	export default{
		name:'Navigation',
		data(){
			return{
				
			}
		},
		methods:{
			
		},
		mounted(){
			const that = this;
			mui.init();
			mui.ready(function(){
				mui('#GameGrid').on('tap','.game-item',function(){
					var path = $(this).data('path');
					if(path == 'LotIndex'){
						that.$router.push("/hk6?title=香港六合彩&code=hk6&name=香港六合彩&id=27&");
					}else if(path == 'Collect'){
						if(!that.islogin){
							that.$alert('您还未登录哦！请立即登录！');
							return false;
						}else{
							that.$router.push({
								path:path
							})
						}
					}else{
						that.$router.push({
							path:path
						})
					}
				})
			})
		},
		computed:{
			islogin(){
				return this.$store.getters.checkLoginState;
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '../../../../static/sass/public.scss';
	#GameGrid {z-index: 10;}
	#Navigation{
		.mui-grid-view.mui-grid-9 {
			background:$whiteColor;
			border: 0 none;
		}
		.mui-grid-view.mui-grid-9 .mui-table-view-cell {
			border: 0 none;
			padding: 0 0.24rem;
		}
		.mui-table-view.mui-grid-view .mui-table-view-cell .mui-media-body {
			font-size: 0.24rem;
		}
	}
	.game-item {
		display: block;
		padding: 0.16rem 0;
		img {
			display: block;
			width: 100%;
			height: auto;
		}
	}
</style>