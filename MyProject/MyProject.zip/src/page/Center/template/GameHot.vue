<template>
	<div id="GameHot">
		<h2 class="mui-text-left mui-clearfix m-title"><span class="mui-pull-left iconfont icon-icon-25 mr-r"></span>热门游戏 <span class="slide-tps mui-pull-right">右滑查看更多</span></h2>
		<div id="slider" class="mui-slider">
			<div class="mui-slider-group">
				<!--第一张-->
				<div class="mui-slider-item mui-slider-item-duplicate mui-clearfix">
					<div class="hot-container">
						<a href="javascript:;" class="tab-item" data-code="ag_live" data-id="4" data-type="live" data-name="AG真人视讯">
							<img class="left-icon mr-r" src="static/img/index/ag_live.png" />
							<div class="right-con">
								<h4 class="hot-name mui-text-left">AG真人视讯</h4>
								<p class="hot-disc mui-text-left mui-ellipsis">AV女忧助阵赢钱</p>
							</div>
						</a>
					</div>
					<div class="hot-container">
						<a href="javascript:;" class="tab-item" data-code="bbin_live" data-id="5" data-type="live" data-name="BBIN真人视讯">
							<img class="left-icon mr-r" src="static/img/index/bbin_live.png" />
							<div class="right-con">
								<h4 class="hot-name mui-text-left">BBIN真人视讯</h4>
								<p class="hot-disc mui-text-left">真人美女发牌</p>
							</div>
						</a>
					</div>
					<div class="hot-container">
						<a href="javascript:;" class="tab-item" data-code="og_live" data-id="6" data-type="live" data-name="OG真人视讯">
							<img class="left-icon mr-r" src="static/img/index/og_slot.png" />
							<div class="right-con">
								<h4 class="hot-name mui-text-left">OG真人视讯</h4>
								<p class="hot-disc mui-text-left">连环百家乐</p>
							</div>
						</a>
					</div>
					<div class="hot-container">
						<a href="javascript:;" class="tab-item" data-code="pt_electronic" data-id="11" data-type="electronic" data-name="PT电子游艺">
							<img class="left-icon mr-r" src="static/img/index/pt_slot.png" />
							<div class="right-con">
								<h4 class="hot-name mui-text-left">PT电子游艺</h4>
								<p class="hot-disc mui-text-left">老虎机刮刮卡</p>
							</div>
						</a>
					</div>
					<div class="hot-container">
						<a href="javascript:;" class="tab-item" data-code="sa_live" data-id="753" data-type="live" data-name="SA真人视讯">
							<img class="left-icon mr-r" src="static/img/index/sa_live.png" />
							<div class="right-con">
								<h4 class="hot-name mui-text-left">SA真人视讯</h4>
								<p class="hot-disc mui-text-left">玩转电游世界</p>
							</div>
						</a>
					</div>
					<div class="hot-container">
						<a href="javascript:;" class="tab-item" data-code="bjpk10" data-id="18" data-type="cpyx" data-name="北京赛车">
							<img class="left-icon mr-r" src="static/img/index/bj_bet.png" />
							<div class="right-con">
								<h4 class="hot-name mui-text-left">北京赛车</h4>
								<p class="hot-disc mui-text-left">赚钱爽到飞起</p>
							</div>
						</a>
					</div>
				</div>
				<!-- 第二张 -->
				<div class="mui-slider-item mui-clearfix">
					<div class="hot-container">
						<a href="javascript:;" class="tab-item" data-code="tgp_live" data-id="GD" data-type="live" data-name="GD真人视讯">
							<img class="left-icon mr-r" src="static/img/index/gd_live.png" />
							<div class="right-con">
								<h4 class="hot-name mui-text-left">GD真人视讯</h4>
								<p class="hot-disc mui-text-left">多台百家乐</p>
							</div>
						</a>
					</div>
					<div class="hot-container">
						<a href="javascript:;" class="tab-item" data-code="hb_electronic" data-id="15" data-type="electronic" data-name="HB电子游艺">
							<img class="left-icon mr-r" src="static/img/index/hb_slot.png" />
							<div class="right-con">
								<h4 class="hot-name mui-text-left">HB电子游艺</h4>
								<p class="hot-disc mui-text-left">新玩法 超高人气</p>
							</div>
						</a>
					</div>
					<div class="hot-container">
						<a href="javascript:;" class="tab-item" data-code="tgp_electronic" data-id="789" data-type="electronic" data-name="SB电子游艺">
							<img class="left-icon mr-r" src="static/img/index/sb_live.png" />
							<div class="right-con">
								<h4 class="hot-name mui-text-left">SB电子游艺</h4>
								<p class="hot-disc mui-text-left">玩转电游世界</p>
							</div>
						</a>
					</div>
					<div class="hot-container">
						<a href="javascript:;" class="tab-item" data-code="ag_electronic" data-id="12" data-type="electronic" data-name="AG电子游艺">
							<img class="left-icon mr-r" src="static/img/index/ag_slot.png" />
							<div class="right-con">
								<h4 class="hot-name mui-text-left">AG电子游艺</h4>
								<p class="hot-disc mui-text-left">精彩的冒险体验</p>
							</div>
						</a>
					</div>
					<div class="hot-container">
						<a href="javascript:;" class="tab-item" data-code="mg_electronic" data-id="10" data-type="electronic" data-name="MG电子游艺">
							<img class="left-icon mr-r" src="static/img/index/mg_game.png" />
							<div class="right-con">
								<h4 class="hot-name mui-text-left">MG电子游艺</h4>
								<p class="hot-disc mui-text-left">爆奖夺金赚翻天</p>
							</div>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import api from '@/api/webUtil';
	export default {
		name:'GameHot',
		data(){
			return{
				
			}
		},
		mounted(){
			const that = this;
			mui.init();
			mui.ready(function(){
				var gallery = mui('#slider');
				gallery.slider({
					interval: 0
				});
				
				//热门游戏跳转方式
				mui('#slider').on('tap','.tab-item',function(){
					var type = $(this).data('type');
					var code = $(this).data('code');
					var id = $(this).data('id');
					var name = $(this).data('name');
					that.openUrl(type,code,id,name);
				})
				
			})
		},
		methods:{
			openUrl(type,code,id,name){
				const that = this;
				if(type == 'cpyx'){
					that.$router.push({
						path: that.Routerpath(code),
						query: {
							id: id,
							code: code,
							name: name,
							title: name,
							Value: Math.random()
						}
					});
				}else if(type == 'electronic'){
					that.$router.push({
						path: '/ElectronicGameDtail',
						query: {
							gameId: id,
							gameCd: code,
						}
					});
				}else if(type == 'live'){
					if(!that.islogin){
						that.$alert('真人游戏需要登录之后才能愉快的玩耍哦！');
						return false;
					}
					that.$toast('精彩马上开始...',{duration:'long'});
					if(!lib.IsApp){
						var wi = window.open('about:blank','_blank');
					}
					api.TransferGameURL(code,1,id,res=>{
						res = JSON.parse(res);
						if(res.state == 'error'){
							that.$alert(res.message);
							return;
						}
						if(code == 'bbin_live' || code == "sa_live"){
							//判断是wap端还是APP端
							if(lib.IsApp){
								mui.plusReady(function(){
									plus.runtime.openURL(lib.gameUrl + "?code=" + code + "&id=" + id + "&userid=" + that.UserInfo.ID);
								})
							}else{
								if(code == 'bbin_live'){
									wi.document.write(res.data.val);
									wi.document.write("<scr" + "ipt> document.post_form.submit();</scr" + "ipt>");
								}else{
									var obj = JSON.parse(res.data.val);
									wi.document.write("<form id='SaLive' name='SaLive' method='POST' action='" + obj.URLS + "'>");
									wi.document.write("<input type='hidden' id='username' name='username' value='" + obj.username + "' />");
									wi.document.write("<input type='hidden' id='token' name='token' value='" + obj.token + "' />");
									wi.document.write("<input type='hidden' id='lobby' name='lobby' value='" + obj.lobby + "' />");
									wi.document.write("<input type='hidden' id='lang' name='lang' value='" + obj.lang + "' />");
									wi.document.write("<input type='hidden' id='mobile' name='mobile' value=" + true + " />");
									wi.document.write("</form>");
									wi.document.write("<scr" + "ipt> document.SaLive.submit();</scr" + "ipt>");
								}
							}
						}else{
							if(lib.IsApp){
								mui.plusReady(function(){
									plus.runtime.openURL(res.data.val);
								})
							}else{
								wi.location.href = res.data.val;
							}
						}
					})
				}
			},
			//过滤彩票游戏
			Routerpath(code) {
				if(code == 'cqssc' || code == 'xjssc' || code == 'jsssc' || code == 'tjssc') {
					return '/ssc';
				} else if(code.indexOf("k3") >= 0) {
					return '/cp3';
				} else if(code.indexOf("11x5") >= 0) {
					return '/cp11';
				} else if(code == 'tjklsf' || code == 'gdklsf' || code == 'cqklsf') {
					return '/gdklsf';
				} else if(code == 'mlaft' || code == 'jspk10' || code == 'bjpk10') {
					return '/bjpk10';
				} else if(code == 'hk6' || code == 'jisuhk6') {
					return '/hk6';
				} else {
					return '/' + code;
				}
			},
		},
		computed:{
			islogin(){
				return this.$store.getters.checkLoginState;
			},
			UserInfo(){
				return this.$store.getters.getUserInfo;
			},
		},
		created(){
			this.$store.dispatch('getUserInfo');
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.m-title {
		padding: 0.2rem 0.24rem;
		font-size: 0.28rem;
		font-weight: 100;
		vertical-align: middle;
	}
	
	.mr-r {
		margin-right: 4px;
		font-size: 16px;
		color: #2ea9e1;
	}
	
	.hot-container {
		padding: 0.11rem;
		display: inline-block;
		width: 49.2%;
		float: left;
	}
	.mui-slider .mui-slider-group .mui-slider-item{
		padding-left: 0.08rem;
		padding-bottom: 0.1rem;
	}
	.slide-tps{
		font-size:0.24rem;
		margin-top: 0.04rem;
		color: $assistFontColor;
	}
	.tab-item {
		background: $bgColor;
		display: flex;
		padding: 0.23rem 0.12rem;
		border-radius: 3px;
		.left-icon {
			display: block;
			width: 1.2rem !important;
			height: 1.2rem;
		}
		.right-con{
			flex: 1;
			padding-left: 0.1rem;
		}
		.hot-name{
			font-size: 0.28rem;
			text-align: center;
			color: $normalFontColor;
			margin-top: 0.28rem;
			font-weight: 100;
		}
		.hot-disc{
			font-size: 0.24rem;
		}
	}
</style>