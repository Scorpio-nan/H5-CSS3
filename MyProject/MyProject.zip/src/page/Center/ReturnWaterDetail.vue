<template>
	<div id="ReturnWaterDetail">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="lr_content bgColor">
					<div class="paa_24 title_t h98">
						<div class="bor_color t_item  mui-clearfix ">
							<div class="mui-col-xs-3 t_list bory_j zyjuz_j mui-pull-left" :class="index == 0? 'bg_j_color':''" data-index="0">
								今日
							</div>
							<div class="mui-col-xs-3 zyjuz_j bory_j t_list mui-pull-left" :class="index == 1? 'bg_j_color':''" data-index="1">
								本周
							</div>
							<div class="mui-col-xs-3 zyjuz_j bory_j t_list mui-pull-left" :class="index == 2? 'bg_j_color':''" data-index="2">
								上周
							</div>
							<div class="mui-col-xs-3 zyjuz_j bory_j t_list mui-pull-left" :class="index == 3? 'bg_j_color':''" data-index="3">
								本月
							</div>
						</div>
					</div>
					<div class="item bg_j ma_t16">
						<div class="title_j bor_b">
							<div class="mui-col-xs-3  mui-pull-left">
								日期
							</div>
							<div class="mui-col-xs-3  mui-pull-left">
								投注时间
							</div>
							<div class="mui-col-xs-3  mui-pull-left">
								有效投注
							</div>
							<div class="mui-col-xs-3  mui-pull-left">
								可返水金额
							</div>
						</div>
						<div class="list_j bor_b" v-for="(item,i) in initData">
							<div class="mui-col-xs-3  mui-pull-left">
								{{item.RPT_DATE.substr(5,5)}}
							</div>
							<div class="mui-col-xs-3  mui-pull-left">
								{{item.BEGIN_REBATE_DTT.substr(10,6)}}--{{item.END_REBATE_DTT.substr(10,6)}}
							</div>
							<div class="mui-col-xs-3  mui-pull-left">
								{{item.EFFECTIVE_BET_AMT}}
							</div>
							<div class="mui-col-xs-3  mui-pull-left">
								{{item.REBATE_AMT}}
							</div>
						</div>
					</div>
					<div class="fz_j ma_t30 zyjuz_j">
						——————无更多数据——————
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	import api from '@/api/userUtil';
	export default {
		name: 'ReturnWaterDetail',
		data() {
			return {
				index:0,
				initData: [],
				queryID:'',
				beginTime:new Date().Format('yyyy-MM-dd'),
				endTime:new Date().Format('yyyy-MM-dd'),
				page:1,
				rows:15,
				code:'',
			}
		},
		created() {
			const that = this;
			this.queryID = this.$route.query.id;
			//通过传过来的id组织游戏code
			switch(this.queryID){
				case 1:
					this.code = 'hgty';
					break;
				case 2:
					this.code = 'cpyx';
					break;
				case 3:
					this.code = 'zrsx';
					break;
				case 2:
					this.code = 'dzyy';
					break;
				default:
					this.code = 'hk6';
					break;
			}
			
			this.init(this.code,'','');
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				
				mui('#ReturnWaterDetail').on('tap','.bory_j',function(){
					var index = $(this).data('index');
					that.index = index;
					that.querySubmit();
				})
				
			})
		},
		watch: {},
		computed: {},
		methods: {
			//初始化
			init(code,start,end){
				var param = {
					page:this.page,
					rows:this.rows,
					date:start,
					edate:end,
					gtype:this.code
				}
				api.GetReturnAmtList(param,(res)=>{
					console.log(res);
					this.initData = res.rows;
				})
			},
			//获取本周、上周、本月、上月的时间
			querySubmit() {
				var that = this;
				var Today = new Date();
				var weekday = new Date();
				var lastweekstart = new Date();
				var lastweekend = new Date();
				var monthstart = new Date();
				var lastmonthstart = new Date();
				var lastmonthend = new Date();

				weekday.setDate(Today.getDate() - 6); //本周开始时间时间
				lastweekstart.setDate(Today.getDate() - Today.getDay() - 6); //上周开始时间
				lastweekend.setDate(Today.getDate() - Today.getDay()); //上周结束时间
				monthstart.setDate(1); //本月第一天
				lastmonthstart.setMonth(Today.getMonth() - 1); //上月第一天
				lastmonthstart.setDate(1); //上月第一天
				lastmonthend.setDate(monthstart.getDate() - 1); //上月最后一天
				
				
				var start_date = new Date();
				var end_date = new Date();
				switch(that.index) {
					case 0:
						start_date = that.makedate(Today);
						end_date = that.makedate(Today);
						break;
					case 1:
						start_date = that.makedate(lastweekend);
						end_date = that.makedate(Today);
						break;
					case 2:
						start_date = that.makedate(lastweekstart);
						end_date = that.makedate(lastweekend);
						break;
					case 3:
						start_date = that.makedate(monthstart);
						end_date = that.makedate(Today);
						break;
				};
				this.init(this.code,start_date, end_date)
			},
			makedate(vals) {
				var val = new Date(vals);
				var month = val.getMonth() + 1;
				var strDate = val.getDate();
				if(month >= 1 && month <= 9) {
					month = "0" + month;
				}
				if(strDate >= 0 && strDate <= 9) {
					strDate = "0" + strDate;
				}
				var dateTemp = val.getFullYear() + "-" + month + "-" + strDate;
				return dateTemp
			},
			
			
		},
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	.bory_j{border-right: .02rem solid $blueColor;}
	input {
		font-size: .28rem;
	}
	.t_list.bg_j_color{color: #fff !important;}
	.mui-input-row {
		font-size: .28rem;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.zyjuz_j {
		display: flex;
		display: -webkit-flex;
		justify-content: space-around;
	}
	
	.bgColor {
		background: $bgColor;
	}
	
	.bg_j {
		background: $whiteColor;
	}
	
	.t_list {
		height: .64rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .26rem;
		color: $normalFontColor;
	}
	
	.juz {
		position: absolute;
	}
	
	.h98 {
		height: .98rem;
	}
	
	.ma_t30 {
		margin-top: .3rem;
	}
	
	.ma_t40 {
		margin-top: .4rem;
	}
	
	.bg_j_color {
		background: $blueColor;
	}
	
	.boa_5 {
		border-radius: .1rem;
	}
	
	.ma_t16 {
		margin-top: .16rem;
	}
	
	.bor_b {
		border-bottom: .02rem solid $tipsFontColor;
	}
	
	.bor_a {
		border: .02rem solid $tipsFontColor;
	}
	
	.bor_color {
		border: .02rem solid $blueColor;
	}
	
	.text_big_j {
		font-size: .55rem !important;
	}
	
	.imp_j {
		height: 1rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.title_j {
		height: .80rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.list_j {
		height: .88rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .26rem;
		color: $normalFontColor;
		label {
			height: .88rem;
			padding: 0 .24rem;
			display: flex;
			display: -webkit-flex;
			align-items: center;
			font-size: .26rem;
			color: $normalFontColor;
		}
		input {
			height: .88rem;
			padding: 0 .24rem;
			display: flex;
			display: -webkit-flex;
			align-items: center;
			font-size: .26rem;
			color: $normalFontColor;
		}
	}
	
	.paz_24 {
		padding: 0 .24rem;
	}
	
	.fz_j {
		height: .8rem;
		padding: 0 .24rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.paa_24 {
		padding: .24rem;
	}
</style>