<template>
	<div id="BankCard">
		<ul v-if="isadd" class="Banklist">
			<li class="mui-table-view-cell" v-for="(item,index) in getCardlist" :key="index" :data-id = "item.id">
				<div class="mui-slider-right mui-disabled">
					<a class="mui-btn mui-btn-red del">删除</a>
				</div>
				<div class="mui-slider-handle mui-text-center">
					<img :src="item.src" alt="">
					<span class="banktitle">{{item.title}}</span>
					<span class="banknum">{{item.desc}}</span>
				</div>				
			</li>
		</ul>
		<div v-else class="Bankbox">
			<form class="mui-input-group">
				<div class="mui-input-row">
					<label class="mui-text-justify">真实姓名</label>
					<input type="text" class="mui-input-clear" placeholder="请输入真实姓名" v-if="realName == null" v-model="UserName">
					<input type="text" class="mui-input-clear" placeholder="请输入真实姓名" v-else disabled v-model='realName'>
				</div>
				<div class="mui-input-row">
					<label class="mui-text-justify">开户行</label>
					<input type="text" class="mui-input-clear Select" placeholder="请选择开户银行" v-model="CardVal" readonly>
				</div>
				<div class="mui-input-row">
					<label class="mui-text-justify">银行卡账号</label>
					<input type="tel" class="mui-input-clear" placeholder="请填写银行卡账号" v-model="openingNumber">
				</div>
				<div class="mui-input-row">
					<label class="mui-text-justify">开户城市</label>
					<input type="text" class="mui-input-clear city" placeholder="请选择开户省市" v-model="banklocation" readonly>
				</div>
				<div class="mui-input-row">
					<label class="mui-text-justify">开户支行</label>
					<input type="text" class="mui-input-clear" placeholder="请填写开户支行" v-model="bankaddress">
				</div>
				<!--<div class="mui-input-row">
					<label class="mui-text-justify">取款密码</label>
					<input type="text" class="mui-input-clear" placeholder="请设置取款密码">
				</div>-->
			</form>
		</div>

		<div class="btn-group ">
			<button type="button" class=" mui-btn mui-btn-blue mui-btn-block mr-t-20 add-btn">添加银行卡</button>
		</div>

		<div class="Prompt">
			<div>
				*友情提示<br/>
				1.银行账户持有人姓名必须与注册时输入的姓名一致，否则无法申请提款。<br/>
				2.每位客户只可以使用一张银行卡进行提款，如需要更换银行卡请于客服人员联系；否则提款将被拒绝。<br/>
				3.为保障客户资金安全，有可能需要用户提供电话单、银行对账单。或其他资料验证，以确保客户资金不会被冒领。<br/>
			</div>
		</div>

		<transition name="fadeIn">
			<div class="redbag-mask" v-show="RedbagShow">
				<transition name="bounce">
					<div class="redbag-container" v-show="RedbagShow">
						<div class="mui-input-row">设置密码</div>
						<div class="mui-input-row">
							<label class="mui-text-justify">取款密码</label>
							<input type="password" class="mui-input-clear" placeholder="请设置6位数字取款密码" maxlength="6" v-model="Password1">
						</div>
						<div class="mui-input-row">
							<label class="mui-text-justify">确定密码</label>
							<input type="password" class="mui-input-clear" placeholder="请确定取款密码" maxlength="6" v-model="Password2">
						</div>
						<div class="mui-input-row"><button class="get">{{innerText}}</button></div>
						
					</div>
				</transition>
			</div>
		</transition>

	</div>
</template>

<script>
	import tools from '@/api/tools.js';
	import UserApi from '@/api/userUtil.js';
	import webApi from '@/api/webUtil.js';
	import agnApi from '@/api/agentUtil.js';
	export default {
		name: 'BankCard',
		data() {
			return {
				Cardlist: [],
				CardVal: '-- 请选择银行 --',
				realName: '', //user_info 读取
				UserName: '',
				banklocation: null,
				bankaddress: null,
				bankaccount: null,
				openingNumber: null,
				Password1:'',
				Password2:'',
				RedbagShow: false,
				innerText: '设置密码',
				msg:"",
				citylist:[],//城市列表
				isadd:true,
				getCardlist:[],//查询到用户绑定的银行卡
				isCard:"",//是否绑定过银行卡
			}
		},
		created() {
			const that = this;
			that.realName = that.$store.getters.getUserInfo.REAL_NAME;
			that.UserName = that.$store.getters.getUserInfo.REAL_NAME;
			this.init();
			that.getbanglist()
			this.getDrawBankList()	
		},
		mounted() {
			const that = this;
			that.ispassword()				
			mui.init();
			mui.ready(function() {
				mui('#BankCard').on('tap', '.Select', function() {
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.Cardlist);
					CardPiker.show(function(items) {
						that.CardVal = items[0]['text'];
					});
				})
				mui('.btn-group').on('tap', '.add-btn', function() {//提交银行卡信息
					//点击按钮会变高，需改loading图片大小
					$('.mui-btn-block .mui-spinner').css({
						'width': '16px',
						'height': '16px'
					})
				that.isadd=false;
					that.Submitaddbank();
					mui(this).button('loading');					
					setTimeout(() => {
						mui(this).button('reset');
					}, 1000)

					//					that.$router.push({
					//						path: 'BindingBankCard'
					//					})

					//					$('.mui-btn-block .mui-spinner').css({'width':'18px','height':'18px'})
					//				    setTimeout(function() {
					//				        mui(this).button('reset');
					//				    }.bind(this), 2000);
				})

				//点击对话框
				mui('.redbag-mask').on('tap', '.mui-input-clear', function() {
					return false
				})

				//遮罩
				mui('#BankCard').on('tap', '.redbag-mask', function() {
					that.RedbagShow = false;
					that.$router.goBack()
				})

				//点击提交支付密码
				mui('.redbag-mask').on('tap', '.get', function() {
					var pwd1 = that.Password1;
					var pwd2 = that.Password2;
					that.setpwd(pwd1,pwd2)				
				})
				//点击删除绑定银行卡
				mui('#BankCard').on('tap', '.del', function() {
					var id=$(this).closest("li").data('id');
					that.$confirm('确认删除当前银行卡？','提示',['取消','确认'],function(e){
						if(e.index == 1){
							that.delBankCard(id);
						}
					})
					

				})

				//城市列表
				mui('#BankCard').on('tap','.city',function(){
					const CardPiker = new mui.PopPicker({
						layer: 2
					});
					CardPiker.setData(that.citylist);
					CardPiker.show(function(items) {
						that.banklocation = items[0]['text']+' ';
						that.banklocation += items[1]['text'];
						CardPiker.dispose();
					});
				})


			})
		},
		methods: {

			Submitaddbank() { //添加银行卡
				var that = this;
				if(that.openingNumber != null) {
					that.bankaccount = that.openingNumber.split(' ').join('');
				};
				if(that.validate() == false) {
					return false;
				};
				var postdata = {
					PAY_BANK: that.CardVal,
					PAY_ACCOUNT: that.bankaccount,
					PAY_ADDRESS: that.banklocation + that.bankaddress,
					PAY_NAME: that.UserName
				};
				
				UserApi.SubBankInfo(postdata, function(data) {//绑定银行卡
					if(data.state == 'success') {
						that.$toast('绑定成功！');
						setTimeout(() => {
							that.bankaccount = null;
							that.openingNumber = null;
							that.banklocation = null;
							that.bankaddress = null;
							that.isadd = true;

							that.getDrawBankList()
						}, 1000)
					} else {
						that.$toast(data.message);
						that.bankaccount = null;
						that.banklocation = null;
						that.bankaddress = null;
						that.openingNumber = null;
					}
				});

			},
			TestingCard(num){//检测银行卡号
				var that = this;
				that.$Utils.luhmCheck(num,function(data){
					if(data == "success"){//卡号格式正确
						that.msg=1
					}else{
						that.$toast(data)
						that.msg=2
					}
					// that.msg = data
				})
			},
			validate: function() {
				var that = this;
				
				if(that.CardVal.indexOf('选择') > 0) {
					that.$toast('未选择银行！');
					return false;
				} else if(that.bankaccount == null || that.bankaccount == '') {
					that.$toast('未填写帐号！');
					return false;
				} else if(that.openingNumber != null || that.openingNumber != ''){
					that.TestingCard(that.openingNumber)//去检测卡号
					if(that.msg == 2){
						return false;
					}else if(that.banklocation == null || that.banklocation == '') {
						that.$toast('开户城市为空！');
						return false;
					} else if(that.banklocation.length > 20) {
						that.$toast('开户城市不得超过20位！');
						return false;
					} else if(that.bankaddress == null || that.bankaddress == '') {
						that.$toast('未填写开户行！');
					} else if(that.bankaddress.length > 20) {
						that.$toast('开户支行不得超过20位！');
						return false;
					} 				
				} 					
				
			},
			ispassword(){//检查有没有设置过密码
				var that=this
				if(that.UserInfo.DRAW_PASSWORD==null || that.UserInfo.DRAW_PASSWORD=='' || that.UserInfo.DRAW_PASSWORD== undefined){
					that.RedbagShow=true					
				}
			},
			
			setpwd(pwd1,pwd2){
				var that = this
				const reg=/^\d{6}$/;
				if(pwd1=="" || pwd2==""){
					that.$toast("取款密码不能为空")
					return false;
				}else if(!reg.test(pwd1) || !reg.test(pwd2)){
					that.$toast("密码只能是6位的数字")
					return false;
				}else if(pwd1 != pwd2){
					that.$toast("两次密码不一致")
					return false;
				}else{
					var obj = {
						attr2:pwd1,
						Pass: $.md5(pwd1)
					}
					UserApi.setDrawPass(obj,function(data){
						if(data.state == 'success') {
							that.$toast("设置成功")
							that.RedbagShow = false;
							if(that.isCard == false){
								that.$alert("您没有绑定银行卡")
							}
						}
					})
				}
			},
			init(){
				const that = this;
				$.getJSON('static/json/citylist.json', function(res) {
					that.citylist = res;
				})
			},
			getDrawBankList(){//获取绑定的银行卡列表
				var that = this; 
				that.getCardlist = [];
				UserApi.GetDrawBankList(function(data){
					if(data.length>0){//绑定过银行卡
						for(var i = 0; i < data.length; i++) {
							console.log(data)
							var obj = {
								src: that.getBankIcon2(data[i].PAY_BANK),
								title: data[i].PAY_BANK,
								desc: '**** **** **** ' + data[i].PAY_ACCOUNT.substr(data[i].PAY_ACCOUNT.length - 4),
								id: data[i].ID
							};
							that.getCardlist.push(obj);
						};
						that.isadd = true;
					}else{//没有绑定过
						that.isCard = false;
						that.isadd = !that.isadd;	//没有就默认显示添加银行卡页面
						console.log(that.isadd)
					}
				})
			},
			getBankIcon2: function(val) {
				return tools.getBankIcon(val);
			},
			getbanglist(){//所有银行卡列表
				var that = this;
				webApi.GetBankList((data)=>{
					var res = JSON.parse(data);
					res.forEach((ele,index,arr) => {
						var obj = {
							text:ele.FULLNAME,
							value:ele.FULLNAME
						}
						that.Cardlist.push(obj);
					});
				})
			},
			delBankCard(id){//删除绑定银行卡操作
			const that = this;
				UserApi.delDrawBank(id,(data)=>{
					//console.log(data)
					if(data.state == 'success'){
						that.$toast('删除成功！');
						that.getDrawBankList();
					}
				})
			},

		},
		watch: {
			openingNumber: function() {
				if(/\S{5}/.test(this.openingNumber)) {
					this.openingNumber = this.openingNumber.replace(/\s/g, '').replace(/(.{4})/g, "$1 ");
				}
			}

		},
		computed: {
			UserInfo(){
				return this.$store.getters.getUserInfo;
			},
		},
	}
</script>

<style scoped lang="scss">
	@import '../../../static/sass/public.scss';
	#BankCard {		
		height: 100%;
		position: relative;
		.Bankbox{
			padding-top: 1rem;
		}
		.Banklist{
			background:#fff;
			margin-top:0.16rem;

			img{
				width: 1rem;
				height: auto;
				float: left;
				margin-right:0.3rem;
			}
			.banktitle{
				font-size:0.24rem;
				color: $importFontColor;
				float: left;
				padding-top:0.3rem;
			}
			.banknum{
				font-size:0.24rem;
				color: $normalFontColor;
				float: right;
				padding-right:0.5rem;
				padding-top:0.3rem;				
			}
		}
	}
	
	.mui-input-group {
		background: $whiteColor;
	}
	
	input {
		font-size: 0.28rem;
	}
	
	.mui-input-row {
		font-size: 0.28rem;
		color: $normalFontColor;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.mr-t-20 {
		margin-top: 0.7rem;
	}
	.redbag-mask {
		width: 100%;
		height: 100%;
		position: absolute;
		top: 0;
   		left: 0;
		background: rgba(0, 0, 0, 0.3);
		z-index: 120;

		.redbag-container {
			border-radius:3px;
			position: absolute;
			left: 50%;
			top: 50%;
			transform: translate(-50%, -50%);
			width: 5.2rem;
			// height: 5.88rem;
			padding: 0.24rem 0;
			background:#fff;
			.mui-text-justify{
				font-size: 0.28rem;
				width:36%;
			}
			input{
				font-size: 0.28rem;
				padding-top: 0.11rem;
				width: 64%;
			}
			.get {
				border-radius: 30px;
				border: 0 none;
				background:$blueColor;
				color: #fff;
				font-size: 0.26rem;
				padding: 0.1rem 0.4rem;
			}
		}
	}
	.Prompt{
		margin-top:0.7rem;
		padding: 0.24rem;
		div{
			border-radius:3px;
			border: 1px dotted #f07377;
			font-size:0.24rem;
			background: #fff;
			text-align: left;
			padding:0.24rem;
			color: #f07377;
		}
	}

	.fadeIn-enter-active {
		animation: fade-in .5s;
	}
	
	.fadeIn-leave-active {
		animation: fade-out .5s;
	}
	
	@keyframes fade-in {
		0% {
			opacity: 0;
		}
		100% {
			opacity: 1;
		}
	}
	
	@keyframes fade-out {
		0% {
			opacity: 1;
		}
		100% {
			opacity: 0;
		}
	}
	/*
	 *  红包里面的小包包弹出
	 ***/
	
	.bounce-enter-active {
		animation: bounceIn .35s;
		transform-origin: 0 0;
	}
	
	.bounce-leave-active {
		animation: bounceOut .35s;
		transform-origin: 0 0;
	}
	
	@keyframes bounceIn {
		0% {
			opacity: 0;
			transform: scale3d(0, 0, 0)translate(-50%, -50%);
		}
		20% {
			transform: scale3d(.2, .2, .2)translate(-50%, -50%);
		}
		40% {
			transform: scale3d(.4, .4, .4)translate(-50%, -50%);
		}
		60% {
			opacity: 1;
			transform: scale3d(.6, .6, .6)translate(-50%, -50%);
		}
		80% {
			transform: scale3d(.8, .8, .8)translate(-50%, -50%);
		}
		to {
			opacity: 1;
			transform: scale3d(1, 1, 1)translate(-50%, -50%);
		}
	}
	
	@keyframes bounceOut {
		20% {
			transform: scale3d(.9, .9, .9)translate(-50%, -50%);
		}
		50%,
		55% {
			opacity: 1;
			transform: scale3d(1.1, 1.1, 1.1)translate(-50%, -50%);
		}
		to {
			opacity: 0;
			transform: scale3d(.3, .3, .3)translate(-50%, -50%);
		}
	}
</style>