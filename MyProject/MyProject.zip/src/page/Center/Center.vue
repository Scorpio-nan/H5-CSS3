<template>
	<div id="Center">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="Center-List">
					<ul class="mui-table-view mui-table-view-chevron transparentColor">
						<li class="mui-table-view-cell mui-media">
							<a class="mui-right-icon" href="javascript:;">
								<div class="mui-media-body padding innerColor">
									ID : {{UserInfo.USER_NAME}}
									<p class="mui-ellipsis innerChildColor">TEL:{{UserInfo.MOBILE?UserInfo.MOBILE:"(暂未设置)"}}</p>
								</div>
							</a>
						</li>
					</ul>
					<ul class="mui-table-view table-layout tranparentChild">
						<li class="table-item" data-path="Information">
							<a href="javascript:;" class="mui-text-left list-font innerChildColor"><span class="iconfont icon-icon-6"></span>我的消息 <span class="mui-badge mui-badge-primary" v-if="getMsgNum">  {{getMsgNum}}</span></a>
						</li>
						<li class="table-item searchRecord">
							<a href="javascript:;" class="mui-text-left list-font innerChildColor"><span class="iconfont icon-icon-14"></span>资金明细</a>
						</li>
						<li class="table-item vipCenter">
							<a href="javascript:;" class="mui-text-left list-font innerChildColor"><span class="iconfont icon-icon-13"></span>个人资料</a>
						</li>
					</ul>
					<div class="mui-table-view mr-t-8" id="account">
						<div class="account-warpper mr-r-8 default">
							<p class="mui-font mui-text-left darkcolor">账户余额</p>
							<h4 class="mui-h4 mui-font mui-text-left color-red">
								&yen;<CountUp :start-val="1" :end-val="Account.Wallet ? parseFloat(Account.Wallet) : 0" :duration="1" :decimals="2"></CountUp>
							</h4>
							<p class="mui-font mui-text-left tips ">查看详情</p>
						</div>
						<div class="fanshui-warpper">
							<p class="mui-font mui-text-left resetWater darkcolor">实时返水</p>
							<h4 class="mui-h4 mui-font mui-text-left color-gray">
								&yen;<CountUp :start-val="1" :end-val="Account.Integral ? parseFloat(Account.Integral) : 0" :duration="1" :decimals="2"></CountUp>
							</h4>
							<p class="mui-font mui-text-left tips">返水详情</p>
						</div>
						<a href="javascript:;" class="depositBtn">
							<span>返水</span>
							<span>提现</span>
						</a>
					</div>
					<div class="mui-table-view mr-t-8">
						<ul class="flex-box">
							<li class="list-font border-right border-bottom mui-text-left" data-index="0">
								<a href="javascript:;" class="mui-text-left list-font"><span class="iconfont icon-icon-12 color-red"></span>充值</a>
							</li>
							<li class="list-font border-bottom mui-text-left" data-index="1">
								<a href="javascript:;" class="mui-text-left list-font"><span class="iconfont icon-icon-17 color-red"></span>额度转换</a>
							</li>
						</ul>
						<ul class="flex-box">
							<li class="list-font border-right mui-text-left" data-index="2">
								<a href="javascript:;" class="mui-text-left list-font"><span class="iconfont icon-icon-30 color-red"></span>取款</a>
							</li>
							<li class="list-font mui-text-left" data-index="3">
								<a href="javascript:;" class="mui-text-left list-font"><span class="iconfont icon-icon-16 color-red"></span>代理中心</a>
							</li>
						</ul>
					</div>
					<ul class="mui-table-view mui-table-view-chevron mr-t-8 list-ico-group ">
						<li class="mui-table-view-cell Flowdetails">
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-79"></span>流水明细<i class="mui-pull-right tips">查看存/取款、转账记录</i></a>
						</li>
						<li class="mui-table-view-cell Betting">
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-60"></span>投注记录<i class="mui-pull-right tips">查看投注记录</i></a>
						</li>
						<li class="mui-table-view-cell BankCard">
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-80"></span>银行卡<i class="mui-pull-right tips">绑定银行卡信息</i></a>
						</li>
						<li class="mui-table-view-cell Account">
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont">&#xe672;</span>账号与安全<i class="mui-pull-right tips">修改取款密码</i></a>
						</li>
					</ul>
					<ul class="mui-table-view mui-table-view-chevron mr-t-8 list-ico-group ">
						<li class="mui-table-view-cell clear">
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-52"></span>清除缓存</a>
						</li>
						<li class="mui-table-view-cell cellme">
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-55"></span>联系我们</a>
						</li>
						<li class="mui-table-view-cell aboutUs">
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font"><span class="iconfont icon-icon-56"></span>关于我们</a>
						</li>
					</ul>
					<ul class="mui-table-view  mr-t-8 ">
						<li class="mui-table-view-cell loginOut" style="text-align: center;">
							<a>退出登录</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import CountUp from '@/components/CountUp';
	import api from '@/api/userUtil'
	export default {
		name: 'Center',
		components: {
			CountUp
		},
		data() {
			return {}
		},
		mounted() {
			const that = this;
			mui.init();
			this.userInfoInit();
			mui.ready(function() {
				// Scroll 区域
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});

				mui('.Center-List').on('tap', '.Betting', function() {
					that.$router.push({
						path: 'BettingRecord'
					})
				})

				//流水明细
				mui('.Center-List').on('tap', '.Flowdetails', function() {
					that.$router.push({
						path: 'Flowdetails'
					})
				})

				/*ACE 会员中心*/
				mui('.Center-List').on('tap', '.vipCenter', function() {
					that.$router.push({
						path: 'UserMsg'
					})
				})
				mui('.Center-List').on('tap', '.vipCenter', function() {
					that.$router.push({
						path: 'UserMsg'
					})
				}) //跳转到个人资料
				mui('.Center-List').on('tap', '.cellme', function() {
					that.$router.push({
						path: 'CellMe'
					})
				}) //跳转到联系我们
				mui('.Center-List').on('tap', '.default', function() { //default
					that.$router.push({
						path: 'AccountBalance'
					})
				})

				mui('.Center-List').on('tap', '.resetWater', function() {
					that.$router.push({
						path: 'VipCenter'
					})
				})

				mui('.Center-List').on('tap', '.searchRecord', function() { //资金明细
					that.$router.push({
						path: 'CaptailDetail'
					})
				})
				/*END*/

				mui('.Center-List').on('tap', '.BankCard', function() {
					that.$router.push({
						path: 'BankCard'
					})
				})

				mui('.Center-List').on('tap', '.Account', function() {
					that.$router.push({
						path: 'Account'
					})
				})

				mui('#Center').on('tap', '.fanshui-warpper', function() {
					that.$router.push({
						path: 'ReturnWaterRecord'
					})
				})
				mui('#Center').on('tap', '.mui-media', function() {
					that.$router.push({
						path: 'AccountInformation'
					})
				})
				mui('.table-layout').on('tap', '.table-item', function() {
					var path = $(this).data('path');
					that.$router.push({
						path: path
					})
				})

				mui('.mui-table-view').on('tap', '.aboutUs', function() {
					that.$router.push({
						path: 'AboutUs'
					})
				})

				//退出登录
				mui('.mui-table-view').on('tap', '.loginOut', function() {
					var arr = ['取消', '确认'];
					that.$confirm('确认退出当前账号？', '温馨提示', arr, function(e) {
						if(e.index == 1) {
							that.handleLoginOut();
							that.$toast('退出登录！');
							that.$router.push({
								path: '/'
							})
						}
					})
				})

				//清除缓存
				mui('.mui-table-view').on('tap', '.clear', function() {
					var arr = ['取消', '确认']
					that.$confirm('您确定要清除所有的浏览记录？', '提示', arr, function(e) {
						if(e.index == 1) {
							window.localStorage.clear();
							that.$toast('清除成功！');
						}
					})
				})

				//返水提现
				mui('.Center-List').on('tap', '.depositBtn', function() {
					var arr = ['取消', '确认'];
					that.$confirm('将返水余额转入我的钱包？', '提示', arr, function(e) {
						if(e.index == 1) {
							if(parseFloat(that.Wallet) > 0) {
								that.handleDeposit();
								that.$toast('提现成功！');
							} else {
								that.$alert('当前可提现金额不足！');
							}
						}
					})
				})

				mui('.flex-box').on('tap', '.mui-text-left', function() {
					var index = $(this).data('index');
					that.index = index;
					if(index == 0) {
						that.$router.push({
							path: '/Rechargeonline'
						})
					} else if(index == 1) {
						that.$router.push({
							path: '/QuotaConversion'
						})
					} else if(index == 2) {
						that.$router.push({
							path: '/WithdrawMoney'
						})
					} else if(index == 3) {
						that.$router.push({
							path: '/AgentCenter'
						})
					}
				})
			})
		},
		methods: {
			//退出登录
			handleLoginOut() {
				api.OutLogin(this);
			},
			//返水提现
			handleDeposit() {
				api.GetReturnAmtToWallet((res) => {
					if(res) {
						this.$store.dispatch('getAccount');
					}
				})
			},
			userInfoInit() {
				var this_ = this;

				// this_.personalName = this_.userInfo.USER_NAME;
				// this_.personalLevel = this_.userInfo.GROUP_NAME;
				// this_.personalREAL = this_.userInfo.REAL_NAME;
				// this_.personalTel = this_.userInfo.MOBILE;
				// this_.personalDtt = this_.userInfo.CREATE_DTT;
			},

		},
		computed: {
			Account() {
				var UserArr = this.$store.getters.getAccount;
				var obj = {
					Wallet: '',
					Integral: ''
				}
				for(let i = 0; i < UserArr.length; i++) {
					if(UserArr[i].ACC_BAL_CD == 'my_wallet') {
						obj.Wallet = UserArr[i].ACC_BAL.toFixed(2);
					} else {
						obj.Integral = UserArr[i].ACC_BAL.toFixed(2);
					}
				}
				return obj;
			},
			UserInfo() {
				return this.$store.getters.getUserInfo;
			},
			getMsgNum() {
				return this.$store.getters.getMsgNum;
			},
		},
		created() {
			var this_ = this;
			setTimeout(function() {
				this_.$store.dispatch('getAccount');
				this_.$store.dispatch('getMsgNum');
			}, 600)

		}
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	.darkcolor{
		color: #333
	}
	.mr-t-8 {
		margin-top: 0.2rem;
	}
	
	.Center-List {
		padding-bottom: 0.4rem;
	}
	
	.mr-r-8 {
		margin-right: 0.2rem;
	}
	
	.transparentColor {
		background: $titleBgColor;
		&:after {
			display: none;
		}
		&:before {
			display: none;
		}
	}
	
	.innerColor {
		color: $bgColor;
	}
	
	.innerChildColor {
		color: rgba($bgColor, 0.6) !important;
	}
	
	.mui-table-view-cell>a:not(.mui-btn).mui-active {
		background: rgba($bgColor, 0.6);
	}
	
	.tranparentChild {
		background: rgba($titleBgColor, 0.9);
		li {
			&:after {
				display: none;
			}
		}
		&:before {
			display: none;
		}
	}
	
	.tips {
		font-size: 0.24rem !important;
		color: $assistFontColor;
	}
	
	.border-right,
	{
		border-right: 3px solid #eee;
	}
	
	.border-bottom {
		border-bottom: 3px solid #eee;
	}
	
	.mui-right-icon {
		position: relative;
		&:after {
			display: block;
			content: '\e583';
			font-family: Muiicons;
			font-size: inherit;
			line-height: 1;
			position: absolute;
			top: 50%;
			display: inline-block;
			-webkit-transform: translateY(-50%);
			transform: translateY(-50%);
			text-decoration: none;
			color: #fff;
			-webkit-font-smoothing: antialiased;
			right: 38px;
		}
	}
	
	#Center {
		width: 100%;
		height: 100%;
		.padding {
			padding: 0.1rem 0;
		}
		.table-layout {
			display: table;
			width: 100%;
			.table-item {
				display: table-cell;
				width: 33.3333%;
				padding: 0.2rem 0;
				&:active {
					background: rgba($bgColor, 0.3) !important;
				}
				.iconfont {
					font-size: 0.4rem;
					vertical-align: middle;
					margin-right: 3px;
				}
			}
		}
		.user-count {
			font-size: 0.3rem;
			padding: 0 5px;
			color: $warnColor;
		}
		.list-font {
			font-size: 0.28rem;
			color: $normalFontColor;
			vertical-align: middle;
			.color-red {
				color: #e95316;
				font-size: 0.4rem;
				margin-right: 5px;
				vertical-align: middle;
				transform: translateY(-3px);
			}
		}
		.flex-box {
			display: flex;
			li {
				flex: 1;
				padding: 0.2rem 0.24rem;
				&:active {
					background: #f2f2f2;
				}
			}
		}
		#account {
			display: flex;
			background: $bgColor;
			position: relative;
			.account-warpper,
			.fanshui-warpper {
				flex: 1;
				padding: 0.24rem;
				background: #fff;
				&:active {
					background: rgba($bgColor, 0.3) !important;
				}
				.mui-font {
					font-size: 0.28rem;
				}
			}
			.fanshui-warpper {
				p {
					font-size: 0.28rem;
					padding-left: 0.8rem;
				}
				.tips {
					font-size: 0.24rem;
				}
				.mui-h4 {
					padding: 0.1rem 0;
					padding-left: 0.8rem;
				}
			}
			.account-warpper {
				.mui-h4 {
					padding: 0.1rem 0;
				}
			}
			.color-red {
				color: $warnColor;
			}
			.color-gray {
				color: $assistFontColor;
			}
			.depositBtn {
				text-align: center;
				display: block;
				width: 1rem;
				height: 1rem;
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -50%);
				background: linear-gradient(to bottom, #33d6d6 0%, #19b4f5 100%);
				border-radius: 50%;
				font-size: 0.24rem;
				padding-top: 0.15rem;
				box-shadow: 0 0 0 0.14rem $bgColor;
				color: #fff;
				span {
					display: block;
					line-height: 0.35rem;
				}
				&:active {
					background: rgba(#19b4f5, 0.7);
				}
			}
		}
		.list-ico-group {
			.iconfont {
				font-size: 0.4rem;
				color: $blueColor;
				margin-right: 5px;
				vertical-align: middle;
			}
		}
	}
	
	.mui-table-view-chevron .mui-table-view-cell>a:not(.mui-btn) {
		margin-right: -95px;
	}
	
	.mui-navigate-right:after,
	.mui-push-right:after {
		right: 40px;
	}
	
	.mui-badge-blue,
	.mui-badge-primary {
		background-color: #ec5055;
	}
	
	.mui-table-view:before {
		display: none;
	}
</style>