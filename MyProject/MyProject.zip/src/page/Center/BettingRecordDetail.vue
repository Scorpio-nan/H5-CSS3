<template>
	<div id="BetttingRecodsDtail">
		<div class="condition">
			<button class="mui-btn BeginTime mr-r" data-options='{}'>{{endTime}}</button>
			<button class="mui-btn GameType">{{currentGame}}</button>
			<input type="text" class="mui-input mr-l" placeholder="请输入下注号码" v-model="queryNum" v-if="showQueryNum" />
		</div>
		<nav class="thead">
			<a href="javascript:;" v-for="(item,index) in thead">{{item}}</a>
		</nav>
		<div class="main">
			<Scroller :on-infinite="infinite" ref="Scroll" :loadingShow="loadingShow">
				
				<!-- 真人 电子类 -->
				<table border="" cellspacing="" cellpadding="" v-if="$route.query.game_cd == 3 || $route.query.game_cd == 9">
					<tr v-for="(item,index) in liveRecordListData">
						<td>
							<p>{{item.CODE_NAME}}</p>
							<p>{{item.GAME_TYPE}}</p>
						</td>
						<td>{{item.BETTING_TIME!=null?item.BETTING_TIME.substr(5,5):''}}</td>
						<td>{{item.GAME_NAME}}</td>
						<td>&yen;{{item.VALIDBET_AMT}}/
							<span v-if="item.WINNING_PLAYER_LIMIT<0" class="error">&yen;{{item.WINNING_PLAYER_LIMIT}}</span>
							<span v-else class="success">&yen;{{item.WINNING_PLAYER_LIMIT}}</span>
						</td>
					</tr>
				</table>

				<!-- 彩票游戏类 -->
				<table border="" cellspacing="" cellpadding="" v-else-if="$route.query.game_cd == 2">
					<tr v-for="(item,index) in ticketRecordListData">
						<td>{{item.LOTTERY_TICKET_NAME}}</td>
						<td>
							<p>{{item.BET_DTT!=null?item.BET_DTT.substr(5,5):''}}</p>
							<p>{{item.PERIODS_NO}}</p>
						</td>
						<td>
							<p>{{item.BET_RULE}}</p>
							<p>{{item.BET_NO}}</p>
						</td>
						<td>
							&yen;{{item.BET_AMT}}/
							<span v-if="item.WIN<0" class="error">&yen;{{item.WIN}}</span>
							<span v-else class="success">&yen;{{item.WIN}}</span>
							<br />
							<span :style=" item.OK_IND=='1'?'color:#1AAD19':''">{{item.BET_RESULT}}</span>
						</td>
					</tr>
				</table>

				<!-- 体育赛事类   -->
				<table border="" cellspacing="" cellpadding="" v-else-if="$route.query.game_cd == 1">
					<tr v-for="(item,index) in sptRecordListData">
						<td>{{item.LOTTERY_TICKET_NAME}}</td>
						<td>
							<p v-if="item.NORMAL_PARLAY==0">{{item.BET_DETAIL_JSON.league_name}}</p>
							<p v-else>{{item.ODDS_TYPE}}</p>
						</td>
						<td>
							<p v-if="item.NORMAL_PARLAY==0">{{item.BET_DETAIL_JSON.teamA_name}}vs{{item.BET_DETAIL_JSON.teamB_name}}</p>
							<p v-else>{{item.PLAY_TYPE}}串球</p>
						</td>
						<td>
							&yen;{{item.WAGER_STAKE}}/
							<span v-if="item.WIN_AMT<0" class="error">&yen;{{item.WIN_AMT}}</span>
							<span v-else class="success">&yen;{{item.WIN_AMT}}</span>
							<br />
							<span>{{item.BETTING_STATUS}}</span>
						</td>
					</tr>
				</table>
			</Scroller>
		</div>
		<div class="btn-container">
			<button class="mui-btn mui-btn-block btn">确认查询</button>
		</div>
	</div>
</template>

<script>
	import Scroller from '@/components/Scroller';
	import api from '@/api/webUtil';
	import Userapi from '@/api/userUtil';
	import Repapi from '@/api/report';
	export default {
		name: 'BetttingRecodsDtail',
		components: {
			Scroller
		},
		data() {
			return {
				queryID: '',
				thead: [],
				beginTime: '',
				endTime: new Date().Format('yyyy-MM-dd hh:mm'),
				gameList: [],
				currentGame: '', //当前选中游戏类名
				currentValue: '', //当前选中查询游戏类别的id
				page: 1,
				rows: 15,
				queryNum: '', //单号查询
				param: {},
				liveRecordListData: [], //真人数组集合
				ticketRecordListData: [], //彩票数组集合
				sptRecordListData: [], //体育数组集合
				loadingShow: true,
				loadMore: true,
				showQueryNum: true, //如果是电子游戏和真人视讯类就隐藏单号查询
			}
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				//开始时间
				mui('.condition').on('tap', '.BeginTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {
						})
					} else {
						//var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker({
							beginDate: new Date(that.beginTime.split("-"))//设置开始日期
						});
						self.piker.show(function(res) {
							self.picker = null;
							that.endTime = res['text'];
						})
					}
				})

				//游戏种类选择
				mui('.condition').on('tap', '.GameType', function() {
					const self = $(this);
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.gameList);
					CardPiker.show(function(items) {
						that.currentGame = items[0]['text'];
						that.currentValue = items[0]['value'];
					});
				})

				//点击查询按钮
				mui('.btn-container').on('tap', '.btn', function() {
					that.liveRecordListData = [];
					that.ticketRecordListData = [];
					that.sptRecordListData = [];
					that.page = 1;
					that.loadMore = true;
					switch(that.queryID) {
						case 3:
							that.getSportGame();
							break;
						case 2:
							that.getLooteryGame();
							break;
						default:
							that.getVideoGame();
					}
				})

			})
		},
		created() {
			this.queryID = this.$route.query.game_cd; //3是视讯，9是电子，2是彩票，1是体育
			this.beginTime = this.$route.query.start;
			console.log(this.beginTime.split("-"))
			switch(this.queryID) {
				case 1:
				//体育类
					this.gameList = [];
					this.thead = ['游戏类别', '游戏场次', '下注内容', '下注/输赢'];
					this.init(1);
					this.getSportGame();
					break;
				case 2:
					//彩票类
					this.gameList = [];
					this.thead = ['游戏类别', '下注期数', '下注内容', '下注/输赢'];
					this.init(2);
					this.getLooteryGame();
					break;
				default:
					//真人电子类
					this.showQueryNum = false;
					this.gameList = [];
					this.thead = ['游戏类别', '下注时间', '游戏名称', '下注/输赢'];
					this.init(3);
					this.init(9);
					this.getVideoGame();
					break;
			}

		},
		methods: {
			//上拉加载
			infinite(finish) {
				const that = this;
				if(!that.loadMore) {
					setTimeout(() => {
						that.loadingShow = false;
						finish(true);
					}, 1500)
					return;
				}
				setTimeout(() => {
					switch(that.queryID) {
						case 3:
							that.getSportGame();
							break;
						case 2:
							that.getLooteryGame();
							break;
						default:
							that.getVideoGame();
					}
					setTimeout(() => {
						finish();
					},1000)
				}, 1500)
			},
			//初始化
			init(id) {
				const that = this;
				api.GetMobileList(id, (res) => {
					for(let i = 0; i < res.length; i++) {
						var obj = {
							text: res[i].LOTTERY_TICKET_NAME,
							value: res[i].ID
						}
						that.gameList.push(obj);
					}
					//下拉列表默认显示项
					if(that.queryID == 1) {
						that.currentGame = res[0].LOTTERY_TICKET_NAME;
					} else {
						that.currentGame = that.gameList[0]['text'];
					}
				})
			},
			//真人视讯和电子游艺接口
			getVideoGame() {
				const that = this;
				var param = {
					b_no: this.queryNum,
					sys_id: this.currentValue,
					star_time: this.beginTime,
					end_time: this.endTime,
					rows: this.rows,
					page: this.page,
					sidx: 'BETTING_TIME',
					sord: 'DESC'
				}
				Userapi.GetIntBet(param, (res) => {
					var res = JSON.parse(res);
					if(res.rows.length == 0) {
						that.loadMore = false;
						that.$toast('暂无更多数据...')
					}
					for(let i = 0; i < res.rows.length; i++) {
						that.liveRecordListData.push(res.rows[i]);
					}
					that.page++;
				})
			},
			//彩票游戏接口
			getLooteryGame() {
				const that = this;
				var param = {
					b_no: this.queryNum,
					sys_id: this.currentValue,
					star_time: this.beginTime,
					end_time: this.endTime,
					rows: this.rows,
					page: this.page,
					sidx: 'a.ID',
					sord: 'DESC'
				}
				Userapi.GetLotterList(param, (res) => {
					var res = JSON.parse(res);
					if(res.rows.length == 0) {
						that.loadMore = false;
						that.$toast('暂无更多数据...')
					}
					for(let i = 0; i < res.rows.length; i++) {
						that.ticketRecordListData.push(res.rows[i]);
					}
					that.page++;
				})
			},
			//获取体育赛事接口
			getSportGame() {
				const that = this;
				var param = {
					b_no: this.queryNum,
					sys_id: this.currentValue,
					star_time: this.beginTime,
					end_time: this.endTime,
					rows: this.rows,
					page: this.page,
					sidx: 'ID',
					sord: 'DESC'
				}
				Repapi.GetSptList(param, (res) => {
					if(res.rows.length == 0) {
						that.loadMore = false;
						that.$toast('暂无更多数据...')
					}
					for(let i = 0; i < res.rows.length; i++) {
						that.sptRecordListData.push(res.rows[i]);
					}
					that.page++;
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	#BetttingRecodsDtail {
		display: flex;
		flex-direction: column;
		.thead {
			display: flex;
			background: #fff;
			padding: 0.12rem 0;
			margin-top: 0.16rem;
			@include border1px(#ccc, bottom) a {
				flex: 1;
				font-size: 0.24rem;
			}
		}
		.condition {
			display: flex;
			padding: 0.24rem;
			background: #fff;
			.mui-btn {
				margin: 0;
				font-size: 0.24rem;
				flex: 1;
			}
			input {
				margin: 0;
				font-size: 0.24rem;
				flex: 1;
			}
			.mr-r {
				margin-right: 0.16rem;
			}
			.mr-l {
				margin-left: 0.16rem;
			}
		}
		.main {
			flex: 1;
			position: relative;
			table {
				width: 100%;
				background: #fff;
				color: #666;
				tr {
					height: 0.66rem;
					td {
						font-size: 0.24rem;
						@include border-1px(#ccc, bottom);
						width: 25%;
					}
				}
			}
		}
		.btn-container {
			padding: 0.24rem;
			.btn {
				margin: 0;
				padding: 0.2rem 0;
				background: #19b4f5;
				border: 0 none;
				color: #fff;
				&:active {
					background: rgba(#19b4f5, 0.6);
				}
			}
		}
	}
</style>