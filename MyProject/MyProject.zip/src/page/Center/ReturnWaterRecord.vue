<template>
	<div id="ReturnWaterRecord">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="rw_content mr_t16">
					<div class="item text_jiac">
						<div class="list_j mui-text-left">
							实时返水(元)
						</div>
						<div class="list_j mui-text-left">
							<i class="rmb">¥</i> <span class="pa_24 text_big_j totalMount">{{initSum.toFixed(2)}} </span>
						</div>
					</div>
					<ul class="item  mr_t16" id="ReturnWaterRecord_list">
						<li class="list pa_24" v-for="(item,index) in initData" :data-id="item.ID">
							<div class="mui-text-left mui-pull-left mui-col-xs-6">
								{{item.PARA_NAME + '返水'}}
							</div>
							<div class="mui-text-right mui-pull-right mui-col-xs-6">
								¥ {{item.SUM_REBATE_AMT.toFixed(2)}}<span class="mui-icon mui-icon-forward fontColor"></span>
							</div>
						</li>
					</ul>

					<div class="b_text pa_24 ma_t300 ReturnWaterTips">
						<h3 class="mui-text-left text_color_warn returnWaterTitle">*返水提示*</h3>
						<div class="b_con   mui-text-left boa_5 ">
							<p class="text_color_warn"> 1、彩票游戏，六合彩，游戏结束后立即结算返水；实时返水记录可到注单明细查看，数据统计前1小时的返水；</p>
							<p class="text_color_warn">2 、电子游艺，真人视讯，每小时结算注单返水</p>
							<p class="text_color_warn">3 、皇冠体育，每天的凌晨两点，结算前一天的注单返水</p>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
</template>
<script>
	import api from '@/api/userUtil';
	export default {
		name: 'ReturnWaterRecord',
		data() {
			return {
				initData: [],
				initSum: 0,
			}
		},
		beforeMount: function() {

		},
		created() {
			const that = this;
			this.init();
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				mui('#ReturnWaterRecord_list').on('tap', '.list', function() {
					var id = $(this).data('id');
					that.$router.push({
						path: 'ReturnWaterDetail',
						query: {
							id: id
						}
					})
				})
			})
		},
		watch: {},
		computed: {

		},
		methods: {
			//数据初始化
			init() {
				const that = this;
				api.GetSumUserReturnAmt((res) => {
					that.initData = res;
					console.log(res);
					res.forEach((ele, index, arr) => {
						that.initSum += parseFloat(ele.SUM_REBATE_AMT);
					})
				})
			}
		},
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	.fontColor{
		color: #999
	}
	.returnWaterTitle{
		font-size: .28rem !important;
	}
	.rmb{
		margin-top: .2rem;
		display: inline;
		vertical-align: bottom;
	}
	.totalMount{
		display: inline;
		padding-left: .05rem !important;
		vertical-align: bottom;
	}
	.text_color_warn {
		color: $warnColor !important;
	}
	
	.ReturnWaterTips {
		border: 1px dashed #ec5050;
	}
	.text_jiac{
		@include border-1px(#ccc,bottom);
	}
	#ReturnWaterRecord {
		background: $bgColor;
		.item {
			background: $whiteColor;
			.list {
				height: .9rem;
				/*			border-bottom: .02rem solid $tipsFontColor;*/
				display: flex;
				display: -webkit-flex;
				align-items: center;
				font-size: .28rem;
				color: $importFontColor;
				letter-spacing: -.01rem;
				font-weight: bold;
			}
			.list:last-child {
				border-bottom: none;
			}
		}
		.b_text {
			h3 {
				margin-top: .4rem;
				margin-bottom: .2rem;
				display: flex;
				display: -webkit-flex;
				align-items: center;
				font-size: .32rem;
				color: $blackColor;
				font-weight: normal;
			}
			.b_con {
				padding-bottom: .4rem;
				p {
					display: flex;
					display: -webkit-flex;
					align-items: center;
					font-size: .24rem;
					color: $normalFontColor;
					font-weight: normal;
				}
			}
		}
	}
	
	.text_jiac {
		font-weight: bold;
	}
	
	.text_big_j {
		font-size: .55rem !important;
		font-weight: bold;
	}
	
	input {
		font-size: .28rem;
	}
	
	.mui-input-row {
		font-size: .28rem;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.ma_t300 {
		margin: .34rem .3rem 0 .3rem;
	}
	
	/*.mr_t16 {
		margin-top: .16rem;
	}*/
	
	.pa_4 {
		padding: 0 .44rem;
	}
	
	.pa_24 {
		padding: 0 .2rem 0 .3rem;
		@include border-1px(#ccc,bottom);
	}
	
	.paa_2 {
		padding: .2rem;
	}
	
	.list_j {
		width: 100%;
		height: .9rem;
		padding: 0 .3rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.border_all {
		border: .02rem solid $tipsFontColor;
	}
	
	.boa_5 {
		border-radius: .1rem;
	}
	
	.whiteColor {
		background: $whiteColor;
	}
	
	.mui-icon-forward:before {
		position: relative;
		top: 1px;
	}
</style>