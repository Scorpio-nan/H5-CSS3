<template>
	<div id="ElectronicGameDtail">
		<div class="Serch-container">
			<a href="javascript:;" class="serch-condition mui-text-left dragdown">筛选<span class="iconfont icon-xiangxia1 mui-pull-right mr-r down" :class="hide ? 'handleUp':'handleDown'"></span></a>
			<div class="serch-input">
				<input type="search" class="mui-input-clear" placeholder="查找游戏" v-model="searchText">
			</div>
			<a href="javascript:;" class="serch-btn">
				<span class="iconfont icon-sousuo"></span>
			</a>
		</div>
		<div class="gameList-container">
			<!-- 默认列表 -->
			<scroller :on-infinite="infinite" ref="Scroll" :loadingShow="loadingShow">
				<ul class="game-list" id="game-list_j">
					<li class=" mui-item" v-for="(item , index) in gameList" :key="index">
						<a href="javascript:;" class="inline-block">
							<div class="item-img" :data-gameid="item.GAME_ID">
								<img :src="'static/img/game/'+gameCd+'/'+item.GAME_ID.replace('|','_')+'.png'" />
							</div>
							<div class="item-title mui-clearfix">
								<p class="mui-pull-left mui-ellipsis">{{item.ZH_GAME_NAME}}</p>
								<span class="iconfont mui-pull-right scBtn" :data-id="item.ID" :class="item.DELETE_IND*1 ? 'icon-xin' : 'icon-xin1' "></span>
							</div>
						</a>
					</li>
				</ul>
			</scroller>

			<!-- 下拉列表 -->
			<div class="dragDown-container">
				<h3 class="mui-h5 mui-text-left">游戏平台</h3>
				<div class="select-btn-group">
					<a href="javascript:;" class="active">所有平台</a>
					<span class="kuang" v-for="(item,index) in results" :key="index">
						<a href="javascript:;" class="game" :data-id="item.gameId" :data-code="item.gameCd" :data-shudu="index"  :class="[index2 == index ? 'mui-active2': '']">{{item.title}}</a>
					</span>
				</div>
				<div class="btn-con">
					<button class="mui-btn-block mui-btn-danger done">完成</button>
				</div>
			</div>
		</div>
		
		<!--  需要手动关闭遮罩添加     @handleHide="handleLodingHide"   -->
		<TransferDom :show="loadingImg">
			<img src="static/img/loading/loading-bars.svg" alt="" class="loading"/>
		</TransferDom>
		
	</div>
</template>

<script>
	import web from '@/api/webUtil'
	import Scroller from '@/components/Scroller'
	import TransferDom from '@/components/TransferDom';
	export default {
		components: {
			Scroller,
			TransferDom
		},
		name: 'ElectronicGameDtail',
		data() {
			return {
				gemeCdType:[],
				imgUrl_: lib.electronImgUrl,
				gameList: [],
				gameTypeId: 0,
				gameCd: '',
				liveStat: {
					pullupStatus: 'default'
				},
				scrollerHeight: '300px',
				searchText: '',
				livePage: { //真人參數
					total: 0, //总页数
					page: 1, //当前页数
					rows: 15, //每页显示记录数
					records: 0, //总记录数
					isDataLoading: false, //加载时显示
					isNotData: false, //无数据时显示
					pullupStatus: 'default'
				},
				isLoginShowWarn: false,
				LoginShowWarnText: '',
				isFixed: false,
				
				loadingShow: true,
				list: 15,
				jiazing: false,
				first: 0,
				hide: false,
				dragstart: false,
				nowTime: '',
				clickTime: '',
				tx: 0,
				ctx: 0,
				loadingImg:false,
				results: [],
				index2: 0,
				code_id:'',
				game_cd:''
			}
		},
		mounted() {
			const that = this;
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});
			mui.init();
			mui.ready(function() {
				mui('.Serch-container').on('tap', '.dragdown', function() {
					that.dragDownShow();
				});
				//下拉栏目
				mui('.select-btn-group').on('tap', '.game', function() {
					var xuan = $(this).data('shudu');
					that.index2 = xuan;
					that.code_id = $(this).data('id');
					that.game_cd = $(this).data('code');			
				});
				//确认筛选
				mui('.btn-con').on('tap', '.done', function() {
					that.livePage.page = 1;
					that.gameTypeId = that.code_id;
					that.gameList = [];
					that.getGameList();
					that.gameCd = that.game_cd;
					that.dragDownShow()
				});		
				mui('.Serch-container').on('tap', '.serch-btn', function() {
					that.onCancel()
				});		
				//点击跳转
				mui('.game-list').on('tap','.item-img',function(){
					var gameID = $(this).data('gameid');
					that.onItemClick(gameID,that.gameCd);
				})

				mui('#ElectronicGameDtail').on('tap', '.scBtn', function(e) {
					var id = $(this).data('id')
					var self = $(this);
					that.shoucang(id,self)
				})
			})
		
		},
		computed: {
			islogin() {
				return this.$store.getters.checkLoginState;
			},
		},
		created() {
			var this_=this;
			this_.gameTypeId = this_.$route.query.gameId;
			this_.gameCd = this_.$route.query.gameCd;
			this_.getGameList();
			this_.getResult();
		},
		methods: {
			onCancel() {
				var this_ = this;
				this_.isFixed = false
				this_.livePage.page = 1;
				this_.livePage.isNotData = true;
				this_.livePage.isDataLoading = true;
				this_.gameList = [];
				this_.getGameList();
			},
			//搜索接口
			getResult() {
				var this_ = this;
				web.GetMobileList(9, function(data) {
					for(var i = 0; i < data.length; i++) {
						this_.results.push({
							title: data[i].PARA_NAME,
							gameId: data[i].ID,
							gameCd: data[i].CODE
						})
					}
				})
			},			
			shoucang(id,self){
				if(!this.islogin){
					this.$alert('您还未登录哦！请立即登录！');
					return false;
				}
				var that = this
				var idx = that.gameTypeId
				web.AddGameFavorite(3,idx,id,function(data){
					data = JSON.parse(data);
					if(data.state == "success"){
						self.removeClass("icon-xin1").addClass('icon-xin');
						that.$toast("收藏成功")
					}else{
						self.removeClass("icon-xin").addClass('icon-xin1');
						that.$toast("取消成功")
					}
				})
			},
			onItemClick(gameId,gameCd) {
				if(!this.islogin){
					this.$alert('您还未登录哦！请立即登录！');
					return false;
				}
				const that = this;
				that.loadingImg = true;
				if(!lib.IsApp){
					var wi = window.open('about:blank', '_blank');
				}
				web.TransferGameURL(gameCd, 1, gameId, res => {
					res = JSON.parse(res);
					that.loadingImg = false;
					if(res.state == 'error'){
						that.$alert(res.message);
						return;
					}
					if(lib.IsApp){
						mui.plusReady(function(){
							plus.runtime.openURL(res.data.val);
						})
					}else{
						wi.location.href = res.data.val;
					}
				})
			},
			getGameList() {
				var this_ = this;
				var postData = {
					sys_id:this_.gameTypeId,
					mode_ind:1,
					rows: this_.livePage.rows,
					page: this_.livePage.page,
					mob:1,
					game_name:this_.searchText,
					sidx: 'ID',
					sord: 'DESC'
				};
				setTimeout(() => {
					/*请求电子游艺*/
					web.GetEGamesList(postData, function(data) {
						var data = eval('(' + data + ')');
						var list = data.rows;
						//无数据
						if(list.length > 0){
							this_.livePage.isNotData = false;
							//加载数据
							for(var i = 0; i < list.length; i++) {
								if(list[i].GAME_IMG_LINK.indexOf('http') == '-1' && list[i].GAME_IMG_LINK.indexOf('https') == "-1") {
									list[i].GAME_IMG_LINK = this_.imgUrl_ + list[i].GAME_IMG_LINK;
								}
								this_.gameList.push(list[i]);
							}
	
							this_.livePage.page++;
							setTimeout(() => {
								this_.liveStat.pullupStatus = 'default'
								this_.livePage.isDataLoading = false;
							}, 100)
						}else {
							this_.livePage.isNotData = true;
						}

					})

				}, 100)

			},			
			infinite(finish) {
				const that = this;
				if(that.livePage.isNotData) {
					setTimeout(() => {
						that.loadingShow = false;
						finish(true);
					}, 1500)
					return;
				}
				setTimeout(() => {
					that.getGameList();
//					this.list = this.list + 10;
					setTimeout(() => {
						finish();
					})
				}, 1500)
			},
			init() {
				var that=this;
				var gemeCdType=JSON.parse(that.gemeCdType)
				for(var i=0;i<gemeCdType.length;i++){
					if(that.gameCd==gemeCdType[i].code){
					}
				}
			},
			dragDownShow() {
				if(this.hide) {
					$('.dragDown-container').slideUp(250);
				} else {
					$('.dragDown-container').slideDown(250);
				}
				this.hide = !this.hide;
			},
			//加载时动画
			handleLodingHide(){
				this.loadingImg = !this.loadingImg;
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	/*#game-list_j{padding-bottom:.5rem ;}*/
	
	.jiazing {
		bottom: 0;
		height: 1rem;
	}
	.loading{
		display: block;
		width: 1rem;
		height: 1rem;
	}
	.jiazing svg {
		width: .5rem;
		height: .5rem;
	}
	
	.jiazing span {}
	
	#ElectronicGameDtail {
		display: flex;
		flex-direction: column;
		.Serch-container {
			display: flex;
			background: #fff;
			padding: 0 0.24rem;
			/*box-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);*/
			@include border-1px(#ccc,bottom);
			a {
				display: block;
				padding: 0.28rem 0;
			}
			.serch-condition {
				width: 1.5rem;
				font-size: 0.28rem;
				position: relative;
			}
			.serch-input {
				flex: 1;
				input[type=search] {
					background: #f2f2f2;
				}
			}
			.mui-input-clear {
				margin-bottom: 0;
				margin-top: 0.16rem;
			}
			.serch-btn {
				width: 0.8rem;
				font-size: 0.26rem;
				color: #00ccff;
			}
			.mr-r {
				margin-right: 0.1rem;
			}
			.down{
				position: absolute;
				right: 0;
				top: 0.5rem;
			}
		}
		.gameList-container {
			flex: 1;
			position: relative;
		}
	}
	
	.dragDown-container {
		position: absolute;
		left: 0;
		right: 0;
		background: #fff;
		width: 100%;
		height: 100%;
		z-index: 50;
		padding: 0.24rem;
		padding-right: 0;
		display: none;
		.mr-t {
			margin-top: 0.22rem;
		}
	}
	
	.btn-con {
		padding-right: 0.24rem;
		padding-top: 1rem;
		.mui-btn-block {
			padding: 0.2rem 0;
		}
	}
	
	.select-btn-group {
		text-align: left;
		padding-top: 0.3rem;
		a {
			font-size: 0.24rem;
			display: inline-block;
			width: 2.22rem;
			padding: 0.1rem 0;
			background: #f2f2f2;
			border-radius: 3px;
			text-align: center;
			margin-right: 0.1rem;
			margin-bottom: 0.2rem;
			color: #666;
		}
		.active {
			color: #ff6633;
		}
	}
	
	.game-list {
		padding: 0.24rem;
		padding-right: 0;
		text-align: center;
	}
	
	.item-img {
		/*width: 2.2rem;
		height:1.6rem;*/
		background: #fff;
		border-radius: 3px 3px 0 0;
		overflow: hidden;
		background: #fff url('../../../static/img/public/cai.png') no-repeat center;
		background-size: cover;
		img {
			display: block;
			width: 2.2rem;
			height: 1.6rem;
		}
	}
	
	.icon-xin {
		color: red;
	}
	
	.item-title {
		overflow: hidden;
		width: 2.2rem;
		background: #eee;
		border-radius: 0 0 3px 3px;
		padding: 0.12rem 0.1rem;
		text-align: left;
		position: relative;
		p {
			width: 83%;
			font-size: 0.24rem;
		}
		.scBtn{
			position: absolute;
			right: 0;
			top: 0;
			width: 0.5rem;
			height: 100%;
			padding-top:0.14rem;
		}
	}
	
	.mui-item {
		overflow: hidden;
		margin: 0 0.19rem 0.28rem 0;
		display: inline-block;
	}
.mui-active2{
	background: rgba(#666, 0.2) !important;	
}
.kuang{
	margin-right: 0.08rem;
}		
</style>