<template>
	<div id="BindingBankCard">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="bb_content bgColor ">
					<div class="item ma_t16  bg_j">
						<div class="paz_24 ">
							<div class="bor_b pan_j list_j">
								<div class="mui-col-xs-3 mui-pull-left mui-text-left">
									会员账号
								</div>
								<div class="mui-col-xs-9 mui-pull-left mui-text-left">
									{{accounts}}
								</div>
							</div>
						</div>
						<div class="list_j">
							<div class="mui-col-xs-3 mui-pull-left mui-text-left">
								真实姓名
							</div>
							<div class="mui-col-xs-9 mui-pull-left mui-text-left">
								{{accounts}}
							</div>
						</div>
					</div>
					<div class="item paa_24">
						<div class="boa_5 paa_24 bg_j_color ">
							<div class="list_j pan_j text_bscolor">
								<div class="mui-col-xs-3 mui-text-left">
									开户名
								</div>
								<div class="mui-col-xs-9 mui-text-left">
									{{accounts}}
								</div>
							</div>
							<div class="list_j pan_j text_bscolor">
								<div class="mui-col-xs-3 mui-text-left">
									开户行
								</div>
								<div class="mui-col-xs-9 mui-text-left">
									{{accounts}}
								</div>
							</div>
							<div class="list_j pan_j text_bscolor">
								<div class="mui-col-xs-3 mui-text-left">
									卡号
								</div>
								<div class="mui-col-xs-9 mui-text-left">
									{{accounts}}
								</div>
							</div>
						</div>
					</div>

					<div class="item ma_t16">
						<div class="btn-group">
							<button type="button" class="mui-btn mui-btn-blue mui-btn-block  add-btn">修改银行卡号</button>
						</div>
					</div>
					<div class="item ma_t40 mui-text-left paz_24 text_fzcolor">
						<p class="text_fzcolor">友情提示</p>
						<p class="text_fzcolor">1.银行卡必须是本人的银行卡必须是本人的银行卡必须是本人的银行卡必须是本人的银行卡必须是本人的银行卡必须是本人的</p>
						<p class="text_fzcolor">2.友情提示银行卡必须是本人的银行卡必须是本人的银行卡必须是本人的银行卡必须是本人的</p>
					</div>
					<div class="fz_j ma_t30 zyjuz_j">
						——————别扯了，俺也是有底线的人——————
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	export default {
		name: 'BindingBankCard',
		data() {
			return {
				Wallet: 666,
				Wallet1: 66,
				accounts: '呵呵',
				address: '菲律宾',
				datalist1: [],
				CardVal: '工商银行'
			}
		},
		beforeMount: function() {

		},
		created() {
			const that = this;
			$.getJSON('static/json/LotteryGameReturnWater.json', function(res) {
				that.datalist1 = res;
			});
			$.getJSON('static/json/bankcard.json', function(res) {
				that.Cardlist = res;
			})
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				mui('.list_j').on('tap', '.Select', function() {
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.Cardlist);
					CardPiker.show(function(items) {
						that.CardVal = items[0]['text'];
					});
				});
				mui('.btn-group').on('tap', '.add-btn', function() {
					mui(this).button('loading');
					$('.mui-btn-block .mui-spinner').css({
						'width': '18px',
						'height': '18px'
					})
					setTimeout(function() {
						mui(this).button('reset');
					}.bind(this), 2000);
				})
			})
		},
		watch: {},
		computed: {},
		methods: {

		},
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	input {
		font-size: .28rem;
		padding: 0;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: inherit;
		margin: 0;
	}
	
	.width_80 {
		width: 80% !important;
	}
	
	.mui-input-row {
		font-size: .28rem;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.tc {
		top: 0;
	}
	
	.tc_item {
		width: 100%;
		bottom: 2rem;
	}
	
	.z_index {
		z-index: 1111;
	}
	
	.bgColor {
		background: $bgColor;
	}
	
	.bg_j {
		background: $whiteColor;
	}
	
	.hui_j {
		background: $tipsFontColor;
	}
	
	.hei_toum_j {
		background: rgba(0, 0, 0, .6);
	}
	
	.bg_j_color {
		background: $blueColor;
	}
	
	.text_bscolor {
		color: $whiteColor !important;
	}
	
	.text_cscolor {
		color: $warnColor !important;
	}
	
	.text_lscolor {
		color: $blueColor !important;
	}
	
	.text_fzcolor {
		color: $assistFontColor !important;
	}
	
	.ma_t16 {
		margin-top: .16rem;
	}
	
	.ma_tx24 {
		margin: .24rem 0;
	}
	
	.ma_t30 {
		margin-top: .3rem;
	}
	
	.ma_t40 {
		margin-top: .4rem;
	}
	
	.pan_j {
		padding: 0 !important;
	}
	
	.paz_24 {
		padding: 0 .24rem;
	}
	
	.pat_24 {
		padding: .24rem 0;
	}
	
	.paa_24 {
		padding: .24rem;
	}
	
	.boa_5 {
		border-radius: .1rem;
	}
	
	.boa_50 {
		border-radius: 50%;
	}
	
	.wh120 {
		width: 1.2rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 1.2rem;
	}
	
	.wh100 {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 100%;
	}
	
	.posif {
		position: fixed;
	}
	
	.posia {
		position: absolute;
	}
	
	.posir {
		position: relative;
	}
	
	.borr_j {
		border-right: .02rem solid $whiteColor;
	}
	
	.bor_b {
		border-bottom: .02rem solid $tipsFontColor;
	}
	
	.boryn_j {
		border-right: none !important;
	}
	
	.born_j {
		border: none !important;
	}
	
	.boryx_j {
		border-right: .02rem solid $tipsFontColor;
		border-bottom: .02rem solid $tipsFontColor;
	}
	
	.boryx_color_j {
		border-right: .07rem solid $bgColor;
		border-bottom: .07rem solid $bgColor;
	}
	
	.boryx_huicolor_j {
		border-right: .07rem solid rgba(0, 0, 0, .6);
		border-bottom: .07rem solid rgba(0, 0, 0, .6);
	}
	
	.borsz_j {
		border-top: .02rem solid $tipsFontColor;
		border-left: .02rem solid $tipsFontColor;
	}
	
	.bor_a {
		border: .02rem solid $tipsFontColor;
	}
	
	.bora10_j {
		border: .1rem solid $tipsFontColor;
	}
	
	.bor_color {
		border: .02rem solid $blueColor;
	}
	
	.hb {
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 100%;
	}
	
	.ovhide {
		overflow: hidden;
	}
	
	.sxzyjuz_j {
		display: -webkit-flex;
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	
	.sxjuz_j {
		display: flex;
		display: -webkit-flex;
		align-items: center;
	}
	
	.zyjuz_j {
		display: flex;
		display: -webkit-flex;
		justify-content: space-around;
	}
	
	.h98 {
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .98rem !important;
	}
	
	.h180 {
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 1.8rem !important;
	}
	
	.text_big_j {
		font-size: .55rem !important;
		font-weight: bold;
	}
	
	.imp_j {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 1rem;
		padding: 0 .24rem;
		font-size: .32rem;
		color: $importFontColor;
	}
	
	.nav_j {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .98rem;
		padding: .2rem;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.title_j {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .92rem;
		padding: 0 .24rem;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.list_j {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .88rem;
		padding: 0 .24rem;
		font-size: .26rem;
		color: $normalFontColor;
		label {
			display: flex;
			display: -webkit-flex;
			align-items: center;
			height: .88rem;
			padding: 0 .24rem;
			font-size: .26rem;
			color: $normalFontColor;
		}
		input {
			display: flex;
			display: -webkit-flex;
			align-items: center;
			height: .88rem;
			padding: 0 .24rem;
			font-size: .26rem;
			color: $normalFontColor;
		}
	}
	
	.t_list {
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .5rem;
		font-size: .26rem;
		color: $normalFontColor;
	}
	
	.text_xj {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .7rem;
		padding: 0 .24rem;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.text45_xj {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .45rem;
		padding: 0 .24rem;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.text35_xj {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .35rem;
		padding: 0 .24rem;
		font-size: .22rem;
		color: $tipsFontColor;
	}
	
	.fz_j {
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .8rem;
		padding: 0 .24rem;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.title_j:last-child {
		border-bottom: none;
	}
</style>