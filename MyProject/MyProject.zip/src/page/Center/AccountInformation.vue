<template>
	<div id="AccountInformation">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="ac_content">
					<div class="item mr-t-2 pa_4 whiteColor mui-text-left mui-clearfix">
						<h2>账户信息</h2>
						<div class="list mui-col-xs-12 ">
							<div class="mui-col-xs-6 mui-pull-left">
								会员名称：
							</div>
							<div class="mui-col-xs-6 mui-pull-right mui-text-left" v-if="list.REAL_NAME">
								{{Array(list.REAL_NAME.length).join('*') + list.REAL_NAME.substr(-1)}}
							</div>
							<div class="mui-col-xs-6 mui-pull-right mui-text-left" v-else>
								
							</div>
						</div>
						<div class="list mui-col-xs-12 ">
							<div class="mui-col-xs-6 mui-pull-left">
								手机号：
							</div>
							<div class="mui-col-xs-6 mui-pull-right mui-text-left">
								{{list.MOBILE}}
							</div>
						</div>
						<div class="list mui-col-xs-12 ">
							<div class="mui-col-xs-6 mui-pull-left">
								注册时间：
							</div>
							<div class="mui-col-xs-6 mui-pull-right mui-text-left">
								{{list.CREATE_DTT}}
							</div>
						</div>
					</div>

					<div class="item mr-t-2 pa_4 whiteColor mui-text-left mui-clearfix">
						<h2>财务信息</h2>
						<div v-for="(a,i) in getCardlist" :key="i" class="bankbox">
							<div class="list mui-col-xs-12 ">
								<div class="mui-col-xs-6 mui-pull-left">
									收款人姓名：
								</div>
								<div class="mui-col-xs-6 mui-pull-right mui-text-left">
									{{a.name}}
								</div>
							</div>
							<div class="list mui-col-xs-12 ">
								<div class="mui-col-xs-6 mui-pull-left">
									收款银行：
								</div>
								<div v-if="bon" class="mui-col-xs-6 mui-pull-right mui-text-left">
									{{a.bank}}
								</div>
								<div v-else class="mui-col-xs-6 acecolor mui-pull-right mui-text-left">
									点击设置您的银行资料
								</div>
							</div>
							<div class="list mui-col-xs-12 ">
								<div class="mui-col-xs-6 mui-pull-left">
									银行帐号：
								</div>
								<div v-if="bon" class="mui-col-xs-6 mui-pull-right mui-text-left">
									{{a.num}}
								</div>
								<div v-else class="mui-col-xs-6 acecolor mui-pull-right mui-text-left">
									点击设置您的银行资料
								</div>
							</div>
							<div class="list mui-col-xs-12 ">
								<div class="mui-col-xs-6 mui-pull-left">
									开户行地址：
								</div>
								<div v-if="bon" class="mui-col-xs-6 mui-pull-right mui-text-left">
									{{a.add}}
								</div>
								<div v-else class="mui-col-xs-6 acecolor mui-pull-right mui-text-left">
									点击设置您的银行资料
								</div>
							</div>
						</div>
						<div v-if="isbank">
							<div class="list mui-col-xs-12 ">
								<div class="mui-col-xs-6 mui-pull-left">
									收款人姓名：
								</div>
								<div class="mui-col-xs-6 mui-pull-right mui-text-left">
									{{list.REAL_NAME}}
								</div>
							</div>
							<div class="list mui-col-xs-12 ">
								<div class="mui-col-xs-6 mui-pull-left">
									收款银行：
								</div>
								<div class="mui-col-xs-6 acecolor mui-pull-right mui-text-left">
									点击设置您的银行资料
								</div>
							</div>
							<div class="list mui-col-xs-12 ">
								<div class="mui-col-xs-6 mui-pull-left">
									银行帐号：
								</div>
								<div class="mui-col-xs-6 acecolor mui-pull-right mui-text-left">
									点击设置您的银行资料
								</div>
							</div>
							<div class="list mui-col-xs-12 ">
								<div class="mui-col-xs-6 mui-pull-left">
									开户行地址：
								</div>
								<div  class="mui-col-xs-6 acecolor mui-pull-right mui-text-left">
									点击设置您的银行资料
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	import UserApi from '@/api/userUtil.js';
	export default {
		name: 'AccountInformation',
		data() {
			return {
				bon:false,
				getCardlist:[],
				isbank:true
			}
		},
		beforeMount: function() {

		},
		created() {
			const that = this;
			
			
			that.isUsername(that.list)
			that.getDrawBankList()
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				mui('#AccountInformation').on('tap', '.acecolor', function() {
					that.$router.push({
						path: 'BankCard'
					})
				})
			})
		},
		watch: {},
		computed: {
			list() {
				return this.$store.getters.getUserInfo;
			},
			
		},
		methods: {
			getDrawBankList(){//获取绑定的银行卡列表
				var that = this; 
				that.getCardlist = [];
				UserApi.GetDrawBankList(function(data){
					if(data.length>0){//绑定过银行卡
						for(var i = 0; i < data.length; i++) {
							console.log(data)
							var obj = {
								name: Array(data[i].PAY_NAME.length).join('*') + data[i].PAY_NAME.substr(-1),
								bank: data[i].PAY_BANK,
								num: '**** **** **** ' + data[i].PAY_ACCOUNT.substr(data[i].PAY_ACCOUNT.length - 4),
								add: data[i].PAY_ADDRESS
							};
							that.getCardlist.push(obj);
						};
						that.bon = true;
						that.isbank = false;
					}else{//没有绑定过
						
					}
				})
			},
			isUsername(obj){
				var that = this
				if(obj.REAL_NAME == null ||  obj.REAL_NAME == ""){
					var arr = ['取消', '确认'];
					that.$confirm('请尽快完善个人资料', '温馨提示', arr, function(e) {
						if(e.index == 1) {
							that.$router.push({
								path: 'UserMsg'
							})
						} else {
							that.$router.push({
								path: 'Center'
							})
						}
					})
				}
			}
		},
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	/*@import '~static/sass/wx-jx.scss';*/
	
	#AccountInformation {
		background: $bgColor;
		.item {
			h2 {
				display: flex;
				display: -webkit-flex;
				align-items: center;
				height: .88rem;
				font-size: .28rem;
				color: $importFontColor;
				/*font-weight: normal;*/
			}
			.list {
				display: flex;
				display: -webkit-flex;
				align-items: center;
				font-size: .24rem;
				color: $normalFontColor;
				font-weight: normal;
				height: .52rem;
			}
		}
	}
	.acecolor{color:$blueColor ;}
	input {
		font-size: 0.28rem;
	}
	
	.mui-input-row {
		font-size: 0.28rem;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.mr-t-2 {
		margin-top: .2rem;
	}
	
	.pa_4 {
		padding: 0 .44rem;
	}
	
	.whiteColor {
		background: $whiteColor;
	}
	.bankbox{
		border-bottom: 1px solid $tipsFontColor;
		margin-bottom:0.2rem;
		padding-bottom:0.2rem;
	}
</style>