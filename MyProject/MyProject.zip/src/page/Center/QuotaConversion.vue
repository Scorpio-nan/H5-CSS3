<template>
	<div id="QuotaConversion">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="ab_content bgColor ">
					<div class="title_j sxjuz_j paz_24 ma_t16 bg_j mui-clearfix mui-text-left ">
						<div class="mui-pull-left mui-col-xs-6">
							账户余额 <span class="text_cscolor"><CountUp :start-val="1" :end-val="AccountSum ? parseFloat(AccountSum) : 0" :duration="1" :decimals="2"></CountUp>RMB</span>
						</div>
						<div class="mui-pull-right text_lscolor mui-text-right  mui-col-xs-6 captailDetail">
							<span class="iconfont icon-icon-72"></span>资金明细
						</div>
					</div>

					<div class="item  ma_t16 paz_24  mui-clearfix" id="qc_item">
						<!--  bg_j_color   -->
						<div  class="boryx_color_j bg_j pat_24 mui-col-xs-4 mui-col-sm-3 mui-pull-left" v-for="(item,index) in Account" 
							:data-type="item.ACC_BAL_CD" 
							:class="AccountCD == item.ACC_BAL_CD ? 'bg_j_color' : ''">
							<div class="text45_xj sxzyjuz_j ">
								{{item.FULLNAME}}
							</div>
							<div class="text35_xj sxzyjuz_j innerMoney">
								<CountUp :id="item.ACC_BAL_CD" :start-val="1" :end-val="item.ACC_BAL ? parseFloat(item.ACC_BAL) : 0" :duration="1" :decimals="2"></CountUp>
							</div>
							<div class="loading-img">
								<img src="static/img/loading/loading-spin.svg"/>
							</div>
						</div>
					</div>

					<div id="zhuanru" class="title_j sxjuz_j paz_24 ma_t16 bg_j mui-clearfix mui-text-left ">
						<div class="mui-col-xs-4 mui-pull-left">
							选择转入账户
						</div>
						<div class="mui-col-xs-4 text_lscolor mui-pull-left xuanz">
							{{shiftTo}}
						</div>
						<div class="mui-col-xs-4 text_lscolor mui-text-center mui-pull-left xuanz">
							<span class="iconfont text_lscolor icon-xiangxia1"></span>
						</div>
					</div>
					<div class="item bg_j bor_b ma_t16">
						<div class="text_xj sxjuz_j  mui-text-left">
							输入金额
						</div>
						<div class="mui-text-left text_big_j title_j ovhide">
							<span>¥</span>
							<input type="text" class="width_80 mui-input-clear born_j text_big_j " placeholder="输入金额" maxlength="10" v-model="Wallet">
							<span class="delete iconfont icon-delete"></span>
							<span class="all">全部转入</span>
						</div>
					</div>
					<div class="select-group QuotaConversion_btn" >
						<button class="btn mui-btn mui-btn-mini mr-r " :class="index == 0 ? 'code_':''"  data-num="500" data-index="0">￥500</button>
						<button class="btn mui-btn mui-btn-mini mr-r" data-num="1000" :class="index == 1 ? 'code_':''" data-index="1">￥1000</button>
						<button class="btn mui-btn mui-btn-mini mr-r" data-num="1500" :class="index == 2 ? 'code_':''" data-index="2">￥1500</button>
						<button class="btn mui-btn mui-btn-mini game-type" data-num="2000" :class="index == 3 ? 'code_':''" data-index="3">￥2000</button>
					</div>
					<div class="btn-group mr-t-8">
						<button type="button" class=" hui_j mui-btn  mui-btn-block  add-btn newbtnstyle">确认转换</button>
					</div>
					<div class="btn-group">
						<button type="button" class="ma_t16  mui-btn mui-btn-warning  mui-btn-block  add-btn">一键回收主账号</button>
					</div>
					<div class="fz_j ma_t30 zyjuz_j">
						——————别扯了，俺也是有底线的人——————
					</div>
				</div>
			</div>
		</div>
		<ActionSheet :show="actionShow" @hide="handleAction">
			<div slot='action' id="TransferAccount" class="hei_toum_j wh100  z_index tc">
				<div class="TransferAccount_wrap  tc_item">
					<div id="item" class="item mui-clearfix    paz_24  mui-clearfix">
						<div  class=" bg_j  mui-col-xs-4  mui-pull-left" v-for="(item,index) in AccountList" :data-type="item.ENCODE" :data-name="item.FULLNAME">
							<div class=" pat_24 mui-col-xs-11 boryx_huicolor_j mui-pull-left selectItem">
								<div class="text45_xj sxzyjuz_j">
									{{item.FULLNAME}}
								</div>
							</div>
							<div class="mui-col-xs-1 mui-pull-right">
							</div>
						</div>
					</div>
				</div>
			</div>
		</ActionSheet>
	</div>
</template>
<script>
	import ActionSheet from './template/ActionSheet.vue';
	import api from '@/api/userUtil';
	import CountUp from '@/components/CountUp';
	
	export default {
		name: 'QuotaConversion',
		components: {
			ActionSheet,
			CountUp
		},
		data() {
			return {
				Wallet: 0,
				shiftTo: '请选择转入账户',	//选择转入账户
				actionShow:false,
				AccountList:[],				//转入账户列表
				AccountCD:'my_wallet',		//默认选中转出账户
				AccountShiftCD:'',			//默认选中转入账户
				index:0                     //默认选中
			}
		},
		created() {
			const that = this;
			setTimeout(function(){
				that.$store.dispatch('getAccount','all');
			},200)
			this.$store.dispatch('getAccountList');
			this.init();
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				
				//点击快速转入按钮
				mui('.QuotaConversion_btn').on('tap', '.mui-btn', function() {
					var num = $(this).data('num');
					that.index = $(this).data('index');
					that.Wallet = parseInt(num);
				});
				
				
				//选择转入账户
				mui('#item').on('tap', '.bg_j', function() {
					var dataType = $(this).data('type');
					var dataName = $(this).data('name');
					that.AccountShiftCD = dataType;
					that.shiftTo = dataName;
					that.handleAction();
					$(this).find('.selectItem').addClass('bg_j_color').parent().siblings().find('.mui-col-xs-11').removeClass('bg_j_color');
				});
				
				
				//选择转入账户
				mui('#QuotaConversion').on('tap', '#zhuanru', function() {
					that.actionShow = !that.actionShow;
				});
				
				
				//选择全部转入
				mui('.ovhide').on('tap', '.all', function() {
					that.Wallet =  parseInt($('#'+that.AccountCD).text())
				});
				//清空输入框
				mui('.ovhide').on('tap', '.delete', function() {
					that.Wallet = []
				});				
				
				//选择转出账户
				mui('#qc_item').on('tap', '.bg_j', function() {
					var self = $(this);
					var type = $(this).data('type');
					that.AccountCD = type;
					self.find('.loading-img').show();
					api.GetBalance(type,(res)=>{
						if(res != null && res != undefined && res.data != null && res.data != undefined){
							self.find('.loading-img').hide();
							self.find('.innerMoney').text(res.data.toFixed(2));
						}
					})
					var t = setTimeout(()=>{
						self.find('.loading-img').hide();
					},1500)
				});
				
				//确认转入按钮
				mui('.btn-group').on('tap', '.add-btn', function() {
					mui(this).button('loading');
					$('.mui-btn-block .mui-spinner').css({
						'width': '18px',
						'height': '18px'
					})
					that.handleAffirm();
					setTimeout(function() {
						mui(this).button('reset');
					}.bind(this), 2000);
				})
				
				//资金明细
		        mui('.ab_content').on('tap','.captailDetail',function(){
		          var path = $(this).data('path');
		          that.$router.push({
		            path:'/CaptailDetail'
		          })
		        })
			})
		},
		watch: {},
		computed: {
			Account(){
				return this.$store.getters.getAccount.accBalInfo;
			},
			UserGroup(){
				return this.$store.getters.getUserGroup;
			},
			getAccountList(){
				return this.$store.getters.getAccountList;
			},
			AccountSum(){
				return this.$store.getters.getAccount.allmoney;
			}
		},
		methods: {
			handleAction(){
				this.actionShow = !this.actionShow;
			},
			//初始化数据
			init(){
				const that = this;
				this.AccountList = this.getAccountList;
				//初始化金额为用户组规定最小重置金额
				this.Wallet = this.UserGroup.MIN_ZR_TRANSFORM_AMT;
			},
			//确认转入账户
			handleAffirm(){
				const that = this;
				var re = /^[0-9]*[1-9][0-9]*$/
				if(this.Wallet < this.UserGroup.MIN_ZR_TRANSFORM_AMT){
					this.$alert(`最小充值金额不能小于${this.UserGroup.MIN_ZR_TRANSFORM_AMT}`);
					return;
				}
				if(this.shiftTo.indexOf('请选择') != -1){
					this.$alert(`请选择转入账户!`);
					return;
				}
				if(re.test(this.Wallet)== false){
					this.$alert(`金额必须为整数!`);
					return;
				}
				if(this.AccountCD==this.AccountShiftCD){
					this.$alert(`操作账户不能相同!`);
					return;
				}
				var param = {
					transfer_amt: this.Wallet,		
					OUT_INT_IDENT_CD: this.AccountCD,		
					IN_INT_IDENT_CD: this.AccountShiftCD		
				}
				api.TransferOperate(param,(res)=>{
					if(res.state == 'success'){
						that.$store.dispatch('getAccount','all');
					}
					that.$alert(res.message);
				})
			}
		},
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	.newbtnstyle{
		border: none
	}
	.ma_b16{margin-bottom: .2rem;}
	.TransferAccount_wrap{
		width: 100%;background: $whiteColor;padding: .2rem 0 .2rem .2rem;
	}
	.btn{
		&:active{
			background: rgba(0,0,0,0.4) !important;
		}
	}
	.mayx_2{margin:0 .2rem .2rem 0 ;}
	input {
		font-size: .28rem;
		padding: 0;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: inherit;
		margin: 0;
	}
	
	.width_80 {
		width: 73% !important;
	}
	.delete {
		position: relative;
		right: 1.6rem;
	}
	.mui-input-row {
		font-size: .28rem;
	}
	
	.mui-btn-block {
		padding: 0.2rem 0;
		width: 90%;
		margin: 0 auto;
		font-size: 0.32rem;
	}
	
	.tc {
		top: 0;
	}
	
	.tc_item {
		width: 100%;
		bottom: 0;
	}
	
	.z_index {
		z-index: 1111;
	}
	
	.bgColor {
		background: $bgColor;
	}
	
	.bg_j {
		background: $whiteColor;
		position: relative;
		.loading-img{
			position: absolute;
			width: 100%;
			height: 100%;
			background: rgba(0,0,0,0.5);
			top: 0;
			left: 0;
			display:none;
			img{
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translate(-50%,-50%);
			}
		}
	}
	
	.hui_j {
		background: #19b4f6;
		color: #fffeff;
	}
	
	.hei_toum_j {
		background: rgba(0, 0, 0, .6);
	}
	
	.bg_j_color {
		background: $blueColor;
		position: relative;
		&::after {
			display: block;
			position: absolute;
			content: '';
			right: 0.1rem;
			bottom: 0.1rem;
			width: 0.34rem;
			height: 0.34rem;
			background: url('../../../static/img/public/check.png') no-repeat;
			background-size: 100% 100%;
			/*background: #fff;*/
		}
	}
	.select-group{
		padding:0.24rem;
		background: #fff;
		display: flex;
		.mr-r{
			margin-right: 0.2rem;
		}
		.btn{
			flex: 1;
			padding: 5px 0;
			color:$normalFontColor;
		}
	}
	.mr-t-8{
		margin-top: 0.24rem;
	}
	.bg_j_color .text45_xj {
		color: $whiteColor;
	}
	.bg_j_color.boryx_huicolor_j {
		border: 0.02rem solid #19b4f5 !important;
	}
	.bg_j_color .text35_xj {
		color: $whiteColor;
	}
	
	.text_cscolor {
		color: $warnColor !important;
		padding: 0 5px;
	}
	
	.text_lscolor {
		color: $blueColor !important;
	}
	
	.ma_t16 {
		margin-top: .16rem;
	}
	
	.ma_tx24 {
		margin: .24rem 0;
	}
	
	.ma_t30 {
		margin-top: .3rem;
	}
	
	.ma_t40 {
		margin-top: .4rem;
	}
	
	.pat_24 {
		padding: .24rem 0;
	}
	
	.paa_24 {
		padding: .24rem;
	}
	
	.boa_5 {
		border-radius: .1rem;
	}
	
	.boa_50 {
		border-radius: 50%;
	}
	
	.wh120 {
		width: 1.2rem;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 1.2rem;
	}
	
	.wh100 {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 100%;
	}
	
	.posif {
		position: fixed;
	}
	
	.posia {
		position: absolute;
	}
	
	.posir {
		position: relative;
	}
	
	.borr_j {
		border-right: .02rem solid $whiteColor;
	}
	
	.bor_b {
		@include border-1px(#ccc,'bottom');
	}
	
	.boryn_j {
		border-right: none !important;
	}
	.born_j {
		border: none !important;
	}
	
	.boryx_j {
		border-right: .02rem solid $tipsFontColor;border-radius: .1rem;
		border-bottom: .02rem solid $tipsFontColor;
	}
	
	.boryx_color_j {
		border-right: .07rem solid $bgColor;
		border-bottom: .07rem solid $bgColor;
	}
	@media (min-width: 400px){
		.mui-col-sm-3.boryx_color_j:nth-child(4n) {
			border-right: 0 none;
		}
	}
	@media (max-width: 400px){
		.mui-col-xs-4.boryx_color_j:nth-child(3n) {
		border-right: 0 none;
	}
	}
	
	.boryx_huicolor_j {
		border: .02rem solid $tipsFontColor;border-radius: .1rem;margin-bottom: .2rem;
	}
	
	.borsz_j {
		border-top: .02rem solid $tipsFontColor;
		border-left: .02rem solid $tipsFontColor;
	}
	
	.bor_a {
		border: .02rem solid $tipsFontColor;
	}
	
	.bora10_j {
		border: .1rem solid $tipsFontColor;
	}
	
	.bor_color {
		border: .02rem solid $blueColor;
	}
	
	.hb {
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 100%;
	}
	
	.ovhide {
		overflow: hidden;
	}
	
	.sxzyjuz_j {
		display: -webkit-flex;
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	
	.sxjuz_j {
		display: flex;
		display: -webkit-flex;
		align-items: center;
	}
	
	.zyjuz_j {
		display: flex;
		display: -webkit-flex;
		justify-content: space-around;
	}
	
	.h98 {
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .98rem !important;
	}
	
	.h180 {
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 1.8rem !important;
	}
	
	.text_big_j {
		font-size: .55rem !important;
		font-weight: bold;
	}
	
	.imp_j {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 1rem;
		padding: 0 .24rem;
		font-size: .32rem;
		color: $importFontColor;
	}
	
	.nav_j {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .98rem;
		padding: .2rem;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.title_j {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .92rem;
		padding: 0 .24rem;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.t_list {
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .5rem;
		font-size: .26rem;
		color: $normalFontColor;
	}
	
	.text_xj {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .7rem;
		padding: 0 .24rem;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.text45_xj {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .45rem;
		font-size: .28rem;
		color: $importFontColor;
	}
	
	.text35_xj {
		width: 100%;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .35rem;
		font-size: .22rem;
		color: $normalFontColor;
	}
	
	.fz_j {
		display: flex;
		display: -webkit-flex;
		align-items: center;
		height: .8rem;
		padding: 0 .24rem;
		font-size: .24rem;
		color: $assistFontColor;
	}
	
	.list:last-child {
		border-bottom: none;
	}
	.code_{
		background: #f5f6f8;
		color: #999999;
		/*border: 0;*/
	}
.mui-btn-warning, .mui-btn-yellow {
    color: #ffffff;
    border: 1px solid #ec5054;
    background-color: #ec5054;
}
.all{
	color: #17b5f2;
	font-size: 0.22rem;
}
.all:active{
	color: #62c9f5;
}	
</style>