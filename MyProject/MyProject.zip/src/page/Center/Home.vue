<template>
	<div id="Home">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<!--轮播图-->
				<div class="mui-slider" id="mui-slider">
					<div class="mui-slider-group">
						<div class="mui-slider-item">
							<a href="#"><img src="static/img/public/banner@2x.png" /></a>
						</div>
						<div class="mui-slider-item">
							<router-link to="ElectronicGame"><img src="static/img/public/banner3@2x.jpg" /></router-link>
						</div>
						<div class="mui-slider-item">
							<router-link to="Register"><img src="static/img/public/banner2.png" /></router-link>
						</div>
						<div class="mui-slider-item">
							<router-link to="Download"><img src="static/img/public/download-banner.png" /></router-link>
						</div>
					</div>
					<div class="mui-slider-indicator">
						<div class="mui-indicator mui-active"></div>
						<div class="mui-indicator"></div>
						<div class="mui-indicator"></div>
						<div class="mui-indicator"></div>
					</div>
				</div>

				<!--滚动广告-->
				<div class="Marquem-container">
					<div class="Marquem-bg">
						<span class="icon iconfont icon-icon-23"></span>
						<div class="Notice">
							<marquee class="NotContent" scrollamount="3" scrolldelay="0" direction="left"></marquee>
						</div>
					</div>
				</div>
				<!--每一个页面展示的主页不一样，这里抽成组件显示-->
				<NaigationDfault></NaigationDfault>
				<div class="grayLine"></div>
				<!--热门游戏-->
				<GameHot></GameHot>
				
				<div class="grayLine"></div>
				<!--优惠活动-->
				<SpecialOffers></SpecialOffers>
				
				<!--  版权信息     -->
				<CopyRight></CopyRight>
			</div>
		</div>
	</div>
</template>

<script>
	import NaigationDfault from './template/NavigationDefult.vue';
	import SpecialOffers from './template/SpecialOffers.vue';
	import GameHot from './template/GameHot.vue';
	import CopyRight from '@/components/CopyRight.vue';
	import report from '@/api/report'
	export default {
		name: 'Home',
		components:{
			NaigationDfault,
			GameHot,
			SpecialOffers,
			CopyRight
		},
		data() {
			return {
				
			}
		},
		methods: {
			getnotice(){
				var postdata = {
					notice_type: 1,
					window_ind: '0',
				}				
				report.GetNotice($(".NotContent"), postdata);
			}
		},
		mounted() {
			mui.init();
			this.getnotice()
			mui.ready(function() {
				// 获得slider插件对象     interval:  0 为手动轮播  否则为自动轮播
				var gallery = mui('#mui-slider');
				gallery.slider({
					interval: 5000
				});
				// Scroll 区域
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				//下面横向滚动区
				var muiScroll = mui('.mui-slider');
				gallery.slider({
					interval: 0
				});
			})			
		}
	}
</script>

<style scoped lang="scss">
	@import '../../../static/sass/public.scss';
	.grayLine {
		height: 0.16rem;
		background: $bgColor;
	}
	.width-full{
		width: 100%;
	}
	.flex-box{
		display: flex !important;
		
	}
	.mui-slider-indicator{
		bottom: 3px;
	}
	#Home {
		width: 100%;
		height: 100%;
		background: $whiteColor;
		.mui-slider-indicator .mui-indicator {
			margin: 1px 3px;
			background: #ccc;
			box-shadow: inherit;
		}
		.mui-slider-indicator .mui-active.mui-indicator {
			background: #fff;
		}
		.Marquem-container {
			padding: 0.12rem 0.24rem;
			.Marquem-bg {
				width: 100%;
				border-radius: 30px;
				display: flex;
				background: $bgColor;
				overflow: hidden;
				.Notice {
					flex: 1;
					marquee {
						font-size: 0.24rem;
						transform: translate3d(0, 2px, 0);
					}
				}
				.icon {
					width: 0.56rem;
					line-height: 0.52rem;
					color: #2ea9e1;
				}
			}
		}
	}


</style>