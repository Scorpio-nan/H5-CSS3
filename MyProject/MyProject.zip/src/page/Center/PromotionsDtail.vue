<template>
	<div id="PromotionsDtail">
		<div class="mui-scroll-wrapper" id="slide">
		    <div class="mui-scroll">
		    	<div class="container">
		    		<div class="img-con">
		    			<img src="static/img/public/sale1.png"/>
		    		</div>
		    		<div class="content">
		    			<div class="discrip mui-clearfix">
		    				<div class="context mui-pull-left mui-text-left">
		    					<p class="tit">新春活动:存100送100</p>
		    					<p class="msg">新春活动:存100送100存100送100</p>
		    				</div>
		    				<button type="button" class="mui-btn mui-btn-primary mui-btn-outlined mui-pull-right mui-btn-mini">立即参加</button>
		    			</div>
		    			<div class="text-container">
		    				<h3 class="mui-text-center mui-h4 title">优惠内容</h3>
		    				<p class="mui-text-left text">会员于澳门银河赌场进行电子游艺游戏，按照北京时间计算当日有效投注2000元或以上。次日即可获得相应的得意彩金，每日高达3888元~~</p>
		    				<h3 class="mui-text-center mui-h4 title">申请方式</h3>
		    				<p class="mui-text-left text">符合活动标准请自行进入到【优惠活动大厅】填写信息并提交，专员会在60分钟内为您审核办理</p>
		    				<h3 class="mui-text-center mui-h4 title">活动细则</h3>
		    				<p class="mui-text-left text ">1、会员所获得彩金只需一倍流水即可申请取款。</p>
		    				<p class="mui-text-left text ">2、符合条件的会员必须在北京时间次日24小时内进行申请，逾期视为自动放弃。</p>
		    				<p class="mui-text-left text ">3、此活动不与【激情电子七天乐】活动共享。</p>
		    				<p class="mui-text-left text ">4、参与该优惠，即表示您同意【优惠规则与条款】</p>
		    				<h3 class="mui-text-center mui-h4 title">优惠规则与条款</h3>
		    				<p class="mui-text-left text ">1、所有优惠以人民币（CNY）为结算金额，以北京时间（UTC）为计时区间。</p>
		    				<p class="mui-text-left text ">2、参与此优惠活动，即表示您同意《优惠规则与条款》</p>
		    				<p class="mui-text-left text ">3、此优惠活动只适用于同一位客户，同一台计算机，同一个住址和IP地址，若会员有重复申请账号行为，公司将收回会员优惠彩金的权利。</p>
		    				<p class="mui-text-left text ">4、澳门银河赌场所有优惠为玩家而设，如发现任何团体或个人，以不诚实方式套取或任何威胁，滥用公司优惠等行为，公司将有权取消或冻结其账户和账户余额。</p>
		    				<p class="mui-text-left text ">5、澳门银河赌场将保留对活动的最终解释权，以及在无通知的情况下进行修改，终止活动的权利。</p>
		    			</div>
		    		</div>
		    	</div>
		    </div>
		</div>
	</div>
</template>

<script>
	export default{
		name:'PromotionsDtail',
		data(){
			return{
				//SS:this.$Utils,
			}
		},
		mounted(){
			//console.log(this.$Utils);
			const that = this;
			mui.init();
			mui.ready(function(){
				mui('#slide').scroll({
					deceleration: 0.0005
				})
			})
		}
	}
</script>

<style lang="scss" scoped>
	@import '../../../static/sass/public.scss';
	#PromotionsDtail{
		.container{
			padding: 0.24rem;
			padding-bottom: 0.2rem;
			border-radius: 3px;
		}
		.img-con{
			height: auto;
			img{
				display:block;
				width: 100%;
				height: 100%;
			}
		}
		.content{
			background: $whiteColor;
		}
		.discrip{
			padding: 0.2rem;
		}
		.tit,.msg{
			font-size: 0.24rem;
			line-height: 16px;
			color: $titleBgColor;
		}
		.mui-btn, button, input[type=button], input[type=reset], input[type=submit]{
			font-size: 0.24rem;
			padding: 0.08rem 0.16rem;
		}
		.text-container{
			padding: 0.22rem;
			.title{
				font-size: 0.32rem;
				font-weight: 100;
				padding: 0.2rem 0;
			}
			.text{
				font-size: 0.24rem;
			}
			.text-indent{
				text-indent: 0.48rem;
			}
		}
	}
</style>