<template>
	<div id="Account">
		<nav class="nav">
			<a href="javascript:;" class="mui-text-center tab" :class="index == 0? 'active':''" data-index="0">修改账户密码</a>
			<a href="javascript:;" class="mui-text-center tab" :class="index == 1? 'active':''" data-index="1">修改支付密码</a>
		</nav>
		<form class="mui-input-group mr-t-2 animated" :class="index == 0 ? 'fadeIn':''" v-show="index == 0">
		    <div class="mui-input-row">
		        <label class="mui-text-justify">原登录密码</label>
		        <input type="password" class="mui-input-clear" placeholder="请输入原登录密码" v-model="oldUserPwd">
		    </div>
		    <div class="mui-input-row">
		        <label class="mui-text-justify">新登录密码</label>
		        <input type="password" class="mui-input-clear" placeholder="请输入新密码" v-model="newUserPwd">
		    </div>
		    <div class="mui-input-row">
		        <label class="mui-text-justify">确认密码</label>
		        <input type="password" class="mui-input-clear" placeholder="请重新输入密码" v-model="newUserPwd2">
		    </div>
		</form>
		
		<form class="mui-input-group mr-t-2 animated" :class="index == 1 ? 'fadeIn':''" v-show="index == 1">
		    <div class="mui-input-row">
		        <label class="mui-text-justify">原支付密码</label>
		        <input type="password" class="mui-input-clear" placeholder="请输入原支付密码" v-model="oldPayPwd">
		    </div>
		    <div class="mui-input-row">
		        <label class="mui-text-justify">新支付密码</label>
		        <input type="password" class="mui-input-clear" placeholder="请输入新新支付密码" v-model="newPayPwd">
		    </div>
		    <div class="mui-input-row">
		        <label class="mui-text-justify">确认密码</label>
		        <input type="password" class="mui-input-clear" placeholder="请重新输入密码" v-model="newPayPwd2">
		    </div>
		</form>
		
		
		<div class="btn-con mr-t-10">
			<button class="mui-btn mui-btn-block mui-btn-blue mui-font my-btn">提交</button>
		</div>
	</div>
</template>

<script>
	import api from '@/api/userUtil'
	export default{
		name:'Account',
		data(){
			return{
				index:0,
				oldUserPwd:'',		//原账户密码
				newUserPwd:'',		//新账户密码
				newUserPwd2:'',		//确认新账户密码
				oldPayPwd:'',		//原取款密码
				newPayPwd:'',		//新取款密码
				newPayPwd2:'',		//确认新取款密码
			}
		},
		mounted(){
			const that = this;
			mui.init();
			mui.ready(function(){
				mui('.nav').on('tap','.tab',function(){
					var index = $(this).data('index');
					that.index = index;
					if(index == 1){
						if(that.UserInfo.DRAW_PASSWORD == null){
							that.$alert('对不起，你尚未设置过取款密码！');
							that.$router.push({
								path:'BankCard'
							})
							return false;
						}
					}
				})
				
				//点击提交
				mui('.btn-con').on('tap','.mui-btn',function(){
					mui(this).button('loading');
					//点击按钮会变高，需改loading图片大小
					$('.mui-btn-block .mui-spinner').css({
						'width': '18px',
						'height': '18px'
					})
					that.querySubmit();
					setTimeout(function() {
						mui(this).button('reset');
					}.bind(this), 1500);
				})
				
			})
		},
		methods:{
			//数据初始化
			init(){
						
			},
			//确认修改
			querySubmit(){
				//账户密码
				if(this.index == 0){
					if(this.formCheck()){
						this.updateUserPwd();
					}
				}else{
					//取款密码
					if(this.formCheck()){
						this.updatePayPwd();
					}
				}
			},
			//表单验证
			formCheck(){
				const that = this;
				var userPwd = /^[a-zA-Z]\w{5,11}$/;
				var payPwd = /^\d{6}$/;
				if(this.index == 0){
					if(this.oldUserPwd == '' || this.oldUserPwd == undefined){
						this.$alert('请输入原密码！');
						return false;
					}
					if(this.newUserPwd == '' || this.newUserPwd == undefined){
						this.$alert('请输入新密码！');
						return false;
					}
					if(this.newUserPwd !== this.newUserPwd2){
						this.$alert('两次输入的密码不一致！');
						return false;
					}
					return true;
				}else{
					if(this.oldPayPwd == '' || this.oldPayPwd == undefined){
						this.$alert('请输入原密码！');
						return false;
					}
					if(this.newPayPwd == '' || this.newPayPwd == undefined){
						this.$alert('请输入新密码！');
						return false;
					}
					if(this.newPayPwd !== this.newPayPwd2){
						this.$alert('两次输入的密码不一致！');
						return false;
					}
					return true;
				}
			},
			//更新账户密码
			updateUserPwd(){
				const that = this;
				var param = {
					Upd_Type : 1,
					Old_Pass : $.md5(this.oldUserPwd),
					New_Pass : $.md5(this.newUserPwd),
					ATTR1 : this.oldUserPwd
				}
				api.UpdPass(param,(res)=>{
					var res = JSON.parse(res);
					if(res.state == 'success'){
						that.$alert('修改成功，请重新登录！');
						that.$router.push({
							path:'/'
						})
						location.reload();
					}else{
						that.$alert('修改失败！');
					}
				})
				
			},
			//更新取款密码
			updatePayPwd(){
				const that = this;
				var param = {
					Upd_Type : 2,
					Old_Pass : $.md5(this.oldPayPwd),
					New_Pass : $.md5(this.newPayPwd),
					ATTR2 : this.oldPayPwd
				}
				api.UpdPass(param,(res)=>{
					var res = JSON.parse(res);
					if(res.state == 'success'){
						that.$store.dispatch('getUserInfo');
						that.$alert('提款密码修改成功！');
						that.$router.push({
							path:'/'
						})
						location.reload();
					}else{
						that.$alert('修改失败！');
					}
				})
			}
		},
		computed:{
			UserInfo(){
				return this.$store.getters.getUserInfo;
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.mui-input-row,input{
		font-size: 0.28rem;
		color: $normalFontColor;
	}
	.mr-t-2{
		margin-top: 2px;
	}
	.mr-t-10{
		margin-top: 1rem;
	}
	.my-btn{
		width: 91%;
		margin: 0 auto;
		padding: 0.2rem 0;
		font-size: 0.32rem;
	}
	.nav{
		background: $bgColor;
		display: flex;
		a{
			flex: 1;
			padding: 0.28rem 0.35rem;
			font-size: 0.28rem;
			position: relative;
		}
		.active{
			color: #19b4f5;
			&:after{
				display: block;
				content: '';
				height: 1px;
				background: #19b4f5;
				width: 100%;
				position: absolute;
				left: 0;
				bottom: 0;
			}
		}
	}
	.mui-input-group{
		background: $whiteColor;
	}
	.mui-btn-blue{
		border: none;
		background-color: #19b4f5;
	}
	.mui-input-group:before{
		background-color: transparent
	}
</style>