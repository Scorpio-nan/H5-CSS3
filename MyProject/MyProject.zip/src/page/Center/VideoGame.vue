<template>
	<div id="VideoGame">
		<div class="mui-scroll-wrapper">
		    <div class="mui-scroll">
		        <div class="Gamelist">
			        <ul class="mui-clearfix">
			        	<li class="mui-pull-left list-item" v-for="(item,index) in GameList">
			        		<a href="javascript:;" class="mui-block">
			        			<div class="item-img" :data-code="item.CODE" :data-id="item.ID">
			        				<img :src="'static/img/public/'+item.CODE+'.png'"/>
			        			</div>
			        			<div class="item-title mui-clearfix">
			        				<p class="mui-pull-left">{{item.PARA_NAME}}</p>
			        				<span class="iconfont mui-pull-right scBtn" :data-id="item.ID" :class="item.DELETE_IND*1 ? 'icon-xin' : 'icon-xin1' "></span>
			        			</div>
			        		</a>
			        	</li>
			        </ul>
		        </div>
		    </div>
		</div>
		<!--  需要手动关闭遮罩添加     @handleHide="handleLodingHide"   -->
		<TransferDom :show="loadingShow">
			<img src="static/img/loading/loading-bars.svg" alt="" class="loading"/>
		</TransferDom>
	</div>
</template>
<script>
	import TransferDom from '@/components/TransferDom';
	import api from '@/api/webUtil';
	export default{
		name:'VideoGame',
		components:{
			TransferDom
		},
		data(){
			return{
				loadingShow:false,
			}
		},
		mounted(){
			const that = this;
			mui.init();
			mui.ready(function(){
				
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				
				mui('.Gamelist').on('tap','.item-img',function(){
					var code = $(this).data('code');
					var id = $(this).data('id');
					console.log(code + '------' + id);
					that.openUrl(code,id);
				})

				mui('#VideoGame').on('tap', '.scBtn', function() {
					console.log("点击收藏")
					var id = $(this).data('id')
					var self = $(this);
					that.shoucang(id,self)
				})
				
			})
		},
		methods:{
			//游戏跳转，如果是web端就直接打开网页；如果是APP端就调用原生浏览器
			openUrl(code,id){
				if(!this.islogin){
					this.$alert('您还未登录哦！请立即登录！');
					return false;
				}
				const that = this;
				that.loadingShow = true;
				if(!lib.IsApp){
					var wi = window.open('about:blank','_blank');
				}
				api.TransferGameURL(code,1,id,res=>{
					res = JSON.parse(res);
					that.loadingShow = false;
					console.log(res);
					if(res.state == 'error'){
						that.$alert(res.message);
						return;
					}
					if(code == 'bbin_live' || code == "sa_live"){
						//判断是wap端还是APP端
						if(lib.IsApp){
							mui.plusReady(function(){
								plus.runtime.openURL(lib.gameUrl + "?code=" + code + "&id=" + id + "&userid=" + that.UserInfo.ID);
							})
						}else{
							if(code == 'bbin_live'){
								wi.document.write(res.data.val);
								wi.document.write("<scr" + "ipt> document.post_form.submit();</scr" + "ipt>");
							}else{
								var obj = JSON.parse(res.data.val);
								wi.document.write("<form id='SaLive' name='SaLive' method='POST' action='" + obj.URLS + "'>");
								wi.document.write("<input type='hidden' id='username' name='username' value='" + obj.username + "' />");
								wi.document.write("<input type='hidden' id='token' name='token' value='" + obj.token + "' />");
								wi.document.write("<input type='hidden' id='lobby' name='lobby' value='" + obj.lobby + "' />");
								wi.document.write("<input type='hidden' id='lang' name='lang' value='" + obj.lang + "' />");
								wi.document.write("<input type='hidden' id='mobile' name='mobile' value=" + true + " />");
								wi.document.write("</form>");
								wi.document.write("<scr" + "ipt> document.SaLive.submit();</scr" + "ipt>");
							}
						}
					}else{
						if(lib.IsApp){
							mui.plusReady(function(){
								plus.runtime.openURL(res.data.val);
							})
						}else{
							wi.location.href = res.data.val;
						}
					}
				})
				
			},
			shoucang(id,self){
				if(!this.islogin){
					this.$alert('您还未登录哦！请立即登录！');
					return false;
				}
				var that = this
				api.AddGameFavorite(2,3,id,function(data){
					data = JSON.parse(data);
					console.log("收藏接口返回",data)
					if(data.state == "success"){
						self.removeClass("icon-xin1").addClass('icon-xin');
						that.$toast("收藏成功")
					}else{
						self.removeClass("icon-xin").addClass('icon-xin1');
						that.$toast("取消成功")
					}
				})
			},
			//加载时动画
			handleLodingHide(){
				this.loadingShow = !this.loadingShow;
			}
		},
		computed:{
			GameList(){
				return this.$store.getters.game22List;
			},
			UserInfo(){
				return this.$store.getters.getUserInfo;
			},
			islogin(){
				return this.$store.getters.checkLoginState;
			}
		},
		created(){
			this.$store.dispatch('getUserInfo');
			this.$store.dispatch('getGame2List');
		}
		
	}
</script>

<style lang="scss" scoped>
	@import '../../../static/sass/public.scss';
	#ElectronicGame{
		
	}
	.loading{
		display: block;
		width: 1rem;
		height: 1rem;
	}
	.Gamelist{
		padding: 0.24rem;
		padding-right: 0;
	}
	.list-item{
		margin:  0 0.18rem 0.26rem 0;
	}
	.item-img{
		width: 3.4rem;
		height: 1.9rem;
		background: #fff;
		overflow: hidden;
		border-radius: 3px 3px 0 0;
		background:#fff url('../../../static/img/public/cai.png') no-repeat center;
		background-size:cover;
		img{
			display: block;
			width: 100%;
			height: 100%;
		}
	}
	.icon-xin{
		color: $warnColor;
	}
	.item-title{
		background: #eee;
		border-radius: 0 0 3px 3px;
		overflow: hidden;
		padding: 0.16rem 0.1rem;
		position: relative;
		p{
			font-size: 0.24rem;
		}
		.scBtn{
			position: absolute;
			right: 0;
			top: 0;
			width: 0.5rem;
			height: 100%;
			padding-top:0.14rem;
		}
	}
</style>