<template>
	<div id="Information">
		<div class="tab-container">
			<a href="javascript:;" data-index="0" :class="index == 0?'active':''">未读消息</a>
			<a href="javascript:;" data-index="1" :class="index == 1?'active':''">已读消息</a>
		</div>
		<div class="message-container" v-show="!index">
			<div class="mui-scroll-wrapper">
				<div class="mui-scroll">
					<ul class="mui-table-view" v-for="(item,i) in Mesinformation" :key="i" v-if="item.ID">
						<li class="mui-table-view-cell weidu" :data-id = "item.ID">
							<div class="mui-slider-right mui-disabled">
								<a class="mui-btn mui-btn-red del">删除</a>
								<a class="mui-btn mui-btn-green advisory">咨询</a>
							</div>
							<div class="mui-slider-handle mui-text-center">
								<p class="msg-title">{{item.TITLE}}</p>
								<p class="msg-date">{{item.PUBLISH_DTT}}</p>
								<span class="mui-badge mui-badge-red"></span>
							</div>
							
						</li>
						<li :class="'message-detail'+item.ID" class="message-detail">
							<div class="content">
								<div class="text-container">
									<p class="mui-text-left text " v-html="item.CONTENT"></p>
								</div>
								<div class="usermsg"  v-for="(a,j) in userMsg0[i]" :key="j">
									<div class="user">
										<p>您咨询：</p>
										<p>{{a.CONSULT_CONTENT}}</p>
										<p class="time">【{{a.CONSULT_TIME}}】</p>
									</div>
									<div class="kefu" v-if="a.REPLY_STATUS">
										<p>客服回复：</p>
										<p>{{a.ADMIN_REPLY_CONTENT}}</p>
										<p class="time">【{{a.ADMIN_REPLY_TIME}}】</p>
									</div>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="message-container" v-show="index">
			<div class="mui-scroll-wrapper">
				<div class="mui-scroll">
					<ul class="mui-table-view" v-for="(item,i) in Mes" :key="i" v-if="item.ID">
						<li class="mui-table-view-cell yidu" :data-id = "item.ID">
							<div class="mui-slider-right mui-disabled">
								<a class="mui-btn mui-btn-red del">删除</a>
								<a class="mui-btn mui-btn-green advisory">咨询</a>
							</div>
							<div class="mui-slider-handle mui-text-center">
								<p class="msg-title">{{item.TITLE}}</p>
								<p class="msg-date">{{item.PUBLISH_DTT}}</p>
							</div>
							
						</li>
						<li :class="'message-detail'+item.ID" class="message-detail">
							<div class="content">
								<div class="text-container">
									<p class="mui-text-left text " v-html="item.CONTENT"></p>
								</div>
								<div class="usermsg"  v-for="(arr,s) in userMsg1[i]" :key="s">						
										<div class="user">
											<p>您咨询：</p>
											<p>{{arr.CONSULT_CONTENT}}</p>
											<p class="time">【{{arr.CONSULT_TIME}}】</p>
										</div>
										<div class="kefu" v-if="arr.REPLY_STATUS*1">
											<p>客服回复：</p>
											<p>{{arr.ADMIN_REPLY_CONTENT}}</p>
											<p class="time">【{{arr.ADMIN_REPLY_TIME}}】</p>
										</div>	
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>

		<Actionsheet :show="show" @hide="onActionhide" class="actionsheet">
			<div slot="action" class="alert">
					<textarea class="textarea" v-model="content" placeholder="请留下您的宝贵意见，平台客服会第一时间给您反馈。祝您游戏愉快，谢谢!"></textarea>
					<button class="mui-btn btn">确认提交</button>
				
			</div>
		</Actionsheet>	
	</div>
</template>

<script>
	import msgApi from '@/api/msgUtil';
	import Actionsheet from '@page/Center/template/ActionSheet'
	export default {
		name: 'Information',
		components: {
			Actionsheet
		},
		data() {
			return {
				flag:false,
				index:0,
				Mesinformation: [],
				Mes: [],
				isShowWarnText:"",
				show:false,
				num:0,//咨询消息id
				content:"",//咨询内容
				userMsg0:[],
				userMsg1:[],
				iskefushow:false,//判断客服是否回复
				Msg:[],
				clickflag:false

			}
		},
		mounted() {
			const that = this;
			this.getList();
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			})
			
			
			
			mui.init();
			mui.ready(function(){
				mui('.mui-scroll').on('tap','.mui-table-view-cell',function(){
					var id=$(this).data('id');
					that.slideDown(id);				
				})

				mui('.mui-scroll').on('tap','.yidu',function(){
					var id=$(this).data('id');
					that.clickflag =!that.clickflag
					that.GetUserMsg(id,"type0")	

				})

				mui('.mui-scroll').on('tap','.weidu',function(){
					var id=$(this).data('id');
					that.UpdMessageState(id)//更新状态			
					that.GetUserMsg(id,"type1")
					console.log("未读数组--咨询消息",that.userMsg1)				
				})

				mui('.mui-scroll').on('tap','.del',function(){//删除操作
					var id=$(this).closest("li").data('id');
					that.delMsg(id)
					$(this).closest("ul").remove();
					that.$toast("删除成功")
				})

				mui('.mui-scroll').on('tap','.advisory',function(){//咨询操作
					that.show=true;
					var id=$(this).closest("li").data('id');
					that.num=id;
				})
				
				mui('.tab-container').on('tap','a',function(){
					var index = $(this).data('index');
					that.index = index;	
					that.getList();			
				})

				mui('body').on('tap', '#Information', function() {
					that.show = false;
				})
				mui('.action').on('tap', '.textarea', function() {
					return false;
				})
				mui('.alert').on('tap', '.btn', function() {
					that.AdduserMsg(that.num,that.content)
					that.content=""
					that.show = false;
				})
				
			})
			
		},
		methods: {
			slideDown(id){
				if(!this.flag){
					$('.message-detail' + id).toggle(250);
				}else{
					$('.message-detail' + id).toggle(250);
				}
				this.flag = !this.flag;
			},
			getList(){//获取所有消息
				var that = this;
				that.Mesinformation = [];//未读消息
				that.Mes = [];//已读消息	
				that.Msg = []
				msgApi.GetMessageList(function(data){
					console.log("消息列表")
					that.Msg = data
					that.forData(that.Msg)	
				})						
			},

			UpdMessageState(id) {//更新消息状态（变成已读）
				msgApi.UpdMessageState(id, function(data) {
				});
			},
			delMsg(id) {//删除消息
				var that = this;
				msgApi.DelMessage(id, function(data) {
					if(data.state == 'success') {
						// that.getList()
					}
				});
			},
			AdduserMsg(id,content) {//插入一条咨询消息
				var that = this;
				msgApi.AddUserMsgConsult(id,content, function(data) {
					if(data.state == 'success') {
						that.$toast("提交成功")
					}
				});
			},
			GetUserMsg(id,type) {//获取咨询回复
				var that = this;
				if(that.clickflag == true){
					msgApi.GetUserMsgConsultList(id, function(data) {
						if(type == "type1"){
							that.userMsg0.push(data)
						}else{
							that.userMsg1.push(data)
						}
						console.log("咨询返回数据",data)
						console.log("总未读",that.userMsg1)
						
					});
				}
				
			},
			onActionhide() {//咨询弹出框显示隐藏
				this.show = !this.show;
			},
			forData(data){
				var that = this
				for(var i = 0; i < data.rows.length; i++) {
					if(that.index == 0 && data.rows[i].LOOK_IND == "0"){//获取未读消息
						that.Mesinformation.push(data.rows[i]);
					}else if(that.index == 1 && data.rows[i].LOOK_IND == "1"){										  //获取已读消息	
						that.Mes.push(data.rows[i]);
					}
				}
			}
		},
		computed: {

		},
	}
</script>

<style lang="scss" scoped>
	@import "~static/sass/public.scss";
	.mui-btn{
		border: none;
	}
	#Information {
		display: flex;
		flex-direction: column;
	}
	
	.tab-container {
		display: flex;
		height: 0.88rem;
		background: #fff;
		a {
			flex: 1;
			text-align: center;
			font-size: 0.28rem;
			padding: 0.22rem 0;
			position: relative;
			color: $normalFontColor;
		}
		.active {
			color: #2894ff;
			&:after {
				content: '';
				display: block;
				height: 0.02rem;
				width: 1.16rem;
				background: #2894ff;
				position: absolute;
				left: 50%;
				bottom: 0;
				transform: translate(-50%, -50%);
			}
		}
	}
	.message-detail{
		display: none;
	}
	.mui-table-view{
		padding:0.16rem 0.24rem 0 0.24rem;
		background:none;
		&::before,&::after{
			display: none;
		}
	}
	.mui-table-view-cell {
		padding:0;
		position: relative;
		border-radius:3px;
		&::after{
			display: none;
		}
		.mui-slider-handle{
			padding:0.16rem;
		}
	}
	
	.message-container {
		flex: 1;
		position: relative;
	}
	
	.content {
		background: $whiteColor;
	}
	
	.discrip {
		padding: 0.2rem;
	}
	
	.tit,
	.msg {
		font-size: 0.24rem;
		line-height: 16px;
		color: $titleBgColor;
	}
	.text-container {
		padding: 0.24rem;
		.title {
			font-size: 0.32rem;
			font-weight: 100;
			padding: 0.2rem 0;
		}
		.text {
			font-size: 0.24rem;
			word-break: break-word;
			text-indent: 2em;
		}
		.text-indent {
			text-indent: 0.48rem;
		}
	}
	.msg-title{
		text-align: left;
		font-size:0.28rem;
		color:#000;
		width: 80%;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.msg-date{
		text-align:left;
		font-size:0.24rem;
	}
	.mui-badge{
		padding:4px;
		position: absolute;
		top: 0.2rem;
		right: 0.3rem;
	}

	.alert{
		height: 5rem;
		padding:0.24rem;
		background: #fff;


		.textarea{
			border:1px solid $tipsFontColor;
			height: 3.5rem;
			padding:0.16rem;
			font-size:0.24rem;
			width: 100%;
			z-index: 99999999;
		}
		.btn{
			width:100%;
			background:$blueColor;
			color: #fff;
			height: 0.88rem;
			margin-top:0.1rem;
		}
	}
	.usermsg{
		border-top: 1px solid $bgColor;
		padding:0.2rem;
		padding-bottom: 0;
		.user{
			text-align:left;
			p:nth-child(1){
				text-align: right;
				font-weight:800;
				color:#fb5353;
			}
		}
		.kefu{
			text-align:left;
			margin-top:0.16rem;
			border-top: 1px solid $bgColor;	
			p:nth-child(1){
				font-weight:800;
				color:#41de64;
			}		
		}
		.time{
			text-align: right;
			font-size:0.24rem;
		}
		// p:nth-child(2){
		// 	text-indent:2em;
		// }
	}	

</style>