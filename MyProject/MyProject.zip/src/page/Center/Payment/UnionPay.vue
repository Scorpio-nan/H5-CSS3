<template>
	<div>
		<div class="replace">
			<div class="mui-content">
				<div class="mui-row ongou">
					<div class="aaa">
						<div class="mui-input-row mui-radio mui-left mui-blank mui-blank_a" :class="[rank == 1 ? 'mui-blank_b': '']" v-for="(item,rank) in ChanelList">
							<label :class="index==rank?'bat':''" class="la_onclick" :data-index="rank" :data-object="JSON.stringify(item)">
								<div class="mui-media-body mui_size">
									{{item.SYS_ITEM_DETALL_NAME}}
									<p class='mui-ellipsis'>
										{{item.REMARK}}
									</p>
								</div>
							</label>
							<img src="static/img/public/right2.png" :class="index==rank?'gou2':''">
							<img class="pay_img" :src="'static/img/ge/'+ item.SYS_ITEM_DETAIL_TYPE +'.png'">
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="UnionPay_yin" v-show="PayType=='online'">
			<div class="area6">
				<div class="left_conten" :data-num="num" v-for="(item,num) in OnlineList" :class="subIndex==num?'bg_j_color':''">
					<span>通道 ({{num+1}}) <a v-if="item.ONL_PREFERENTIAL_RATE>0" >赠送{{item.ONL_PREFERENTIAL_RATE}}%</a>
					<br v-if="item.LIMIT_AMT>0"> 单笔限额{{item.LIMIT_AMT}}</span>
				</div>
			</div>
			<!--银联支付 -->
			<div class="UnionPay_payment">
				<div class="grayLine"></div>
				<div class="area">
					<div class="title">
						<div class="title_size mui-text-left">
							充值金额: <input class="sim" type="number" placeholder="单笔最低充值金额10元" v-model="chargeMoney">
						</div>
					</div>
				</div>
				<div class="grayLine">
				</div>
				<div class="area2">
					<div class="mui-container-fluid">
						<div class="mui-row">
							<div class="customize flexBtn">
								<button type="button" class="mui-btn mui-btn-block" data-index="0" data-amt="100" :class="Amtindex == 0 ? 'add_class':''">100元</button>
							</div>
							<div class="customize mui_jiange flexBtn">
								<button type="button" class="mui-btn mui-btn-block" data-index="1" data-amt="200" :class="Amtindex == 1 ? 'add_class':''">200元</button>
							</div>
							<div class="customize right_con flexBtn">
								<button type="button" class="mui-btn mui-btn-block" data-index="2" data-amt="500" :class="Amtindex == 2 ? 'add_class':''">500元</button>
							</div>
						</div>
						<div class="mui-row distance">
							<div class="customize flexBtn">
								<button type="button" class="mui-btn mui-btn-block" data-index="3" data-amt="1000" :class="Amtindex == 3 ? 'add_class':''">1000元</button>
							</div>
							<div class="customize mui_jiange flexBtn">
								<button type="button" class="mui-btn mui-btn-block" data-index="4" data-amt="2000" :class="Amtindex == 4 ? 'add_class':''">2000元</button>
							</div>
							<div class="customize right_con flexBtn">
								<button type="button" class="mui-btn mui-btn-block" data-index="5" data-amt="3000" :class="Amtindex == 5 ? 'add_class':''">3000元 <span class="tui">( 推荐 )</span></button>
							</div>
						</div>
					</div>
				</div>
				<form id="depositPayHideForm" method="post" target="_blank" v-bind:action="OnlineITem.PAY_URL + '/' + OnlineITem.PAYINT_TYPE_CD + '/Post?rd'+Math.random()">
					<input type="hidden" name="Int_pay_config_pay_id" :value="OnlineITem.INT_PAY_CONFIG_ID">
					<input type="hidden" name="Amount" :value="chargeMoney">
					<input type="hidden" name="Member_ind" value="1">
					<input type="hidden" name="Browser" value="M">
					<input type="hidden" name="User_info_id" :value="UserInfo.ID">
					<input type="hidden" name="Remark" value="手机端会员在线充值">
					<input type="hidden" name="Loan_type_cd" :value="OnlineITem.PAY_SHOW_ICO_CD">
					<input type="hidden" name="Payint_type_cd" :value="OnlineITem.PAYINT_TYPE_CD">
					<input type="hidden" name="Return_url" v-model="hideFromReturn_url">
					<input type="hidden" name="PayMethod" :value="OnlineITem.ENCODE">
				</form>
				<div class="area_u bottonOnline">
					<button type="button" class="mui-btn mui-btn-ti mr-t-20 add-btn">立即充值</button>
					<div class="out">
						<p>
							*温馨提示
						</p>
						<p>
							若通道无法正常支付，请选择其它通道或支付方式
						</p>
					</div>
				</div>
			</div>
		</div>
		<!--以上的是选择银联支付时候出现 -->

		<!--银联转账模块 -->
		<div class="transfer" v-show="PayType=='transfer'">

			<div class="grayLine">
			</div>
			<div class="area2">
				<div class="mui-container-fluid" id="demo5">
					<button class="btn mui-btn mui-btn-xuanze mui-text-left Select">选择账号：<span class="balk">{{TransferItem.PAY_BANK}}</span><span class="balk2">{{TransferItem.PAY_NAME}}</span></button>
				</div>
				<div class="mui-container-fluid2" id="demo6">
					<button class="btn mui-btn mui-btn-xuanze mui-text-left Select BeginTime" data-options='{"type":"time","beginYear":2014,"endYear":2018}'>转账时间：<span class="balk">{{beginTime}}</span></button>
				</div>
			</div>
			<div class="lists clearfix">
				<ul class="clearfix ul" id="clearfixul">
					<li class="add">
						<div class="left_code">
							<span>户名：</span><span id="name">{{TransferItem.PAY_NAME}}</span>
						</div>
						<div class="right">
							<button type="button" class="btn_register mui-btn-right" data-clipboard-action="copy" data-clipboard-target="#name" id="copy_btn1">复制</button>
						</div>
					</li>
					<li class="add">
						<div class="left_code">
							<span>帐号：</span><span id="accounts">{{TransferItem.PAY_ACCOUNT}}</span>
						</div>
						<div class="right">
							<button type="button" class="mui-btn-right btn_register" data-clipboard-action="copy" data-clipboard-target="#accounts" id="copy_btn2">复制</button>
						</div>
					</li>
					<li>
						<div class="left_code">
							<span>地址：</span><span id="address">{{TransferItem.PAY_ADDRESS}}</span>
						</div>
						<div class="right">
							<button type="button" class="mui-btn-right btn_register" data-clipboard-action="copy" data-clipboard-target="#address" id="copy_btn3">复制</button>
						</div>
					</li>
				</ul>
			</div>
			<div class="mui-content2">
				<ul class="mui-table-view">
					<li class="mui-table-view-cell left">充值金额：<input class="sim" type="number" placeholder="单笔最低充值金额10元" v-model="chargeMoney"></li>
					<li class="mui-table-view-cell left">{{pay_title}}：<input class="sim" type="text" placeholder="汇款账户" v-model="whocharge"></li>
				</ul>
			</div>
			<div class="area_u bottonTransfer">
				<img v-if="TransferItem.ORCODE_URL!=null && TransferItem.ORCODE_URL!='&nbsp;' && TransferItem.ORCODE_URL!=''" class="er_code" v-bind:src="imgUrl_ + TransferItem.ORCODE_URL">
				<button type="button" class="mui-btn mui-btn-ti mr-t-20 add-btn">提交订单</button>
				<div class="out">
					<p>
						*温馨提示
					</p>
					<p>
						若通道无法正常支付，请选择其它通道或支付方式
					</p>
				</div>
			</div>
		</div>
		<!--scoll，底部别动 -->
	</div>

</template>l
<script>
	import user from '@/api/userUtil';
	import pay from '@/api/payUtil';
	export default {
		name: "",
		components: {},
		props: {
			ChanelList: Array,
		},
		data() {
			return {
				hideFromReturn_url: lib.ME_URL___,
				chargeMoney: null, //充值金额
				whocharge: null, //充值姓名
				imgUrl_: lib.imgUrl,
				pay_title: '汇款姓名',
				PayType: '',
				OnlineList: [],
				OnlineITem: [],
				TransferList: [],
				TransferItem: {
					PAY_BANK: '',
					PAY_NAME: '',
					PAY_ADDRESS: '',
					PAY_ACCOUNT: '',
					ORCODE_URL: '',
				},
				Cardlist: [], //转账下拉选项卡
				index: 0,
				subIndex: 0,
				Amtindex: 99,
				warnText1: "亲，已经复制好了:)",
				beginTime: new Date().Format('hh:mm')
			};
		},
		created() {
			const that = this;
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				$('.mui-blank_b').css({
					'borderColor': 'red'
				})

				mui("#demo5").on("tap", ".Select", function() {
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.Cardlist);
					CardPiker.show(function(items) {
						for(var i = 0; i < that.TransferList.length; i++) {
							if(that.TransferList[i].ID == items[0].value) {
								that.ChooseItme(i);
							}
						}
					});
				});
				mui("#demo6").on("tap", ".BeginTime", function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.beginTime = res['text'];
						})
					}
				});

				mui(".ongou").on("tap", ".la_onclick", function() {
					var index = $(this).data("index");
					var obj = $(this).data("object");
					that.index = index;
					that.GetDetailList(obj.SYS_ITEM_DETAIL_TYPE, obj.SOURCE_CODE);
					$('.la_onclick').parents('.mui-radio').css({
						'borderColor': '#ccc'
					})
					$(this).parents('.mui-radio').css({
						'borderColor': '#19b4f5'
					})

				});

				mui(".UnionPay_yin").on("tap", ".left_conten", function() {
					that.subIndex = $(this).data("num");
					that.ChooseItme(that.subIndex);
				});
				mui(".customize").on("tap", ".mui-btn-block", function() {
					var index = $(this).data("index");
					var amt = $(this).data("amt");
					that.Amtindex = index;
					that.chargeMoney = amt;

				});
				mui(".bottonTransfer").on("tap", ".add-btn", function() {
					mui(this).button('loading');
					$('.mui-btn-block .mui-spinner').css({
						'width': '18px',
						'height': '18px'
					})
					that.companysubmit();
					setTimeout(function() {
						mui(this).button('reset');
					}.bind(this), 1000);

				});
				mui(".bottonOnline").on("tap", ".add-btn", function() {
					mui(this).button('loading');
					$('.mui-btn-block .mui-spinner').css({
						'width': '18px',
						'height': '18px'
					})
					that.hrefPayPage();
					setTimeout(function() {
						mui(this).button('reset');
					}.bind(this), 1000);

				});
				//复制粘贴功能
				var clipboard = new Clipboard("#copy_btn1");
				clipboard.on("success", function(e) {
					that.$toast(that.warnText1);
				});
				var clipboard = new Clipboard("#copy_btn2");
				clipboard.on("success", function(e) {
					that.$toast(that.warnText1);
				});
				var clipboard = new Clipboard("#copy_btn3");
				clipboard.on("success", function(e) {
					that.$toast(that.warnText1);
				});
			});
		},
		methods: {
			hrefPayPage: function() { //在线存款提交
				var this_ = this;
				var mReg = /^[0-9]+\.{0,1}[0-9]{0,2}$/;
				if(this_.chargeMoney == '' || this_.chargeMoney == null || this_.chargeMoney == 0) {
					this_.$alert('请输入正确的入款金额')
					return;
				} else if(mReg.test(this_.chargeMoney) == false) {
					this_.$alert('金额格式不正确')
					return;
				} else if(this_.chargeMoney < this_.userGroup.MIN_DEPOSIT_AMT) {
					this_.$alert('最低充值金額不得低于' + this_.userGroup.MIN_DEPOSIT_AMT + '元')
					return;
				} else if(this_.chargeMoney > this_.OnlineITem.LIMIT_AMT && this_.OnlineITem.IS_RESTRICT == '1') {
					this_.$alert('该线路单笔限额' + this_.OnlineITem.LIMIT_AMT + '元')
					return;
				}
				if(this_.OnlineITem.IS_ADJUST == '1') {
					this_.chargeMoney = parseFloat(this_.chargeMoney) + Math.random() / 10;
					this_.chargeMoney = this_.chargeMoney.toFixed(2);
				}
				if(lib.IsApp) {
					mui.plusReady(function() {
						var obj = {
							'url': this.OnlineITem.PAY_URL + '/' + this.OnlineITem.PAYINT_TYPE_CD + '/Post',
							'payid': this.OnlineITem.INT_PAY_CONFIG_ID,
							'Amount': this.chargeMoney,
							'Userinfoid': this.UserInfo.ID,
							'Loantypecd': this.OnlineITem.PAY_SHOW_ICO_CD,
							'Payinttypecd': this.OnlineITem.PAYINT_TYPE_CD,
							'PayMethod': this.OnlineITem.ENCODE
						}
						plus.runtime.openURL(lib.payUrl + "?url=" + obj['url'] + "&id=" + obj['payid'] + "&Amount=" + obj['Amount'] + "&Userid=" + obj['Userinfoid'] + "&Loantypecd=" + obj['Loantypecd'] + "&Payinttypecd=" + obj['Payinttypecd'] + "&PayMethod=" + obj['PayMethod'])
					})
				} else {
					setTimeout(() => {
						$('#depositPayHideForm').submit();
					}, 100)
				}
			},
			companysubmit() { //公司入款提交
				var this_ = this;
				if(this_.companyvalidate() == false) {
					return;
				};
				var paychannel = '';
				var loanTypeCd = '';
				switch(this_.chanl_code) {
					case 'bank':
						paychannel = '网银转账'
						loanTypeCd = '2-4'
						break;
					case 'bank_quick':
						paychannel = '银联云闪付'
						loanTypeCd = '2-4'
						break;
					case 'alipay':
						paychannel = '支付宝转账'
						loanTypeCd = '2-13'
						break;
					case 'wechat':
						paychannel = '微信转账'
						loanTypeCd = '2-14'
						break;
					case 'qq':
						paychannel = 'qq转账'
						loanTypeCd = '2-15'
						break;
					case 'alipay_bank':
						paychannel = '支付宝转银行'
						loanTypeCd = '2-13'
						break;
					case 'wechat_bank':
						paychannel = '微信转银行'
						loanTypeCd = '2-14'
						break;
					default:
						paychannel = '转账汇款'
						loanTypeCd = '2-4'
				};
				var postdata = {
					loan_type_cd: loanTypeCd,
					pay_id: this_.TransferItem.ID,
					amt: this_.chargeMoney,
					pay_address: paychannel,
					pay_name: this_.whocharge,
					ORDER_MAKE_DTT: new Date().Format('yyyy-MM-dd')+' '+ this_.beginTime + ':00',
				};
				user.SubDeposit(postdata, function(data) {
					this_.chargeMoney = null; //充值金额
					this_.whocharge = null; //充值姓名
					if(data.state == 'success') {
						this_.$alert('您的信息已经提交，我们的客服人员会尽快处理');
					}
				});
			},
			companyvalidate: function() {
				var Vreg = /^[0-9]+\.{0,1}[0-9]{0,2}$/;
				if(this.chargeMoney == null || this.chargeMoney == '' || this.chargeMoney <= 0) {
					this.$alert('请输入正确的入款金额')
					return false;
				} else if(this.chargeMoney.substr(0, 1) == 0) {
					this.$alert('请输入正确的入款金额')
					return;
				} else if(Vreg.test(this.chargeMoney) == false) {
					this.$alert('请输入正确的入款金额')
					return false;
				} else if(this.chargeMoney < this.userGroup.MIN_RECHARGE_AMT) {
					this.$alert('最低入款额度为' + this.userGroup.MIN_RECHARGE_AMT)
					return false;
				} else if(this.whocharge == null || this.whocharge == '') {
					this.$alert('请输入汇款人信息');
					return false;
				} else if(this.beginTime == null || this.beginTime == '') {
					this.$alert('请输入正确转账时间');
					return false;
				}
			},
			GetDetailList(code, sorce) {
				var that = this;
				that.PayType = sorce;
				if(sorce == 'online') {
					that.OnlineList = [];
					pay.GetOnlinePayDetailLineList(code, function(data) {
						for(var i = 0; i < data.length; i++) {
							if(data[i].MOBILE_IND == 1) {
								that.OnlineList.push(data[i])
							}
						}
						that.ChooseItme(0)
					})
				} else {
					that.Cardlist = [];
					user.GetPayBankList(code, function(data) {
						if(data.length > 0) {
							that.TransferList = data;
							that.ChooseItme(0);
							for(var i = 0; i < data.length; i++) {
								if(data[i].ONL_PREFERENTIAL_RATE > 0) {
									var __obj = {
										value: data[i].ID,
										text: data[i].PAY_BANK + '  ' + data[i].PAY_NAME + '  赠送' + data[i].ONL_PREFERENTIAL_RATE * 100 + '%',
									}
								} else {
									var __obj = {
										value: data[i].ID,
										text: data[i].PAY_BANK + '  ' + data[i].PAY_NAME,
									}
								}
								that.Cardlist.push(__obj);
							}
						}
					})
				}
			},
			ChooseItme(e) {
				if(this.PayType == 'online') {
					this.OnlineITem = this.OnlineList[e];
				} else {
					this.TransferItem = this.TransferList[e];
				}

			},

		},
		computed: {
			chanel() {
				return this.ChanelList
			},
			userGroup() {
				return this.$store.getters.getUserGroup;
			},
			UserInfo() {
				return this.$store.getters.getUserInfo;
			},
		},
		watch: {
			chanel(val) {
				var that = this;
				that.index = 0;
				that.subIndex = 0;
				if(val[0].SOURCE_CODE == 'bank_quick') {
					that.pay_title = '卡号后四位';
				} else if(val[0].SOURCE_CODE == 'qq') {
					that.pay_title = '支付账号';
				} else {
					that.pay_title = '汇款姓名';
				}
				that.GetDetailList(val[0].SYS_ITEM_DETAIL_TYPE, val[0].SOURCE_CODE);
			}

		}
	};
</script>

<style scoped lang="scss">
	@import "~static/sass/public.scss";
	.active {
		background: rgb(21, 149, 136);
		color: white;
		border: 1px solid green;
	}
	
	.aaa {
		width: 100%;
		display: flex;
		flex-wrap: wrap;
	}
	
	.flexBtn {
		flex: 0 0 31.3%;
	}
	
	#Rechargeonline {
		background: $bgColor;
	}
	
	.replace {
		// display: none;
	}
	
	.mui-table-view.mui-grid-view .mui-table-view-cell .mui-media-body {
		font-size: 0.24rem;
		line-height: inherit;
		display: block;
		width: 100%;
		height: inherit;
		margin-top: 0.15rem;
		text-overflow: ellipsis;
		color: $importFontColor;
	}
	
	.mui-grid-view.mui-grid-9 {
		border-top: 0;
		border-left: 0;
		background-color: $whiteColor;
		text-align: left;
	}
	
	.mui-icon img {
		width: 0.66rem;
		display: block;
		height: 0.66rem;
	}
	
	.ke {
		margin-left: 0.36rem;
	}
	
	.grayLine {
		height: 0.18rem;
		background: #e9e9e9;
	}
	
	.mui-checkbox input[type="checkbox"],
	.mui-radio input[type="radio"] {
		position: absolute;
		top: 0.5rem;
		right: 20px;
		display: inline-block;
		width: 28px;
		height: 26px;
		border: 0;
		outline: 0 !important;
		background-color: transparent;
		-webkit-appearance: none;
		left: 2.9rem;
	}
	
	.mui-checkbox input[type="checkbox"] {
		top: 3px;
	}
	
	.mui-blank {
		width: 48%;
		height: 1.08rem;
	}
	
	.mui-checkbox.mui-left label {
		padding-top: 0.12rem;
		padding-bottom: 0.12rem;
	}
	
	.mui-input-row {
		clear: none;
	}
	
	.mui-blank_a {
		flex: 0 0 46%;
		background: $bgColor;
		border: 1px solid $tipsFontColor;
		margin-left: .2rem;
		margin-bottom: .2rem;
		/*		border-radius: 0.03rem;*/
		margin-bottom: 0.2rem;
	}
	
	.mui-blank_b {
		margin-left: 0.2rem;
		float: right;
		background: $bgColor !important;
		/*		border-radius: 0.03rem;*/
	}
	
	.mui-grid-view.mui-grid-9 .mui-table-view-cell {
		margin: 0;
		padding: 0;
		margin: 0.2rem 0.28rem 0.2rem 0;
		vertical-align: top;
		border-right: 0;
		border-bottom: 0;
	}
	
	.mui-grid-view.mui-grid-9 .mui-table-view-cell>a:not(.mui-btn) {
		margin: 0;
		padding: 0;
	}
	
	.mui-col-xs-3 {
		width: 21%;
	}
	
	.pay_img {
		width: 0.66rem;
		height: 0.66rem;
		position: absolute;
		top: 0.2rem;
		display: inline-block;
		left: 0.2rem;
	}
	
	.mui-grid-view.mui-grid-9 .mui-media .mui-icon {
		font-size: 0.67rem;
		position: relative;
		top: 0.2rem;
	}
	
	.mui-content {
		background: $bgColor;
		margin-top: 0.2rem;
	}
	
	.mui-ellipsis {
		font-size: 0.24rem;
		color: $assistFontColor;
		margin-top: .1rem;
	}
	
	.mui_size {
		font-size: 0.28rem;
		color: $importFontColor;
		text-align: left;
		/*		margin-top: 0.08rem;*/
	}
	
	.title {
		width: 100%;
		margin: auto;
		padding: 0.22rem 0.22rem 0.22rem 0;
	}
	
	.title_size {
		font-size: 0.28rem;
		color: $importFontColor;
		font-weight: bold;
	}
	
	.sim {
		font-size: 0.28rem;
		padding-left: 0.19rem;
		width: 50%;
		padding: 0 0 0 0.19rem;
		height: initial;
		margin-bottom: inherit;
		border: 0;
		font-weight: lighter;
	}
	
	.mui-container-fluid {
		padding-top: 0.2rem;
	}
	
	.mui-container-fluid2 {
		padding-top: 0.15rem;
	}
	
	.customize {
		width: 31.5%;
		float: left;
		text-align: left;
	}
	
	.mui-btn-block {
		font-size: 0.25rem;
		display: inline-block;
		width: 100%;
		margin-bottom: 0;
		padding: 0.09rem;
		color: $normalFontColor;
		border-radius: 0.03rem;
	}
	
	.distance {
		margin-top: 0.2rem;
	}
	
	.mui-btn-zidingyi {
		font-size: 0.3rem;
		display: inline-block;
		width: 100%;
		margin-bottom: 0;
		padding: 0.22rem;
		text-indent: 0.34rem;
		background: url("/static/img/public/down.png")$tipsFontColor no-repeat;
		background-position: right;
		color: $normalFontColor;
		display: none;
	}
	
	.mui-btn-ti {
		font-size: 0.32rem;
		display: inline-block;
		width: 100%;
		margin-top: 0.4rem;
		padding: 0.23rem;
		border: 0;
		background: $blueColor;
		color: $whiteColor;
		border-radius: 0.03rem;
	}
	
	.mui-btn-ti:active {
		background: #499eff;
	}
	
	.out {
		margin-top: 0.2rem;
		padding-bottom: 0.2rem;
	}
	
	.out p {
		height: initial;
		line-height: initial;
		font-size: 0.24rem;
		color: $warnColor;
		text-align: left;
	}
	
	.mui-radio input[type="radio"]:checked:before {
		content: "\e442";
		// background: rebeccapurple;
	}
	
	.mui-table-view-cell:after {
		position: absolute;
		right: 0;
		bottom: 0;
		left: 0px;
		height: 1px;
		content: "";
		-webkit-transform: scaleY(0.5);
		transform: scaleY(0.5);
		background-color: #c8c7cc;
	}
	
	.left {
		text-align: left;
		font-size: 0.28rem;
		padding: 0.3rem 0 0.3rem 0.24rem;
	}
	
	.mui-checkbox input[type="checkbox"]:before,
	.mui-radio input[type="radio"]:active {
		background: rebeccapurple;
	}
	
	.mui-table-view:before {
		position: static;
		right: 0;
		left: 0;
		height: 1px;
		content: "";
		-webkit-transform: scaleY(0.5);
		transform: scaleY(0.5);
		background-color: #c8c7cc;
		top: -1px;
	}
	
	.mui-content>.mui-table-view:first-child {
		margin-top: 0;
	}
	
	.mui-btn-xuanze {
		font-size: 0.24rem;
		display: inline-block;
		width: 100%;
		margin-bottom: 0;
		padding: 0.21rem 0;
		text-indent: 0.19rem;
		background: url("/static/img/public/triangle.png")no-repeat #eeeeee;
		background-position: 96%;
		background-size: 0.24rem 0.16rem;
		color: #333333;
		border: 1px solid #cccccc;
	}
	
	.balk {
		padding-left: 0.39rem;
	}
	
	.balk2 {
		padding-left: 0.4rem;
	}
	
	.lists {
		background: #fff;
		.ul {
			padding: 0 0.24rem;
			li {
				width: 100%;
				float: left;
				height: 0.9rem;
				.left {
					float: left;
					span {
						font-size: 0.15rem;
					}
					span:nth-child(2) {}
				}
				.right {
					float: right;
					button {
						background: $titleBgColor;
						color: $whiteColor;
						margin-top: 0.12rem;
					}
				}
			}
		}
		.add {
			border-bottom: 1px solid #eeeeee;
		}
	}
	
	.mui-btn-right {
		font-size: 0.24rem;
		font-weight: 400;
		position: relative;
		display: inline-block;
		margin-bottom: 0;
		padding: 0.1rem 0.18rem;
		cursor: pointer;
		-webkit-transition: all;
		transition: all;
		-webkit-transition-timing-function: linear;
		transition-timing-function: linear;
		-webkit-transition-duration: 0.2s;
		transition-duration: 0.2s;
		text-align: center;
		vertical-align: top;
		white-space: nowrap;
		color: #333;
		/*		border: 1px solid #ccc;*/
		border-radius: 3px;
		border-top-left-radius: 3px;
		border-top-right-radius: 3px;
		border-bottom-right-radius: 3px;
		border-bottom-left-radius: 3px;
		background-color: #fff;
		background-clip: padding-box;
	}
	
	.mui-checkbox input[type="checkbox"]:before,
	.mui-radio input[type="radio"]:before {
		font-family: Muiicons;
		font-size: 0.34rem;
		font-weight: 400;
		line-height: 1;
		text-decoration: none;
		// color: #aaa;
		border-radius: 0;
		background: 0 0;
		-webkit-font-smoothing: antialiased;
	}
	
	.mui-input-row label {
		/*padding-top: 0.22rem;
		padding-bottom: 0.24rem;*/
		background: $whiteColor;
		padding-left: 1rem;
	}
	
	.area {
		padding: 0 0.24rem;
		background: $whiteColor;
	}
	
	.area2 {
		padding: 0 0.24rem 0.2rem;
		background: $whiteColor;
	}
	
	.area_u {
		padding: 0 0.24rem;
	}
	
	.mui_jiange {
		margin-left: 0.2rem;
	}
	
	.juli {
		margin-left: 0.2rem;
	}
	
	.right_con {
		/*float: right;*/
		margin-left: .2rem;
	}
	
	.content_list {
		height: 1.4rem;
		background: rebeccapurple;
	}
	
	.left_conten {
		height: 0.98rem;
		width: 2.4rem;
		background: #ffffff;
		font-size: 0.24rem;
		color: #666666;
		text-align: left;
		box-sizing: border-box;
		padding-left: 0.13rem;
		padding-top: 0.1rem;
		display: inline-block;
		border: 1px solid $tipsFontColor;
		margin-right: 0.2rem;
	}
	
	.area6 {
		padding: 0.2rem 0.24rem;
		background: $whiteColor;
		text-align: left;
	}
	
	.tui {
		color: #f07377;
		font-size: 0.25rem;
	}
	
	.mui-content2 {
		background: $whiteColor;
		margin-top: 0.2rem;
	}
	
	.left_code {
		display: inline-block;
		float: left;
		font-size: 0.24rem;
		color: #333333;
		padding-top: 0.2rem;
	}
	
	.mui-blank_c {
		margin-top: 0.2rem;
	}
	
	.bg_j_color {
		background: $blueColor;
		position: relative;
		color: $whiteColor;
		border-radius: 0.03rem;
		border: 1px solid transparent;
		margin-bottom: .16rem;
		&::after {
			display: block;
			position: absolute;
			content: "";
			right: 0.1rem;
			bottom: 0.1rem;
			width: 0.34rem;
			height: 0.34rem;
			background: url("../../../../static/img/public/check.png") no-repeat;
			background-size: 100% 100%;
		}
	}
	
	.mui-table-view:after {
		position: absolute;
		right: 0;
		bottom: 0;
		left: 0;
		height: 1px;
		content: "";
		-webkit-transform: scaleY(0.5);
		transform: scaleY(0.5);
		background-color: inherit;
	}
	
	.er_code {
		width: 2.4rem;
		height: 2.4rem;
		margin-top: 0.4rem;
	}
	
	.bat {
		background: #19b4f5 !important;
		position: relative;
		border: 1px solid #19b4f5;
		.mui_size {
			color: $whiteColor !important;
		}
		.mui-ellipsis {
			color: $whiteColor !important;
			background: #19b4f5 !important;
			margin-top: .1rem;
		}
		.mui-blank_a {
			border: 0 !important;
		}
		.mui-blank_b {
			border: 0 !important;
		}
	}
	
	.gou2 {
		width: 0.36rem;
		height: 0.36rem;
		position: absolute;
		top: 0.5rem;
		right: 0.1rem;
		display: inline-block;
		border: 0;
		outline: 0 !important;
		background-color: transparent;
		-webkit-appearance: none;
	}
	
	.add_class {
		color: #676767;
		background-color: #f5f6f8;
		border: 1px solid #CCCCCC;
	}
	
	.mui-row {
		display: flex;
		flex-wrap: wrap;
	}
	
	.mui-blank_a:first-child {
		border: 1px solid #19b4f5;
	}
</style>