<template>
	<div class="BetttingRecods">
		<nav class="first-nav">
			<a href="javascript:;" class="border-right-none" :class="timeSlect == 0 ?'active':''" data-index="0">本周</a>
			<a href="javascript:;" class="border-right-none" :class="timeSlect == 1 ?'active':''" data-index="1">上周</a>
			<a href="javascript:;" class="border-right-none" :class="timeSlect == 2 ?'active':''" data-index="2">本月</a>
			<a href="javascript:;" class="border-right-none" :class="timeSlect == 3 ?'active':''" data-index="3">上月</a>
		</nav>
		<nav class="seconde-nav">
			<a href="javascript:;" class="border-right-none" :class="typeSelect == 0?'active':''" data-index="0">真人视讯</a>
			<a href="javascript:;" class="border-right-none" :class="typeSelect == 1?'active':''" data-index="1">电子游艺</a>
			<a href="javascript:;" class="border-right-none" :class="typeSelect == 2?'active':''" data-index="2">彩票游戏</a>
			<a href="javascript:;" class="border-right-none" :class="typeSelect == 3?'active':''" data-index="3">体育竞技</a>
		</nav>
		<nav class="third-nav">
			<a href="javascript:;" class="border-right-none">时间</a>
			<a href="javascript:;" class="border-right-none">笔数</a>
			<a href="javascript:;" class="border-right-none">有效投注</a>
			<a href="javascript:;" class="border-right-none">输赢</a>
			<a href="javascript:;" class="border-right-none">注单</a>
		</nav>
		<div class="main">
			<scroller>
				<table border="0" cellspacing="0" cellpadding="0">
					<tr v-for="(item,index) in betArray">
						<td>
							<p class="font-tit">{{item.RPT_DATE.substr(0,10)}}</p>
							<p class="font-tit">{{item.DAY_WEEK}}</p>
						</td>
						<td>{{item.BET_NUM}}</td>
						<td>&yen;{{item.BET_AMT}}</td>
						<td>&yen;{{item.WIN}}</td>
						<td class="Record-detail" :data-start="item.RPT_DATE.substr(0,10)" :data-selgame="selectedgame" :data-betnum="item.BET_NUM">
							<span class="iconfont icon-icon-70"></span>
						</td>
					</tr>
				</table>
			</scroller>
		</div>
		<div class="btn-box">
			<button class="mui-btn mui-btn-blue mui-btn-block querybtn">立即查询</button>
		</div>

		<ActionSheet :show="actionShow" @hide="handleAction">
			<div class="mui-card timer" slot="action">
				<ul class="mui-table-view mui-table-view-chevron mr-t-8">
					<li class="mui-table-view-cell btn" data-options='{}'>
						<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">开始日期
							<div class="segmented-Select">
								<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="btn mui-btn mui-btn-block BeginTime mr-r">{{beginTime}}</button>
							</div>
						</a>
					</li>
					<li class="mui-table-view-cell btn" data-options='{}'>
						<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">结束日期
							<div class="segmented-Select">
								<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="btn mui-btn mui-btn-block EndTime mr-r">{{endTime}}</button>
							</div>
						</a>
					</li>
					<li class="mui-table-view-cell gametype">
						<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">游戏类型
							<input type="text" class="mui-input-clear" placeholder="请选择游戏类型" readonly="readonly" v-model="currentGame">
						</a>
					</li>
				</ul>
				<p class="gray-line"></p>
				<button type="button" class="mui-btn mui-btn-primary Search-btn mui-btn-block">立即查询</button>
			</div>
		</ActionSheet>
	</div>
</template>

<script>
	import api from '@/api/userUtil';
	import ActionSheet from './template/ActionSheet';
	import Scroller from '@/components/Scroller'
	export default {
		name: 'AgentBetDetail',
		components: {
			ActionSheet,
			Scroller
		},
		data() {
			return {
				loadingShow: true,
				actionShow: false,
				beginTime: new Date().Format('yyyy-MM-dd'),
				endTime: new Date().Format('yyyy-MM-dd'),
				gamelist: [{ //默認查詢條件
					value: 0,
					text: "全部"
				}, {
					value: 3,
					text: "视讯"
				}, {
					value: 9,
					text: "电子"
				}, {
					value: 2,
					text: "彩票"
				}, {
					value: 1,
					text: "体育"
				}],
				timeSlect: 0,
				typeSelect: 0,
				selectedgame: '',
				betArray: [],
				BetSum: {},
				currentGame: '',
			}
		},
		mounted() {
			const that = this;

			mui.init();
			mui.ready(function() {
				//详情
				mui('.main').on('tap', '.Record-detail', function() {
					var start = $(this).data('start');
					var selgame = $(this).data('selgame');
					var betnum = $(this).data('betnum');
					var st_dt = start.substr(0, 10)
					that.$router.push({
						path: '/BettingRecordDetail',
						query: {
							start: st_dt,
							game_cd: selgame,
						}
					});
				})

				//底部查询按钮
				mui('.btn-box').on('tap', '.querybtn', function() {
					that.actionShow = true;
				})

				//开始时间
				mui('.timer').on('tap', '.BeginTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {
						})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.beginTime = res['text'];
						})
					}
				})

				//结束时间
				mui('.timer').on('tap', '.EndTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {
						})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.endTime = res['text'];
						})
					}
				})

				//弹出菜单查询
				mui('.timer').on('tap', '.Search-btn', function() {
					that.actionShow = false;
					that.querySubmit();
				})

				//选择游戏类型
				mui('.timer').on('tap', '.gametype', function() {
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.gamelist);
					CardPiker.show(function(items) {
						that.currentGame = items[0]['text'];
						that.selectedgame = items[0]['value'];
					});
				})

				//时间nav切换
				mui('.first-nav').on('tap', 'a', function() {
					var index = $(this).data('index');
					that.timeSlect = index;
					that.makeQueryJson();
				})

				//游戏类型nav切换
				mui('.seconde-nav').on('tap', 'a', function() {
					var index = $(this).data('index');
					that.typeSelect = index;
					that.makeQueryJson();
				})

			})

		},
		methods: {
			//弹出菜单
			handleAction() {
				this.actionShow = !this.actionShow;
			},
			//数据初始化
			init(sttd, enddt, cd) {
				const that = this;
				var postData = {
					star_time: sttd,
					end_time: enddt,
					game_id: cd
				}
				if(this.$route.path == '/AgentBetDetail') {
					api.GetUserLeavesbetRpt(postData, (res) => {
						var res = JSON.parse(res);
						that.betArray = res;
						var x, y, z, i;
						for(i = 0; i < res.length; i++) {
							x += res[i].BET_NUM;
							y += res[i].BET_AMT;
							z += res[i].WIN;
						}
						that.BetSum = {
							BET_NUM: x,
							BET_AMT: y.toFixed(2),
							WIN: z.toFixed(2)
						};
					});
				} else {
					api.GetUserbetRpt(postData, (res) => {
						var res = JSON.parse(res);
						that.betArray = res;
						var x, y, z, i;
						for(i = 0; i < res.length; i++) {
							x += res[i].BET_NUM;
							y += res[i].BET_AMT;
							z += res[i].WIN;
						}
						that.BetSum = {
							BET_NUM: x,
							BET_AMT: y.toFixed(2),
							WIN: z.toFixed(2)
						};
					});
				}
			},
			//计算时间周期
			makeQueryJson() {
				var that = this;
				var Today = new Date(),
					weekday = new Date(), //本周开始时间时间
					lastweekstart = new Date(), //上周开始时间
					lastweekend = new Date(), //上周结束时间
					monthstart = new Date(), //本月第一天
					lastmonthstart = new Date(), //上月第一天
					lastmonthend = new Date(), //上月最后一天
					start_date,
					end_date,
					game_type; //游戏类型

				weekday.setDate(Today.getDate() - 6);
				lastweekstart.setDate(Today.getDate() - Today.getDay() - 6);
				lastweekend.setDate(Today.getDate() - Today.getDay());
				monthstart.setDate(1);
				lastmonthstart.setMonth(Today.getMonth() - 1);
				lastmonthstart.setDate(1);
				lastmonthend.setDate(monthstart.getDate() - 1);

				switch(that.typeSelect) {
					case 0:
						game_type = 3;
						this.currentGame = '真人'
						break;
					case 1:
						game_type = 9;
						this.currentGame = '电子'
						break;
					case 2:
						game_type = 2;
						this.currentGame = '彩票'
						break;
					case 3:
						game_type = 1;
						this.currentGame = '体育'
						break;
				};
				switch(that.timeSlect) {
					case 0:
						start_date = that.makedate(weekday);
						end_date = that.makedate(Today);
						break;
					case 1:
						start_date = that.makedate(lastweekstart);
						end_date = that.makedate(lastweekend);
						break;
					case 2:
						start_date = that.makedate(monthstart);
						end_date = that.makedate(Today);
						break;
					case 3:
						start_date = that.makedate(lastmonthstart);
						end_date = that.makedate(lastmonthend);
						break;
				};
				that.selectedgame = game_type;
				that.init(start_date, end_date, game_type);
			},
			//确认提交按钮
			querySubmit() {
				var that = this;
				switch(that.selectedgame) {
					case 3:
						that.typeSelect = 0;
						break;
					case 9:
						that.typeSelect = 1;
						break;
					case 2:
						that.typeSelect = 2;
						break;
					case 1:
						that.typeSelect = 3;
						break;
				};
				that.init(that.beginTime, that.endTime, that.selectedgame);
			},
			//加工时间格式
			makedate(vals) {
				var val = new Date(vals);
				var month = val.getMonth() + 1;
				var strDate = val.getDate();
				if(month >= 1 && month <= 9) {
					month = "0" + month;
				}
				if(strDate >= 0 && strDate <= 9) {
					strDate = "0" + strDate;
				}
				var dateTemp = val.getFullYear() + "-" + month + "-" + strDate;
				return dateTemp
			},
		},
		created() {
			this.makeQueryJson();
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.BetttingRecods {
		height: 100%;
		display: flex;
		flex-direction: column;
		.first-nav {
			padding: 0.24rem;
			display: flex;
			a {
				flex: 1;
				font-size: 0.28rem;
				background: #fff;
				padding: 0.1rem 0;
				@include border1px($blueColor)
			}
			a:first-child {
				border-radius: 3px 0 0 3px;
			}
			a:first-child::after {
				border-radius: 3px 0 0 3px;
			}
			a:last-child {
				border-radius: 0 3px 3px 0;
			}
			a:last-child::after {
				border-radius: 0 3px 3px 0;
			}
			.active {
				background: $blueColor;
				color: #fff;
			}
		}
		.seconde-nav {
			background: #fff;
			display: flex;
			a {
				flex: 1;
				font-size: 0.28rem;
				padding: 0.2rem;
			}
			.active {
				color: $blueColor;
				position: relative;
				&:after {
					content: '';
					height: 1px;
					width: 1.2rem;
					background: $blueColor;
					position: absolute;
					left: 50%;
					bottom: 0;
					transform: translate(-50%, -50%);
				}
			}
		}
		.third-nav {
			margin-top: 0.16rem;
			background: #fff;
			display: flex;
			a {
				flex: 1;
				font-size: 0.24rem;
				padding: 0.1rem 0;
				@include border-1px(#ccc, bottom);
			}
		}
		.main {
			flex: 1;
			position: relative;
			table {
				width: 100%;
				background: #fff;
				tr {
					td {
						font-size: 0.24rem;
						height: 0.8rem;
						@include border-1px(#ccc, bottom);
						width: 20%;
					}
				}
				.font-tit{
					font-size: 0.24rem;
					color: #666;
				}
			}
		}
		.Record-detail {
			.iconfont {
				font-size: 0.4rem;
				color: #19b4f5;
			}
			&:active .iconfont {
				color: rgba(#19b4f5, 0.6);
			}
		}
		.btn-box {
			padding: 0.24rem;
			.querybtn {
				margin: 0;
				padding: 0.2rem 0;
				background: #19b4f5;
				border: 0 none;
				&:active {
					background: rgba(#19b4f5, 0.6);
				}
			}
		}
		.timer {
			box-shadow: none;
			a {
				padding: 0 0 0 15px;
			}
			.mui-table-view-cell:after {
				content: '';
				height: 0;
			}
			.segmented-Select {
				display: inline-block;
				button {
					font-size: 0.24rem;
					padding: 0.2rem 2rem;
					border: none;
					margin: 0;
					&:active {
						background: rgba(255, 255, 255, 0.4);
					}
				}
			}
			.mui-input-clear {
				border: none;
				padding-left: 2rem;
				font-size: 0.24rem;
				margin: 0;
			}
			.mui-table-view-cell>a:not(.mui-btn) {
				padding-right: 15px;
			}
			.mui-card {
				margin: 0;
			}
			.mui-table-view-cell:after {
				left: 0;
			}
			.mui-btn-primary {
				font-size: 0.32rem;
				background: $blueColor;
				border: 0;
				margin: 0;
				padding: 0.2rem 0;
			}
			.gray-line {
				height: 0.2rem;
				background: $bgColor;
			}
		}
	}
</style>