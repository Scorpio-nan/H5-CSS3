<template>
	<div id="GameLong">
		<div class="serch-input">
			<button class="btn mui-btn game-type mui-btn-mini"><i class="fontIcon"></i>
				{{gameType}}
			</button>
		</div>
		<div class="mui-input-group">
			<ul>
				<li>彩种</li>
				<li>期数</li>
			</ul>
		</div>
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<div class="gameList-container">
					<ul v-for="item in LongListData">
						<li>{{item.PARA_NAME}} - {{item.RESULT1}}</li>
						<li>{{item.CN}}</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import lotteryApi from '../../../api/lotteryUtil';
	export default {
		components: {},
		data() {
			return {
				isNotData: false,
				isDataLoading: false,
				gameValue: '',
				gameType: '',
				GameList: [], //游戏类型集合
				LongListData: [],
			}
		},
		mounted() {
			const that = this;
			that.init();
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				mui('.serch-input').on('tap', '.game-type', function() {
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.GameList);
					CardPiker.show(function(items) {
						that.gameValue = items[0]['value'];
						that.gameType = items[0]['text'];
						that.init();
					});
				})
			})
		},
		created() {
			const that = this;
			this.gameType = this.$route.query.name;
			this.gameValue = this.$route.query.id;
		},
		methods: {
			//获取彩票下拉框列表
			init() {
				var that = this;
				lotteryApi.GetGameLevelCode(function(data) {
					for(var i = 0; i < data.length; i++) {
						if(data[i].id != 2) {
							var __obj = {
								value: data[i].id,
								text: data[i].text.replace(/\s+/, ''),
							}
							that.GameList.push(__obj);
						}
					}
				});
				that.getLongList();
			},

			//两面长龙列表
			getLongList() {
				var that = this;
				setTimeout(() => {
					lotteryApi.GetLotClongCN(function(itemList) {
						if(itemList.length == 0) {
							that.isNotData = true;
						} else {
							that.isDataLoading = false;
							that.LongListData = itemList;
						}
					}, that.gameValue);
				}, 100)
			}
		},
		watch: {
			gameValue(val) {
				this.$store.dispatch('getgameid', val);
			},
		},
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	#GameLong {
		height: 100%;
		width: 100%;
		display: flex;
		flex-direction: column;
	}
	
	.mui-btn,
	button,
	input[type=button],
	input[type=reset],
	input[type=submit] {
		border: 0 none;
		padding: 0rem 1rem;
		line-height: inherit;
	}
	
	.mui-input-group {
		height: 0.95rem;
		ul {
			font-size: 0.28rem;
			color: #666;
			overflow: hidden;
			display: table;
			width: 100%;
			height: 100%;
			li {
				vertical-align: middle;
				display: table-cell;
				text-align: center;
				border-left: 0.02rem solid $bgColor;
			}
		}
	}
	
	.mui-scroll-wrapper {
		flex: 1;
		position: relative;
	}
	
	.gameList-container {
		flex: 1;
		position: relative;
		ul {
			background-color: #FFFFFF;
			color: #666666;
			overflow: hidden;
			margin: 0.02rem 0rem;
			li {
				font-size: 0.24rem;
				float: left;
				border-left: 0.02rem solid $bgColor;
				padding: 0.15rem 0;
			}
			li:nth-child(1) {
				width: 50%;
			}
			li:nth-child(2) {
				width: 50%;
			}
		}
	}
	
	.serch-input {
		display: flex;
		height: 1.15rem;
		font-size: 0.26rem;
		padding: 0.2rem 0.3rem;
	}
	
	.fontIcon {
		position: absolute;
		border-top: 8px solid transparent;
		border-left: 15px solid #ccc;
		border-bottom: 8px solid transparent;
		left: 0.35rem;
		top: 0.21rem;
	}
</style>