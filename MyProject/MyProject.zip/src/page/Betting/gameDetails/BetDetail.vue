<template>
	<div class="betDetail">
		<div id="slider" class="mui-slider mui-fullscreen">
			<div class="topJ mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
				<div class="mui-scroll navbar">
					<div class="mui-control-item tab0" :class="gameIndex == 0? 'mui-active':''" data-id="0">未结注单</div>
					<div class="mui-control-item tab1" :class="gameIndex == 1? 'mui-active':''" data-id="1">已结注单</div>
				</div>
			</div>
			<div class="mui-input-group top1J">
				<ul class="table-header">
					<li>类型</li>
					<li>期数</li>
					<li>下注内容</li>
					<li>下注/输赢</li>
				</ul>
			</div>
			<div class="scrollerWrap">
				<scroller :on-infinite="infinite" ref="Scroll" :loadingShow="loadingShow" v-if="ListData0">
					<div class="mui-input-group1" >
						<ul class="table-header" v-for="item in ticketRecordListData" :key="item.ID">
							<li>
								{{item.LOTTERY_TICKET_NAME}}
							</li>
							<li>
								{{item.BET_DTT!=null?item.BET_DTT.substr(5,5):''}}
								<br/> {{item.PERIODS_NO}}
							</li>
							<li>
								{{item.BET_RULE}}<br />{{item.BET_NO}}</li>
							<li>
								&yen;{{item.BET_AMT}}/
								<span v-if="item.WIN<0" style="color: red;">&yen;{{item.WIN}}</span>
								<span v-else style="color: green;">&yen;{{item.WIN}}</span><br/>
								<span :style=" item.OK_IND=='1'?'color:#ffcf00':''">{{item.BET_RESULT}}</span>
							</li>
						</ul>
					</div>
				</scroller>
				<scroller :on-infinite="infinite1" ref="Scroll" :loadingShow="loadingShow1" v-if="ListData1">
					<div class="mui-input-group1" >
						<ul class="table-header" v-for="item in ticketRecordListData1" :key="item.ID">
							<li>
								{{item.LOTTERY_TICKET_NAME}}
							</li>
							<li>
								{{item.BET_DTT!=null?item.BET_DTT.substr(5,5):''}}
								<br/> {{item.PERIODS_NO}}
							</li>
							<li>
								{{item.BET_RULE}}<br />{{item.BET_NO}}</li>
							<li>
								&yen;{{item.BET_AMT}}/
								<span v-if="item.WIN<0" style="color: red;">&yen;{{item.WIN}}</span>
								<span v-else style="color: green;">&yen;{{item.WIN}}</span><br/>
								<span :style=" item.OK_IND=='1'?'color:#ffcf00':''">{{item.BET_RESULT}}</span>
							</li>
						</ul>
					</div>
				</scroller>
			</div>
			<div class="btn-box posiBott">
				<button class="mui-btn mui-btn-blue mui-btn-block querybtn">立即查询</button>
			</div>
			<!--条件查询-->
			<ActionSheet :show="ispopupQueryShow" @hide="initSearch">
				<div slot="action" class="tcMark">
					<ul class="mui-table-view mui-table-view-chevron mr-t-8">
						<li class="mui-table-view-cell btn" data-options='{}'>
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">
								<div class="mui-col-xs-5 mui-pull-left standard">
									开始日期
								</div>
								<div class="segmented-Select standard mui-col-xs-7 mui-pull-left">
									<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="standard btn mui-btn mui-btn-block BeginTime mr-r">{{query.startDtt}}</button>
								</div>
							</a>
						</li>
						<li class="mui-table-view-cell btn" data-options='{}'>
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">
								<div class="mui-col-xs-5 mui-pull-left standard">
									结束日期
								</div>
								<div class="segmented-Select mui-col-xs-7 mui-pull-left standard">
									<button data-options='{"type":"date","beginYear":2014,"endYear":2018}' class=" standard btn mui-btn mui-btn-block EndTime mr-r">{{query.endDtt}}</button>
								</div>
							</a>
						</li>
						<li class="mui-table-view-cell btn" data-options='{}'>
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">
								<div class="mui-col-xs-5 mui-pull-left standard">
									下注号码
								</div>
								<div class="segmented-Select mui-col-xs-7 mui-pull-left standard">
									<input type="text" v-model="query.value" class="standard mui-col-xs-7 mui-pull-left" placeholder="请输入下注号码" />
								</div>
							</a>
						</li>
						<li class="mui-table-view-cell btnheight">
							<a href="javascript:;" class="mui-navigate-right mui-text-left list-font">
								<div class="mui-col-xs-5 mui-pull-left standard">
									选择彩种
								</div>
								<div class=" standard mui-col-xs-7 mui-pull-left">
									<button class="standard btn mui-btn game-type  mui-col-xs-7 mui-pull-left">{{gameType}}</button>
								</div>
							</a>
						</li>
					</ul>
					<button type="button" class="ma_b16 mui-btn mui-btn-primary">确认</button>
				</div>
			</ActionSheet>
		</div>
	</div>
</template>

<script>
	import user from '../../../api/userUtil.js';
	import web from '../../../api/webUtil.js'
	import ActionSheet from '@/page/Center/template/ActionSheet'; //下弹出框组件路径
	import Scroller from '@/components/Scroller'; //滚动组件的路
	export default {
		components: {
			ActionSheet, //下弹出框的组件
			Scroller //下拉刷新的组件
		},
		data() {
			return {
				isClick: true,
				loadingShow: true,
				loadingShow1: true,
				ListData1: false,
				ListData0: true,
				gameIndex: 0, //游戏默认索引[0: 已结注单  1: 未结注单]
				beginTime: '2018-03-07',
				endTime: '2018-03-07',
				ispopupQueryShow: false,
				gameTypeResults: [],
				ticketRecordListData: [], //彩票数组集合
				ticketRecordListData1: [], //彩票数组集合
				GameList: [], //游戏类型集合
				gameType: '重庆时时彩',
				query: { //默認查詢條件
					startDtt: "",
					endDtt: "",
					value: "",
					gameTypeId: "", //this.$route.query.id
				},
				lotteryPage: { //未结注单分页參數
					total: 0, //总页数
					page: 1, //当前页数
					rows: 11, //每页显示记录数
					records: 0, //总记录数
					isDataLoading: false, //加载时显示
					isNotData: false, //无数据时显示 
				},
				isData: false, //无数据时显示
				notBetStat: {
					pullupStatus: 'default'
				},
				lotteryStat: {
					pullupStatus: 'default'
				},
				notBetPage: { //已结注单分页參數
					total: 0, //总页数
					page: 1, //当前页数
					rows: 11, //每页显示记录数
					records: 0, //总记录数
					isDataLoading: false, //加载时显示
					isNotData: false, //无数据时显示
					pullupStatus: 'default'
				},
			}
		},

		mounted() {
			const that = this;
			that.loadingDatanotBet();
			mui.init();

			this.query.startDtt = new Date().Format('yyyy-MM-dd 00:00');
			this.query.endDtt = new Date().Format('yyyy-MM-dd 23:59');
			mui.ready(function() {
				mui('.segmented-Select').on('tap', '.BeginTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.query.startDtt = res['text'];
						})
					}
				})
				mui('.tcMark').on('tap', '.ma_b16', function() {
					that.querySubmit();
					that.initSearch();
				});
				mui('.segmented-Select').on('tap', '.EndTime', function() {
					const self = $(this);
					if(self.picker) {
						self.piker.show(function(res) {})
					} else {
						var optionJson = self.data('options') || '{}';
						self.piker = new mui.DtPicker(optionJson);
						self.piker.show(function(res) {
							self.picker = null;
							that.query.endDtt = res['text'];
						})
					}
				})

				mui('.mui-scroll-wrapper').scroll({
					bounce: true,
					indicators: true,
					deceleration: mui.os.ios ? 0.003 : 0.0009
				});
				mui('.mui-scroll').on('tap', '.tab1', function() {
					var gameIndex = $(this).data('id');
					that.isClick = true;
					that.ListData1 = true;
					that.ListData0 = false;
					that.gameIndex = gameIndex;
					that.loadingDataLottery();
				});
				mui('.mui-scroll').on('tap', '.tab0', function() {
					that.isClick = true;
					that.ListData1 = false;
					that.ListData0 = true;
					var gameIndex = $(this).data('id');
					that.gameIndex = gameIndex;
					that.loadingDatanotBet();
				});
				mui('.posiBott').on('tap', '.querybtn', function() {
					that.initSearch();
				});
				mui('.mui-text-left').on('tap', '.game-type', function() {
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.GameList);
					CardPiker.show(function(items) {
						that.gameType = items[0]['text'];
						for(var i = 0; i < that.gameTypeResults.length; i++) {
							if(that.gameType == that.gameTypeResults[i].title) {
								that.query.gameTypeId = that.gameTypeResults[i].gameId;
							}
						}
					});
				})
			})
			$('.scrollerWrap').css('height', parseInt($('.scrollerWrap').css('height')) - parseInt($('.btn-box').outerHeight(true)) - parseInt($('.top1J').outerHeight(true)) - parseInt($('.topJ').outerHeight(true))-20)
		},

		methods: {
			querySubmit() {
				var this_ = this;
				switch(this_.gameIndex) {
					case 0:
						this_.isClick = true;
						this_.notBetPage.page = 1;
						this_.notBetPage.isNotData = false;
						this_.notBetPage.isDataLoading = true;
						this_.lotteryPage.isNotData = false;
						this_.loadingDatanotBet();
						break;
					case 1:
						this_.isClick = true;
						this_.lotteryPage.page = 1;
						this_.lotteryStat.isDataLoading = true;
						this_.lotteryPage.isNotData = false;
						this_.loadingDataLottery();
						break;
				}
			},
			infinite(finish) {
				const that = this;
				if(that.notBetPage.isNotData) {
					setTimeout(() => {
						that.loadingShow = false;
						finish(true);
					}, 1500)
					return;
				}
				setTimeout(() => {
					that.isClick = false;
					that.notBetPage.page++;
					that.loadingDatanotBet();
					setTimeout(() => {
						finish();
					})
				}, 1500)
			},
			infinite1(finish) {
				const that = this;
				if(that.lotteryPage.isNotData) {
					setTimeout(() => {
						that.loadingShow1 = false;
						finish(true);
					}, 1500)
					return;
				}
				setTimeout(() => {
					that.isClick = false;
					that.lotteryPage.page++;
					that.loadingDataLottery();
					setTimeout(() => {
						finish();
					})
				}, 1500)
			},
			/*未结注单*/
			loadingDatanotBet() {
				var this_ = this;
				var typePage = 1;
				if(this_.isClick) {
					this_.ticketRecordListData = [];
					this_.notBetPage.isNotData = false;
					typePage = 1;
				} else {
					typePage = this_.notBetPage.page;
				}
				if(this_.notBetPage.isNotData) {
					this_.notBetStat.pullupStatus = 'disable'
					return
				}
				var queryJson = this_.makeQueryJson(this_.query.gameTypeId, this_.query.value)
				var postData = {
					b_no: queryJson.bet_no,
					sys_id: queryJson.type_id,
					ok_ind: queryJson.ok_ind,
					rows: this_.notBetPage.rows,
					page: typePage,
					sidx: 'a.ID',
					sord: 'DESC'
				};
				setTimeout(() => {
					/*请求注单明细*/
					user.GetLotterList(postData, function(data) {
						var ticketRecord_ = eval('(' + data + ')');
						//无数据
						if(ticketRecord_.rows.length == 0) {
							this_.notBetPage.isNotData = true
						} else {
							this_.notBetPage.isNotData = false
						}
						//加载数据
						for(var i = 0; i < ticketRecord_.rows.length; i++) {
							this_.ticketRecordListData.push(ticketRecord_.rows[i])
						}
						this_.notBetPage.page++;
						setTimeout(() => {
							this_.notBetStat.pullupStatus = 'default'
							this_.notBetPage.isDataLoading = false;
						}, 100)
					});
				}, 100)

			},
			/*已结注单*/
			loadingDataLottery() {
				var this_ = this;
				var typePage = 1;
				if(this_.isClick) {
					this_.ticketRecordListData1 = [];
					this_.lotteryPage.isNotData = false;
					typePage = 1;
				} else {
					typePage = this_.lotteryPage.page
				}
				if(this_.lotteryPage.isNotData) {
					this_.lotteryStat.pullupStatus = 'disable'
					return
				}
				var queryJson = this_.makeQueryJson(this_.query.gameTypeId, this_.query.value, this_.query.startDtt, this_.query.endDtt)
				var postData = {
					b_no: queryJson.bet_no,
					star_time: queryJson.starttime,
					end_time: queryJson.endtime,
					sys_id: queryJson.type_id,
					ok_ind: queryJson.ok_ind,
					rows: this_.lotteryPage.rows,
					page: typePage,
					sidx: 'a.ID',
					sord: 'DESC'
				};
				setTimeout(() => {
					/*请求注单明细*/
					user.GetLotterList(postData, function(data) {
						var ticketRecord_ = eval('(' + data + ')');
						//无数据
						if(ticketRecord_.rows.length == 0) {
							this_.lotteryPage.isNotData = true
						} else {
							this_.lotteryPage.isNotData = false
						}
						//加载数据
						for(var i = 0; i < ticketRecord_.rows.length; i++) {
							if(this_.gameIndex == 1) {
								ticketRecord_.rows[i].OK_IND != 0;
								this_.ticketRecordListData1.push(ticketRecord_.rows[i]);
							}
						}
						this_.lotteryPage.page++;
						setTimeout(() => {
							this_.lotteryStat.pullupStatus = 'default'
							this_.lotteryPage.isDataLoading = false;
						}, 100)
					});
				}, 100)
			},
			makeQueryJson(gameTypeId, value, start, end) {
				var this_ = this;
				if(start && end) {
					start += ':00';
					end += ':59';
				};
				var queryJson = {};
				if(this_.gameIndex == 0) {
					queryJson = {
						bet_no: value,
						ok_ind: 0,
						type_id: gameTypeId,
					};
				} else {
					queryJson = {
						bet_no: value,
						ok_ind: "1,2",
						type_id: gameTypeId,
						starttime: start,
						endtime: end
					};
				}
				return queryJson
			},
			initSearch() {
				this.ispopupQueryShow = !this.ispopupQueryShow;
			},

			getLotGameType() {
				var this_ = this;
				this_.gameTypeResults = [];
				web.GetGameClassBig(2, function(data) {
					var list1 = eval('(' + data + ')')
					for(var i = 0; i < list1.length; i++) {
						var obj = {
							value: 'zz',
							text: list1[i].PARA_NAME
						};
						this_.GameList.push(obj);
						this_.gameTypeResults.push({
							title: list1[i].PARA_NAME,
							gameId: list1[i].ID,
							gameCd: list1[i].CODE,
						})
					}
				});
				this_.GameList.push({
					value: 'zz',
					text: "香港六合彩"
				});
				this_.gameTypeResults.push({
					title: "香港六合彩",
					gameId: 27,
					gameCd: "hk6",
				});
			},
		},

		created() {
			const that = this;
			this.getLotGameType();
		},
		computed: {

		},
	}
</script>

<style scoped lang="scss">
	@import "~static/sass/public.scss";
	#betDetail {
		height: 100%;
		width: 100%;
		display: flex;
		flex-direction: column;
	}
	.mui-input-group1 {
		.table-header {
			border-bottom: 0.02rem solid $bgColor;
			background-color: #FFFFFF;
			font-size: 0.28rem;
			color: #666;
			overflow: hidden;
			display: table;
			width: 100%;
			height: 100%;
			li {
				font-size: 0.24rem;
				vertical-align: middle;
				display: table-cell;
				text-align: center;
			}
			li:nth-child(1) {
				width: 25%;
			}
			li:nth-child(2) {
				width: 25%;
			}
			li:nth-child(3) {
				width: 25%;
			}
			li:nth-child(4) {
				width: 25%;
			}
		}
	}
	.scrollerWrap {
		height: 100%;
		position: relative;
	}
	
	.ma_b16 {
		margin-top: .16rem;
		margin-bottom: .36rem;
		width: 95%;
		height: .88rem;
		background-color: #19b4f5;
	}
	
	.standard {
		padding: 0 !important;
		position: inherit !important;
		right: 0;
		border: none;
		height: .5rem;
		font-size: .28rem;
		margin-bottom: 0;
		display: flex;
		display: -webkit-flex;
		align-items: center;
		/*指定垂直居中*/
	}
	
	.posiBott {
		background: #fff;
		position: fixed;
		bottom: 0;
		width: 100%;
	}
	
	.mui-input-group {
		height: 0.95rem;
		.table-header {
			border-bottom: 0.02rem solid $bgColor;
			background-color: #FFFFFF;
			font-size: 0.28rem;
			color: #666;
			overflow: hidden;
			display: table;
			width: 100%;
			height: 100%;
			li {
				font-size: 0.24rem;
				vertical-align: middle;
				display: table-cell;
				text-align: center;
			}
			li:nth-child(1) {
				width: 25%;
			}
			li:nth-child(2) {
				width: 25%;
			}
			li:nth-child(3) {
				width: 25%;
			}
			li:nth-child(4) {
				width: 25%;
			}
		}
	}
	
	.btnheight {
		margin: 0.1rem 0rem;
	}
	
	.mui-btn,
	button,
	input[type=button],
	input[type=reset],
	input[type=submit] {
		border: 0 none;
		padding: 0.12rem 1.86rem;
	}
	
	.mui-slider-indicator.mui-segmented-control {
		padding: 5px 0;
		background: $bgColor;
		.mui-scroll {
			width: 100%;
			top: 0.1rem;
		}
	}
	
	.navbar {
		display: flex;
		background: #fff;
		div {
			flex: 1;
			position: relative;
		}
		.active {
			color: $blueColor;
			&:after {
				display: block;
				content: '';
				height: 1px;
				background: $blueColor;
				width: 45%;
				position: absolute;
				left: 50%;
				bottom: 0;
				-webkit-transform: translate(-50%, -50%);
				transform: translate(-50%, -50%);
			}
		}
	}
	
	.mui-segmented-control.mui-scroll-wrapper {
		height: 50px;
		.mui-control-item {
			width: 50%;
		}
	}
	
	.mui-segmented-control.mui-scroll-wrapper .mui-scroll {
		a {
			position: relative;
		}
		.mui-active {
			color: #158bff;
			&:after {
				display: block;
				content: '';
				height: 1px;
				background: #158bff;
				width: 100%;
				position: absolute;
				left: 0;
				bottom: 0;
			}
		}
	}
	
	.mui-navigate-right:after,
	.mui-push-right:after {
		content: ''
	}
	
	.mui-table-view-cell>a:not(.mui-btn) {
		padding-right: 15px;
	}
	
	.mui-table-view-cell:after,
	.mui-input-group:after {
		left: 0;
		height: 0rem;
	}
	
	.mui-table-view {
		margin: 0.1rem 0.5em;
		border-radius: 0.18rem;
	}
	
	.mui-scroll-wrapper {
		background: $bgColor;
	}
	
	.btn-box {
		padding: 0.24rem;
		.querybtn {
			margin: 0;
			padding: 0.2rem 0;
			background: #19b4f5;
			border: 0 none;
			&:active {
				background: rgba(#19b4f5, 0.6);
			}
		}
	}
	
	.timer {
		top: 6rem;
		a {
			padding: 0 0 0 15px;
		}
		.mui-btn-primary {
			width: 95%;
			height: 0.88rem;
			margin: 0.3rem 0.2rem;
		}
		.segmented-Select {
			display: inline-block;
			button {
				font-size: 0.24rem;
				padding: 0.2rem 2rem;
				border: none;
				margin: 0;
			}
		}
	}
</style>