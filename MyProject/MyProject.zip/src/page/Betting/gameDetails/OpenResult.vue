<template>
	<div id="GameLong">
		<div class="serch-input">
			<button class="btn mui-btn game-type mui-btn-mini mui-ellipsis"><i class="fontIcon"></i>
				{{gameType}}
			</button>
			<button v-if="lotteryID != 27 " data-options='{"type":"date","beginYear":2014,"endYear":2018}' class="btn mui-btn mui-btn-mini btntime mui-ellipsis">
				<i class="fontIcon"></i>{{DateSelected}}</button>
		</div>
		<div class="mui-input-group">
			<ul>
				<li>期数</li>
				<li>开奖号码</li>
			</ul>
		</div>
		<div class="mui-scroll-wrapper">
			<div class="gameList-container">
				<ul v-for="item in LotHistoryList">
					<li>{{item.PERIODS_NO}} </br>
						<div>
							<span class="foncolor" v-if="lotteryID != 27 ">{{item.START_TT}}</span>
							<span class="foncolor" v-if="lotteryID == 27 ">{{item.OK_DTT!=null?item.OK_DTT.substr(5,15):item.OK_DTT}}</span>
						</div>
					</li>
					<li>
						<div class="row-ballOpen">
							<div class="flex-content">
								<span v-for="item in item.OPEN_CODE.split(',')" v-if="lotteryID == 18||lotteryID == 19||lotteryID == 1055" :class="'ball-round'+' pk_' + fristOpenCode[parseInt(item)]">{{parseInt(item)}}</span>
								<span v-for="item in item.OPEN_CODE.split(',')" v-if="lotteryID != 1707 && lotteryID != 1709 && lotteryID != 1143 && lotteryID != 1706 &&  lotteryID != 1141 && lotteryID != 1708 
									&& lotteryID != 1145 && lotteryID != 856 && lotteryID != 1713 && lotteryID != 1712 && lotteryID != 1711 && lotteryID != 18 && lotteryID != 27 && lotteryID != 1827  && lotteryID != 1055&& lotteryID != 19" :class="'ball-round  ssc_ball' +' ssc_' + fristOpenCode[parseInt(item)]">
								    {{parseInt(item)}}</span>
								<span v-for="(item,ke) in item.OPEN_CODE.split(',')" v-if="lotteryID == 1707 || lotteryID ==1709 || lotteryID == 1706 
									|| lotteryID == 1141 || lotteryID == 1143 || lotteryID == 1708 || lotteryID == 1145 ||lotteryID == 856 || lotteryID == 1713 ||lotteryID == 1712 || lotteryID == 1711" :class="'kuaisan-ball kuaisan'+parseInt(item)" class="flex-content">&nbsp;</span>
								<span v-for="item in item.OPEN_CODE.split(',')" v-if="lotteryID == 27 || lotteryID == 1827" :class="'ball ball-color-'+numColors[parseInt(item)]">{{parseInt(item)}}</span>
							</div>

							<div class="flex-content" v-if="lotteryID == 18||lotteryID == 1055 ||lotteryID == 19 ">
								<span v-for="item in item.G" class="resultData-width"> {{item}}</span>
								<span v-for="item in item.I" class="resultData-width"> {{item.substr(item.length-1,1)}}</span>
							</div>

							<div class="flex-content" v-else-if="lotteryID == 21 ">
								<span class="resultData-width">{{item.total}}</span>
								<span v-for="item in item.A" class="resultData-width"> {{item}}</span>
							</div>

							<div class="flex-content" v-else-if="lotteryID == 27 || lotteryID == 1827">
								<span class="resultData-width" v-for="item in item.JSON_RESULT[0].split(',')"> {{item}}</span>
							</div>

							<div class="flex-content" v-else>
								<span class="resultData-width">{{item.total}}</span>
								<span v-for="item in item.A" class="resultData-width"> {{item}}</span>
							</div>
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
</template>

<script>
	import lotteryApi from '../../../api/lotteryUtil';
	import Scroller from '@/components/Scroller';
	export default {
		components: {
			Scroller
		},
		data() {
			return {
				fristOpenCode: {}, //第一行的开奖结果
				list: 10,
				hide: false,
				gameType: '重庆时时彩',
				lotteryID: '-', //选中的游戏类型ID
				GameList: [], //游戏类型集合
				LotHistoryList: [], //开奖结果数据
				dateArray: [], //日期下拉框
				DateSelected: '', //选中的日期：默认当天
				total: 0, //总页数
				page: 1, //当前页数
				records: 0, //总记录数
				pagesize: 20,
				numColors: {},
			}
		},
		mounted() {
			const that = this;
			that.LotteryResult();
			//新增球的颜色数组 --加入缓存
			if(window.localStorage.getItem('numColors') != null) {
				var data = eval('(' + window.localStorage.getItem('numColors') + ')');
				that.numColors = data;
			} else {
				lotteryApi.hk6Color(function(itemList) {
					that.numColors = itemList;
					window.localStorage.setItem('numColors', JSON.stringify(itemList));
				});
			}
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005
				});
				mui('.serch-input').on('tap', '.game-type', function() {
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.GameList);
					CardPiker.show(function(items) {
						that.lotteryID = items[0]['value'];
						that.gameType = items[0]['text'];
						that.LotteryResult(true);
					});
				})
				mui('.serch-input').on('tap', '.btntime', function() {
					const CardPiker = new mui.PopPicker();
					CardPiker.setData(that.dateArray);
					CardPiker.show(function(items) {
						that.DateSelected = items[0].text;
					});
				})
			})
		},
		created() {
			const that = this;
			this.gameType = this.$route.query.name;
			this.lotteryID = this.$route.query.id;
			that.ininLotteryMenu();
			var toDayDate = new Date(); //获取最近五天日期下拉框
			that.dateArray = [];
			this.isOnload = true;
			var dateTemp;
			for(var i = 0; i < 5; i++) {
				var month = toDayDate.getMonth() + 1;
				var strDate = toDayDate.getDate();
				if(month >= 1 && month <= 9) {
					month = "0" + month;
				}
				if(strDate >= 0 && strDate <= 9) {
					strDate = "0" + strDate;
				}
				dateTemp = toDayDate.getFullYear() + "-" + month + "-" + strDate;
				var __obj = {
					value: dateTemp,
					text: dateTemp,
				}
				that.dateArray.push(__obj);
				toDayDate.setDate(toDayDate.getDate() - 1);
				that.DateSelected = that.dateArray[0].text;
			}
			setTimeout(function() {
				that.LotteryResult(true);
			}, 500)
		},
		methods: {
			ininLotteryMenu() {
				var that = this;
				if(window.localStorage.getItem('opentime_LotList') != null) {
					var data = JSON.parse(localStorage.getItem('opentime_LotList'));
					that.GameList = data;
				} else {
					lotteryApi.GetGameLevelCode(function(data) {
						that.GameList = [];
						for(var i = 0; i < data.length; i++) {
							if(data[i].id == 2) {
								var __obj = {
									value: '27',
									text: "香港六合彩",
								}
							} else {
								var __obj = {
									value: data[i].id,
									text: data[i].text.trim(),
								}
							}
							that.GameList.push(__obj);
						}
						window.localStorage.setItem('opentime_LotList', JSON.stringify(that.GameList));
					});
				}
			},
			LotteryResult(state) {
				var that = this;
				if(!state) return;
				that.queryState = true;
				var __rpt_date = that.DateSelected;
				var postData = {
					game_id: that.lotteryID,
					rpt_date: __rpt_date,
					top: 100,
				};
				var postDatahk = {
					rows: that.pagesize,
					page: that.page,
					sord: "Desc",
					sidx: "ID"
				};
				if(that.lotteryID == 27) {
					lotteryApi.Hk6openresult(function(itemList) {
						for(var index in itemList.rows) {
							var __obj = eval('(' + itemList.rows[index].JSON_RESULT + ')');
							itemList.rows[index].JSON_RESULT = __obj['hk6'];
						}
						that.LotHistoryList = itemList.rows;
						that.total = itemList.total;
						that.page = itemList.page;
						that.records = itemList.records;
					}, postDatahk);
				} else if(that.lotteryID == 1827) {
					lotteryApi.GetWinResult(function(itemList) {
						for(var index in itemList) {
							var __obj = eval('(' + itemList[index].JSON_RESULT + ')');
							itemList[index].JSON_RESULT = __obj['jisuhk6'];
						}
						that.LotHistoryList = itemList;
					}, postData);
				} else {
					lotteryApi.GetWinResult(function(itemList) {
						for(var index in itemList) {
							//记录第一行的数据  设置颜色
							if(index == 0) {
								that.fristOpenCode = [];
								var fristCode = itemList[index].OPEN_CODE.split(',');
								for(var i = 0; i < fristCode.length; i++) {

									that.fristOpenCode[parseInt(fristCode[i])] = new Array();
									that.fristOpenCode[parseInt(fristCode[i])] = parseInt(fristCode[i])
								}
							}
							var __obj = eval('(' + itemList[index].JSON_RESULT + ')');
							var opennum = itemList[index].OPEN_CODE.split(',');
							var opensum = 0; //总和
							for(var i = 0; i < opennum.length; i++) {
								opensum = opensum + parseFloat(opennum[i]);
							}
							itemList[index].total = opensum;
							if(that.lotteryID == 18 || that.lotteryID == 1055 || that.lotteryID == 19) {
								//pk10-18
								itemList[index].G = __obj['冠亚和'];
								itemList[index].H = __obj['冠亚季和'];
								itemList[index].I = __obj['龙虎'];
							} else if(that.lotteryID == 21) {
								//pk10-18
								itemList[index].A = __obj['总和-龙虎'];
							} else {
								itemList[index].A = __obj['总和-龙虎'];
							}
						}
						that.LotHistoryList = itemList;
					}, postData);
				}
			},
		},
		watch: {
			lotteryID(val) {
				this.$store.dispatch('getgameid', val);
			},
		},
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	#GameLong {
		height: 100%;
		width: 100%;
		display: flex;
		flex-direction: column;
	}
	
	.mui-btn,
	button,
	input[type=button],
	input[type=reset],
	input[type=submit] {
		border: 0 none;
		line-height: inherit;
		flex: 1;
	}
	
	.btntime {
		margin-left: 0.2rem;
	}
	
	.mui-input-group {
		height: 0.95rem;
		ul {
			font-size: 0.28rem;
			color: #666;
			overflow: hidden;
			display: table;
			width: 100%;
			height: 100%;
			li {
				vertical-align: middle;
				display: table-cell;
				text-align: center;
				border-left: 0.02rem solid $bgColor;
			}
		}
	}
	
	.mui-scroll-wrapper {
		flex: 1;
		position: relative;
	}
	
	.foncolor {
		color: #999999;
	}
	
	.gameList-container {
		flex: 1;
		position: relative;
		ul {
			background-color: #FFFFFF;
			color: #666666;
			overflow: hidden;
			margin: 0.02rem 0rem;
			li {
				font-size: 0.24rem;
				float: left;
				border-left: 0.02rem solid $bgColor;
			}
			li:nth-child(1) {
				width: 33.7%;
				padding-top: 0.15rem;
			}
			li:nth-child(2) {
				width: 66.3%;
			}
		}
	}
	
	.serch-input {
		display: flex;
		height: 1.15rem;
		font-size: 0.26rem;
		padding: 0.2rem 0.3rem;
	}
	
	.fontIcon {
		position: absolute;
		border-top: 8px solid transparent;
		border-left: 15px solid #ccc;
		border-bottom: 8px solid transparent;
		left: 0.35rem;
		top: 0.21rem;
	}
	
	.ball-round {
		margin-bottom: 0px;
		margin-right: 6px;
		width: 22px;
		height: 22px;
		margin-right: 2px;
		color: #ffffff;
		display: inline-block;
		text-align: center;
		font-weight: normal;
	}
	
	.resultData-width {
		font-size: 0.28rem;
		color: rgba(0, 0, 0, 0.7);
		background: rgba(255, 255, 255, 0.3);
		border: 0.02rem solid rgba(255, 255, 255, 0.6);
	}
	
	.flex-content {
		margin-top: 0.1rem;
		text-align: center;
		font-size: 0.26rem;
		border-radius: 0.08rem;
		background-clip: padding-box;
		font-weight: 500;
	}
	
	.pk_1 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #d5d220;
		background: #d5d220;
	}
	
	.pk_2 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #008bf9;
		background: #008bf9;
	}
	
	.pk_3 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #4c4d51;
		background: #4c4d51;
	}
	
	.pk_4 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #f47a00;
		background: #f47a00;
	}
	
	.pk_5 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #8ff9f9;
		background: #8ff9f9;
	}
	
	.pk_6 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #4a14fe;
		background: #4a14fe;
	}
	
	.pk_7 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #afafaf;
		background: #afafaf;
	}
	
	.pk_8 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #ff0400;
		background: #ff0400;
	}
	
	.pk_9 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #770100;
		background: #770100;
	}
	
	.pk_10 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #2bc610;
		background: #2bc610;
	}
	
	.pk_11 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #d5d220;
		background: #d5d220;
	}
	
	.pk_12 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #008bf9;
		background: #008bf9;
	}
	
	.pk_13 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #4c4d51;
		background: #4c4d51;
	}
	
	.pk_14 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #f47a00;
		background: #f47a00;
	}
	
	.pk_15 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #8ff9f9;
		background: #8ff9f9;
	}
	
	.pk_16 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #4a14fe;
		background: #4a14fe;
	}
	
	.pk_17 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #afafaf;
		background: #afafaf;
	}
	
	.pk_18 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #ff0400;
		background: #ff0400;
	}
	
	.pk_19 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #770100;
		background: #770100;
	}
	
	.ssc_ball {
		display: inline-block;
		width: 0.50rem;
		height: 0.50rem;
		border: 1px solid #ccc;
		line-height: 0.50rem;
		border-radius: 50%;
		color: #ff1a18;
		font-size: 0.28rem;
	}
	
	.ssc_0 {
		color: #000;
		box-shadow: inset 1px -6px 10px #878503;
		background: #FFFB08;
	}
	
	.ssc_1 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #045391;
		background: #008BF9;
	}
	
	.ssc_2 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #039138;
		background: #25EE71;
	}
	
	.ssc_3 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #944C05;
		background: #F47A00;
	}
	
	.ssc_4 {
		color: #FF0400;
		box-shadow: inset 1px -6px 10px #078282;
		background: #8FF9F9;
	}
	
	.ssc_5 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #260596;
		background: #6A40F5;
	}
	
	.ssc_6 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #99003D;
		background: #FB629F;
	}
	
	.ssc_7 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #970604;
		background: #FF0400;
	}
	
	.ssc_8 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #5E0404;
		background: #B32B2A;
	}
	
	.ssc_9 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #116103;
		background: #2BC610;
	}
	
	.ssc_10 {
		color: #000;
		box-shadow: inset 1px -6px 10px #878503;
		background: #FFFB08;
	}
	
	.ssc_11 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #045391;
		background: #008BF9;
	}
	
	.ssc_12 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #0C0C0D;
		background: #4C4D51;
	}
	
	.ssc_13 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #944C05;
		background: #F47A00;
	}
	
	.ssc_14 {
		color: #0E5353;
		box-shadow: inset 1px -6px 10px #078282;
		background: #8FF9F9;
	}
	
	.ssc_15 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #235FF8;
		background: #79CAF9;
	}
	
	.ssc_16 {
		color: #4C4848;
		box-shadow: inset 1px -6px 10px #F0A4A4;
		background: #F2DEDE;
	}
	
	.ssc_17 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #970604;
		background: #FF0400;
	}
	
	.ssc_18 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #5E0404;
		background: #892524;
	}
	
	.ssc_19 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #116103;
		background: #2BC610;
	}
	
	.ssc_20 {
		color: #fff;
		box-shadow: inset 1px -6px 10px #d5d220;
		background: #d5d220;
	}
	
	.row-ballOpen {
		position: relative;
		background: rgba(255, 255, 255, .02);
		text-shadow: 0 1px 0 rgba(255, 255, 255, .23);
		font-weight: bold;
		color: rgba(0, 0, 0, .8);
		box-shadow: inset -1px 1px 0 0 rgba(255, 255, 255, .2), 1px 1px 0 0 rgba(0, 0, 0, .1);
	}
	
	.kuaisan-ball {
		color: #000;
		width: 27px;
		height: 27px;
		background-size: 90%;
		text-align: center;
		font-size: 20px;
		line-height: 30px;
	}
	
	.kuaisan1 {
		background-image: url(../../../../static/img/public/k3/1.png);
		background-repeat: no-repeat;
		display: inline-block;
	}
	
	.kuaisan2 {
		background-image: url(../../../../static/img/public/k3/2.png);
		background-repeat: no-repeat;
		display: inline-block;
	}
	
	.kuaisan3 {
		background-image: url(../../../../static/img/public/k3/3.png);
		background-repeat: no-repeat;
		display: inline-block;
	}
	
	.kuaisan4 {
		background-image: url(../../../../static/img/public/k3/4.png);
		background-repeat: no-repeat;
		display: inline-block;
	}
	
	.kuaisan5 {
		background-image: url(../../../../static/img/public/k3/5.png);
		background-repeat: no-repeat;
		display: inline-block;
	}
	
	.kuaisan6 {
		background-image: url(../../../../static/img/public/k3/6.png);
		background-repeat: no-repeat;
		display: inline-block;
	}
	
	.ball {
		display: inline-block;
		width: 0.5rem;
		height: 0.5rem;
		border: 1px solid #ccc;
		line-height: 0.5rem;
		border-radius: 50%;
		color: #ff1a18;
		font-size: 0.26rem;
		margin: 0.05rem;
	}
	
	.ball-color-red {
		background: #e52f33;
		border-color: #e52f33;
		color: #fff;
	}
	
	.ball-color-green {
		background: #4cbe00;
		border-color: #4cbe00;
		color: #fff;
	}
	
	.ball-color-blue {
		background: #2f84e5;
		border-color: #2f84e5;
		color: #fff;
	}
</style>