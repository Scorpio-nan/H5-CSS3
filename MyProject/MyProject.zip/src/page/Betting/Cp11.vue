<template>
	<div id="HK6">
		<div class="nav">
			<div id="mui-slide" class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
				<div class="mui-scroll">
					<a class="scroll-item handlenav" :class="navActive == i? 'nav-active':''" :data-navactive="i" href="javascript:;" v-for="(item,i) in navArr">
						{{item}}
					</a>
				</div>
			</div>
			<a href="javascript:;" class="handlelist slidetag">
				<!--<span class="more">更多</span>--><span class="iconfont icon-xiangxia1 transferdown" :class="slideDown ? 'handleUp':'handleDown'"></span>
			</a>
			<div class="nav-down-list">
				<div class="down-item-container" v-for="(item,i) in navArr">
					<a class="scroll-item down-item" :class="navActive == i? 'nav-active':''" :data-navactive="i" href="javascript:;">
						<span class="whithimport">{{item}}</span>
					</a>
				</div>
			</div>
		</div>
		<div class="main">
			<!-- 快捷  -->
			<transition :name="animate">
				<div class="shortcut" v-show="navActive == 0">
					<div class="navigation">
						<Scroller>
							<ul class="nav-warpper">
								<li class="nav-item" :data-name="item" :class="i == 0? 'select':''" v-for="(item,i) in Rank">
									<a href="javascript:;">{{item}}</a>
								</li>
							</ul>
						</Scroller>
					</div>
					<div class="select-ball-warpper">
						<div class="mui-scroll-wrapper" id="shortCon">
							<div class="mui-scroll">
								<div class=" padding-box">
									<a href="javascript:;" class="ball-warpper mr-b" v-for="(item,i) in initData[queryCode+'0']" v-if="item.SHOWCLS != 'text'" :data-object="JSON.stringify(item)">
										<span class="ball">{{item.NUM}}</span>
										<span class="ball-odds ball_code">{{item.ODDS}}</span>
									</a>
									<div class="mui-clearfix">
										<a href="javascript:;" class="ball-warpper border-box1 kuaijie" v-for="(item,i) in initData[queryCode+'0']" v-if="item.SHOWCLS == 'text'" :data-object="JSON.stringify(item)">
											<span class="ball-text">{{item.NUM}}</span>
											<span class="ball-odds">{{item.ODDS}}</span>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</transition>

			<!--两面  后几球-->
			<div class="other-play" v-show="navActive != 0">
				<div class="mui-scroll-wrapper" id="otherSide">
					<div class="mui-scroll">
						<div class="mui-slider" id="mui-slider">
							<div class="mui-slider-group">
								<!--  两面    -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 1">
										<h5 class="mui-h5 play-title mr-t">龙虎</h5>
										<div class=" padding-box four">
											<a href="javascript:;" class="ball-warpper border-box" v-for="(item,i,index) in initData[queryCode+'8']" :data-object="JSON.stringify(item)">
												<span class="ball-text">{{item.NUM_NAME}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>

										<h5 class="mui-h5 play-title mr-t">第一球</h5>
										<div class=" padding-box four">
											<a href="javascript:;" class="ball-warpper border-box" v-for="(item,i,index) in initData[queryCode+'0']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<span class="ball-text">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第二球</h5>
										<div class=" padding-box four">
											<a href="javascript:;" class="ball-warpper border-box" v-for="(item,i,index) in initData[queryCode+'1']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<span class="ball-text">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第三球</h5>
										<div class=" padding-box four">
											<a href="javascript:;" class="ball-warpper border-box" v-for="(item,i,index) in initData[queryCode+'2']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<span class="ball-text">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第四球</h5>
										<div class=" padding-box four">
											<a href="javascript:;" class="ball-warpper border-box" v-for="(item,i,index) in initData[queryCode+'3']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<span class="ball-text">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第五球</h5>
										<div class=" padding-box four">
											<a href="javascript:;" class="ball-warpper border-box" v-for="(item,i,index) in initData[queryCode+'4']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<span class="ball-text">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>

									</div>
								</transition>

								<!--  第一球    -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 2">
										<div class=" padding-box mui-clearfix">
											<a href="javascript:;" class="ball-warpper ball_code mr-b" v-for="(item,i,index) in initData[queryCode+'0']" v-if="item.SHOWCLS != 'text'" :data-object="JSON.stringify(item)">
												<span class="ball">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
										<div class=" padding-box mui-clearfix">
											<a href="javascript:;" class="ball-warpper border-box" v-for="(item,i,index) in initData[queryCode+'0']" v-if="item.SHOWCLS == 'text'" :data-object="JSON.stringify(item)">
												<span class="ball-text">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
									</div>
								</transition>

								<!-- 第二球 -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 3">
										<div class=" padding-box mui-clearfix">
											<a href="javascript:;" class="ball-warpper ball_code" v-for="(item,i,index) in initData[queryCode+'1']" v-if="item.SHOWCLS != 'text'" :data-object="JSON.stringify(item)">
												<span class="ball">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
										<div class=" padding-box mui-clearfix">
											<a href="javascript:;" class="ball-warpper border-box" v-for="(item,i,index) in initData[queryCode+'1']" v-if="item.SHOWCLS == 'text'" :data-object="JSON.stringify(item)">
												<span class="ball-text">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
									</div>
								</transition>

								<!--  第三球  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 4">
										<div class=" padding-box mui-clearfix">
											<a href="javascript:;" class="ball-warpper ball_code" v-for="(item,i,index) in initData[queryCode+'2']" v-if="item.SHOWCLS != 'text'" :data-object="JSON.stringify(item)">
												<span class="ball">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
										<div class=" padding-box mui-clearfix">
											<a href="javascript:;" class="ball-warpper border-box" v-for="(item,i,index) in initData[queryCode+'2']" v-if="item.SHOWCLS == 'text'" :data-object="JSON.stringify(item)">
												<span class="ball-text">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
									</div>
								</transition>

								<!--  第四球  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 5">
										<div class=" padding-box mui-clearfix">
											<a href="javascript:;" class="ball-warpper ball_code" v-for="(item,i,index) in initData[queryCode+'3']" v-if="item.SHOWCLS != 'text'" :data-object="JSON.stringify(item)">
												<span class="ball">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
										<div class=" padding-box mui-clearfix">
											<a href="javascript:;" class="ball-warpper border-box" v-for="(item,i,index) in initData[queryCode+'3']" v-if="item.SHOWCLS == 'text'" :data-object="JSON.stringify(item)">
												<span class="ball-text">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
									</div>
								</transition>

								<!--  第五球  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 6">
										<div class=" padding-box mui-clearfix">
											<a href="javascript:;" class="ball-warpper ball_code" v-for="(item,i,index) in initData[queryCode+'4']" v-if="item.SHOWCLS != 'text'" :data-object="JSON.stringify(item)">
												<span class="ball">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
										<div class=" padding-box mui-clearfix">
											<a href="javascript:;" class="ball-warpper border-box" v-for="(item,i,index) in initData[queryCode+'4']" v-if="item.SHOWCLS == 'text'" :data-object="JSON.stringify(item)">
												<span class="ball-text">{{item.NUM}}</span>
												<span class="ball-odds">{{item.ODDS}}</span>
											</a>
										</div>
									</div>
								</transition>

							</div>
						</div>
					</div>
				</div>

				<!--  直选    -->
				<transition :name="animate">
					<div class="mui-slider-item heightCover" v-show="navActive == 7">
						<div class="leftTab">
							<div class="mui-scroll-wrapper">
								<div class="mui-scroll">
									<ul class="navContainer">
										<li class="handleClickItem" :data-name="item.NUM_NAME" v-for="(item,i,index) in initData[queryCode+'5']" :class="optionIndex == index? 'active':''" :data-index="index">
											<a href="javascript:;">{{item.NUM_NAME}}</a>
											<p>{{item.ODDS}}</p>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="rightContainer">
							<div class="mui-scroll-wrapper">
								<div class="mui-scroll">
									<div class=" padding-box mui-clearfix">
										<a href="javascript:;" class="ball-warpper ball_code mr-b" v-for="(item,i,index) in initData[queryCode+'0']" v-if="item.SHOWCLS != 'text'" :data-index="index">
											<span class="ball">{{item.NUM}}</span>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</transition>

				<!--  组选    -->
				<transition :name="animate">
					<div class="mui-slider-item heightCover" v-show="navActive == 8">
						<div class="leftTab">
							<div class="mui-scroll-wrapper">
								<div class="mui-scroll">
									<ul class="navContainer">
										<li class="handleClickItem" :data-name="item.NUM_NAME" v-for="(item,i,index) in initData[queryCode+'6']" :class="optionIndex == index? 'active':''" :data-index="index">
											<a href="javascript:;">{{item.NUM_NAME}}</a>
											<p>{{item.ODDS}}</p>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="rightContainer">
							<div class="mui-scroll-wrapper">
								<div class="mui-scroll">
									<div class=" padding-box mui-clearfix">
										<a href="javascript:;" class="ball-warpper ball_code mr-b" v-for="(item,i,index) in initData[queryCode+'0']" v-if="item.SHOWCLS != 'text'" :data-index="index">
											<span class="ball">{{item.NUM}}</span>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</transition>

				<!--  任选    -->
				<transition :name="animate">
					<div class="mui-slider-item heightCover" v-show="navActive == 9">
						<div class="leftTab">
							<div class="mui-scroll-wrapper">
								<div class="mui-scroll">
									<ul class="navContainer">
										<li class="handleClickItem" :data-name="item.NUM_NAME" v-for="(item,i,index) in initData[queryCode+'7']" :class="optionIndex == index? 'active':''" :data-index="index">
											<a href="javascript:;">{{item.NUM_NAME}}</a>
											<p>{{item.ODDS}}</p>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="rightContainer">
							<div class="mui-scroll-wrapper">
								<div class="mui-scroll">
									<div class=" padding-box mui-clearfix">
										<a href="javascript:;" class="ball-warpper ball_code mr-b" v-for="(item,i,index) in initData[queryCode+'0']" v-if="item.SHOWCLS != 'text'" :data-index="index">
											<span class="ball">{{item.NUM}}</span>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</transition>

			</div>
		</div>
		<div class="footer">
			<BFooter @handleBet="HandleBet" @handleDelete="deleteSelected" :Value="Value" :Count='betLenght'></BFooter>
		</div>
	</div>
</template>

<script>
	import Scroller from "@/components/Scroller";
	import BFooter from "./template/Footer";
	import api from "../../api/lotteryUtil.js";
	export default {
		name: "cp11",
		components: {
			Scroller,
			BFooter
		},
		data() {
			return {
				Value: 0,
				queryCode: "",
				swipeBack: false,
				navActive: 0,
				navArr: [
					"快捷",
					"两面",
					"第一球",
					"第二球",
					"第三球",
					"第四球",
					"第五球",
					"直选",
					"组选",
					"任选"
				],
				initData: {}, //初始化数据
				betArr: [], //投注数组
				betValue: "", //投注金额
				betSum: 0, //总共下注
				winSum: 0, //可赢
				betLenght: 0, //当前选中多少注
				resetBtn: false, //输入框reset
				tempIndex: 0, //暂时记录上一个index值
				animate: "slide-in", //默认动画
				slideDown: false, //导航页签
				Rank: ["第一球", "第二球", "第三球", "第四球", "第五球"], //快捷选项左边栏目
				optionIndex: 0,
				optionName: '前二',
				tempArr: [], //临时数组
				zhixuan: {}, //直选参数
				zuxuan: {}, //组选参数
				renxuan: {}, //任选参数
			};
		},
		mounted() {
			const that = this;
			mui.init({
				swipeBack: this.swipeBack
			});

			mui(".mui-scroll-wrapper").scroll({
				deceleration: 0.0005
			});

			mui.ready(function() {
				//tab导航点击滚到第几球
				mui(".nav").on("tap", ".handlenav", function() {
					var active = $(this).data("navactive");
					that.navActive = active;
					that.handleTabChange();
					if(active == 7 || active == 8) {
						that.optionName = '前二';
					} else if(active == 9) {
						that.optionName = '一中一';
					}
					console.log(active)
				});

				//下拉菜单点击事件
				mui(".nav").on("tap", ".down-item", function() {
					var active = $(this).data("navactive");
					that.navActive = active;
					that.handleTabChange();
					mui("#mui-slide")
						.scroll()
						.scrollTo(-($(this).width() * active), 0, 0);
					that.slideDown = !that.slideDown;
				});

				//tab导航右上角icon
				mui(".nav").on("tap", ".handlelist", function() {
					if(that.slideDown) {
						$(".nav-down-list").slideUp(150);
					} else {
						$(".nav-down-list").slideDown(150);
					}
					that.slideDown = !that.slideDown;
				});

				//左侧快捷选球功能
				mui(".nav-warpper").on("tap", ".nav-item", function() {
					var isSelect = $(this).hasClass("select");
					if(isSelect) {
						$(this).removeClass("select");
					} else {
						$(this).addClass("select");
					}
					if($(".Selected").length > 0) {
						if($(".nav-item.select").length > 0) {
							that.betLenght =
								$(".Selected").length * $(".nav-item.select").length;
							that.betSum =
								$(".Selected").length *
								that.betValue *
								$(".nav-item.select").length;
						} else {
							that.betLenght = $(".Selected").length;
							that.betSum = $(".Selected").length * that.betValue;
						}
					}
				});

				//点击选中和不选中球
				mui(".main").on("tap", ".ball-warpper", function() {
					var self = $(this);
					var SelectLenght = $(".Selected").length;
					////直选，组选，任选选球
					if(that.navActive == 7 || that.navActive == 8 || that.navActive == 9) {
						that.handleGroupSelect(self);
					} else {
						that.SelectBall(self);
						if(SelectLenght > 0) {
							if($(".nav-item.select").length > 0) {
								that.betLenght =
									SelectLenght * $(".nav-item.select").length;
								that.betSum =
									SelectLenght *
									that.betValue *
									$(".nav-item.select").length;
							} else {
								that.betLenght = SelectLenght;
								that.betSum = SelectLenght * that.betValue;
							}
						} else {
							that.betLenght = 0;
						}
					}
				});

				//直选，组选，任选玩法
				mui('.heightCover').on('tap', '.handleClickItem', function() {
					var index = $(this).data('index');
					var name = $(this).data('name');
					that.optionName = name;
					that.optionIndex = index;
					that.deleteSelected();
					that.tempArr = [];
				})

			});
		},
		methods: {
			//直选，组选，任选玩法选球
			handleGroupSelect(self) {
				const that = this;
				var SelectLenght = $(".Selected").length;
				var index = self.data('index');
				//直选的前二玩法
				if(that.navActive == 7 && that.optionIndex == 0) {
					if(SelectLenght > 1) {
						that.$toast('最多只能选两注球哦~', )
						return false;
					} else if(SelectLenght == 1) {
						that.betLenght = 1;
					}
					that.tempArr.push(index + 1);
					that.SelectBall(self);
					//直选的前三玩法	
				} else if(that.navActive == 7 && that.optionIndex == 1) {
					if(SelectLenght > 2) {
						that.$toast('最多只能选三注球哦~', )
						return false;
					} else if(SelectLenght == 2) {
						that.betLenght = 1;
					}
					that.tempArr.push(index + 1);
					that.SelectBall(self);
				} else if(that.navActive == 8) {
					that.SelectBall(self);
					//组选的前二玩法
					if(that.optionIndex == 0) {
						if(self.hasClass('Selected')) {
							that.tempArr[index] = index + 1;
						} else {
							that.tempArr[index] = '';
						}
						that.$Utils.arrayCombine(res => {

							that.betLenght = res.length;

						}, 2, that.tempArr.filter((n) => {return n}))
						//组选的前三玩法
					} else if(that.optionIndex == 1) {
						if(self.hasClass('Selected')) {
							that.tempArr[index] = index + 1;
						} else {
							that.tempArr[index] = '';
						}
						that.$Utils.arrayCombine(res => {

							that.betLenght = res.length;
						}, 3, that.tempArr.filter((n) => {return n}))
					}
					//任选玩法		
				} else {
					that.SelectBall(self);
					if(self.hasClass('Selected')) {
						that.tempArr[index] = index + 1;
					} else {
						that.tempArr[index] = '';
					}
					that.$Utils.arrayCombine(res => {
						that.betLenght = res.length;
					}, that.optionIndex + 1, that.tempArr.filter((n) => {return n}))
				}

			},

			//直选，组选，任选玩法
			handleOptions(val) {
				const that = this;
				var SelectedDom = $(".Selected");
				var objs, str = '',
					betObj;
				//直选
				if(that.navActive == 7) {
					if(that.optionIndex == 0) {
						objs = that.zhixuan[that.queryCode + '5_前二'];
						that.$Utils.arrayCombine(res => {
							for(let i = 0; i < res.length; i++) {
								var betno = '' + res[i];
								that.handleBetArr(objs, betno, val);
							}
							that.betSum = res.length * parseFloat(val)
							that.betLenght = res.length;
						}, 2, that.tempArr.filter((n) => {return n}))
					} else {
						objs = that.zhixuan[that.queryCode + '5_前三'];
						that.$Utils.arrayCombine(res => {
							for(let i = 0; i < res.length; i++) {
								var betno = '' + res[i];
								that.handleBetArr(objs, betno, val);
							}
							that.betSum = res.length * parseFloat(val)
							that.betLenght = res.length;
						}, 3, that.tempArr.filter((n) => {return n}))
					}
					//组选
				} else if(that.navActive == 8) {
					if(that.optionIndex == 0) {
						objs = that.zuxuan[that.queryCode + '6_前二'];
						that.$Utils.arrayCombine(res => {
							for(let i = 0; i < res.length; i++) {
								var betno = '' + res[i];
								that.handleBetArr(objs, betno, val);
							}
							that.betSum = res.length * parseFloat(val)
							that.betLenght = res.length;
						}, 2, that.tempArr.filter((n) => {return n}))

					} else {
						objs = that.zuxuan[that.queryCode + '6_前三'];
						that.$Utils.arrayCombine(res => {
							for(let i = 0; i < res.length; i++) {
								var betno = '' + res[i];
								that.handleBetArr(objs, betno, val);
							}
							that.betSum = res.length * parseFloat(val)
							that.betLenght = res.length;
						}, 3, that.tempArr.filter((n) => {return n}))
					}
					//任选
				} else {
					objs = that.renxuan[that.queryCode + '7_' + that.optionName];
					that.$Utils.arrayCombine(res => {
						for(let i = 0; i < res.length; i++) {
							var betno = '' + res[i];
							that.handleBetArr(objs, betno, val);
						}
						that.betSum = res.length * parseFloat(val)
						that.betLenght = res.length;
					}, that.optionIndex + 1, that.tempArr.filter((n) => {return n}))
				}
			},
			//组织投注数据
			handleBetArr(objs, betno, val) {
				const that = this;
				var betObj = {
					BET_NO: betno,
					SYS_GAME_LEVEL_CODE_ID: objs.P_1ID,
					SYS_GAME_LEVEL_CODE3_ID: objs.P_3ID,
					BET_RULE: objs.GROUP_NAME,
					BET_CONTENT: objs.NUM_NAME,
					ODDS: objs.ODDS,
					BET_AMT: parseInt(val),
					WIN: (parseInt(val) * objs.ODDS).toFixed(2),
					CODE: objs.CODE,
					BET_SUB_RULE: objs.NUM_NAME
				}
				that.betArr.push(betObj);
			},
			//点击tab清除所有记录项
			handleTabChange() {
				const that = this;
				that.betValue = "";
				that.Value = Math.random();
				that.deleteSelected();
				that.betLenght = 0;
				that.betSum = 0;
				mui("#shortCon")
					.scroll()
					.scrollTo(0, 0, 100);
				mui("#otherSide")
					.scroll()
					.scrollTo(0, 0, 100);
				$(".nav-down-list").slideUp(150);
				that.optionIndex = 0;
				that.tempArr = [];
			},
			//初始化
			simulation_data() {
				this.queryCode = this.$route.query.code;
				const that = this;
				$.getJSON("static/json/temp/" + that.queryCode + ".json", function(res) {
					var arr = [];
					that.initData = res;
				});
				//刷新页面后开始是本地JSON，延迟后再访问接口
				var t = setTimeout(() => {
					api.GetLotOddsDictList(function(itemList) {
						that.initData = itemList;
					}, that.lotteryID);
				}, 1000);
			},
			//选球功能
			SelectBall(self) {
				if(self.hasClass("Selected")) {
					self.removeClass("Selected");
				} else {
					self.addClass("Selected");
				}
			},
			//清除所有选中项
			deleteSelected() {
				this.betValue = "";
				this.betLenght = 0;
				this.tempArr = [];
				$(".ball-warpper.Selected").attr("class", function(i, cls) {
					return cls.replace(/Selected/g, "");
				});
				$(".nav-item.select").attr("class", function(i, cls) {
					return cls.replace(/select/g, "");
				});
			},
			initGame_data() {
				var that = this;
				//加入存储
				api.GetLotOddsDictList(
					function(itemList) {
						that.initData = itemList;
						that.zhixuan = itemList[that.queryCode + '5'];
						that.zuxuan = itemList[that.queryCode + '6'];
						that.renxuan = itemList[that.queryCode + '7'];
					},
					that.lotteryID,
					that
				);
			},
			//点击下注按钮操作
			HandleBet(val) {
				const that = this;
				var SelectedDom = $(".Selected");
				var selectNav = $(".nav-item.select");
				var obj = {},
					betObj = {},
					name = "";
				that.betArr = [];

				//投注验证
				if(!that.islogin) {
					that.$toast("请先登录后再下注~");
					return false;
				}
				if(parseInt(val) <= 0 || val == "") {
					that.$toast("请输入正确金额~");
					return false;
				}
				if(SelectedDom.length <= 0) {
					that.$toast("请选中玩法下注~");
					return false;
				}

				if(that.navActive == 0) {
					// 两面的投注方式
					if(selectNav.length == undefined || selectNav.length <= 0) {
						that.$toast("请选中玩法下注~");
						return false;
					}
					that.betLenght = SelectedDom.length * selectNav.length;
					that.betSum = SelectedDom.length * val * selectNav.length;
					for(let i = 0; i < SelectedDom.length; i++) {
						obj = SelectedDom[i].dataset["object"];
						obj = JSON.parse(obj);
						for(let j = 0; j < selectNav.length; j++) {
							name = selectNav[j].dataset["name"];
							betObj = {
								BET_NO: obj.NUM,
								SYS_GAME_LEVEL_CODE_ID: obj.P_1ID,
								SYS_GAME_LEVEL_CODE3_ID: obj.P_3ID,
								BET_RULE: name,
								BET_CONTENT: obj.NUM_NAME,
								ODDS: obj.ODDS,
								BET_AMT: parseInt(val),
								WIN: (parseInt(val) * obj.ODDS).toFixed(2),
								CODE: obj.CODE
							};
							that.betArr.push(betObj);
						}
					}
				} else if(that.navActive == 7 || that.navActive == 8 || that.navActive == 9) {
					//直选，组选，任选玩法
					if(that.betLenght <= 0) {
						that.$toast('请选择正确的玩法！');
						return false;
					}
					that.handleOptions(val);
				} else {
					//其他球的投注方式
					that.betLenght = SelectedDom.length;
					that.betSum = SelectedDom.length * val;
					for(let i = 0; i < SelectedDom.length; i++) {
						obj = SelectedDom[i].dataset["object"];
						obj = JSON.parse(obj);
						betObj = {
							BET_NO: obj.NUM,
							SYS_GAME_LEVEL_CODE_ID: obj.P_1ID,
							SYS_GAME_LEVEL_CODE3_ID: obj.P_3ID,
							BET_RULE: obj.GROUP_NAME,
							BET_CONTENT: obj.NUM_NAME,
							ODDS: obj.ODDS,
							BET_AMT: parseInt(val),
							WIN: (parseInt(val) * obj.ODDS).toFixed(2),
							CODE: obj.CODE
						};
						that.betArr.push(betObj);
					}
				}

				var dispack = {
					IsShow: true,
					title: `当前选中 ${this.betLenght} 注,总下注金额${this.betSum}元`,
					arr: that.betArr,
					type: "cp"
				};
				this.$store.dispatch("handleBetPour", dispack);
			},
			//filter
		},
		created() {
			// this.init();
			var this_ = this;
			this_.queryCode = this_.$route.query.code;
			this.Value = Math.random();
			this_.lotteryID = this_.$route.query.id;
			//判断用户是否有登录状态,根据islogin来判断
			if(!this_.islogin) {
				//等于这个执行假数据
				this_.simulation_data();
			} else {
				//执行缓存或者API数据
				this_.initGame_data();
			}
		},
		watch: {
			navActive(val) {
				if(val > this.tempIndex) {
					this.animate = "slide-out";
				} else {
					this.animate = "slide-in";
				}
				this.tempIndex = val;
			},
			rountddata(val) {
				var this_ = this;
				this_.queryCode = this_.$route.query.code;
				this.Value = Math.random();
				this_.lotteryID = this_.$route.query.id;
				//判断用户是否有登录状态,根据islogin来判断
				if(!this_.islogin) {
					this_.simulation_data();
				} else {
					//true执行缓存或者API数据
					this_.initGame_data();
				}
			}
		},
		props: ["mask", "side_right", "data"],
		computed: {
			islogin() {
				return this.$store.getters.checkLoginState;
			},
			rountddata() {
				return this.data.id;
			}
		}
	};
</script>

<style lang="scss" scoped>
	@import "~static/sass/public.scss";
	#HK6 {
		height: 100%;
		width: 100%;
		display: flex;
		flex-direction: column;
	}
	
	.kuaijie {
		margin-top: 0 !important;
	}
	
	.heightCover {
		height: 100%;
		width: 100%;
		display: flex;
		.leftTab {
			width: 1.6rem;
			height: 100%;
			position: relative;
			background: #f9f9f9;
			@include border-1px(#eee, right);
			.nav-item {
				p {
					font-size: 0.24rem;
				}
			}
		}
		.rightContainer {
			flex: 1;
			position: relative;
		}
	}
	
	.navContainer {
		width: 100%;
		padding: 0.24rem 0;
		li {
			padding: 0.22rem 0;
			position: relative;
			border-top: 1px solid #eeeeee;
			&:before {
				content: "";
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: #cccccc;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #777777 inset;
			}
			a {
				font-size: 0.28rem;
			}
		}
		.active {
			background: #fff;
			&:after {
				content: "";
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: red;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #8e0807 inset;
			}
			a {
				color: #ff1a18;
			}
			p {
				color: #ff1a18;
			}
		}
	}
	
	.nav {
		height: 0.88rem;
		background: #f5f6f7;
		position: relative;
		@include border-1px(#ccc, bottom);
		.slidetag {
			display: block;
			position: absolute;
			top: 0;
			right: 0;
			width: 1.45rem;
			height: 0.86rem;
			background: #f5f6f7;
			z-index: 6;
			font-size: 0.28rem;
			text-align: center;
			.more {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -50%);
				color: #999999;
				text-indent: -0.3rem;
				font-size: 0.24rem;
			}
			.transferdown {
				position: absolute;
				left: 0.8rem;
				top: 50%;
				transform: translate(-50%, -50%);
				color: #999999;
				font-size: 0.4rem;
			}
		}
		.nav-down-list {
			width: 100%;
			background: #f5f6f7;
			position: absolute;
			left: 0;
			z-index: 5;
			padding: 0.24rem;
			padding-bottom: 0.1rem;
			display: none;
			box-shadow: 0 5px 5px rgba(0, 0, 0, 0.1);
			.down-item-container {
				width: 25%;
				margin-bottom: 0.12rem;
				float: left;
				position: relative;
			}
			.down-item {
				border: 1px solid #ccc;
				width: 80%;
			}
		}
	}
	
	.mui-segmented-control.mui-scroll-wrapper {
		height: 0.88rem;
	}
	
	.mui-segmented-control.mui-scroll-wrapper .mui-scroll {
		height: 0.88rem;
		padding: 0.09rem 0.24rem;
		padding-right: 1.5rem;
	}
	
	.scroll-item {
		display: inline-block;
		font-size: 0.28rem;
		width: 1.52rem;
		height: 0.7rem;
		padding-top: 0.15rem;
		box-sizing: border-box;
		border-radius: 4px;
		color: $importFontColor;
		font-size: 0.28rem;
	}
	
	.mr-t {
		margin-top: 0.3rem;
	}
	
	.code {
		font-size: 0.24rem;
		color: #999999;
	}
	
	.nav-active {
		background: #fff;
		position: relative;
		border: 1px solid #ff1a18 !important;
		color: #ff1a18;
	}
	
	.footer {
		position: absolute;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 1rem;
		z-index: 100;
	}
	
	.main {
		/*flex: 1;*/
		/*position: relative;*/
		position: absolute;
		z-index: 1;
		height: 100%;
		width: 100%;
		top: 0.88rem;
		bottom: 1rem;
		left: 0;
		padding-bottom: 1.88rem;
		.shortcut {
			height: 100%;
			display: flex;
			position: absolute;
			width: 100%;
			padding-bottom: 1.88rem;
			.navigation {
				width: 1.6rem;
				background: #eee;
				position: relative;
			}
			.select-ball-warpper {
				flex: 1;
				position: relative;
			}
		}
		#shortCon {
			position: absolute;
			width: 100%;
			height: 100%;
			background: #ffffff;
		}
	}
	
	.nav-warpper {
		width: 100%;
		padding: 0.24rem 0;
		li {
			padding: 0.22rem 0;
			position: relative;
			border-top: 1px solid #eeeeee;
			&:before {
				content: "";
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: #cccccc;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #777777 inset;
			}
			a {
				font-size: 0.28rem;
			}
		}
		.select {
			background: #fff;
			&:after {
				content: "";
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: red;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #8e0807 inset;
			}
			a {
				color: #ff1a18;
			}
		}
	}
	
	.ball_code {
		color: #666;
	}
	
	.padding-box {
		padding: 0.3rem;
		padding-left: 0.3rem;
		padding-right: 0;
		padding-bottom: 0;
		.ball-warpper {
			width: 1rem;
			height: 1.6rem;
			text-align: center;
			display: inline-block;
			margin-right: 0.4rem;
			.ball {
				display: inline-block;
				width: 1rem;
				height: 1rem;
				border: 1px solid #ff0000;
				line-height: 1rem;
				border-radius: 50%;
				color: #ff1a18;
				font-size: 0.6rem;
			}
			.ball-odds {
				display: block;
				text-align: center;
				font-size: 0.23rem;
				padding-top: 0.01rem;
			}
		}
		.border-box {
			position: relative;
			border: 1px solid #ccc;
			border-radius: 4px;
			width: 1.6rem;
			height: 1rem;
			margin-right: 0.18rem;
			color: #666;
			margin-top: 0.2rem;
			.ball-text {
				display: inline-block;
				padding-top: 0.11rem;
				font-size: 0.32rem;
				font-weight: 600;
				color: #333;
			}
		}
	}
	
	.other-play {
		width: 100%;
		height: 100%;
		position: relative;
		background: #ffffff;
	}
	
	.border-box.Selected {
		background: #f5f6f7;
		border: 1px solid #ec5050 !important;
		 :after {
			content: "";
			width: 0.5rem;
			height: 0.5rem;
			background: url(~static/img/public/pk10/right.png);
			position: absolute;
			right: -0.02rem;
			top: -0.02rem;
			background-size: 100% auto;
		}
		span{
			color: $warnColor !important;
		}
	}
	
	.ball-warpper.Selected {
		.ball {
			background: red !important;
			color: #fff !important;
			border-color: red !important;
		}
	}
	
	.animated {
		animation-duration: 0.55s;
		animation-fill-mode: both;
	}
	
	@keyframes fadeIn {
		from {
			opacity: 0;
			z-index: 0;
			display: none;
		}
		to {
			opacity: 1;
			z-index: 100;
			display: block;
		}
	}
	
	.fadeIn {
		animation-name: fadeIn;
	}
	
	@keyframes fadeOut {
		from {
			opacity: 1;
			z-index: 100;
			display: block;
		}
		to {
			opacity: 0;
			z-index: 0;
			display: none;
		}
	}
	
	.fadeOut {
		animation-name: fadeOut;
		display: none !important;
	}
	
	.fade-enter-active {
		animation: fade-in 0.35s;
	}
	
	.fade-leave-active {
		animation: fade-out 0.35s;
	}
	
	@keyframes fade-in {
		0% {
			opacity: 0;
		}
		100% {
			opacity: 0.5;
		}
	}
	
	@keyframes fade-out {
		0% {
			opacity: 0.5;
		}
		100% {
			opacity: 0;
		}
	}
	
	.four {
		padding-top: inherit;
	}
	
	.padding-box .border-box1 {
		position: relative;
		border: 1px solid #ccc;
		border-radius: 4px;
		width: 1.2rem;
		height: 1rem;
		margin-right: 0.18rem;
		color: #666;
		margin-top: 0.2rem;
		.ball-text {
			font-size: 0.32rem;
			color: #333;
			font-weight: 600;
		}
		.ball-odds {
			font-size: 0.28rem;
			margin-top: -0.05rem;
			color: #666;
		}
	}
	
	.border-box1.Selected {
		background: #f5f6f7;
		border: 1px solid #ec5050 !important;
		 :after {
			content: "";
			width: 0.5rem;
			height: 0.5rem;
			background: url(~static/img/public/pk10/right.png);
			position: absolute;
			right: -0.02rem;
			top: -0.02rem;
			background-size: 100% auto;
		}
		span{
			color: $warnColor !important;
		}
	}
</style>