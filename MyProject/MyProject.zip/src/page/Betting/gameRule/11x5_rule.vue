<template>
		<div id="SyxwGameRule">
			<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<!-- 游戏介绍 -->
				<div class="gameIntroduce">
					每期{{gameName}}（开奖网）开奖球数共五粒，{{lotteyTime}}，{{periodsNo}}。 
					具体规则介绍如下：
				</div>
		
				<!-- 游戏规则 -->
				<div class="gameRules">
					<div class="ruleNum">
						<h3>1、单码：</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>指每一球出现的顺序与号码为派彩依据，如第一球开出号码8，下注第一球为8者视为中奖，第五球开出是2，下注第五球为2者视为中奖，其余情形视为不中奖</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>2、两面：</h3>
						<ul class="ruleNumChild">
							<li>单、双：</li>
							<li>自第一球至第五球，开出的号码为双数叫双，如8、10，开出的号码为单数叫单，如3、5，开出11为和 (不计算输赢)。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>大、小：</li>
							<li>自第一球至第五球，开出的号码大于或等于6为大，开出的号码小于等于5为小，开出11为和 (不计算输赢)。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>总和单双：</li>
							<li>所有5个开奖号码的数字总和相加的值是单数的为总和单，如数字总和值是11、31；所有5个开奖号码的数字总和相加的值是双数为总和双，如数字总和是42、30；假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>总和大小：</li>
							<li>所有5个开奖号码的数字总和相加的值是大于30为总和大；所有5个开奖号码的数字总和相加的值小于30为总和小，若总和值等于30为和 (不计算输赢)。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>总尾大小：</li>
							<li>所有5个开奖号码的数字总和值的个位数大于等于5为总尾大，小于等于4为总尾小；假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>总尾单双：</li>
							<li>所有5个开奖号码的数字总和值的尾数为单叫总尾单，所有5个开奖号码的数字总和值的尾数为双叫总尾双；假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>龙虎：</li>
							<li>
								以第一球的中奖号码和第五球的中奖号码作为兑奖号码。<br/>
								1、龙 开出的号码第一球的中奖号码大于第五球的中奖号码。如第一球开出10第五球开出7等中奖为龙。<br/>
								2、虎 开出的号码第一球的中奖号码小于第五球的中奖号码。如第一球开出3第五球开出7等中奖为虎。
							</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>3.选号：</h3>
						<ul class="ruleNumChild">
							<li>任选一中一：</li>
							<li>指投注1个号码与当期开奖的5个号码中任1个号码相同，视为中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>任选二中二：</li>
							<li>投注2个号码与当期开奖的5个号码中任2个号码相同(顺序不限)，视为中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>任选三中三：</li>
							<li>投注3个号码与当期开奖的5个号码中任3个号码相同(顺序不限)，视为中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>任选四中四：</li>
							<li>投注4个号码与当期开奖的5个号码中任4个号码相同(顺序不限)，视为中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>任选五中五：</li>
							<li>投注5个号码与当期开奖的5个号码中5个号码相同(顺序不限)，视为中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>任选六中六：</li>
							<li>投注6个号码中任5个号码与当期开奖的5个号码相同(顺序不限)，视为中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>任选七中七：</li>
							<li>投注7个号码中任5个号码与当期开奖的5个号码相同(顺序不限)，视为中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>任选八中八</li>
							<li>投注8个号码中任5个号码与当期开奖的5个号码相同(顺序不限)，视为中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>组选前二：</li>
							<li>投注的2个号码与当期顺序开出的5个号码中的前2个号码相同(顺序不限)，视为中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>组选前三</li>
							<li>投注的3个号码与当期顺序开出的5个号码中的前3个号码相同(顺序不限)，视为中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>直选前二：</li>
							<li>投注的2个号码与当期顺序开出的5个号码中的前2个号码相同且顺序一致，视为中奖。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>直选前三：</li>
							<li>投注的3个号码与当期顺序开出的5个号码中的前3个号码相同且顺序一致，视为中奖。</li>
						</ul>
					</div>
			</div>
		</div>
	</div></div>
</template>

<script>
	export default{
		name:'SyxwGameRule',
		data(){
			return{
				gameName: '',
				gameCode: '',
				periodsNo: '',
				lotteyTime: '',
			}
		},
		computed: {
			getGainValue : function() {
				return JSON.parse(localStorage.getItem('GameRule'));
			}
		},
		created(){
			var that = this;
			this.gameName = this.getGainValue.name;
			this.gameCode = this.getGainValue.code;
			console.log(this.gameName)
			if(this.gameCode == 'jisu11x5') {
				that.periodsNo = "每天开1440期";
				that.lotteyTime = "每期间隔1分钟。 北京时间（GMT+8）每天白天从上午00:00开到晚上23:59";
			}else if(this.gameCode == 'gd11x5'){
				that.periodsNo = "每天开84期";
				that.lotteyTime = "每期间隔10分钟。 北京时间（GMT+8）每天白天从上午9:00开到晚上23:00";
			}else if(this.gameCode == 'ah11x5'){
				that.periodsNo = "每天开84期";
				that.lotteyTime = "每期间隔10分钟。 北京时间（GMT+8）每天白天从上午9:00开到晚上23:00";
			}else if(this.gameCode == 'bj11x5'){
				that.periodsNo = "每天开85期";
				that.lotteyTime = "每期间隔10分钟。 北京时间（GMT+8）每天白天从上午9:00开到晚上23:00";
			}else if(this.gameCode == 'fj11x5'){
				that.periodsNo = "每天开90期";
				that.lotteyTime = "每期间隔10分钟。 北京时间（GMT+8）每天白天从上午8:00开到晚上23:00";
			}else if(this.gameCode == 'hub11x5'){
				that.periodsNo = "每天开81期";
				that.lotteyTime = "每期间隔10分钟。 北京时间（GMT+8）每天白天从上午8:36开到晚上21:56";
			}else if(this.gameCode == 'js11x5'){
				that.periodsNo = "每天开82期";
				that.lotteyTime = "每期间隔10分钟。 北京时间（GMT+8）每天白天从上午8:37开到晚上22:07";
			}else if(this.gameCode == 'jx11x5'){
				that.periodsNo = "每天开84期";
				that.lotteyTime = "每期间隔10分钟。 北京时间（GMT+8）每天白天从上午9:10开到晚上23:00";
			}else if(this.gameCode == 'ln11x5'){
				that.periodsNo = "每天开83期";
				that.lotteyTime = "每期间隔10分钟。 北京时间（GMT+8）每天白天从上午8:38开到晚上22:28";
			}else{
				that.periodsNo = "每天开90期";
				that.lotteyTime = "每期间隔10分钟。 北京时间（GMT+8）每天白天从上午9:00开到晚上23:50";
			}
		},
		mounted(){
			const that = this;
			mui.init();
			mui.ready(function(){
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005 //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
				});
			})
		}
	}
</script>

<style lang="scss" scoped>
	#SyxwGameRule{
		text-align: left;
		font-size: .26rem;
	}

	/*游戏介绍*/
	.gameIntroduce{
		/*margin: .24rem 0;*/
		padding: .24rem .24rem .45rem;
		font-size: .28rem;
		font-weight: bold;
		color:  #333333;
	}
	
	/*游戏规则*/
	.gameRules{
		padding: 0 .24rem;
		
		.ruleNum{
			color:#999999;
			h3{
				padding-bottom: .2rem;
				font-size: .26rem;
				color:  #333333;
			}
			.ruleNumChild{
				padding-bottom: .36rem;
				font-size: .26rem;
			}
			.ruleNumChild > li:first-of-type{
				padding-bottom: .15rem;
				font-size: .26rem;
				font-weight: bold;
				color: #333333;
			}
		}
	}
</style>