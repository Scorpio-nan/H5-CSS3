<template>
	<div id="cqsscRule">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<!-- 游戏介绍 -->
				<div class="gameIntroduce">
					{{gameName}}游戏是依照中国{{gameName}}福利彩票发行中心统一发行的『时时彩』彩票的开奖数据为依据所规划的线上彩票游戏，{{lotteyTime}}，{{periodsNo}}。
				</div>
		
				<!-- 游戏规则 -->
				<div class="gameRules">
					<div class="isRuleHeader">
						<ul>
							<li>规则如下:</li>
							<li>开奖结果为五码 (万、仟、佰、拾、个)。</br>假设结果为1 、2 、3 、4、5。</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>1.第一球~第五球</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>第一球、第二球、第三球、第四球、第五球：指下注的每一球特码与开出之号码其开奖顺序及开奖号码相同，视为中奖，如第一球开出号码 8，下注第一球为 8 者视为中奖，其余情形视为不中奖。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>单双大小</li>
							<li>根据相应单项投注第一球 ~ 第五球开出的球号，判断胜负。</li>
							<ul class="ruleNumChildChild">
								<li>大小</li>
								<li>根据相应单项投注的第一球 ~ 第五球开出的球号大于或等于 5 为特码大，小于或等于 4 为特码小。</li>
							</ul>
							<ul class="ruleNumChildChild">
								<li>单双</li>
								<li>根据相应单项投注的第一球 ~ 第五球开出的球号为双数则为特码双，如 2、6；球号为单数则为特码单，如 1、3。</li>
							</ul>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>2.总和</h3>
						<ul class="ruleNumChild">
							<li>第一球~第五球</li>
							<li>第一球、第二球、第三球、第四球、第五球：指下注的每一球特码与开出之号码其开奖顺序及开奖号码相同，视为中奖，如第一球开出号码 8，下注第一球为 8 者视为中奖，其余情形视为不中奖。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>单双大小</li>
							<li>根据相应单项投注第一球 ~ 第五球开出的球号，判断胜负。</li>
							<ul class="ruleNumChildChild">
								<li>大小</li>
								<li>根据相应单项投注的第一球 ~ 第五球开出的球号大于或等于 5 为特码大，小于或等于 4 为特码小。</li>
							</ul>
							<ul class="ruleNumChildChild">
								<li>单双</li>
								<li>根据相应单项投注的第一球 ~ 第五球开出的球号为双数则为特码双，如 2、6；球号为单数则为特码单，如 1、3。</li>
							</ul>
						</ul>
					</div>
				</div>
			</div>
		</div>
		
	</div>
</template>

<script>
	export default{
		name:'CqsscRule',
		data(){
			return{
				gameName: '',
				gameCode: '',
				periodsNo: '',
				lotteyTime: '',
			}
		},
		computed: {
			getGainValue : function() {
				return JSON.parse(localStorage.getItem('GameRule'));
			}
		},
		
		created() {
			var that = this;
			this.gameName = this.getGainValue.name;
			this.gameCode = this.getGainValue.code;
			if(this.gameCode == 'jsssc') {
				that.periodsNo = "每1分钟开一次奖,每天开奖1440期";
				that.lotteyTime = "北京时间（GMT+8）每天凌晨00:00开到当日晚上23:59";
			}else if(this.gameCode == 'xjssc'){
				that.periodsNo = "每天开奖96期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午10:00开到晚上00:00，夜场从00:00至凌晨02:00,每10分钟开一次奖";
			}else if(this.gameCode == 'ynssc'){
				that.periodsNo = "每天开奖72期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午09:30开到晚上21:30,每10分钟开一次奖";
			}else if(this.gameCode == 'tjssc'){
				that.periodsNo = "每天开奖84期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午09：00开到晚上23：00,每10分钟开一次奖";
			}else {
				that.periodsNo = "每天开奖120期（白天72期，夜晚48期）";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午10:00开到晚上22:00，夜场从22:00到凌晨2:00，每10分钟开一次奖，夜场每5分钟开一次奖";
			}
		},
		mounted(){
			const that = this;
			mui.init();
			this.$route.query.title;
			mui.ready(function(){
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005 //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
				});
			})
		}
	}
</script>

<style lang="scss" scoped>
	#cqsscRule{
		text-align: left;
		/*background-color:#ffffff;*/

		
	}

	/*游戏介绍*/
	.gameIntroduce{
		padding: 0.3rem 0.3rem;
		font-size: 0.28rem;
		color: #333333;
		font-weight: 600;
	}
	
	/*游戏规则*/
	.gameRules{
		padding: 0 .6rem 0 .5rem;
		.isRuleHeader{
			margin-bottom: .4rem;
			font-size: 0.26rem;
			color: #999999;
		}
		.ruleNum{
			h3{
				margin-bottom: 0.3rem;
				font-size: 0.26rem;
				color: #333333;
			}
			.ruleNumChild{
				margin-bottom: 0.3rem;
				font-size: 0.26rem;
				color: #999999;
			}
			.ruleNumChild > li:first-of-type{
				margin-bottom: 0.3rem;
				color: #333333;
				font-weight: bold;
			}
			.ruleNumChildChild{
				margin-top: 0.3rem;
				color: #999999;
			}
			.ruleNumChildChild:first-of-type{
					margin-top: 0.3rem;
					color: #999999;
			}
			
		}
	}
</style>