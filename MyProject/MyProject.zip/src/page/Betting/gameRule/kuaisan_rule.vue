<template>
	<div id="KsGameRule">
	<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<!-- 游戏介绍 -->
				<div class="gameIntroduce">
					每期{{gameName}}游戏的投注时间、开奖时间和开奖号码与“{{gameName}}”完全同步（官方网），北京时间（GMT+8）每天白天从上午9:00开到晚上22:30，每10分钟开一次奖,每天开奖82期。
				</div>
		
				<!-- 游戏规则 -->
				<div class="gameRules">
					<div class="ruleNum">
						<h3>骰宝</h3>
						<ul class="ruleNumChild">
							<li>I、博彩者可在下列各瓣下注：</li>
							<li>
								（一）“小”三粒骰子之点数总和由4点至10点；<br/>
								（二）“大”三粒骰子之点数总和由11点至17点；(注：若三粒骰子平面点数相同，通吃「大」、「小」各注)。<br/>
								（三）“三军/鱼虾蟹”任何一粒骰子出现选定之平面点数（开出1～3骰赔率不同）；<br/>
								（四）“围骰”三粒骰子平面与选定点数相同；<br/>
								（五）“全骰”在一点至六点内，三粒骰子平面点数相同；<br/>
								（六）“点数”由4点至17点，三粒骰子平面点数之总和；<br/>
								（七）“长牌”任两粒骰子之平面点数；<br/>
								（八）“短牌”选定两粒骰子之平面点数；
							</li>
						</ul>
				</div>
		</div>
	</div></div>
	</div>
</template>

<script>
	export default{
		name:'GsGameRule',
		data(){
			return{
				gameName: '',
				gameCode: '',
				periodsNo: '',
				lotteyTime: '',
			}
		},
		computed: {
			getGainValue : function() {
				return JSON.parse(localStorage.getItem('GameRule'));
			}
		},
		created(){
			var that = this;
			this.gameName = this.getGainValue.name;
			this.gameCode = this.getGainValue.code;
			if(this.gameCode == 'jisuk3'){
				that.periodsNo = "每1分钟开一次奖,每天开奖1440期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午00:00开到晚上23:59";
			}else if(this.gameCode == 'ahk3'){
				that.periodsNo = "每10分钟开一次奖,每天开奖80期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午8:40开到晚上22:00";
			}else if(this.gameCode == 'gxk3'){
				that.periodsNo = "每10分钟开一次奖,每天开奖78期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午9:38开到晚上22:28";
			}else if(this.gameCode == 'gsk3'){
				that.periodsNo = "每10分钟开一次奖,每天开奖72期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午10:10开到晚上22:00";
			}else if(this.gameCode == 'shk3'){
				that.periodsNo = "每10分钟开一次奖,每天开奖82期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午9:00开到晚上22:30";
			}else if(this.gameCode == 'hubk3'){
				that.periodsNo = "每10分钟开一次奖,每天开奖78期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午9:10开到晚上22:00";
			}else if(this.gameCode == 'hebk3'){
				that.periodsNo = "每10分钟开一次奖,每天开奖81期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午8:40开到晚上22:00";
			}
			else{
				that.periodsNo = "每10分钟开一次奖,每天开奖89期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午9:10开到晚上23:50";
				
			}
		},
		mounted(){
			const that = this;
			mui.init();
			mui.ready(function(){
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005 //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
				});
			})
		}
	}
</script>

<style lang="scss" scoped>
	#KsGameRule{
		text-align: left;
		font-size: .26rem;
	}

	/*游戏介绍*/
	.gameIntroduce{
		margin: .24rem 0;
		padding: 0 .24rem;
		/*font-size: .24rem;*/
		font-weight: bold;
	}
	
	/*游戏规则*/
	.gameRules{
		padding: 0 .24rem;
		.isRuleHeader{
			margin-bottom: .4rem;
		}
		.ruleNum{
			h3{
				margin-bottom: .36rem;
			}
			.ruleNumChild{
				margin-bottom: .36rem;
			}
			.ruleNumChild:last-of-type{
				margin-bottom: .6rem;
			}
			.ruleNumChild > li:first-of-type{
				margin-bottom: .14rem;
				font-weight: bold;
			}
			.ruleNumChildChild{
				margin-top: .4rem;
			}
			.ruleNumChildChild:first-of-type{
					margin-top: .3rem;
			}
			
		}
	}
</style>