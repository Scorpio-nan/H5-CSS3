<template>
	<div id="GdKlsfGameRule">
	<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<!-- 游戏介绍 -->
				<div class="gameIntroduce">
					每期{{gameName}}开奖球数共八粒。每粒球除了总和玩法，其它都有单独的投注页面。{{gameName}}{{periodsNo}}，{{lotteyTime}}。
				</div>
		
				<!-- 游戏规则 -->
				<div class="gameRules">
					<div class="ruleNum">
						<h3>1、第一球 ~ 第八球</h3>
						<ul class="ruleNumChild">
							<li>第一球~第八球：</li>
							<li>第一球、第二球、第三球、第四球、第五球、第六球、第七球、第八球：指下注的每一球特码与开出之号码其开奖顺序及开奖号码相同，视为中奖，如第一球开出号码 8，下注第一球为 8 者视为中奖，其余情形视为不中奖。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>两面：</li>
							<li>
								指单、双；大、小、尾大、尾小。<br/>
								单、双：号码为双数叫双，如8、10；号码为单数叫单，如9、5。<br/>
								大、小：开出之号码大于或等于11为大，小于或等于10为小。<br/>
								尾大、尾小：开出之尾数大于或等于5为尾大，小于或等于4为尾小。<br/>
								每一个号码为一投注组合，假如投注号码为开奖号码并在所投的球位置，视为中奖，其余情形视为不中奖。<br/>
							</li>
						</ul>
						<ul class="ruleNumChild">
							<li>中发白：</li>
							<li>
								中：开出之号码为01、02、03、04、05、06、07<br/>
								发：开出之号码为08、09、10、11、12、13、14<br/>
								白：开出之号码为15、16、17、18、19、20<br/>
							</li>
						</ul>
						<ul class="ruleNumChild">
							<li>方位：</li>
							<li>
								东：开出之号码为01、05、09、13、17<br/>
								南：开出之号码为02、06、10、14、18<br/>
								西：开出之号码为03、07、11、15、19<br/>
								北：开出之号码为04、08、12、16、20
							</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>2、总和</h3>
						<ul class="ruleNumChild">
							<li>总和单双：</li>
							<li>所有8个开奖号码的数字总和值是单数为总和单，如数字总和值是31、51；所有8个开奖号码的数字总和值是双数为总和双，如数字总和是42、80；假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>总和大小：</li>
							<li>大小：所有8个开奖号码的数字总和值85到132为总大；所有8个开奖号码的数字总和值36到83为总分小；所有8个开奖号码的数字总和值为84打和；如开奖号码为01、20、02、08、17、09、11，数字总和是68，则总分小。假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖，打和不计算结果。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>方位：</li>
							<li>东：开出之号码为01、05、09、13、17</li>
						</ul>
						<ul class="ruleNumChild">
							<li>总尾大小：</li>
							<li>所有8个开奖号码的数字总和数值的个位数大于或等于5为总尾大，小于或等于4为总尾小；假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖。</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>3、龙虎</h3>
						<ul class="ruleNumChild">
							<li>龙：</li>
							<li>开出之号码第一球的中奖号码大于第八球的中奖号码。如 第一球开出14 第八球开出09；第一球开出17 第八球开出08；第一球开出05 第八球开出01...中奖为龙。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>虎：</li>
							<li>开出之号码第一球的中奖号码小于第八球的中奖号码。如 第一球开出14 第八球开出16；第一球开出13 第八球开出18；第一球开出05 第八球开出08...中奖为虎。</li>
						</ul>
					</div>
			</div>
		</div>
	</div></div>
</template>

<script>
	export default{
		name:'KlsfGameRule',
		data(){
			return{
				gameName: '',
				gameCode: '',
				periodsNo: '',
				lotteyTime: '',
			}
		},
		computed: {
			getGainValue : function() {
				return JSON.parse(localStorage.getItem('GameRule'));
			}
		},
		created(){
			var that = this;
			this.gameName = this.getGainValue.name;
			this.gameCode = this.getGainValue.code;
			if(this.gameCode == 'gdklsf'){
				that.periodsNo = "每天开84期，每期间隔10分钟。投注时间为8分钟，等待开奖时间为2分钟";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午09：00开到晚上23：00";
			}else if(this.gameCode == 'cqklsf'){
				that.periodsNo = "每天开97期，每期间隔10分钟。投注时间为8分钟，等待时间为2分钟";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午09:53开到晚上凌晨02:03";
			}else{
				that.periodsNo = "每5分钟开一次奖，每天开奖179期";
				that.lotteyTime = "北京时间（GMT+8）每天白天从上午09:02开到晚上23:57";
				
			}
		},
		mounted(){
			const that = this;
			mui.init();
			mui.ready(function(){
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005 //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
				});
			})
		}
	}
</script>

<style lang="scss" scoped>
	#GdKlsfGameRule{
		text-align: left;
		font-size: .26rem;
	}

	/*游戏介绍*/
	.gameIntroduce{
		/*margin: .24rem 0;*/
		padding: .24rem .24rem .45rem;
		font-size: .28rem;
		font-weight: bold;
		color:  #333333;
	}
	
	/*游戏规则*/
	.gameRules{
		padding: 0 .24rem;
		.ruleNum{
			color:#999999;
			h3{
				padding-bottom: .2rem;
				font-size: .26rem;
				color:  #333333;
			}
			.ruleNumChild{
				padding-bottom: .36rem;
				font-size: .26rem;
			}
			.ruleNumChild > li:first-of-type{
				padding-bottom: .15rem;
				font-size: .26rem;
				font-weight: bold;
				color: #333333;
			}
		}
	}
</style>