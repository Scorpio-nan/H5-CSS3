<template>
		<div id="LhcGameRule">
	<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<!-- 游戏介绍 -->
				<div class="gameIntroduce">
					特别号码 (简称: 特码)。香港六合公司每期开出的最后一号码為『特码』。 开盘时间:上期封盘一小时后北京时间22:30至开奖日21:30封盘。
				</div>
		
				<!-- 游戏规则 -->
				<div class="gameRules">
					<div class="ruleNum">
						<h3>1、号码盘势规则</h3>
						<ul class="ruleNumChild">
							<li>大　小：</li>
							<li>以指定出现位置的号码大于或等于25为大，小于或等于24为小，开出49为和。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>单 双:</li>
							<li>以指定出现位置的号码为单数或双数下注，开出49为和</li>
						</ul>
							<ul class="ruleNumChild">
							<li>合大合小：</li>
							<li>以指定出现位置的号码个位和十位数字总和来判断胜负，和数大于或等于7为合大，小于或等于6为合小，开出49为和。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>合单合双：</li>
							<li>以指定出现位置的号码个位和十位数字总和来判断单双，开出49为和。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>大单小单大双小双：</li>
							<li>以指定出现位置的号码大小单双混合判断，开出49为和。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>尾大尾小：</li>
							<li>以指定出现位置的号码末尾数来判断大小，0尾~4尾为小、5尾~9尾为大，开出49为和。</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>2、生肖色波</h3>
						<ul class="ruleNumChild">
							<li>生肖：</li>
							<li>
								生肖顺序為 鼠 > 牛 > 虎 > 兔 > 龙 > 蛇 > 马 > 羊 > 猴 > 鸡 > 狗 > 猪 如今年是狗年，就以狗為开始，依顺序将 49个号码分為 12个生肖（如下），再以生肖下注，若当期开奖号码落在下注生肖范围内，则视為中奖。<br/>

								狗 : 1 , 13 , 25 , 37 , 49<br/>
								
								猪: 12 , 24 , 36 , 48<br/>
								
								鼠: 11 , 23 , 35 , 47<br/>
								
								牛: 10 , 22 , 34 , 46<br/>
								
								虎: 9 , 21 , 33 , 45<br/>
								
								兔 : 8 , 20 , 32 , 44<br/>
								
								龙: 7 , 19 , 31 , 43<br/>
								
								蛇 : 6 , 18 , 30 , 42<br/>
								
								马 : 5 , 17 , 29 , 41<br/>
								
								羊 : 4 , 16 , 28 , 40<br/>
								
								猴: 3 , 15 , 27 , 39<br/>
								
								鸡 : 2 , 14 , 26 , 38
							</li>
						</ul>
						<ul class="ruleNumChild">
							<li>色波：</li>
							<li>
								以特别号的球色下注，开奖的球色与下注的颜色相同，视为中奖，球色号码分布如下:<br/><span class="color"></span>

								<span class="colorRed">1</span> <span class="colorGreen">11 21 </span> <span class="colorBlue">31 41</span><br/>
								
								<span class="colorRed">2 12</span> <span class="colorGreen">22 32</span> <span class="colorBlue">42</span><br/>
								
								<span class="colorBlue">3</span> <span class="colorRed">13 23</span> <span class="colorGreen">33 43</span><br/>
								
								<span class="colorBlue">4 14</span> <span class="colorRed">24 34</span> <span class="colorGreen">44</span><br/>
								
								<span class="colorGreen">5</span> <span class="colorBlue">15 25</span> <span class="colorRed">35 45</span><br/>
								
								<span class="colorGreen">6 16</span> <span class="colorBlue">26 36</span> <span class="colorRed">46</span><br/>
								
								<span class="colorRed">7</span> <span class="colorGreen">17 27</span> <span class="colorBlue">37 47</span><br/>
								
								<span class="colorRed">8 18</span> <span class="colorGreen">28 38</span> <span class="colorBlue">48</span><br/>
								
								<span class="colorBlue">9</span> <span class="colorRed">19 29</span> <span class="colorGreen">39 49</span><br/>
								
								<span class="colorBlue">10 20</span> <span class="colorRed">30 40</span>
							</li>
						</ul>
							<ul class="ruleNumChild">
							<li>家禽野兽：</li>
							<li>开出的特码属于十二生肖中的牛、马、羊、鸡、狗、猪号码为家禽，属于十二生肖中的鼠、虎、龙、蛇、兔、猴号码为野兽；开出 49则视为和局。</li>
						</ul>
							<ul class="ruleNumChild">
							<li>总和单双:</li>
							<li>所有七个开奖号码的分数总和判断单双，总和是单数叫(总分单)，如分数总和是115、183；分数总和是双数叫(总分双)，如分数总和是108、162</li>
						</ul>
							<ul class="ruleNumChild">
							<li>总和大小：</li>
							<li>所有七个开奖号码的分数总和判断大小，总和大于或等于175为总分大；总和小于或等于174为总分小。</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>3、特码</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>香港六合彩公司当期开出的最后一码为特别号或特码。假如投注号码为开奖号码之特码，视为中奖，其余情形视为不中奖。 特码大小、单双、色波、生肖等玩法对应参考以上“号码盘势规则”的说明。</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>4、正码</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>香港六合彩公司当期开出之前6个号码叫正码。每一个号码为一投注组合，假如投注号码为开奖号码之正码，视为中奖，其余情形视为不中奖。 正码总和单双、大小玩法对应参考以上“号码盘势规则”的说明。 特别说明正码龙虎为：第一球跟第六球比较大小，第一球号码大于第六球号码为龙，反之为虎。</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>5、正码特</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>正码特是指正1特、正2特、正3特、正4特、正5特、正6特：香港六合彩公司当期开出之前6个号码叫正码。第一时间出来的叫正1特，依次为正2特、正3特…… 正6特(并不以号码大小排序)。其下注的正码特号与现场摇珠开出之正码其开奖顺序及开奖号码相同，视为中奖， 如现场摇珠第一个正码开奖为49号，下注第一个正码特为49则视为中奖，其它号码视为不中奖。</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>6、正码1-6</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>香港六合彩公司当期开出之前6个号码叫正码。第一时间出来的叫正码1，依次叫正码2、正码3……正码6，不以大小排序</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>7、过关</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>任选2-8个号码为一投注组合，其赔率为所选号码当时赔率的总乘积。投注组合所选号码必须全中 才视为中奖。当开奖结果中某一号码为49时，其单双大小为和，赔率以1计算，波色为绿波。如正1为49 ，正1小-正1红为不中奖，正1大-正1单为和局，正1大-正1绿为中绿波。</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>8、连码</h3>
						<ul class="ruleNumChild">
							<li>三全中：</li>
							<li>所投注的每三个号码为一组合，若三个号码都是开奖号码之正码，视为中奖，其余情形视为 不中奖。如06、07、08三个都是开奖号码之正码，视为中奖，如两个正码加上一个特别号码视为不中奖 。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>三中二：</li>
							<li>所投注的每三个号码为一组合，若其中2个是开奖号码中的正码，即为三中二，视为中奖； 若3个都是开奖号码中的正码，即为三中二之中三，其余情形视为不中奖，如06、07、08 为一组合，开奖号码中有06、07两个正码，没有08，即为三中二，按三中二赔付；如开奖 号码中有06、07、08三个正码，即为三中二之中三，按中三赔付；如出现1个或没有，视为不中奖 。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>二全中：</li>
							<li>所投注的每二个号码为一组合，若二个号码都是开奖号码之正码，视为中奖，其余情形视为不中奖（含一个正码加一个特别号码之情形）。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>二中特：</li>
							<li>所投注的每二个号码为一组合，若二个号码都是开奖号码之正码，叫二中特之中二；若其中一个是正码，一个是特别号码，叫二中特之中特；其余情形视为不中奖 。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>特串：</li>
							<li>所投注的每二个号码为一组合，其中一个是正码，一个是特别号码，视为中奖，其余情形视为不中奖（含二个号码都是正码之情形） 。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>四全中：</li>
							<li>所投注的每四个号码为一组合，若四个号码都是开奖号码之正码，视为中奖，其余情形视 为不中奖。如06、07、08、09四个都是开奖号码之正码，视为中奖，如三个正码加上一个特别号码视为 不中奖。</li>
						</ul>
						<ul class="ruleNumChild">
							<li>依照二全中·二中特·特串 此3种玩法规则,来进行‘生肖对碰’或‘尾数对碰’或'胆拖'或'生尾对碰'或'任意对碰'</li>
							<li>
								例一：<br/>
								
								选择‘二全中’,之后进行‘生肖对碰’选择马马(5 , 17 , 29 , 41)以及猴 (3 , 15 , 27 , 39) 则会产生20组号码组合：<br/>
								
								[2,1] [2,13] [2,25] [2,37] [2,49]<br/>
								
								[14,1] [14,13] [14,25] [14,37] [14,49]<br/>
								
								[26,1] [26,13] [26,25] [26,37] [26,49]<br/>
								
								[38,1] [38,13] [38,25] [38,37] [38,49]<br/>

								例二：<br/>
								
								选择‘二中特’,之后进行‘尾数对碰’选择0(10，20，30，40)以及5(5，15，25，35，45)<br/>
								
								则会产生20组号码组合：<br/>
								
								[10,5] [10,15] [10,25] [10,35] [10,45]<br/>
								
								[20,5] [20,15] [20,25] [20,35] [20,45]
							</li>
						</ul>
						<ul class="ruleNumChild">
							<li>肖串尾数:</li>
							<li>肖串尾数:选择一主肖，可扥0-9尾的球． 以三全中的肖串尾数为例： 选择【猴】当主肖(号码3,15,27,39)并且扥9尾数．因为9尾数中的39已在主肖中出现，将不重复组合． 故蛇主肖扥9尾数共可组合出24种组合(二个尾数号码+一个主肖号码的组合)．</li>
						</ul>
						<ul class="ruleNumChild">
							<li>'生肖对碰'或‘尾数对碰’或'胆拖'或'生尾对碰'或'任意对碰' 相当于是二全中·二中特·特串的一种快捷下注方式</li>
							<li>
								例如：选择‘二中特’,之后进行‘胆拖’ 在号码区选择10以及（12.13.14.15）则会产生4组号码组合：<br/>

								[10,12] [10,13] [10,14] [10,15]<br/>
								
								'生尾对碰'或'任意对碰'同理是前后号码的组合，所产生的组合为下注内容<br/>
								
								ps:前后号码中出现的重复号码将自动剔除其中一个。<br/>
							</li>
						</ul>
						<ul class="ruleNumChild">
							<li>半波：</li>
							<li>以特码色波和特单，特双，特大，特小为一个投注组合，当期特码开出符合投注组合，即视为中奖； 若当期特码开出49号，则视为和局；其余情形视为不中奖。</li>
						</ul>
					</div>
						<div class="ruleNum">
						<h3>9.一肖/尾数</h3>
						<ul class="ruleNumChild">
							<li>一肖：</li>
							<li>
								将生肖依序排列，例如今年是狗年，就以狗为开始，依顺序将49个号码分为12个生肖(如下)，再以生肖下注。<br/>

								狗 : 1 , 13 , 25 , 37 , 49<br/>
								
								猪: 12 , 24 , 36 , 48<br/>
								
								鼠: 11 , 23 , 35 , 47<br/>
								
								牛: 10 , 22 , 34 , 46<br/>
								
								虎: 9 , 21 , 33 , 45<br/>
								
								兔 : 8 , 20 , 32 , 44<br/>
								
								龙: 7 , 19 , 31 , 43<br/>
								
								蛇 : 6 , 18 , 30 , 42<br/>
								
								马 : 5 , 17 , 29 , 41<br/>
								
								羊 : 4 , 16 , 28 , 40<br/>
								
								猴: 3 , 15 , 27 , 39<br/>
								
								鸡 : 2 , 14 , 26 , 38<br/>
								
								只要当期号码(所有正码与最后开出的特码)，落在下注生肖范围内，则视为中奖。<br/>
								
								<span class="colorRed">(请注意：49亦算输赢，不为和)。</span>
							</li>
						</ul>
						<ul class="ruleNumChild">
							<li>尾数：</li>
							<li>
								指7个开奖号码中含有所属尾数的一个或多个号码，不论同尾数的号码出现一个或多个，派彩只派一次。<br/>

								0尾包括：10，20，30，40<br/>
								
								1尾包括：1，11，21，31，41<br/>
								
								2尾包括：2，12，22，32，42<br/>
								
								3尾包括：3，13，23，33，43<br/>
								
								4尾包括：4，14，24，34，44<br/>
								
								5尾包括：5，15，25，35，45<br/>
								
								6尾包括：6，16，26，36，46<br/>
								
								7尾包括：7，17，27，37，47<br/>
								
								8尾包括：8，18，28，38，48<br/>
								
								9尾包括：9，19，29，39，49
							</li>
						</ul>
					</div>
					<div class="ruleNum">
						<h3>10、特码生肖</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>以当期特码落在下注生肖范围内，视为中奖。 特码生肖请参考以上“号码盘势规则”的说明</li>
						</ul>
					</div>
						<div class="ruleNum">
						<h3>11、合肖</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>选2~11生肖(排列如同生肖)为一组合，并选择开奖号码的特码是否在此组合内，若当期开奖之特码落入所选生肖组合内则视为中奖，其他情形不中奖； 若当期特码开出49号，则所有组合皆视为和局。</li>
						</ul>
					</div>
						<div class="ruleNum">
						<h3>12、生肖连</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>挑选2~5生肖(排列如同生肖)为一个组合，当期号码(所有正码与最后开出的特码)坐落于投注时所勾选之生肖组合所属号码内，所勾选之生肖皆至少有中一个号码，则视为中奖，其余情况视为不中奖(请注意49亦算输赢，不为和)例如：如果当期号码为19、24、12、34、40、39.特码：49，所勾选三个生肖(称为三肖连)，若所有生肖的所属号码内至少一个出现于当期号码，则视为中奖。</li>
						</ul>
					</div>
						<div class="ruleNum">
						<h3>13、尾数连</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>挑选2~4个尾数为一组合，当期号码（所有正码与最后出的特码）坐落于投注时所勾选之尾数组合所属号码内，则视为中奖，其余情形视为不中奖(请注意49亦算输赢，不为和) 举例1：下注2尾碰，勾选0,1，当期七个号码若0尾及1尾皆有开出，视为中奖 举例2：下注2尾碰，勾选0,1,2三种尾数，会出现三种组合（组合一：0,1）（组合二：0,2）（组合三：1,2），当期七个号码若开出其中一种组合所选的两个尾数，视为中奖。</li>
						</ul>
					</div>
						<div class="ruleNum">
						<h3>14、全不中</h3>
						<ul class="ruleNumChild">
							<li></li>
							<li>挑选5~12个号码为一个组合，当期号码(所有正码与最后开出的特码)皆没有坐落于投注时所挑选之号码组合内，则视为中奖，若是有任何一个当期号码开在所挑选的号码组合情形视为不中奖。 例如当期号码为19,24,17,34,40,39,特别号49，所挑选5个号码(称为五不中)，若所挑选的号码内皆没有坐落于当期号码，则为中奖。</li>
						</ul>
					</div>
			</div>
		</div>
	</div></div>
</template>

<script>
	export default{
		name:'LhcGameRule',
		data(){
			return{
			
			}
		},
		created(){
			
		},
		mounted(){
			const that = this;
			mui.init();
			mui.ready(function(){
				mui('.mui-scroll-wrapper').scroll({
					deceleration: 0.0005 //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
				});
			})
		}
	}
</script>

<style lang="scss" scoped>
	#LhcGameRule{
		text-align: left;
		font-size: .26rem;
			.colorBlue{
			color: blue;
		}
		.colorGreen{
			color: green;
		}
		.colorRed{
			color: red;
		}
	}

	/*游戏介绍*/
	.gameIntroduce{
		/*margin: .24rem 0;*/
		padding: .24rem .24rem .45rem;
		font-size: .28rem;
		font-weight: bold;
		color:  #333333;
	}
	
	/*游戏规则*/
	.gameRules{
		padding: 0 .24rem;
		.ruleNum{
			color:#999999;
			h3{
				padding-bottom: .2rem;
				font-size: .26rem;
				color:  #333333;
			}
			.ruleNumChild{
				padding-bottom: .36rem;
				font-size: .26rem;
			}
			.ruleNumChild > li:first-of-type{
				padding-bottom: .15rem;
				font-size: .26rem;
				font-weight: bold;
				color: #333333;
			}
		}
	}
</style>