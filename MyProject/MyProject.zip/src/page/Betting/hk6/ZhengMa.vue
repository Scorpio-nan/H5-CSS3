<template>
	<div id="temaA">
		<div class="tema-main">
			<aside class="aside">
				<Scroller>
						<ul class="nav-warpper">
							<li class="nav-item" :data-code="item.code" v-for="(item,index) in asideNav" :data-index="index" :class="asideIndex == index ? 'select':''">
								<a href="javascript:;">{{item.name}}</a>
							</li>
						</ul>
				</Scroller>
			</aside>
			<!--  特码A  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 0">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in initData[queryCode+'9']" v-if="item.CLO != 'text'" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-odds ball_code">{{item.OS}}</span>
									</a>
								</div>
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper-text" v-for="(item,i,index) in initData[queryCode+'9']" v-if="item.CLO == 'text'" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-text-odds">{{item.OS}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			<!--  特码B  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 1">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in initData[queryCode+'10']" v-if="item.CLO != 'text'" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-odds ball_code">{{item.OS}}</span>
									</a>
								</div>
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper-text" v-for="(item,i,index) in initData[queryCode+'10']" v-if="item.CLO == 'text'&&index<49" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-text-odds">{{item.OS}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
		</div>
		<BFooter @handleBet="HandleBet" @handleDelete="deleteSelected" :Value="Value_" :Count='betLenght'></BFooter>
	</div>
</template>

<script>
	import Scroller from '@/components/Scroller';
	import BFooter from '../template/Footer';
	import api from '../../../api/lotteryUtil.js';
	export default {
		components: {
			Scroller,
			BFooter
		},
		data() {
			return {
				b_title: false,
				betLenght: 0,Value_:0,
				betSum: 0,
				betValue: '',
				resetBtn: false,
				asideNav: [{
					name: '正码A',
					code: 'zmaA'
				}, {
					name: '正码B',
					code: 'zmaB'
				}],
				queryCode: 'hk6',
				queryName: '',
				lotteryID: '27',
				betCount: 0,
				asideIndex: 0,
				initData: {},
				 currPeriodsNo: '20170000000',
				animate: 'slide-out',
				tempIndex: 0,
				betArr: [],
				myBetArray: {},
			}
		},
		mounted() {
			const that = this;
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});

			mui.init();
			mui.ready(function() {

				mui('.nav-warpper').on('tap', '.nav-item', function() {
					that.deleteSelected();
					that.betSum = 0;
					that.betLenght = 0;
					var index = $(this).data('index');
					that.asideIndex = index;
					if(index == 0){
						that.animate = 'slide-in';
					}else{
						that.animate = 'slide-out';
					}
				})

				mui('.section').on('tap', '.ball-item', function() {
					const self = $(this);
					var color = $(this).data('color');
					that.SelectBall(self, color)
					that.betLenght = ($('.select-red').length)+($('.select-green').length)+($('.select-blue').length)+($('.select-text').length);
				})


			})
		},
		created: function() {
			var this_ = this;
			this_.lotteryID = this_.$route.query.id;
			if(this_.logined||lib.WEB_TYPE__=='money'){
			this_.queryCode = this_.$route.query.code;
			this_.initOddsLottery();
			}else{
				$.getJSON("static/json/temp/six/zhengma-show.json", function(data) {
				this_.initData = data;
				 })
			}
		},
		methods: {
			initOddsLottery() {
				var this_ = this;
				var postData = {
					p_id: this_.$route.query.p3_id,
					p3_id: '',
				};
                var __obj = this_.Temashow;
                this_.initData[this_.queryCode+'9'] = __obj[this_.queryCode+'9'];
			    this_.initData[this_.queryCode+'10'] = __obj[this_.queryCode+'10'];
				if(window.localStorage.getItem(this_.lotteryID+'zhengmaArray') != null) {
					var data = eval('(' + window.localStorage.getItem(this_.lotteryID+'zhengmaArray') + ')');
					this_.myBetArray = data;
				} else {   
				     api.GetHk6OddsDict2List(function(itemList) {
						this_.myBetArray = itemList;
					 }, postData);
				} 
			},
			//绑定球颜色
			bindClass(color) {
				var str = '';
				switch(color) {
					case 'red':
						str = 'select-red';
						break;
					case 'blue':
						str = 'select-blue';
						break;
					case 'green':
						str = 'select-green';
						break;
					default:
						str = 'select-text';
						break;
				}
				return str;
			},
			//选球
			SelectBall(self, color) {
				if(self.hasClass(this.bindClass(color))) {
					self.removeClass(this.bindClass(color))
				} else {
					self.addClass(this.bindClass(color));
				}
			},
			//清除所有选中项
			deleteSelected() {
				this.betValue = '';
				$('.ball-item').attr('class', function(i, cls) {
					return cls.replace(/select-/g, '');
				});
			},
			//点击下注按钮
			HandleBet(val) {
				const that = this;
				that.betSum = that.betLenght * parseFloat(val);
				var DomList = $('.ball-item');
				var obj = {},
					betObj = {};
				that.betArr = [];
				DomList.map(function(index, item) {
					if(item.classList.contains('select-red')|| item.classList.contains('select-green') || item.classList.contains('select-blue') || item.classList.contains('select-text')) {
						obj = item.getAttribute('data-object');
						obj = JSON.parse(obj);
						betObj = {
							SYS_GAME_LEVEL_CODE_ID: obj.ID,
							SYS_GAME_LEVEL_CODE3_ID: obj.ID3,
							PERIODS_NO: that.currPeriodsNo,
							BET_RULE: obj.NAME,
							BET_CONTENT: obj.NM_NE,
							BET_NO: obj.NM,
							ODDS: obj.OS,
							BET_AMT: parseFloat(val),
							CODE: obj.CE,
						}
						that.betArr.push(betObj);
					}
				})
				
				if(that.betArr.length > 0){
					if(parseFloat(val) >= 0){
						var dispack = {
							IsShow:true,
							title:`当前选中 ${this.betLenght} 注,总下注金额${this.betSum}元`,
							arr:that.betArr,
							type:'hk6'
						}
						this.$store.dispatch('handleBetPour',dispack);
					}else{
						that.$alert('请输入投注金额！');
					}
				}else{
					that.$alert('请选中玩法后投注！');
				}
				
			}
		},
		computed: {
			logined() {
				return this.$store.getters.checkLoginState;
			},
			Temashow() {
				var this_ = this;
			    var __obj = this_.$store.getters.getTemashow;
			    return  __obj;
			},
		},
		watch: {
			Temashow() {
				var this_ = this;
				this_.queryCode = this_.$route.query.code;
				this_.initOddsLottery();
			},
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.temaA-warper,
	.temaB-warper {
		padding: 0.2rem 0 0 0.3rem;
	}
	.ball_code {
    	color: #999999;
	}	
	.ball-warper {
	display: inline-block;
    width: 0.8rem;
    height: 0.8rem;
    text-align: center;
    margin-bottom: 0.58rem;
    margin-right: 0.32rem;
		.ball {
			display: inline-block;
			width: 0.80rem;
			height: 0.80rem;
			border: 1px solid #ccc;
			line-height: 0.80rem;
			border-radius: 50%;
			box-sizing: border-box;
			font-size: 0.40rem;
		}
		.ball-color-red {
			border-color: #e52f33;
			color: #e52f33;
		}
		.ball-color-green {
			border-color: #4cbe00;
			color: #4cbe00;
		}
		.ball-color-blue {
			border-color: #2f84e5;
			color: #2f84e5;
		}
		.ball-odds {
			display: block;
			text-align: center;
			font-size: 0.24rem;
			padding-top: 0.01rem;
		}
	}
	
	.select-red {
		.ball {
			background: #e52f33;
			color: #fff;
		}
	}
	
	.select-blue {
		.ball {
			background: #2f84e5;
			color: #fff;
		}
	}
	
	.select-green {
		.ball {
			background: #4cbe00;
			color: #fff;
		}
	}
	
	.select-text {
		background: #e52f33;
		color: #fff;
	}
	
	.ball-warper-text {
		border: 1px solid #ccc;
		border-radius: 4px;
		width: 1.26rem;
		height: 0.96rem;
		margin-right: 0.06rem;
		text-align: center;
		display: inline-block;
		font-size: 0.28rem;
		margin-bottom: 0.1rem;
		.ball-text {
			display: block;
			/*padding-top: 0.11rem;*/
			text-align: center;
		}
	}
	
	#temaA {
		display: flex;
		flex-direction: column;
		.tema-main {
			flex: 1;
			display: flex;
			.aside {
				width: 1.6rem;
				background: #efeff4;
				position: relative;
			}
			.section {
				flex: 1;
				position: relative;
				background: #fff;
			}
		}
	}
	
	.b_title {
		font-size: .28rem;
		color: $blackColor;
		position: relative;
		z-index: 3;
		.b_title_main {
			background: $tipsFontColor;
			height: .5rem;
			position: absolute;
			width: 100%;
			top: -.5rem;
		}
		.b_text {
			padding-top: .05rem;
		}
	}
	
	.nav-warpper {
		width: 100%;
		padding: 0.24rem 0;
		li {
			padding: 0.22rem 0;
			position: relative;
			border-top: 1px solid #eeeeee;			
			&:before {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: #cccccc;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #777777 inset;
			}
			a {
				font-size: 0.28rem;
			}
		}
		.select {
			background: #fff;
			&:after {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: red;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #8e0807 inset;
			}
		}
	}
	.nav-warpper .select a {
    	color: #ff1a18;
	}	
	
</style>