<template>
	<div class="WeiShuLian">
		<div class="weishulian-main">
			<aside class="aside">
				<Scroller>
						<ul class="nav-warpper">
							<li class="nav-item" v-for="(item,i,index) in asideNav" :class="asideIndex == index ? 'select':''" :data-index="index" :key="index">
								<a href="javascript:;">{{item.name}}</a>
							</li>
						</ul>
				</Scroller>
			</aside>
			<section class="section">
				<div class="mui-scroll-wrapper" id="Scroll-warper">
					<div class="mui-scroll">
						<transition :name="animate" v-for="(val,key,i) in asideNav" :key="i">
							<div class="temaA-warper" v-show="asideIndex == i">
								<div class="mui-text-center ball-item" v-for="(l,m,n) in initData[queryCode+key]" :data-type="l.NM_NE" :data-object="JSON.stringify(l)" :data-index="n">
									<div class="text-inline-block">
										<div class="list_op">
											<span class="game-type">{{l.NM_NE}}</span>
											<span class="ball-odds">{{l.OS}}</span>
										</div>
										<span class="ball" v-for="ball in WnumArray[l.NM]" :class="'ball-color-' + numColors[ball]">{{ball}}</span>
									</div>
								</div>
							</div>
						</transition>
					</div>
				</div>
			</section>
		</div>
		<BFooter @handleBet="HandleBet" @handleDelete="deleteSelected" :Value="Value_" :Count='betLenght1'></BFooter>
	</div>
</template>

<script>
	import api from '../../../api/lotteryUtil.js';import Util from '../../../api/Util.js';
	import Scroller from '@/components/Scroller';
	import BFooter from '../template/Footer';
	export default {
		components: {
			Scroller,
			BFooter
		},
		data() {
			return {
				checkedGroupArray:[],
				currPeriodsNo: '20070000',Value_:0,betLenght1:0,
				betLenght: 0,
				betSum: 0,
				resetBtn: false,
				asideNav: {
					29: {
						"name": "二尾连中",
						"no": "2"
					},
					30: {
						"name": "三尾连中",
						"no": "3"
					},
					31: {
						"name": "四尾连中",
						"no": "4"
					},
					32: {
						"name": "五尾连中",
						"no": "5"
					}
				},
				asideIndex: 0,
				queryCode: 'hk6',
				initData: {},
				animate: 'slide-out',
				WnumArray: {
					"0尾": ["10", "20", "30", "40"],
					"1尾": ["1", "11", "21", "31", "41"],
					"2尾": ["2", "12", "22", "32", "42"],
					"3尾": ["3", "13", "23", "33", "43"],
					"4尾": ["4", "14", "24", "34", "44"],
					"5尾": ["5", "15", "25", "35", "45"],
					"6尾": ["6", "16", "26", "36", "46"],
					"7尾": ["7", "17", "27", "37", "47"],
					"8尾": ["8", "18", "28", "38", "48"],
					"9尾": ["9", "19", "29", "39", "49"]
				},
				numColors: '',
				queryName:'',
				lotteryID:'',
				myBetArray: {}, //投注数组
				betArr: [],
				ballType: 2, //球类型
				pushArr: [], //尾数数组
				tempArr: [], //暂时存储选中的对象
				tempIndex:0,
			}
		},
		computed: {
			handleBetPourArr(){
				return this.$store.getters.handleBetPour.arr.length;
			},
			logined() {
				return this.$store.getters.checkLoginState;
			},
			Temashow() {
				var this_ = this;
				var __obj = this_.$store.getters.getTemashow;
				return __obj;
			},
		},
		created(){
			this.init();
		},
		mounted() {
			const that = this;that.Value_+=1;
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});

			mui.init();
			mui.ready(function() {
				//左侧导航栏点击
				mui('.nav-warpper').on('tap', '.nav-item', function() {
					var index = $(this).data('index');that.Value_+=1;
					that.asideIndex = index;
					that.deleteSelected();
					that.betSum = 0;
					that.betLenght = 0;
					that.betLenght1 = 0;
					that.pushArr = [];
					that.tempArr = [];
					if(index >= that.tempIndex){
						that.animate = 'slide-out';
					}else{
						that.animate = 'slide-in';
					}
					that.tempIndex = index;
				})

				//选球功能
				mui('.section').on('tap', '.ball-item', function() {
					const self = $(this);
					that.SelectBall(self);
					var index = $(this).data('index'),
						type = $(this).data('type'),
						obj = $(this).data('object');

					if(self.hasClass('select-item')) {
						that.pushArr[index] = type;
						that.tempArr[index] = obj;
					} else {
						that.pushArr[index] = '';
						that.tempArr[index] = '';
					}
					
					that.betLenght = $('.select-item').length;
					if(that.betLenght>8){
						mui.alert('最多选择8个球');
						if(self.hasClass('select-item')) {
							self.removeClass('select-item');
							that.betLenght =$('.select-item').length;
						}
					}
					that.checkedGroupArray=[];
					for(var i=0;i<that.betLenght;i++){
						that.checkedGroupArray.push('55');
					}
					Util.arrayCombine(function(data) {
						that.betLenght1=data.length;
					}, that.ballType, that.checkedGroupArray)
				})

			})
		},
		methods: {
			init() {
				var this_ = this;
				this_.queryName = this_.$route.query.name;
				this_.lotteryID = this_.$route.query.id;
				this_.initcol();
				if(this_.logined||lib.WEB_TYPE__=='money') {
					this_.queryCode = this_.$route.query.code;
					this_.initOddsLottery();
					this_.showtime = true;
				} else {
					$.getJSON("static/json/temp/six/weishulian-show.json", function(data) {
						this_.initData = data;
						this_.showtime = true;
					})
				}
			},
			initOddsLottery() { //初始化数组
				var this_ = this;
				var postData = {
					p_id: this_.$route.query.p3_id,
					p3_id: '',
				};
				if(window.localStorage.getItem(this_.lotteryID+'weishulianArray') != null) {
					var data = eval('(' + window.localStorage.getItem(this_.lotteryID+'weishulianArray') + ')');
					this_.myBetArray = data;
				} else {
					api.GetHk6OddsDict2List(function(itemList) {
						this_.myBetArray = itemList;
					}, postData,this_);
				}
				var __obj = this_.Temashow;
				this_.initData[this_.queryCode+'29'] = __obj[this_.queryCode+'29'];
				this_.initData[this_.queryCode+'30'] = __obj[this_.queryCode+'30'];
				this_.initData[this_.queryCode+'31'] = __obj[this_.queryCode+'31'];
				this_.initData[this_.queryCode+'32'] = __obj[this_.queryCode+'32'];
			},
			initcol() {
				var this_ = this;
				//新增球的颜色数组
				if(window.localStorage.getItem('numColors') != null) {
					var data = eval('(' + window.localStorage.getItem('numColors') + ')');
					this_.numColors = data;
				} else {
					api.hk6Color(function(itemList) {
						this_.numColors = itemList;
					});
				}
			},
			//清除所有选中项
			deleteSelected() {
				$('.ball-item').attr('class', function(i, cls) {
					return cls.replace(/select-/g, '');
				});
			},

			//选球
			SelectBall(self) {
				if(self.hasClass('select-item')) {
					self.removeClass('select-item')
				} else {
					self.addClass('select-item');
				}
			},
			//确认投注
			HandleBet(val) {
				const that = this;
				var DomList = $('.select-item');
				var obj = {},
					betObj = {};
					that.betArr = [];
				if(DomList.length <= 0) {
					that.$alert('请选中玩法下注！');
					return false;
				}

				if(parseFloat(val) <= 0) {
					that.$alert('请输入金额后下注！');
					return false;
				}
				switch(this.asideIndex) {
					case 0:
						that.ballType = 2;
						if(DomList.length < 2 || DomList.length > 8) {
							that.$alert('请选择2~8和号码');
							return false;
						}
						break;
					case 1:
						that.ballType = 3;
						if(DomList.length < 3 || DomList.length > 8) {
							that.$alert('请选择3~8和号码');
							return false;
						}
						break;
					case 2:
						that.ballType = 4;
						if(DomList.length < 4 || DomList.length > 8) {
							that.$alert('请选择4~8和号码');
							return false;
						}
						break;
					default:
						that.ballType = 5;
						if(DomList.length < 5 || DomList.length > 8) {
							that.$alert('请选择5~8和号码');
							return false;
						}
						break;
				}
				
				//过滤掉数组里面为空的字段
				that.pushArr = that.pushArr.filter((n) => {return n});
				that.tempArr = that.tempArr.filter((n) => {return n});
				
				//util扩展数组排列组合选球功能
				that.$Utils.arrayCombine(function(data) {
					that.betLenght = data.length;
					that.betSum = parseFloat(val)*that.betLenght;
					for(var i = 0; i < data.length; i++) {
						var betNo = '' + data[i];
						var minodds = that.tempArr[0].OS;
						var maxodds = that.tempArr[0].OS;
						var odds = minodds;
						for(var b in data[i]) {
							if(data[i][b] == "0尾") {
								odds = maxodds;
							}
						}
						for(var h in that.tempArr) {
							if(minodds > that.tempArr[h].OS) {
								minodds = that.tempArr[h].OS
							}
							if(maxodds < that.tempArr[h].OS) {
								maxodds = that.tempArr[h].OS
							}
						}
						var subObject = {
							SYS_GAME_LEVEL_CODE_ID: that.tempArr[0].ID,
							SYS_GAME_LEVEL_CODE3_ID: that.tempArr[0].ID3,
							PERIODS_NO: that.currPeriodsNo,
							BET_RULE: that.tempArr[0].NAME,
							BET_CONTENT: betNo,
							BET_NO: betNo,
							ODDS: odds,
							BET_AMT: val,
							WIN: 0,
							CODE: that.tempArr[0].CE,
						};
						that.betArr.push(subObject);
					}
					var dispack = {
						IsShow: true,
						title: `当前选中 ${that.betLenght} 注,总下注金额${that.betSum}元`,
						arr: that.betArr,
						type:'hk6'
					}
					that.$store.dispatch('handleBetPour', dispack);
					
				}, that.ballType, that.pushArr)
			},
		},
		watch: {
			handleBetPourArr(){
				this.pushArr = [];
			},
			Temashow() {
				var this_ = this;
				this_.queryCode = this_.$route.query.code;
				this_.initOddsLottery();
			},
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.WeiShuLian {
		height: 100%;
		display: flex;
		flex-direction: column;
		.aside {
			width: 1.6rem;
			background: #efeff4;
			position: relative;
		}
		.section {
			flex: 1;
			position: relative;
			background: #fff;
		}
	}
	.mui-scroll{
		padding-bottom: 0.24rem;
	}
	.weishulian-main {
		flex: 1;
		display: flex;
	}
	
	.nav-warpper {
		width: 100%;
		padding: 0.24rem 0;
		li {
			padding: 0.22rem 0;
			position: relative;
			border-top: 1px solid #eeeeee;
			&:before {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: #cccccc;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #777777 inset;
			}
			a {
				font-size: 0.28rem;
			}
		}
		.select {
			background: #fff;
			&:after {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: red;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #8e0807 inset;
			}
		}
	}
	.nav-warpper .select a{
    	color: #ff1a18;
	}	
	.text-inline-block {
	display: table;
    padding: 0 0.24rem;
    margin: 0 auto;
    font-size: 0.28rem;
    text-align: center;
    padding: 0.1rem 0;
    width: 6rem;
		.ball-odds {
			font-size: 0.24rem;
		}
		.ball {
			display: inline-block;
			border: 1px solid #ccc;
			width: 0.80rem;
			height: 0.80rem;
			line-height: 0.80rem;
			border-radius: 50%;
			margin-right: 0.1rem;
			font-size: 0.40rem;
			float: left;
		}
		.ball-color-red {
			border-color: #e52f33;
			color: #e52f33;
		}
		.ball-color-green {
			border-color: #4cbe00;
			color: #4cbe00;
		}
		.ball-color-blue {
			border-color: #2f84e5;
			color: #2f84e5;
		}
	}
.ball-item{
	@include border-1px($bgColor, bottom);
}		
	.select-item {
		background: #f2f2f2;
			@include border-1px(#ccc, bottom);
		.ball-color-red {
			background: #e52f33;
			color: #fff;
		}
		.ball-color-green {
			background: #4cbe00;
			color: #fff;
		}
		.ball-color-blue {
			background: #2f84e5;
			color: #fff;
		}
	}
	
.list_op {
    padding-right: 0.1rem;
    float: left;
    padding-top: 0.2rem;
    padding-left: 0.1rem;
}	
</style>