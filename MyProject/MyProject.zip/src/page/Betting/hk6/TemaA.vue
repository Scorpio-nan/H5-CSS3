<template>
	<div id="temaA">
		<div class="tema-main">
			<aside class="aside">
				<Scroller>
					<ul class="nav-warpper">
						<li class="nav-item" :data-code="item.code" v-for="(item,index) in asideNav" :data-index="index" :class="asideIndex == index ? 'select':''">
							<a href="javascript:;">{{item.name}}</a>
						</li>
					</ul>
				</Scroller>
			</aside>
			<!--  特码A  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 0">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in initData[queryCode+'0']" v-if="item.CLO != 'text'" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-odds ball_code">{{item.OS}}</span>
									</a>
								</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,i,index) in initData[queryCode+'0']" v-if="item.CLO == 'text'" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-text-odds">{{item.OS}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			<!--  特码B  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 1">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in initData[queryCode+'1']" v-if="item.CLO != 'text'&&index<63" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-odds ball_code">{{item.OS}}</span>
									</a>
								</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,i,index) in initData[queryCode+'1']" v-if="item.CLO == 'text'&&index<63" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-text-odds">{{item.OS}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
		</div>
		<BFooter @handleBet="HandleBet" @handleDelete="deleteSelected" :Value="Value_" :Count='betLenght'></BFooter>
	</div>
</template>

<script>
	import Scroller from '@/components/Scroller';
	import BFooter from '../template/Footer';
	import api from '../../../api/lotteryUtil.js';
	export default {
		components: {
			Scroller,
			BFooter
		},
		data() {
			return {
				currPeriodsNo: '20170000000',
				lotteryID: '27',
				queryCode: 'hk6',
				myBetArray: {},
				showtime: false,
				Value_: 0,
				betLenght: 0,
				betSum: 0,
				resetBtn: false,
				asideNav: [{
					name: '特码A',
					code: 'TemaA'
				}, {
					name: '特码B',
					code: 'TemaB'
				}],
				asideIndex: 0,
				initData: {},
				animate: 'slide-out',
				tempIndex: 0,
				betArr: [],
			}
		},
		created: function() {
			var that = this;
			//			setTimeout(function(){
			//				that.init();
			//			})
			var this_ = this;
			this_.lotteryID = this_.$route.query.id;
			//接口获取赔率延迟5秒加载
			this_.initOddsLottery(this_.lotteryID);
		},
		mounted() {
			this.Value_ += 1;
			const that = this;
			//			this.init();

			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});

			mui.init();
			mui.ready(function() {
				mui('.nav-warpper').on('tap', '.nav-item', function() {
					var index = $(this).data('index');
					that.asideIndex = index;
					that.Value_ += 1;
					that.deleteSelected();
					that.betSum = 0;
					that.betLenght = 0;
					if(index == 0) {
						that.animate = 'slide-in';
					} else {
						that.animate = 'slide-out';
					}

				})

				mui('.section').on('tap', '.ball-item', function() {
					const self = $(this);
					var color = $(this).data('color');
					that.SelectBall(self, color)
					that.betLenght = ($('.select-red').length) + ($('.select-green').length) + ($('.select-blue').length) + ($('.select-text').length);
				})

			})
		},
		methods: {
			initOddsLottery(_id) {
				var this_ = this;
				var postData = {
					p_id: this_.$route.query.p3_id,
					p3_id: '',
				};
				var __obj = this_.Temashow;
				if(__obj != null && __obj[this_.queryCode + '0'] != undefined && __obj[this_.queryCode + '0'] != null && this_.logined) {
					this_.queryCode = this_.$route.query.code;
					this_.initData[this_.queryCode + '0'] = __obj[this_.queryCode + '0'];
					this_.initData[this_.queryCode + '1'] = __obj[this_.queryCode + '1'];
				} else {
					$.getJSON("static/json/temp/six/tema-show.json", function(data) {
						this_.initData = data;
					})
				}
				var t = setTimeout(() => {
					if(window.localStorage.getItem(this_.lotteryID + 'tamaArray') != null) {
						var data = eval('(' + window.localStorage.getItem(this_.lotteryID + 'tamaArray') + ')');
						this_.myBetArray = data;
					} else {
						api.GetHk6OddsDict2List(function(itemList) {
							this_.myBetArray = itemList;
						}, postData, this_);
					}
				}, 800)
			},
			init() {
				const that = this;
				$.getJSON('static/json/temp/six/tema-show.json', function(res) {
					that.initData = res;
				})
			},
			//绑定球颜色
			bindClass(color) {
				var str = '';
				switch(color) {
					case 'red':
						str = 'select-red';
						break;
					case 'blue':
						str = 'select-blue';
						break;
					case 'green':
						str = 'select-green';
						break;
					default:
						str = 'select-text';
						break;
				}
				return str;
			},
			//选球
			SelectBall(self, color) {
				if(self.hasClass(this.bindClass(color))) {
					self.removeClass(this.bindClass(color))
				} else {
					self.addClass(this.bindClass(color));
				}
			},
			//清除所有选中项
			deleteSelected() {
				this.betLenght = 0;
				$('.ball-item').attr('class', function(i, cls) {
					return cls.replace(/select-/g, '');
				});
			},
			//点击下注按钮
			HandleBet(val) {
				const that = this;
				var DomList = $('.ball-item');
				var obj = {},
					betObj = {};
				that.betArr = [];
				that.betSum = that.betLenght * val;
				DomList.map(function(index, item) {
					if(item.classList.contains('select-red') || item.classList.contains('select-green') || item.classList.contains('select-blue') || item.classList.contains('select-text')) {
						item = item.getAttribute('data-object');
						item = JSON.parse(item);
						that.myBetArray[item.CE+'_'+(index+1)].ST = true;
					}else{
						item = item.getAttribute('data-object');
						item = JSON.parse(item);
						if(index<76){
							that.myBetArray[item.CE+'_'+(index+1)].ST = false;
						}
					}
				})
				for(var key in that.myBetArray){
					var obj = that.myBetArray[key];
					if(obj.ST) {
						betObj = {
							SYS_GAME_LEVEL_CODE_ID: obj.ID,
							SYS_GAME_LEVEL_CODE3_ID: obj.ID3,
							PERIODS_NO: that.currPeriodsNo,
							BET_RULE: obj.NAME,
							BET_CONTENT: obj.NM_NE,
							BET_NO: obj.NM,
							ODDS: obj.OS,
							BET_AMT: parseInt(val),
							//WIN: (parseInt(obj.BET_AMT) * obj.ODDS).toFixed(2),
							CODE: obj.CE,
						}
						that.betArr.push(betObj);
					}
				};
				if(that.betArr.length > 0) {
					if(parseFloat(val) >= 0) {
						var dispack = {
							IsShow: true,
							title: `当前选中 ${this.betLenght} 注,总下注金额${this.betSum}元`,
							arr: that.betArr,
							type: 'hk6'
						}
						this.$store.dispatch('handleBetPour', dispack);
					} else {
						that.$alert('请输入投注金额！');
					}
				} else {
					that.$alert('请选中玩法后投注！');
				}

			}
		},
		watch: {
			Temashow() {
				this.initOddsLottery();
			},
		},
		computed: {
			logined() {
				return this.$store.getters.checkLoginState;
			},
			Temashow() {
				var this_ = this;
				var __obj = this_.$store.getters.getTemashow;
				return __obj;
			},
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.temaA-warper,
	.temaB-warper {
		padding: 0.24rem 0 0 0.24rem;
		background: #fff;
	}
	
	.ball-text-odds {
		font-size: 0.28rem;
		color: #666;
	}
	
	.ball-warper {
		display: inline-block;
		width: 0.8rem;
		height: 0.8rem;
		text-align: center;
		margin-bottom: 0.58rem;
		margin-right: 0.32rem;
		.ball {
			display: inline-block;
			width: 0.8rem;
			height: 0.8rem;
			border: 1px solid #ccc;
			line-height: 0.8rem;
			border-radius: 50%;
			color: #ff1a18;
			font-size: .40rem;
		}
		.ball-color-red {
			border-color: #e52f33;
			color: #e52f33;
		}
		.ball-color-green {
			border-color: #4cbe00;
			color: #4cbe00;
		}
		.ball-color-blue {
			border-color: #2f84e5;
			color: #2f84e5;
		}
		.ball-odds {
			display: block;
			text-align: center;
			font-size: 0.24rem;
			padding-top: 0.01rem;
		}
	}
	
	.select-red {
		.ball {
			background: #e52f33;
			color: #fff;
		}
	}
	
	.select-blue {
		.ball {
			background: #2f84e5;
			color: #fff;
		}
	}
	
	.select-green {
		.ball {
			background: #4cbe00;
			color: #fff;
		}
	}
	
	.four {
		.ball-warper-text.select-text {
			background: $bgColor !important;
			border: 1px solid $warnColor;
			&:after {
				content: '';
				width: 0.5rem;
				height: 0.5rem;
				background: url(~static/img/public/pk10/right.png);
				position: absolute;
				right: 0;
				top: 0;
				background-size: 100% auto;
			}
			span{
				color: $warnColor !important;
			}
		}
	}
	
	.ball_code {
		color: #999999;
	}
	
	.ball-warper-text {
		border: 1px solid #ccc;
		border-radius: 4px;
		width: 1.2rem;
/*		height: 1rem;*/
		margin-right: 0.18rem;
		padding-top: 0.1rem;
		text-align: center;
		display: inline-block;
		font-size: 0.32rem;
		margin-bottom: 0.2rem;
		color: #333333;
		position: relative;
		.ball-text {
			display: block;
			font-weight: 600;
			text-align: center;
			font-size: 0.32rem;
		}
	}
	
	#temaA {
		display: flex;
		flex-direction: column;
		.tema-main {
			flex: 1;
			display: flex;
			.aside {
				width: 1.6rem;
				background: #efeff4;
				position: relative;
			}
			.section {
				flex: 1;
				position: relative;
				background: #fff;
			}
		}
	}
	
	.b_title {
		font-size: .28rem;
		color: $blackColor;
		position: relative;
		z-index: 3;
		.b_title_main {
			background: $tipsFontColor;
			height: .5rem;
			position: absolute;
			width: 100%;
			top: -.5rem;
		}
		.b_text {
			padding-top: .05rem;
		}
	}
	
	.nav-warpper {
		width: 100%;
		padding: 0.24rem 0;
		li {
			padding: 0.22rem 0;
			position: relative;
			border-top: 1px solid #eeeeee;
			&:before {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: #cccccc;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #777777 inset;
			}
			a {
				font-size: 0.28rem;
			}
		}
		.select {
			background: #fff;
			&:after {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: red;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #8e0807 inset;
			}
			a {
				color: #ff1a18;
			}
		}
	}
</style>