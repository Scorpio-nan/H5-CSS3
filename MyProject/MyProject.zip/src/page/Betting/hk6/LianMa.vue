<template>
	<div id="temaA">
		<div class="tema-main">
			<aside class="aside">
				<Scroller>
						<ul class="nav-warpper">
							<li class="nav-item" :data-code="item.code" v-for="(item,index) in asideNav" :data-index="index" :class="asideIndex == index ? 'select':''">
								<a href="javascript:;">{{item.name}}</a>
							</li>
						</ul>
				</Scroller>
			</aside>
			<!--  四全中  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 0">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center"  v-for="(title,bigkey,index) in initData" :key="index">
									<div class="mui-text-center getOdds" v-if="title.num=='四全中'">
										赔率：{{title.show_odds}}
									</div>
									<a href="javascript:;"  class="ball-item ball-warper" v-for="(item1 ,key) in numColors" v-if="key<50&&title.num=='四全中'"  :data-color="item1" :data-object="JSON.stringify(title)">
										<span class="ball" :class="'ball-color-'+ item1">{{key}}</span>
										<span class="ball-odds"></span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			<!--  三全中  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 1">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center"  v-for="(title,bigkey,index) in initData" :key="index">
									<div class="mui-text-center getOdds" v-if="title.num=='三全中'">
										赔率：{{title.show_odds}}
									</div>
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item1 ,key) in numColors" v-if="key<50&&title.num=='三全中'"  :data-color="item1" :data-object="JSON.stringify(title)">
										<span class="ball" :class="'ball-color-'+ item1">{{key}}</span>
										<span class="ball-odds"></span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 2">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center"  v-for="(title,bigkey,index) in initData" :key="index">
									<div class="getOdds mui-text-center" v-if="title.num=='三中二'">
										赔率：{{title.show_odds}}
									</div>
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item1 ,key) in numColors" v-if="key<50&&title.num=='三中二'"  :data-color="item1" :data-object="JSON.stringify(title)">
										<span class="ball" :class="'ball-color-'+ item1">{{key}}</span>
										<span class="ball-odds"></span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 3">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center"  v-for="(title,bigkey,index) in initData" :key="index">
									<div class="getOdds mui-text-center" v-if="title.num=='二全中'">
										赔率：{{title.show_odds}}
									</div>
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item1 ,key) in numColors" v-if="key<50&&title.num=='二全中'"  :data-color="item1" :data-object="JSON.stringify(title)">
										<span class="ball" :class="'ball-color-'+ item1">{{key}}</span>
										<span class="ball-odds"></span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 4">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center"  v-for="(title,bigkey,index) in initData" :key="index">
									<div class="getOdds mui-text-center" v-if="title.num=='二中特'">
										赔率：{{title.show_odds}}
									</div>
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item1 ,key) in numColors" v-if="key<50&&title.num=='二中特'"  :data-color="item1" :data-object="JSON.stringify(title)">
										<span class="ball" :class="'ball-color-'+ item1">{{key}}</span>
										<span class="ball-odds"></span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 5">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center"  v-for="(title,bigkey,index) in initData" :key="index">
									<div class="mui-text-center getOdds" v-if="title.num=='特串'">
										赔率：{{title.show_odds}}
									</div>
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item1 ,key) in numColors" v-if="key<50&&title.num=='特串'"  :data-color="item1" :data-object="JSON.stringify(title)">
										<span class="ball" :class="'ball-color-'+ item1">{{key}}</span>
										<span class="ball-odds"></span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			
			
		</div>
		<BFooter @handleBet="HandleBet" @handleDelete="deleteSelected" :Value="Value_" :Count='betLenght1'></BFooter>
	</div>
</template>

<script>
	import Util from '../../../api/Util.js';
	import Scroller from '@/components/Scroller';
	import BFooter from '../template/Footer';
	export default {
		components: {
			Scroller,
			BFooter
		},
		data() {
			return {
				bet_no:[],
				checkedGroupArray:[],
				currPeriodsNo: '20170000000',
				b_title: false,
				betLenght: 0,
				betLenght1: 0,
				Value_:0,
				betSum: 0,
				betValue: '',
				resetBtn: false,
				queryCode:'hk6',
				numColors:{},
				asideNav: [{
					name: '四全中',
					code: 'zmaA'
				}, {
					name: '三全中',
					code: 'zmaB'
				}, {
					name: '三中二',
					code: 'zmaB'
				}, {
					name: '二全中',
					code: 'zmaB'
				}, {
					name: '二中特',
					code: 'zmaB'
				}, {
					name: '特串',
					code: 'zmaB'
				}],
				asideIndex:0,
				initData: {},
				animate: 'slide-out',
				betArr: [],
				lotteryID: '27',
				tempIndex:0,
				miType:4,
			}
		},
		computed: {
			ballType(){
				return this.asideNav[this.asideIndex].name;
			},
			logined() {
				return this.$store.getters.checkLoginState;
			},
			Temashow() {
				var this_ = this;
				var __obj = this_.$store.getters.getTemashow;
				return __obj;
			},
		},
		mounted() {
			const that = this;that.Value_+=1;
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});
			mui.init();
			mui.ready(function() {

				mui('.nav-warpper').on('tap', '.nav-item', function() {
					that.deleteSelected();
					that.betSum = 0;
					that.betLenght1 = 0;
					var index = $(this).data('index');
					that.asideIndex = index;that.Value_+=1;
					if(index >= that.tempIndex){
						that.animate = 'slide-out';
					}else{
						that.animate = 'slide-in';
					}
					that.tempIndex = index;
				})

				mui('.section').on('tap', '.ball-item', function() {
					const self = $(this);
					that.bet_no.push(self.find('.ball').html());
					var color = $(this).data('color');
					var __obj=self.data('object');
					that.SelectBall(self, color);that.betLenght = ($('.select-red').length)+($('.select-green').length)+($('.select-blue').length)+($('.select-text').length);
					if(that.betLenght>10){
						mui.alert('请选择' + __obj.no + '~10个球,最多10个球');
						if(self.hasClass(that.bindClass(color))) {
							self.removeClass(that.bindClass(color))
							that.betLenght = ($('.select-red').length)+($('.select-green').length)+($('.select-blue').length)+($('.select-text').length);
						} 
					}
					that.checkedGroupArray=[];
					for(var i=0;i<that.betLenght;i++){
						that.checkedGroupArray.push('55');
					}
					Util.arrayCombine(function(data) {
						that.betLenght1=data.length;
					}, that.miType, that.checkedGroupArray)
				})


			});
			setTimeout(function(){that.asideIndex=1;setTimeout(function(){that.asideIndex=0;},80)},100)
		},
		created: function() {
			var this_ = this;
			this_.lotteryID = this_.$route.query.id;
         	if(this_.logined||lib.WEB_TYPE__=='money') {
         	    this_.queryCode = this_.$route.query.code;
				this_.initOddsLottery(this_.Temashow[this_.queryCode+'13']);
			} else {
				$.getJSON("static/json/temp/six/lianma-show.json", function(data) {
					this_.initOddsLottery(data[this_.queryCode+'13']);
//					this_.showtime=true;
				})
			}
			if(window.localStorage.getItem('numColors') != null) {
				var data = eval('(' + window.localStorage.getItem('numColors') + ')');
				this_.numColors = data;
			} else {
				api.hk6Color(function(itemList) {
					this_.numColors = itemList;
				});
			}
		},
		methods: {
			init() {
				const that = this;
			},
			pushLianMaOddsList: function(lianma) {
				var this_ = this;
				this_.initData[lianma.NM] = new Array();
				var __obj = {
					pid: lianma.ID,
					pid2: lianma.ID2,
					pid3: lianma.ID3,
					name: lianma.NAME,
					num: lianma.NM,
					odds: lianma.OS,
					show_odds: lianma.OS,
					bet_sub_rule: lianma.NM,
					no: lianma.DC,
					code: lianma.CE
				}
				this_.initData[lianma.NM] = __obj;
//				console.log(this_.initData)
			},
			initOddsLottery(__obj) {
				var this_ = this;
				var postData = {
					p_id: this_.$route.query.p3_id,
					p3_id: '',
				};

				//连码数组重组开始-----------------------
				var dir = __obj;
				var lianma = dir[this_.queryCode+'13_1']; //四全中
				this_.pushLianMaOddsList(lianma);

				lianma = dir[this_.queryCode+'13_2']; //三全中
				this_.pushLianMaOddsList(lianma);

				lianma = dir[this_.queryCode+'13_3']; //三中二|中二 
				var lianma2 = dir[this_.queryCode+'13_4']; //三中二|中三

				var arr = lianma.NM.split('|');
				this_.initData[arr[0]] = new Array();
				var __obj = {
					pid: lianma.ID,
					pid2: lianma.ID2,
					pid3: lianma.ID3,
					name: lianma.NAME,
					num: arr[0],
					odds: lianma2.OS,
					show_odds: '中二:' + lianma.OS + '   中三:' + lianma2.OS,
					bet_sub_rule: arr[0] + '|' + lianma.OS + '|' + lianma2.OS,
					no: lianma.DC,
					code: lianma.CE
				}
				this_.initData[arr[0]] = __obj;

				var lianma = dir[this_.queryCode+'13_5']; //二全中
				this_.pushLianMaOddsList(lianma);

				lianma = dir[this_.queryCode+'13_6']; //二中特|中特
				lianma2 = dir[this_.queryCode+'13_7']; //二中特|中二

				var arr = lianma.NM.split('|');
				this_.initData[arr[0]] = new Array();
				var __obj = {
					pid: lianma.ID,
					pid2: lianma.ID2,
					pid3: lianma.ID3,
					name: lianma.NAME,
					num: arr[0],
					odds: lianma2.OS,
					show_odds: '中特:' + lianma.OS + '     中二:' + lianma2.OS,
					bet_sub_rule: arr[0] + '|' + lianma.OS + '|' + lianma2.OS,
					no: lianma.DC,
					code: lianma.CE
				}
				this_.initData[arr[0]] = __obj;
				var lianma = dir[this_.queryCode+'13_8']; //特串
				this_.pushLianMaOddsList(lianma);
				//结束-----------------------
			},
			//绑定球颜色
			bindClass(color) {
				var str = '';
				switch(color) {
					case 'red':
						str = 'select-red';
						break;
					case 'blue':
						str = 'select-blue';
						break;
					case 'green':
						str = 'select-green';
						break;
					default:
						str = 'select-text';
						break;
				}
				return str;
			},
			//选球
			SelectBall(self, color) {
				if(self.hasClass(this.bindClass(color))) {
					self.removeClass(this.bindClass(color))
				} else {
					self.addClass(this.bindClass(color));
				}
			},
			//清除所有选中项
			deleteSelected() {
//				this.betLenght = 0;
				$('.ball-item').attr('class', function(i, cls) {
					return cls.replace(/select-/g, '');
				});
			},
			//点击下注按钮
			HandleBet(val) {
				const that = this;
				if(that.asideIndex==0){
					if(that.betLenght<4){
						that.miType=4;
						mui.alert('请选择最少4个球');
						return;
					}
				}else if(that.asideIndex==1||that.asideIndex==2){
					if(that.betLenght<3){
						that.miType=3;
						mui.alert('请选择最少3个球');
						return;
					}
				}else if(that.asideIndex==3||that.asideIndex==4||that.asideIndex==5){
					if(that.betLenght<2){
						that.miType=2;
						mui.alert('请选择最少2个球');
						return;
					}
				}
				
				var DomList = $('.ball-item');
				var obj = {},
					betObj = {};
				var btaLengt=0;
				that.betArr = [];
				that.checkedGroupArray = []; //清空选中数组
				DomList.map(function(index, item) {
					if(item.classList.contains('select-red') || item.classList.contains('select-green') || item.classList.contains('select-blue') || item.classList.contains('select-text')) {
						that.checkedGroupArray.push($(item).find('.ball').html());
						obj=that.initData[that.ballType];
					}
				});
				var objDC=that.initData[that.ballType].no;var bet_no="";
				if(that.checkedGroupArray.length >= objDC) {
					Util.arrayCombine(function(data) {
						btaLengt=data.length;
						for(var i = 0; i < data.length; i++) {
							bet_no = '' + data[i];
							betObj = {
								SYS_GAME_LEVEL_CODE_ID: obj.pid,
								SYS_GAME_LEVEL_CODE3_ID: obj.pid3,
								PERIODS_NO: that.currPeriodsNo,
								BET_RULE: obj.name,
								BET_CONTENT: bet_no,
								BET_NO: bet_no,
								ODDS: obj.odds,
								BET_AMT: parseFloat(val),
								WIN: 0,
								CODE: obj.code,
								BET_SUB_RULE: obj.bet_sub_rule
							}
							that.betArr.push(betObj);
						}
						
					}, objDC, that.checkedGroupArray);
				}
				that.betSum = parseFloat(val)*btaLengt;
				if(that.betArr.length > 0) {
					if(parseFloat(val) >= 0) {
						var dispack = {
							IsShow: true,
							title: `当前选中 ${btaLengt} 注,总下注金额${this.betSum}元`,
							arr: that.betArr,
							type:'hk6'
						}
						this.$store.dispatch('handleBetPour', dispack);
					} else {
						that.$alert('请输入投注金额！');
					}
				} else {
					that.$alert('请选中玩法后投注！');
				}

			}
		},
		watch: {
			Temashow(){
				var this_=this;
				this_.queryCode = this_.$route.query.code;
				this_.initOddsLottery(this_.Temashow[this_.queryCode+'13']);
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.temaA-warper,
	.temaB-warper {
		padding: 0.2rem 0 0 0.3rem;
	}
	.getOdds{
		padding: 0.1rem 0;
		padding-bottom: 0.2rem;
	}
	.ball-warper {
		display: inline-block;
    	width: 0.8rem;
    	height: 0.8rem;
    	text-align: center;
    	margin-bottom: 0.58rem;
    	margin-right: 0.32rem;
		.ball {
			display: inline-block;
			width: 0.80rem;
			height: 0.80rem;
			border: 1px solid #ccc;
			line-height: 0.80rem;
			border-radius: 50%;
			box-sizing: border-box;
			font-size: 0.40rem;
		}
		.ball-color-red {
			border-color: #e52f33;
			color: #e52f33;
		}
		.ball-color-green {
			border-color: #4cbe00;
			color: #4cbe00;
		}
		.ball-color-blue {
			border-color: #2f84e5;
			color: #2f84e5;
		}
		.ball-odds {
			display: block;
			text-align: center;
			font-size: 0.24rem;
		}
	}
	
	.select-red {
		.ball {
			background: #e52f33;
			color: #fff;
		}
	}
	
	.select-blue {
		.ball {
			background: #2f84e5;
			color: #fff;
		}
	}
	
	.select-green {
		.ball {
			background: #4cbe00;
			color: #fff;
		}
	}
	
	.select-text {
		background: #e52f33;
		color: #fff;
	}
	
	.ball-warper-text {
		border: 1px solid #ccc;
		border-radius: 4px;
		width: 1.26rem;
		height: 0.96rem;
		margin-right: 0.06rem;
		text-align: center;
		display: inline-block;
		font-size: 0.28rem;
		margin-bottom: 0.1rem;
		.ball-text {
			display: block;
			/*padding-top: 0.11rem;*/
			text-align: center;
		}
	}
	
	#temaA {
		display: flex;
		flex-direction: column;
		.tema-main {
			flex: 1;
			display: flex;
			.aside {
				width: 1.6rem;
				background: #efeff4;
				position: relative;
			}
			.section {
				flex: 1;
				position: relative;
				background: #fff;
			}
		}
	}
	
	.b_title {
		font-size: .28rem;
		color: $blackColor;
		position: relative;
		z-index: 3;
		.b_title_main {
			background: $tipsFontColor;
			height: .5rem;
			position: absolute;
			width: 100%;
			top: -.5rem;
		}
		.b_text {
			padding-top: .05rem;
		}
	}
	
	.nav-warpper {
		width: 100%;
		padding: 0.24rem 0;
		li {
			padding: 0.22rem 0;
			position: relative;
			border-top: 1px solid #eeeeee;	
			&:before {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: #cccccc;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #777777 inset;
			}
			a {
				font-size: 0.28rem;
			}
		}
		.select {
			background: #fff;
			&:after {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: red;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #8e0807 inset;
			}
		}
	}
	.nav-warpper .select a {
    	color: #ff1a18;
	}	
</style>