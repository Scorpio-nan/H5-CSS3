<template>
	<div id="temaA">
		<div class="tema-main">
			<aside class="aside">
				<Scroller>
						<ul class="nav-warpper">
							<li class="nav-item" v-for="(ball,t,r) in initData" :data-index="r" :class="asideIndex == r ? 'select':''">
								<a href="javascript:;">{{ball.NM_NE}}</a>
							</li>
						</ul>
				</Scroller>
			</aside>

			<section class="section">
				<div class="mui-scroll-wrapper" id="Scroll-warper">
					<div class="mui-scroll">
						<transition :name="animate" v-for="(val,key,dex) in initData" :key="dex">
							<div class="temaA-warper" v-show="asideIndex == dex">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in colors" :data-color="item[0]" :data-object="JSON.stringify(val)" :key="i">
										<span class="ball" :class="'ball-color-' + item[0]">{{i}}</span>
										<span class="ball-odds ball_code">{{val.OS}}</span>
									</a>
								</div>
							</div>
						</transition>
					</div>
				</div>
			</section>
			
		</div>
		<BFooter @handleBet="HandleBet" @handleDelete="deleteSelected" :Value="Value_" :Count='betLenght'></BFooter>
	</div>
</template>

<script>
	import Scroller from '@/components/Scroller';
	import BFooter from '../template/Footer';
	import api from '../../../api/lotteryUtil.js';
	import Util from '../../../api/Util.js';
	export default {
		components: {
			Scroller,
			BFooter
		},
		data() {
			return {
				checkedGroupArray:[],
				currPeriodsNo:'20070000',Value_:0,
				b_title: false,
				betLenght: 0,
				betSum: 0,
				resetBtn: false,
				asideNav: [],
				asideIndex: 0,
				initData: {},
				animate: 'slide-out',
				tempIndex: 0,
				betArr: [],
				colors: [],
				lotteryID:'',
				queryCode:'hk6'
			}
		},
		mounted() {
			const that = this;that.Value_+=1;

			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});

			mui.init();
			mui.ready(function() {

				mui('.nav-warpper').on('tap', '.nav-item', function() {
					var index = $(this).data('index');
					that.asideIndex = index;
					that.deleteSelected();
					that.betSum = 0;that.Value_+=1;
					that.betLenght = 0;
					if(index >= that.tempIndex){
						that.animate = 'slide-out';
					}else{
						that.animate = 'slide-in';
					}
					that.tempIndex = index;
				})

				mui('.section').on('tap', '.ball-item', function() {
					that.Value_=parseInt(that.$route.query.Value);
					const self = $(this);
					var color = $(this).data('color');
					that.SelectBall(self, color);
					var __obj=self.data('object');
					var mit=__obj.DC;var max=10;
					if(mit==5||mit==6){max=10;}else{max=parseInt(mit)+3;}
					if(that.betLenght == max) {
						that.$alert('亲，最多只能选中'+max+'个哦！');
						self.removeClass(that.bindClass(color))
						that.betLenght = ($('.select-red').length)+($('.select-green').length)+($('.select-blue').length)+($('.select-text').length);
						return;
					}
					that.betLenght = ($('.select-red').length)+($('.select-green').length)+($('.select-blue').length)+($('.select-text').length);
					that.checkedGroupArray=[];
					for(var i=0;i<that.betLenght;i++){
						that.checkedGroupArray.push('55');
					}
					Util.arrayCombine(function(data) {
						that.betLenght=data.length;
					}, __obj.DC, that.checkedGroupArray)
				});
			})
		},
		created: function() {
			var this_ = this;
			this_.lotteryID = this_.$route.query.id;
			if(this_.logined||lib.WEB_TYPE__=='money') {
				this_.queryCode = this_.$route.query.code;
				this_.initOddsLottery();
//				this_.showtime = true;
			} else {
				this_.init();
			}
			if(window.localStorage.getItem('numColors') != null) {
				var data = eval('(' + window.localStorage.getItem('numColors') + ')');
				this_.colors = data;
			} else {
				api.hk6Color(function(itemList) {
					this_.colors = itemList;
				});
			}
		},
		methods: {
			initOddsLottery() {
				var this_ = this;
				var postData = {
					p_id: this_.$route.query.p3_id,
					p3_id: '',
				};
				var __obj = this_.Temashow[this_.queryCode+'33'];
				this_.initData = __obj;
			},
			init() {
				const that = this;
				$.getJSON('static/json/temp/six/quanbuzhong.json', function(data) {
					that.initData = data[that.queryCode+'33'];
				})
			},
			//绑定球颜色
			bindClass(color) {
				var str = '';
				switch(color) {
					case 'red':
						str = 'select-red';
						break;
					case 'blue':
						str = 'select-blue';
						break;
					case 'green':
						str = 'select-green';
						break;
					default:
						str = 'select-text';
						break;
				}
				return str;
			},
			//选球
			SelectBall(self, color) {
				if(self.hasClass(this.bindClass(color))) {
					self.removeClass(this.bindClass(color))
				} else {
					self.addClass(this.bindClass(color));
				}
			},
			//清除所有选中项
			deleteSelected() {
				$('.ball-item').attr('class', function(i, cls) {
					return cls.replace(/select-/g, '');
				});
			},
			//点击下注按钮
			HandleBet(val) {
				const that = this;
				var DomList = $('.ball-item');
				var obj = {},
					betObj = {};
				that.betArr = [];
				that.checkedGroupArray = []; //清空选中数组
				var bet_no="";
				DomList.map(function(index, item) {
					if(item.classList.contains('select-red') || item.classList.contains('select-green') || item.classList.contains('select-blue') || item.classList.contains('select-text')) {
						that.checkedGroupArray.push($(item).find('.ball').html());
						obj = item.getAttribute('data-object');
						obj = JSON.parse(obj);
						if(that.checkedGroupArray.length >= obj.DC) { //选中数组大于等于玩法规定注数
							Util.arrayCombine(function(data) {
								that.betLenght=data.length;
								that.betSum = val*that.betLenght;
								for(var i = 0; i < data.length; i++) {
									bet_no = '' + data[i];
									betObj = {
										SYS_GAME_LEVEL_CODE_ID: obj.ID,
										SYS_GAME_LEVEL_CODE3_ID: obj.ID3,
										PERIODS_NO: that.currPeriodsNo,
										BET_RULE: obj.NAME,
										BET_CONTENT: bet_no,
										BET_NO: bet_no,
										ODDS: obj.OS,
										BET_AMT: val,
										WIN: 0,
										CODE: obj.CE,
										BET_SUB_RULE: obj.NM + '|' + obj.OS
									};
									that.betArr.push(betObj);
								}
							}, obj.DC, that.checkedGroupArray);
						}
					}
				});
				if(DomList.length < obj.DC) {
					mui.alert('请选择最少'+ obj.DC + '个球', '错误');
					return; //退出
				}
				if(that.betArr.length > 0) {
					if(parseFloat(val) >= 0) {
						var dispack = {
							IsShow: true,
							title: `当前选中 ${that.betLenght} 注,总下注金额${this.betSum}元`,
							arr: that.betArr,
							type:'hk6'
						}
						this.$store.dispatch('handleBetPour', dispack);
					} else {
						that.$alert('请输入投注金额！');
					}
				} else {
					that.$alert('请选中玩法后投注！');
				}

			}
		},
		computed: {
			handleBetPourArr(){
				return this.$store.getters.handleBetPour.arr.length;
			},
			logined() {
				return this.$store.getters.checkLoginState;
			},
			Temashow() {
				var this_ = this;
				var __obj = this_.$store.getters.getTemashow;
				return __obj;
			},
		},
		watch: {
			handleBetPourArr(){
				this.deleteSelected();
			},
			Temashow() {
				var this_ = this;
				this_.queryCode = this_.$route.query.code;
				this_.initOddsLottery();
			},
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.temaA-warper,
	.temaB-warper {
		padding: 0.2rem 0 0 0.3rem;
	}
	
	.ball-warper {
		display: inline-block;
		width: 0.80rem;
		height: 0.80rem;
		text-align: center;
		margin-bottom: 0.58rem;
		margin-right: 0.32rem;
		.ball {
			display: inline-block;
			width: 0.80rem;
			height: 0.80rem;
			border: 1px solid #ccc;
			line-height: 0.80rem;
			border-radius: 50%;
			box-sizing: border-box;
		}
		.ball-color-red {
			border-color: #e52f33;
			color: #e52f33;
		}
		.ball-color-green {
			border-color: #4cbe00;
			color: #4cbe00;
		}
		.ball-color-blue {
			border-color: #2f84e5;
			color: #2f84e5;
		}
		.ball-odds {
			display: block;
			text-align: center;
			font-size: 0.24rem;
			padding-top: 0.01rem;
		}
	}
	
	.select-red {
		.ball {
			background: #e52f33;
			color: #fff;
		}
	}
	
	.select-blue {
		.ball {
			background: #2f84e5;
			color: #fff;
		}
	}
	
	.select-green {
		.ball {
			background: #4cbe00;
			color: #fff;
		}
	}
	
	.select-text {
		background: #e52f33;
		color: #fff;
	}
	
	.ball-warper-text {
		border: 1px solid #ccc;
		border-radius: 4px;
		width: 1.26rem;
		height: 0.96rem;
		margin-right: 0.06rem;
		text-align: center;
		display: inline-block;
		font-size: 0.28rem;
		margin-bottom: 0.1rem;
		.ball-text {
			display: block;
			/*padding-top: 0.11rem;*/
			text-align: center;
		}
	}
	
	#temaA {
		display: flex;
		flex-direction: column;
		.tema-main {
			flex: 1;
			display: flex;
			.aside {
				width: 1.6rem;
				background: #efeff4;
				position: relative;
			}
			.section {
				flex: 1;
				position: relative;
				background: #fff;
			}
		}
	}
	
	.b_title {
		font-size: .28rem;
		color: $blackColor;
		position: relative;
		z-index: 3;
		.b_title_main {
			background: $tipsFontColor;
			height: .5rem;
			position: absolute;
			width: 100%;
			top: -.5rem;
		}
		.b_text {
			padding-top: .05rem;
		}
	}
	
	.nav-warpper {
		width: 100%;
		padding: 0.24rem 0;
		li {
			padding: 0.22rem 0;
			position: relative;
			border-top: 1px solid #eeeeee;
			&:before {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: #cccccc;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #777777 inset;
			}
			a {
				font-size: 0.28rem;
			}
		}
		.select {
			background: #fff;
			&:after {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: red;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #8e0807 inset;
			}
		}
	}
	.nav-warpper .select a{
    	color: #ff1a18;
	}		
.ball_code{
    color: #999999;
}	
</style>