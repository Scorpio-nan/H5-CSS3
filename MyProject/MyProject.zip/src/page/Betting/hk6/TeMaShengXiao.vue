<template>
	<div id="temashengxiao">
		<div class="tema-main">
			<!--  生肖  -->
			<transition :name="animate">
				<section class="section">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="ball-item" v-for="(item,i,index) in myBetArrayShow[queryCode+'1']" v-if="item.SORT>64" :data-object="JSON.stringify(item)">
								<div class="content">
									<div class="ball-warper">
										<div class="list_op">
											<span :class="item.SHOWCLO">{{item.NM_NE}}</span>
											<span class="ball-odds">{{item.OS}}</span>
										</div>
										<span class="ball" :class="'ball-color-' +numColors[ball]" v-for="ball in AnimalArray[item.NM]">{{ball}}</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
		</div>
		<BFooter @handleBet="HandleBet" @handleDelete="deleteSelected" :Value="Value_" :Count='betLenght'></BFooter>
	</div>
</template>

<script>
	import Scroller from '@/components/Scroller';
	import BFooter from '../template/Footer';
	import api from '../../../api/lotteryUtil.js';
	export default {
		components: {
			Scroller,
			BFooter
		},
		data() {
			return {
				currPeriodsNo: '20170000000',
				lotteryID:'27',myBetArray: {},
				b_title: false,Value_:0,
				betLenght: 0,
				betSum: 0,
				betValue: '',
				resetBtn: false,
				animate: 'slide-in',
				tempIndex: 0,
				betArr: [],
				queryCode: 'hk6',
				myBetArrayShow: {},
				numColors:{},
				AnimalArray:{},
			}
		},
		mounted() {
			const that = this;that.Value_+=1;
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});
			mui.init();
			mui.ready(function() {
				mui('.section').on('tap', '.ball-item', function() {
					const self = $(this);
					var color = $(this).data('color');
					that.SelectBall(self, color)
					that.betLenght = ($('.select-red').length)+($('.select-green').length)+($('.select-blue').length)+($('.select-text').length);
				})
			})
		},
		computed: {
			logined() {
				return this.$store.getters.checkLoginState;
			},
			Temashow() {
				var this_ = this;
				var __obj = this_.$store.getters.getTemashow;
				return __obj;
			},
		},
		created(){this.init();},
		methods: {
		init() {
//			console.log(this.logined)
			var this_ = this;
			this_.lotteryID = this_.$route.query.id;
			if(this_.logined || lib.WEB_TYPE__ == 'money') {
				this_.initOddsLottery();
			} else {
				$.getJSON("static/json/temp/six/tema-show.json", function(data) {
					this_.myBetArrayShow = data;
				})
			}
			if(window.localStorage.getItem('numColors') != null) {
				var data = eval('(' + window.localStorage.getItem('numColors') + ')');
				this_.numColors = data;
			} else {
				api.hk6Color(function(itemList) {
					this_.numColors = itemList;
				});
			}
			if(window.localStorage.getItem('AnimalArray') != null) {
				var data = eval('(' + window.localStorage.getItem('AnimalArray') + ')');
				this_.AnimalArray = data;
			} else {
				api.hk6animal(function(itemList) {
					this_.AnimalArray = itemList;
				});
			}

		},
		initOddsLottery() {
				var this_ = this;
				this_.queryCode = this_.$route.query.code;
				var postData = {
					p_id: this_.$route.query.p3_id,
					p3_id: '',
				};
				var __obj = this_.Temashow;
				if(__obj[this_.queryCode + '1'] != null && __obj[this_.queryCode + '1'] != undefined) {
					this_.myBetArrayShow[this_.queryCode + '1'] = __obj[this_.queryCode + '1'];
				}
				if(window.localStorage.getItem(this_.queryCode+'tamaArray') != null) {
					var data = eval('(' + window.localStorage.getItem(this_.queryCode+'tamaArray') + ')');
					this_.myBetArray = data;
				} else {
					api.GetHk6OddsDict2List(function(itemList) {
						this_.myBetArray = itemList;
					}, postData);
				}
			},
			//绑定球颜色
			bindClass(color) {
				var str = '';
				switch(color) {
					case 'red':
						str = 'select-red';
						break;
					case 'blue':
						str = 'select-blue';
						break;
					case 'green':
						str = 'select-green';
						break;
					default:
						str = 'select-text';
						break;
				}
				return str;
			},
			//选球
			SelectBall(self, color) {
				if(self.hasClass(this.bindClass(color))) {
					self.removeClass(this.bindClass(color))
				} else {
					self.addClass(this.bindClass(color));
				}
			},
			//清除所有选中项
			deleteSelected() {
				this.betValue = '';
				$('.ball-item').attr('class', function(i, cls) {
					return cls.replace(/select-/g, '');
				});
			},
			//点击下注按钮
			HandleBet(val) {
				const that = this;
				if(that.betLenght<2){
						mui.alert('请选择2-8个号码')
						return;
					}
				that.betSum = that.betLenght * parseFloat(val);
				var DomList = $('.ball-item');
				var obj = {},
					betObj = {};
				that.betArr = [];
				DomList.map(function(index, item) {
					if(item.classList.contains('select-red') || item.classList.contains('select-green') || item.classList.contains('select-blue') || item.classList.contains('select-text')) {
						obj = item.getAttribute('data-object');
						obj = JSON.parse(obj);
						betObj = {
							SYS_GAME_LEVEL_CODE_ID: obj.ID,
							SYS_GAME_LEVEL_CODE3_ID: obj.ID3,
							PERIODS_NO: that.currPeriodsNo,
							BET_RULE: '特码生肖',
							BET_CONTENT: obj.NM_NE,
							BET_NO: obj.NM,
							ODDS: obj.OS,
							BET_AMT: parseInt(val),
							//WIN: (parseInt(obj.BET_AMT) * obj.ODDS).toFixed(2),
							CODE: obj.CE,
						}
						that.betArr.push(betObj);
					}
				})

				if(that.betArr.length > 0) {
					if(parseFloat(val) >= 0) {
						var dispack = {
							IsShow: true,
							title: `当前选中 ${this.betLenght} 注,总下注金额${this.betSum}元`,
							arr: that.betArr,
							type:'hk6'
						}
						this.$store.dispatch('handleBetPour', dispack);
					} else {
						that.$alert('请输入投注金额！');
					}
				} else {
					that.$alert('请选中玩法后投注！');
				}

			}
		},
		watch: {
			Temashow() {
				var this_ = this;
				this_.queryCode = this_.$route.query.code;
				this_.init();
			},
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	#temashengxiao {
		display: flex;
		flex-direction: column;
		.tema-main {
			flex: 1;
			display: flex;
			.section {
				flex: 1;
				position: relative;
				background: #fff;
			}
		}
	}
	.mui-scroll{
		padding-bottom: 0.24rem;
	}
	.ball-warper {
		display: table;
		padding: 0 0.24rem;
		margin: 0 auto;
		font-size: 0.28rem;
		text-align: center;
		padding: 0.1rem 0;
		width: 6rem;
		.ball {
			display: inline-block;
			width: 0.80rem;
			height: 0.80rem;
			border: 1px solid #ccc;
			line-height: 0.80rem;
			border-radius: 50%;
			box-sizing: border-box;
			margin: 0rem 0.08rem;
			text-align: center;
			float: left;
			font-size: 0.40rem;
		}
		.ball-color-red {
			border-color: #e52f33;
			color: #e52f33;
		}
		.ball-color-green {
			border-color: #4cbe00;
			color: #4cbe00;
		}
		.ball-color-blue {
			border-color: #2f84e5;
			color: #2f84e5;
		}
		.ball-odds {
			display: inline-block;
			padding-left: 2px;
			font-size: 0.24rem;
			color: rgba(0, 0, 0, .5);
			width: 35px;
		}
	}
.ball-item{
	@include border-1px($bgColor, bottom);
}	
	.select-text {
		background: #f2f2f2;
		@include border-1px(#ccc, bottom);
		.ball-color-red {
			background: #e52f33;
			color: #fff;
		}
		.ball-color-green {
			background: #4cbe00;
			color: #fff;
		}
		.ball-color-blue {
			background: #2f84e5;
			color: #fff;
		}
	}
	
	.slide-in-enter-active {
		animation: slide-in .25s;
	}
	
	.slide-out-leave-active {
		animation: slide-out .25s;
	}
	
	@keyframes slide-in {
		from {
			transform: translate3d(-100%, 0, 0);
		}
		to {
			transform: translate3d(0, 0, 0);
		}
	}
	
	@keyframes slide-out {
		from {
			transform: translate3d(0, 0, 0);
		}
		to {
			transform: translate3d(-100%, 0, 0);
		}
	}
	.list_op{
		padding-right: 0.1rem;
    	float: left;
		padding-top: 0.2rem;
	}
	.content{
		width: 80%;
		margin: auto;
	}
</style>