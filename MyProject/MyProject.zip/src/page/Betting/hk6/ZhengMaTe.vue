<template>
	<div id="temaA">
		<div class="tema-main">
			<aside class="aside">
				<Scroller>
					<ul class="nav-warpper">
						<li class="nav-item" :data-code="item.code" v-for="(item,index) in asideNav" :data-index="index" :class="asideIndex == index ? 'select':''">
							<a href="javascript:;">{{item.name}}</a>
						</li>
					</ul>
				</Scroller>
			</aside>
			<!--  特码A  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 0">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in initData[queryCode+'2']" v-if="item.CLO != 'text'" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-odds ball_code">{{item.OS}}</span>
									</a>
								</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,i,index) in initData[queryCode+'2']" v-if="item.CLO == 'text'" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-text-odds">{{item.OS}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			<!--  特码B  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 1">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in initData[queryCode+'3']" v-if="item.CLO != 'text' " :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-odds ball_code">{{item.OS}}</span>
									</a>
								</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,i,index) in initData[queryCode+'3']" v-if="item.CLO == 'text' " :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-text-odds">{{item.OS}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			<!--  正三  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 2">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in initData[queryCode+'4']" v-if="item.CLO != 'text' " :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-odds ball_code">{{item.OS}}</span>
									</a>
								</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,i,index) in initData[queryCode+'4']" v-if="item.CLO == 'text' " :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-text-odds">{{item.OS}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			<!--  正4  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 3">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in initData[queryCode+'5']" v-if="item.CLO != 'text' " :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-odds ball_code">{{item.OS}}</span>
									</a>
								</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,i,index) in initData[queryCode+'5']" v-if="item.CLO == 'text' " :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-text-odds">{{item.OS}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			<!--  正5  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 4">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in initData[queryCode+'6']" v-if="item.CLO != 'text' " :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-odds ball_code">{{item.OS}}</span>
									</a>
								</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,i,index) in initData[queryCode+'6']" v-if="item.CLO == 'text' " :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-text-odds">{{item.OS}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			<!--  正6  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 5">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in initData[queryCode+'7']" v-if="item.CLO != 'text' " :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-odds ball_code">{{item.OS}}</span>
									</a>
								</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,i,index) in initData[queryCode+'7']" v-if="item.CLO == 'text' " :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-text-odds">{{item.OS}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
			<!--  过关  -->
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 6">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<!--<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in initData1" v-if="item.CLO != 'text' " :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NUM_NAME}}</span>
										<span class="ball-odds">{{item.ODDS}}</span>
									</a>
								</div>-->
								<div class="mui-text-center">正一</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,key,index) in initData1" v-if="key<15" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NUM_NAME}}</span>
										<span class="ball-text-odds">{{item.ODDS}}</span>
									</a>
								</div>
								<div class="mui-text-center">正二</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,key,index) in initData1" v-if="key>=15&&key<30" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NUM_NAME}}</span>
										<span class="ball-text-odds">{{item.ODDS}}</span>
									</a>
								</div>
								<div class="mui-text-center">正三</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,key,index) in initData1" v-if="key>=30&&key<45" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NUM_NAME}}</span>
										<span class="ball-text-odds">{{item.ODDS}}</span>
									</a>
								</div>
								<div class="mui-text-center">正四</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,key,index) in initData1" v-if="key>=45&&key<60" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NUM_NAME}}</span>
										<span class="ball-text-odds">{{item.ODDS}}</span>
									</a>
								</div>
								<div class="mui-text-center">正五</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,key,index) in initData1" v-if="key>=60&&key<75" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NUM_NAME}}</span>
										<span class="ball-text-odds">{{item.ODDS}}</span>
									</a>
								</div>
								<div class="mui-text-center">正六</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,key,index) in initData1" v-if="key>=75" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NUM_NAME}}</span>
										<span class="ball-text-odds">{{item.ODDS}}</span>
									</a>
								</div>

							</div>
						</div>
					</div>
				</section>
			</transition>
		</div>
		<BFooter @handleBet="HandleBet" @handleDelete="deleteSelected" :Value="Value_" :Count='betLenght'></BFooter>
	</div>
</template>

<script>
	import api from '../../../api/lotteryUtil.js';
	import Scroller from '@/components/Scroller';
	import BFooter from '../template/Footer';
	export default {
		components: {
			Scroller,
			BFooter
		},
		data() {
			return {
				b_title: false,
				betLenght: 0,Value_:0,
				betSum: 0,
				betValue: '',queryCode: 'hk6',lotteryID: '27',betCount: 0,myBetArray: {},
				resetBtn: false,
				asideNav: [{
					name: '正一',
					code: 'z1'
				}, {
					name: '正二',
					code: 'z2'
				}, {
					name: '正三',
					code: 'z3'
				}, {
					name: '正四',
					code: 'z4'
				}, {
					name: '正五',
					code: 'z5'
				}, {
					name: '正六',
					code: 'z6'
				}, {
					name: '过关',
					code: 'gg'
				}],
				asideIndex: 0,
				initData: {},
				initData1: {},
				animate: 'slide-out',
				tempIndex: 0,
				betArr: [],ballArray: {},
			}
		},
		mounted() {
			const that = this;
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});

			mui.init();
			mui.ready(function() {

				mui('.nav-warpper').on('tap', '.nav-item', function() {
					that.deleteSelected();
					that.betSum = 0;
					that.betLenght = 0;
					var index = $(this).data('index');
					that.asideIndex = index;
					if(index >= that.tempIndex){
						that.animate = 'slide-out';
					}else{
						that.animate = 'slide-in';
					}
					that.tempIndex = index;
				})

				mui('.section').on('tap', '.ball-item', function() {
					const self = $(this);
					var color = $(this).data('color');
					that.SelectBall(self, color)
					that.betLenght = ($('.select-red').length)+($('.select-green').length)+($('.select-blue').length)+($('.select-text').length);
				})
			})
		},
		created: function() {
			var this_ = this;
			this_.lotteryID = this_.$route.query.id;
			if(this_.logined||lib.WEB_TYPE__=='money'){
				this_.queryCode = this_.$route.query.code;
				this_.initOddsLottery();
			    this_.init();
			}else{
				$.getJSON("static/json/temp/six/zhengmate-show.json", function(data) {
				this_.initData = data;
				this_.init();
			     })
				$.getJSON("static/json/temp/six/guoguan.json", function(data) {
				this_.initData1 = data;
			     })
			}
			
		},
		methods: {
			initOddsLottery() {
				var this_ = this;
				var postData = {
					p_id: this_.$route.query.p3_id,
				};
                var __obj = this_.Temashow; 
			    if(window.localStorage.getItem(this_.lotteryID+'zhengmateArray') != null) {
					var data = eval('(' + window.localStorage.getItem(this_.lotteryID+'zhengmateArray') + ')');
					this_.myBetArray = data;
				} else { 
					api.GetHk6OddsDict2List(function(itemList) {
					    this_.myBetArray = itemList; 
				     }, postData);
				}
				this_.initData[this_.queryCode+'2'] = __obj[this_.queryCode+'2'];
			    this_.initData[this_.queryCode+'3'] = __obj[this_.queryCode+'3'];
			    this_.initData[this_.queryCode+'4'] = __obj[this_.queryCode+'4'];
			    this_.initData[this_.queryCode+'5'] = __obj[this_.queryCode+'5'];
			    this_.initData[this_.queryCode+'6'] = __obj[this_.queryCode+'6'];
			    this_.initData[this_.queryCode+'7'] = __obj[this_.queryCode+'7'];
			    this_.initData[this_.queryCode+'8'] = __obj[this_.queryCode+'8'];
				if(window.localStorage.getItem(this_.lotteryID+'ggArray') != null) {
					var data = eval('(' + window.localStorage.getItem(this_.lotteryID+'ggArray') + ')');
					this_.initData1 = data;
				} else {  
				     api.GetHk6LotGgOddsList(function(itemList) {
						this_.initData1 = itemList
						window.localStorage.setItem(this_.lotteryID+'ggArray', JSON.stringify(itemList));
				     },this_.queryCode);
				} 
			},
			init() {
				var this_ = this;
				this_.ballArray = {};
				//------------正一到正六初始化标题---初始化快捷------------------
				for(var __i in this_.ballArrayName) {
					var __obj = {
						name: this_.ballArrayName[__i],
					};
					var __j = parseInt(__i) + 2;
					this_.ballArray[this_.queryCode + __j] = new Array();
					this_.ballArray[this_.queryCode + __j].push(__obj);
				}
			},
			//绑定球颜色
			bindClass(color) {
				var str = '';
				switch(color) {
					case 'red':
						str = 'select-red';
						break;
					case 'blue':
						str = 'select-blue';
						break;
					case 'green':
						str = 'select-green';
						break;
					default:
						str = 'select-text';
						break;
				}
				return str;
			},
			//选球
			SelectBall(self, color) {
				if(self.hasClass(this.bindClass(color))) {
					self.removeClass(this.bindClass(color))
				} else {
					self.addClass(this.bindClass(color));
				}
			},
			//清除所有选中项
			deleteSelected() {
				this.betValue = '';
				$('.ball-item').attr('class', function(i, cls) {
					return cls.replace(/select-/g, '');
				});
			},
			//点击下注按钮
			HandleBet(val) {
				const that = this;
				var DomList = $('.ball-item');
				this.betSum=val*this.betLenght;
				var obj = {},
					betObj = {};
				that.betArr = [];
				DomList.map(function(index, item) {
					if(item.classList.contains('select-red') || item.classList.contains('select-green') || item.classList.contains('select-blue') || item.classList.contains('select-text')) {
						item = item.getAttribute('data-object');
						item = JSON.parse(item);
						that.myBetArray[item.CE+'_'+(index+1)].ST = true;
					}else{
						item = item.getAttribute('data-object');
						item = JSON.parse(item);
						if(index<76){
							that.myBetArray[item.CE+'_'+(index+1)].ST = false;
						}
					}
				})
				for(var key in that.myBetArray){
					var obj = that.myBetArray[key];
					if(obj.ST) {
						var x = null;
						if(key == that.queryCode+'8_1') {
							x = obj.NM
						}
						betObj = {
								SYS_GAME_LEVEL_CODE_ID: obj.ID,
								SYS_GAME_LEVEL_CODE3_ID: obj.ID3,
								BET_RULE: obj.NAME,
								BET_CONTENT: obj.NM_NE,
								BET_NO: obj.NM,
								ODDS: obj.OS,
								BET_AMT: parseFloat(val),
								CODE: obj.CE,
							    BET_SUB_RULE: x,
						}
						that.betArr.push(betObj);
					}
				}
				if(that.betArr.length > 0) {
					if(parseFloat(val) >= 0) {
						var dispack = {
							IsShow: true,
							title: `当前选中 ${this.betLenght} 注,总下注金额${this.betSum}元`,
							arr: that.betArr,
							type:'hk6'
						}
						this.$store.dispatch('handleBetPour', dispack);
					} else {
						that.$alert('请输入投注金额！');
					}
				} else {
					that.$alert('请选中玩法后投注！');
				}

			}
		},
		computed: {
			logined() {
				return this.$store.getters.checkLoginState;
			},
			Temashow() {
				var this_ = this;
			    var __obj = this_.$store.getters.getTemashow;
			    return  __obj;
			},
		},
		watch: {
			Temashow(){
				var this_ = this;
				this_.lotteryID = this_.$route.query.id;
				this_.queryCode = this_.$route.query.code;
				this_.initOddsLottery();
			    this_.init();
			},
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.temaA-warper,
	.temaB-warper {
		padding: 0.24rem 0 0 0.24rem;
	}
.mui-text-center {
    text-align: center!important;
    padding-bottom: 0.1rem;
}	
	.nav-warpper .select a{
    	color: #ff1a18;
	}
	.ball_code {
    	color: #999999;
	}
	.ball-warper {
	display: inline-block;
    width: 0.8rem;
    height: 0.8rem;
    text-align: center;
    margin-bottom: 0.58rem;
    margin-right: 0.32rem;
		.ball {
			display: inline-block;
			width: 0.80rem;
			height: 0.80rem;
			border: 1px solid #ccc;
			line-height: 0.80rem;
			border-radius: 50%;
			box-sizing: border-box;
			font-size: 0.40rem;
		}
		.ball-color-red {
			border-color: #e52f33;
			color: #e52f33;
		}
		.ball-color-green {
			border-color: #4cbe00;
			color: #4cbe00;
		}
		.ball-color-blue {
			border-color: #2f84e5;
			color: #2f84e5;
		}
		.ball-odds {
			display: block;
			text-align: center;
			font-size: 0.24rem;
			padding-top: 0.01rem;
		}
	}
	
	.select-red {
		.ball {
			background: #e52f33;
			color: #fff;
		}
	}
	
	.select-blue {
		.ball {
			background: #2f84e5;
			color: #fff;
		}
	}
	
	.select-green {
		.ball {
			background: #4cbe00;
			color: #fff;
		}
	}
	
	.select-text {
		background: #e52f33;
		color: #fff;
	}
	.four{
		.ball-warper-text.select-text{
			background: $bgColor !important;
			border:1px solid $warnColor;				
			:after{
				content: '';
				width:0.5rem;
				height: 0.5rem;
				background: url(~static/img/public/pk10/right.png);
				position: absolute;
				right:0;
				top:0;
				background-size:100% auto;
			}
			span{
				color: $warnColor !important;
			}
		}
		/*.ball-warper-text{	
			position: relative;
			width: 1.6rem;		
			height: 1rem;
			padding:0.1rem 0.12rem;
			text-align: center;
			box-sizing: border-box;
			vertical-align: middle;
			border-radius:3px;			
		}*/
	}	
	.ball-warper-text {
		border: 1px solid #ccc;
		border-radius: 4px;
		width: 1.20rem;
/*		height: 1rem;*/
		padding-top: 0.1rem;
		margin-right: 0.18rem;
		text-align: center;
		display: inline-block;
		font-size: 0.28rem;
		margin-bottom: 0.16rem;
		position: relative;
		.ball-text {
			display: block;
			/*padding-top: 0.11rem;*/
			text-align: center;
			color: #333;
			font-size: 0.32rem;
			font-weight: 600;
		}
	}
.ball-text-odds{
    font-size: 0.28rem;
    color: #666;
}	
	#temaA {
		display: flex;
		flex-direction: column;
		.tema-main {
			flex: 1;
			display: flex;
			.aside {
				width: 1.6rem;
				background: #efeff4;
				position: relative;
			}
			.section {
				flex: 1;
				position: relative;
				background: #fff;
			}
		}
	}
	
	.b_title {
		font-size: .28rem;
		color: $blackColor;
		position: relative;
		z-index: 3;
		.b_title_main {
			background: $tipsFontColor;
			height: .5rem;
			position: absolute;
			width: 100%;
			top: -.5rem;
		}
		.b_text {
			padding-top: .05rem;
		}
	}
	.nav-warpper {
		width: 100%;
		padding: 0.24rem 0;
		li {
			padding: 0.22rem 0;
			position: relative;
			border-top: 1px solid #eeeeee;
			&:before {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: #cccccc;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #777777 inset;
			}
			a {
				font-size: 0.28rem;
			}
		}
		.select {
			background: #fff;
			&:after {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: red;
				border-radius: 50%;
				position: absolute;
				left: 0.1rem;
				top: 0.12rem;
				box-shadow: 1px 1px 0px 0px #8e0807 inset;
			}
		}
	}
	
</style>