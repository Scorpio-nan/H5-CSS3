<template>
	<div id="temaA">
		<div class="tema-main">
			<transition :name="animate">
				<section class="section" v-show="asideIndex == 0">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="temaA-warper">
								<div class="mui-text-center">
									<a href="javascript:;" class="ball-item ball-warper" v-for="(item,i,index) in myBetArrayShow" v-if="item.CLO != 'text'" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-odds">{{item.OS}}</span>
									</a>
								</div>
								<div class="mui-text-center four">
									<a href="javascript:;" class="ball-item ball-warper-text ball_code" v-for="(item,i,index) in myBetArrayShow" v-if="item.CLO == 'text'" :data-color="item.CLO" :data-object="JSON.stringify(item)">
										<span class="ball-text" :class="'ball-color-' + item.CLO">{{item.NM_NE}}</span>
										<span class="ball-text-odds">{{item.OS}}</span>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
		</div>
		<BFooter @handleBet="HandleBet" @handleDelete="deleteSelected" :Value="Value_" :Count='betLenght'></BFooter>
	</div>
</template>

<script>
	import api from '../../../api/lotteryUtil.js';
	import Scroller from '@/components/Scroller';
	import BFooter from '../template/Footer';
	export default {
		components: {
			Scroller,
			BFooter
		},
		data() {
			return {
				currPeriodsNo: '20170000000',
				queryCode: 'hk6',
				queryName: '',
				lotteryID: '36',
				betCount: 0,
				b_title: false,
				betLenght: 0,Value_:0,
				betSum: 0,
				betValue: '',
				resetBtn: false,
				asideNav: [{
					name: '总和',
					code: 'zh'
				}],
				asideIndex: 0,
				myBetArrayShow: {},
				animate: 'slide-in',
				tempIndex: 0,
				betArr: [],myBetArray: {},
			}
		},
		created: function() {
			var this_ = this;
			this_.lotteryID = this_.$route.query.id;
			if(this_.logined||lib.WEB_TYPE__=='money'){
				this_.queryCode = this_.$route.query.code;
				this_.initOddsLottery();
			}else{
				$.getJSON("static/json/temp/six/zhonghe-show.json", function(data) {
				this_.myBetArrayShow = data[this_.queryCode+'11'];
				 })
			}
		},
		mounted() {
			const that = this;
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});

			mui.init();
			mui.ready(function() {

				mui('.nav-warpper').on('tap', '.nav-item', function() {
					var index = $(this).data('index');
					that.asideIndex = index;
				})

				mui('.section').on('tap', '.ball-item', function() {
					const self = $(this);
					var color = $(this).data('color');
					that.SelectBall(self, color)
					that.betLenght = ($('.select-red').length)+($('.select-green').length)+($('.select-blue').length)+($('.select-text').length);
				})

			})
		},
		methods: {
			initOddsLottery() {
				var this_ = this;
				var postData = {
					p_id: this_.$route.query.p3_id,
					p3_id: '',
				};
               if(window.localStorage.getItem(this_.lotteryID+'zongheArray') != null) {
					var data = eval('(' + window.localStorage.getItem(this_.lotteryID+'zongheArray') + ')');
					this_.myBetArray = data;
				} else { 
				     api.GetHk6OddsDict2List(function(itemList) {
						this_.myBetArray = itemList;
						window.localStorage.setItem(this_.lotteryID+'zongheArray', JSON.stringify(itemList));
					 }, postData);
				} 
				 
                  var __obj = this_.Temashow[this_.queryCode+'11'];
                   this_.myBetArrayShow=__obj;
			},
			init() {
				const that = this;
				$.getJSON('static/json/temp/six/zhonghe-show.json', function(res) {
					that.myBetArrayShow = res;
				})
			},
			//绑定球颜色
			bindClass(color) {
				var str = '';
				switch(color) {
					case 'red':
						str = 'select-red';
						break;
					case 'blue':
						str = 'select-blue';
						break;
					case 'green':
						str = 'select-green';
						break;
					default:
						str = 'select-text';
						break;
				}
				return str;
			},
			//选球
			SelectBall(self, color) {
				if(self.hasClass(this.bindClass(color))) {
					self.removeClass(this.bindClass(color))
				} else {
					self.addClass(this.bindClass(color));
				}
			},
			//清除所有选中项
			deleteSelected() {
				this.betLenght = 0;
				$('.ball-item').attr('class', function(i, cls) {
					return cls.replace(/select-/g, '');
				});
			},
			//点击下注按钮
			HandleBet(val) {
				const that = this;
				this.betSum=val*this.betLenght;
				var DomList = $('.ball-item');
				var obj = {},
					betObj = {};
				that.betArr = [];
				DomList.map(function(index, item) {
					if(item.classList.contains('select-red')|| item.classList.contains('select-green') || item.classList.contains('select-blue') || item.classList.contains('select-text')) {
						obj = item.getAttribute('data-object');
						obj = JSON.parse(obj);
						betObj = {
							SYS_GAME_LEVEL_CODE_ID: obj.ID,
							SYS_GAME_LEVEL_CODE3_ID: obj.ID3,
							PERIODS_NO: that.currPeriodsNo,
							BET_RULE: obj.NAME,
							BET_CONTENT: obj.NM_NE,
							BET_NO: obj.NM,
							ODDS: obj.OS,
							BET_AMT: parseFloat(val),
							CODE: obj.CE,
						}
						that.betArr.push(betObj);
					}
				})
				
				if(that.betArr.length > 0){
					if(parseFloat(val) >= 0){
						var dispack = {
							IsShow:true,
							title:`当前选中 ${this.betLenght}注,总下注金额${this.betSum}元`,
							arr:that.betArr,
							type:'hk6'
						}
						this.$store.dispatch('handleBetPour',dispack);
					}else{
						that.$alert('请输入投注金额！');
					}
				}else{
					that.$alert('请选中玩法后投注！');
				}
				
			}
		},
		computed: {
			logined() {
				return this.$store.getters.checkLoginState;
			},
			Temashow() {
				var this_ = this;
			    var __obj = this_.$store.getters.getTemashow;
			    return  __obj;
			},
		},
		watch: {
			Temashow(){
				var this_ = this;
				this_.queryCode = this_.$route.query.code;
				this_.initOddsLottery();
			},
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.temaA-warper,
	.temaB-warper {
		padding: 0.2rem 0;
	}
.ball_code{
    color: #999999;
}		
	.ball-warper {
		display: inline-block;
		width: 1.1rem;
		height: 1rem;
		text-align: center;
		margin-bottom: 0.2rem;
		.ball {
			display: inline-block;
			width: 0.71rem;
			height: 0.71rem;
			border: 1px solid #ccc;
			line-height: 0.71rem;
			border-radius: 50%;
			box-sizing: border-box;
		}
		.ball-color-red {
			border-color: #e52f33;
			color: #e52f33;
		}
		.ball-color-green {
			border-color: #4cbe00;
			color: #4cbe00;
		}
		.ball-color-blue {
			border-color: #2f84e5;
			color: #2f84e5;
		}
		.ball-odds {
			display: block;
			text-align: center;
			font-size: 0.24rem;
		}
	}
	
	.select-red {
		.ball {
			background: #e52f33;
			color: #fff;
		}
	}
	
	.select-blue {
		.ball {
			background: #2f84e5;
			color: #fff;
		}
	}
	
	.select-green {
		.ball {
			background: #4cbe00;
			color: #fff;
		}
	}
	
	.select-text {
		background: #e52f33;
		color: #fff;
	}
	.four{
		.ball-warper-text.select-text{
			background: $bgColor !important;
			border:1px solid $warnColor;				
			:after{
				content: '';
				width:0.5rem;
				height: 0.5rem;
				background: url(~static/img/public/pk10/right.png);
				position: absolute;
				right:0;
				top:0;
				background-size:100% auto;
			}
			span{
				color: $warnColor !important;
			}
		}
		.ball-warper-text{	
			position: relative;
			width: 1.6rem;		
			height: 1rem;
			padding:0.1rem 0.12rem;
			text-align: center;
			box-sizing: border-box;
			vertical-align: middle;
			border-radius:3px;			
		}
	}	
	.ball-warper-text {
		border: 1px solid #ccc;
		border-radius: 4px;
		width: 1.20rem;
		height: 1rem;
		margin-right: 0.18rem;
		text-align: center;
		display: inline-block;
		font-size: 0.28rem;
		margin-bottom: 0.1rem;
		.ball-text {
			display: block;
			/*padding-top: 0.11rem;*/
			text-align: center;
			font-size: 0.32rem;
			font-weight: 600;
			color: #333;
		}
	}
.ball-text-odds{
    font-size: 0.28rem;
    color: #666;	
}	
	#temaA {
		display: flex;
		flex-direction: column;
		.tema-main {
			flex: 1;
			display: flex;
			.aside {
				width: 1.6rem;
				background: #efeff4;
				position: relative;
			}
			.section {
				flex: 1;
				position: relative;
				background: #fff;
			}
		}
	}
	
	.b_title {
		font-size: .28rem;
		color: $blackColor;
		position: relative;
		z-index: 3;
		.b_title_main {
			background: $tipsFontColor;
			height: .5rem;
			position: absolute;
			width: 100%;
			top: -.5rem;
		}
		.b_text {
			padding-top: .05rem;
		}
	}
	
	.nav-warpper {
		width: 100%;
		padding: 0.24rem 0;
		li {
			padding: 0.16rem 0;
			position: relative;
			&:before {
				display: block;
				content: '';
				width: 100%;
				height: 100%;
				border-bottom: 1px solid #fff;
				position: absolute;
				transform: scaleY(0.5);
			}
			a {
				font-size: 0.28rem;
			}
		}
		.select {
			background: #fff;
			&:after {
				content: '';
				display: block;
				width: 0.15rem;
				height: 0.15rem;
				background: #e52f33;
				border-radius: 50%;
				position: absolute;
				left: 0.18rem;
				top: 0.18rem;
			}
		}
	}
	
	.slide-in-enter-active {
		animation: slide-in .25s;
	}
	
	.slide-out-leave-active {
		animation: slide-out .25s;
	}
	
	@keyframes slide-in {
		from {
			transform: translate3d(-100%, 0, 0);
		}
		to {
			transform: translate3d(0, 0, 0);
		}
	}
	
	@keyframes slide-out {
		from {
			transform: translate3d(0, 0, 0);
		}
		to {
			transform: translate3d(-100%, 0, 0);
		}
	}
	
</style>