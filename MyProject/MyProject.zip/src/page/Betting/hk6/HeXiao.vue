<template>
	<div id="hexiao">
		<div class="tema-main">
			<!--  合肖  -->
			<transition :name="animate">
				<section class="section">
					<div class="mui-scroll-wrapper" id="Scroll-warper">
						<div class="mui-scroll">
							<div class="ball-title" id>
								赔率:<span color="red" id="hexiaoOdds">0.0</span>
							</div>
							<div class="row-bet ball-item" v-for="(item,key) in AnimalArray" v-bind:class="'hh'+key" :data-key="key" :data-object="JSON.stringify(item)">
								<div class="ball-warper">
									<div class="list_op">
										<span class="ball-odds">{{key}}</span>
									</div>
									<span class="ball" :class="'ball-color-' +numColors[ball]" v-for="ball in AnimalArray[key]">{{ball}}</span>
								</div>
							</div>
						</div>
					</div>
				</section>
			</transition>
		</div>
		<BFooter @handleBet="HandleBet" @handleDelete="deleteSelected" :Value="Value_" :Count='betLength'></BFooter>
	</div>
</template>

<script>
	import Scroller from '@/components/Scroller';
	import BFooter from '../template/Footer';
	import api from '../../../api/lotteryUtil.js';
	export default {
		components: {
			Scroller,
			BFooter
		},
		name: 'hexiao',
		data() {
			return {
				queryName: '',
				lotteryID:'',
				Value_:0,
				betSum: 0,
				betAryLength: 0,
				betLength: 0,
				betOdds: 0,
				resetBtn: false,
				currPeriodsNo: '20170000000',
				animate: 'slide-in',
				tempIndex: 0,
				betArr: [],
				queryCode: 'hk6',
				numColors:{},
				AnimalArray:{},
//			    HXAShowArray: {},
				checkedGroupArray: [], //合肖选中 存储数组
			}
		},
		mounted() {
			this.Value_+=1;
			const that = this;
			this.init();
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});
			mui.init();
			mui.ready(function() {
				mui('.section').on('tap', '.ball-item', function() {
					const self = $(this);
					var color = $(this).data('color');
					var key = $(this).data('key');
					that.SelectBall(self, color);
					if(key != undefined) {
						that.onBallClick($(this).data('key'))
					};
					if($('.select-text').length>=2){
						that.betLength = 1;
					}
					
				})

			})
		},
		created: function() {
			this.init();
		},
		methods: {
			initOddsLottery() {
				var this_ = this;
				var postData = {
					p_id: this_.$route.query.p3_id,
					p3_id: '',
				};

				if(window.localStorage.getItem('AnimalArray') != null) {
					var data = eval('(' + window.localStorage.getItem('AnimalArray') + ')');
					this_.AnimalArray = data;
				} else {
					api.hk6animal(function(itemList) {
						this_.AnimalArray = itemList;
					});
				}
				//新增球的颜色数组 --加入缓存
				if(window.localStorage.getItem('numColors') != null) {
					var data = eval('(' + window.localStorage.getItem('numColors') + ')');
					this_.numColors = data;
				} else {
					api.hk6Color(function(itemList) {
						this_.numColors = itemList;
					});
				}
			},
			init() {
				var this_ = this;
				this_.queryCode = this_.$route.query.code;
				this_.queryName = this_.$route.query.name;
				this_.lotteryID = this_.$route.query.id;
				this_.initOddsLottery();
			},
			//绑定球颜色
			bindClass(color) {
				var str = '';
				switch(color) {
					case 'red':
						str = 'select-red';
						break;
					case 'blue':
						str = 'select-blue';
						break;
					case 'green':
						str = 'select-green';
						break;
					default:
						str = 'select-text';
						break;
				}
				return str;
			},
			//选球
			SelectBall(self, color) {
				if(self.hasClass(this.bindClass(color))) {
					self.removeClass(this.bindClass(color))
				} else {
					self.addClass(this.bindClass(color));
				};
			},
			//清除所有选中项
			deleteSelected() {
				this.betAryLength = 0;
				$('.ball-item').attr('class', function(i, cls) {
					return cls.replace(/select-/g, '');
				});
			},
			onBallClick(key) { //合肖選中和取消选中模式
				var that = this;
				var hx = that.HXAShowArray;
				var ballhh = $('.hh' + key);
				var length = 0;
				that.checkedGroupArray = [];
				if(ballhh.hasClass('bet-choose')) {
					ballhh.removeClass('bet-choose');
					ballhh.addClass('row-bet');
				} else {
					ballhh.removeClass('row-bet');
					ballhh.addClass('bet-choose' );
				}
				for(var key in that.AnimalArray) {
					var ball = $('.hh' + key);
					if(ball.hasClass('bet-choose')) {
						length++;
					}
				}
				that.betAryLength = length;
				if(length == 12) { //选中12弹出验证
					that.$alert('亲，最多只能选中11个生肖哦！');
					ballhh.removeClass('row-bet');
					return;
				}
				if(length >= 2) {
					for(var key in that.AnimalArray) {
						var ball = $('.hh' + key);
						if(ball.hasClass('bet-choose')) {
							that.checkedGroupArray.push(key);
						}
					}
					that.betAryLength = that.checkedGroupArray.length;
					var odds = hx[that.queryCode + '15_' + (length - 1)].OS;
					that.betOdds = odds;
					$('#hexiaoOdds').text(odds);
				} else {
					$('#hexiaoOdds').text('0.0');
				}
			},
			HandleBet(val) {
				const that = this;
				if(!that.logined) {
					mui.alert('请登录');
					return;
				}
//				if(!that.myBetMode) {
//					mui.alert('已封盘', 'warn');
//					return;
//				}
				if(this.betAryLength<2){
					mui.alert('最少选择2个生肖!');
					return;
				}
				var DomList = $('.ball-item');
				var hx = that.HXAShowArray;
				var obj = hx[that.queryCode + '15_' + (that.betAryLength - 1)];
				var __bet_no = that.checkedGroupArray;
				__bet_no = JSON.stringify(__bet_no);
				that.betSum = parseFloat(val);
				that.betArr = [];
				var betObj = {
					SYS_GAME_LEVEL_CODE_ID: obj.ID,
					SYS_GAME_LEVEL_CODE3_ID: obj.ID3,
					PERIODS_NO: that.currPeriodsNo,
					BET_RULE: obj.NAME,
					BET_CONTENT: __bet_no,
					BET_NO: __bet_no,
					ODDS: that.betOdds,
					BET_AMT: parseFloat(val),
					WIN: 0,
					CODE: obj.CE,
					BET_SUB_RULE: obj.NM_NE,
				}
				that.betArr.push(betObj);
				
				if(that.betArr.length > 0) {
					if(parseFloat(val) >= 0) {
						var dispack = {
							IsShow: true,
//							title: `当前选中 ${this.betAryLength} 注,总下注金额${this.betSum}元`,
							title: `当前选中 ${1} 注,总下注金额${this.betSum}元`,
							arr: that.betArr,
							type:'hk6'
						}
						this.$store.dispatch('handleBetPour', dispack);
					} else {
						that.$alert('请输入投注金额！');
					}
				} else {
					that.$alert('请选中玩法后投注！');
				}
			},
		},
		computed: {
			logined() {
				return this.$store.getters.checkLoginState;
			},
			HXAShowArray() {
				var this_ = this;
				var __obj = this_.$store.getters.getTemashow[this_.queryCode+'15'];
				return __obj;
			},
		},
		watch: {
			HXAShowArray(){
				this.init();
			},
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	#hexiao {
		display: flex;
		flex-direction: column;
		.tema-main {
			flex: 1;
			display: flex;
			.section {
				flex: 1;
				position: relative;
				background: #fff;
			}
		}
	}
	.mui-scroll{
		padding-bottom: 0.24rem;
	}
	.ball-title {
		padding: 0.2rem 0rem;
	}
	
	.ball-warper {
    display: table;
    margin: 0 auto;
    font-size: 0.28rem;
    text-align: center;
    padding: 0.1rem 0;
    width: 6rem;
		.ball {
			display: inline-block;
			width: 0.80rem;
			height: 0.80rem;
			border: 1px solid #ccc;
			line-height: 0.80rem;
			border-radius: 50%;
			box-sizing: border-box;
			margin: 0rem 0.1rem;
			text-align: center;
			font-size: 0.40rem;
			float: left;
		}
		.ball-color-red {
			border-color: #e52f33;
			color: #e52f33;
		}
		.ball-color-green {
			border-color: #4cbe00;
			color: #4cbe00;
		}
		.ball-color-blue {
			border-color: #2f84e5;
			color: #2f84e5;
		}
		.ball-odds {
			display: inline-block;
			padding-left: 2px;
			font-size: 0.28rem;
			color: #666;
			width: 35px;
		}
	}
.ball-item{
	@include border-1px($bgColor, bottom);
}	
	.select-text {
		background: #f2f2f2;
		@include border-1px(#ccc, bottom);
		.ball-color-red {
			background: #e52f33;
			color: #fff;
		}
		.ball-color-green {
			background: #4cbe00;
			color: #fff;
		}
		.ball-color-blue {
			background: #2f84e5;
			color: #fff;
		}
	}
	
	.slide-in-enter-active {
		animation: slide-in .25s;
	}
	
	.slide-out-leave-active {
		animation: slide-out .25s;
	}
	
	@keyframes slide-in {
		from {
			transform: translate3d(-100%, 0, 0);
		}
		to {
			transform: translate3d(0, 0, 0);
		}
	}
	
	@keyframes slide-out {
		from {
			transform: translate3d(0, 0, 0);
		}
		to {
			transform: translate3d(-100%, 0, 0);
		}
	}
	.list_op{
		padding-right: 0.1rem;
    	float: left;
		padding-top: 0.2rem;
	}	
</style>