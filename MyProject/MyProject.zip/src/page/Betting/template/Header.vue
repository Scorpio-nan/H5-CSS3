<template>
	<div id="Header">
		<div class="header-top">
			<div class="time-container">
				<p class="title-left mui-text-left padding-top-3">开奖号码</p>
				<p class="title-left font-weight mui-text-left"><span class="colorInherit">{{ (Array(4).join('') + openInfo.expect).slice(-6)}}</span>期</p>
			</div>
			<div class="ball-container mui-text-left">
				<div class="disLine" v-if="ballType =='hk6'" v-for="(item,key) in openInfo.ballArr">
					<span v-if="key<6" :class="'ball ball-color-'+numColors[parseInt(item)]">{{parseInt(item)}}</span>
					<a v-if="key==6" class="mui-icon mui-icon-plusempty addfonts"></a>
					<span v-if="key==6" :class="'ball ball-color-'+numColors[parseInt(item)]">{{parseInt(item)}}</span>
				</div>
				<div class="inlineBlockItem">
					<span v-if="ballType == 'cp'" class="ball item" v-for="(item,i) in openInfo.ballArr">{{item}}</span>
					<span class="item" v-if="ballType == 'k3'" :class="'kuaisan-' + item" v-for="(item,i) in openInfo.ballArr">{{item}}</span>
					<span class="item" v-if="ballType == 'pk10'" :class="'pk10-' + item" v-for="(item,i) in openInfo.ballArr">{{item}}</span>
					<span class="item" v-if="ballType == 'mlaft'" :class="'mlaft-' + item" v-for="(item,i) in openInfo.ballArr">{{item}}</span>
				</div>
				<div class="tag-con">
					<span v-for="(item,i) in openInfo.tagArr" class="zhiti" :class="i==6?nobr:''" >
						<a v-if="i<6">{{item}}</a>
						<i v-if="i==6"  class="dongwu mui-icon mui-icon-plusempty addfonts"></i>
						<a v-if="i==6" >{{item}}</a>
					</span>
					<a href="javascript:;" class="openVideo mui-pull-right"><span class="iconfont icon-icon-84"></span></a>
				</div>
			</div>
		</div>

		<div class="header-bottom mui-clearfix">
			<div class="time-container">
				<p class="pull-left timeClose-container mui-text-left"><span class="colorInherit">{{(Array(4).join('') + openInfo.Nextexpect).slice(-6)}}</span>期</p>
			</div>
			<div class="close-time mui-pull-left">
				<p class="mui-pull-left pull-right"><span style="color: #666;font-weight: bold; ">封盘&nbsp;&nbsp;</span>{{openInfo.closeTimeText}}</p>
			</div>
			<div class="close-time mui-pull-left" v-if="GameType.code !='hk6'">
				<p class="pull-left">开奖&nbsp;&nbsp;</p>
				<p class="mui-pull-left pull-right">{{openInfo.ResultTimeText}}</p>
			</div>
			<a href="javascript:;" class="history"><span class="iconfont icon-icon-83"></span>历史开奖</a>
		</div>

		<div class="historyContainer">
			<div class="mui-scroll-wrapper">
				<div class="mui-scroll">
					<table border="0" cellspacing="0" cellpadding="0">
						<thead>
							<tr>
								<th width="30%">期数</th>
								<th width="70%">开奖号码</th>
							</tr>
						</thead>
						<tbody>
							<tr v-for="(item,index) in openResult">
								<td>第{{item.periods}}期</td>
								<td>
									<div class="disLine" v-if="ballType =='hk6'" v-for="(item,key) in item.ball">
										<span v-if="key<6" :class="'ball ball-color-'+numColors[parseInt(item)]">{{parseInt(item)}}</span>
										<a v-if="key==6" style="color:#bebbbb">+</a>
										<span v-if="key==6" :class="'ball ball-color-'+numColors[parseInt(item)]">{{parseInt(item)}}</span>
									</div>
									<span v-if="ballType == 'cp'" class="ball" v-for="(val,key) in item.ball">{{val}}</span>
									<span v-if="ballType == 'k3'" :class="'kuaisan-' + item" v-for="(item,i) in item.ball">{{item}}</span>
									<span v-if="ballType == 'pk10'" :class="'pk10-' + item" v-for="(item,i) in item.ball">{{item}}</span>
									<span v-if="ballType == 'mlaft'" :class="'mlaft-' + item" v-for="(item,i) in item.ball">{{item}}</span>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<div class="shadow"></div>
		</div>
	</div>
</template>

<script>
	var window_TimeCountDown;
	var window_closeTime;
	import api from '@/api/lotteryUtil.js';
	export default {
		name: 'Header',
		props: {
			sy: {
				type: Boolean,
				default: false
			},
			data: Object,

		},
		data() {
			return {
				nobr:'nobr',
				openInfo: {
					expect: '2017091', //第几期
					Nextexpect: '2017092', //第几期
					closeTime: 10,
					ResultTime: 60,
					closeTimeText: '',
					ResultTimeText: '',
					ballArr: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10'], //开奖号码
					tagArr: ['16', '小', '双', '龙', '牛6', '一对'],
				},
				cuttimeMusic: 'static/img/music/cuttime.mp3',
				staringMusic: 'static/img/music/staring.mp3',
				TriEvent: true,
				flag: true,
				openResult: [],
				ws: {
					readyState: 0
				}, //
				wsUrl: lib.WebSocketUrl,
				numColors: {},
			}
		},
		created() {
			const that = this;
			this.init();
			this.GetTicTime();
			this.GetLotteryData_DB();
		},
		mounted() {
			const that = this;
			//新增球的颜色数组 --加入缓存
			if(window.localStorage.getItem('numColors') != null) {
				var data = eval('(' + window.localStorage.getItem('numColors') + ')');
				that.numColors = data;
			} else {
				api.hk6Color(function(itemList) {
					that.numColors = itemList;
					window.localStorage.setItem('numColors', JSON.stringify(itemList));
				});
			}
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});
			mui.init();
			mui.ready(function() {

				//点击历史开奖弹出菜单
				mui('.header-bottom').on('tap', '.history', function() {
					if(that.flag) {
						$('.historyContainer').slideDown(250);
					} else {
						$('.historyContainer').slideUp(250);
					}
					that.flag = !that.flag;
				})
			})
		},
		methods: {
			Onmessage(data) {
				var this_ = this;
				if(data.Type == 'OpenTime') {
					this_.openInfo.Nextexpect = data.PERIODS_NO;
					this_.openInfo.closeTime = data.SEALING_SEC;
					this_.openInfo.ResultTime = data.NEXT_SEC;
				} else if(data.Type == 'LotteryData') {
					if(this_.openInfo.expect != data.Expect) { //如果期数变了
						this_.openInfo.ballArr = data.Opencode.split(',');
						var obj = {
							periods: data.Expect,
							ball: data.Opencode.split(',')
						}
						this_.openResult.unshift(obj);
						this_.openResult.pop();
						this_.openInfo.tagArr = data.Code.split(',');
						this_.openInfo.expect = data.Expect;
					}
				}
			},
			SocketConnect() {
				var that = this;
				var IsSupport = false;
				if(that.wsUrl == 'false'){
					return;
				}
				if("WebSocket" in window) {
					that.ws = new WebSocket(that.wsUrl);
					IsSupport = true;
				} else if("MozWebSocket" in window) {
					that.ws = new MozWebSocket(that.wsUrl);
					IsSupport = true;
				}
				if(IsSupport) {
					that.ws.onopen = function() {
						that.ws.send('fun=opentime&game_id=' + that.GameType.id);
						that.ws.send('fun=lotterydata&p_id=' + that.GameType.id +'&code='+ that.GameType.code );
					};
					that.ws.onmessage = function(event) {
						that.Onmessage(JSON.parse(event.data));
					};
				}
			},
			init() {
				//初始化，倒计时
				var this_ = this;
				window_TimeCountDown = setInterval(function() {
					this_.openInfo.closeTime--;
					this_.openInfo.ResultTime--;
					if(this_.openInfo.closeTime <= 0) {
						this_.openInfo.closeTimeText = '已封盘';this_.$store.commit('Sealing',true);
					} else {
						this_.openInfo.closeTimeText = this_.$Utils.myTimeStamp(this_.openInfo.closeTime);this_.$store.commit('Sealing',false)
						if(this_.openInfo.closeTime < 10 && this_.openInfo.closeTime >= 0) {
							this_.onPlay(this_.cuttimeMusic);
						} else {
							clearInterval(window_closeTime);
						}
					};
					if(this_.openInfo.ResultTime <= 0) {
						if(this_.openInfo.ResultTime == 0) {
							this_.onPlay(this_.staringMusic);
						}
						this_.openInfo.ResultTimeText = '正在开奖'
						//						this_.setOpenStyle(this_.GameType.code);
					} else {
						this_.openInfo.ResultTimeText = this_.$Utils.myTimeStamp(this_.openInfo.ResultTime)
					}
				}, 1000)
			},
			onPlay(__src) {
				var this_ = this;
				if(this.voioe) {
					var bgMusic = document.getElementById('aplayMusic_cuttime');
					bgMusic.setAttribute('src', __src)
					if(bgMusic.paused) {　　　　
						bgMusic.play();　　
					} else {　　　　
						bgMusic.pause();　　
					}
				}
			},
			GetTicTime() { //获取开盘时间 更新openInfo（开盘信息）--后期websocket 可以在这个方法做判断；
				var this_ = this;
				api.getTicTime(function(_ticTime) { //websocket 不支持的时候
					if(_ticTime.state == 'error') {
						//						console.log('网络链接错误')
					} else {
						if(_ticTime.EFF_IND === '0') {
							//提示并跳转热门游戏
						} else {
							this_.openInfo.Nextexpect = _ticTime.PERIODS_NO;
							this_.openInfo.closeTime = _ticTime.SEALING_SEC;
							this_.openInfo.ResultTime = _ticTime.NEXT_SEC;
						}
					}
				}, this_.GameType.id, this_.GameType.code);

			},
			GetLotteryData_DB() {
				var this_ = this;
				api.GetLotteryData_DB(function(resultNo) {
					resultNo = JSON.parse(resultNo);
					if(resultNo.state == 'error') {} else {
						if(this_.openInfo.expect != resultNo.Expect) { //如果期数变了
							this_.openInfo.ballArr = resultNo.Opencode.split(',');
							var obj = {
								periods: resultNo.Expect,
								ball: resultNo.Opencode.split(',')
							}
							this_.openResult.unshift(obj);
							this_.openResult.pop();
						}
						this_.openInfo.tagArr = resultNo.Code.split(',');
						this_.openInfo.expect = resultNo.Expect;
					}
				}, this_.GameType.id, this_.GameType.code);

			},
			//获取彩票开奖前10期
			getHistoryRsult() {
				var param = {
					game_id: this.data.id,
					rpt_date: new Date().Format('yyyy-MM-dd'),
					top: 10
				}
				this.openResult = [];
				api.GetWinResult(res => {
					res.forEach((ele, index, arr) => {
						var obj = {
							periods: ele.PERIODS_NO,
							ball: ele.OPEN_CODE.split(',')
						}
						this.openResult.push(obj);
					})
				}, param)
			},
			//开奖效果
			setOpenStyle(tcode) {
				var this_ = this;
				if(this_.openInfo.ResultTime <= 0) {
					// 开奖效果
					var _openStyle = setInterval(function() {
						var t = Math.random() + '';
						if(tcode == 'bjpk10' || tcode == 'jspk10') {
							this_.openInfo.ballArr = [parseInt(t.substr(2, 1)) + 1, parseInt(t.substr(3, 1)) + 1, parseInt(t.substr(4, 1)) + 1, parseInt(t.substr(5, 1)) + 1, parseInt(t.substr(6, 1)) + 1, parseInt(t.substr(7, 1)) + 1, parseInt(t.substr(8, 1)) + 1, parseInt(t.substr(9, 1)) + 1, parseInt(t.substr(10, 1)) + 1, parseInt(t.substr(11, 1)) + 1];
						} else if(tcode == 'gdklsf' || tcode == 'tjklsf' || tcode == 'cqklsf') {
							this_.openInfo.ballArr = [t.substr(2, 1), t.substr(3, 1), t.substr(4, 1), t.substr(5, 1), t.substr(6, 1), t.substr(7, 1), t.substr(8, 1), t.substr(9, 1)];
						} else if(tcode.indexOf('k3') >= 0) {
							this_.openInfo.ballArr = [parseInt(t.substr(2, 1) / 2) + 2, parseInt(t.substr(3, 1) / 2) + 1, parseInt(t.substr(4, 1) / 2) + 2];
						} else {
							this_.openInfo.ballArr = [t.substr(2, 1), t.substr(3, 1), t.substr(4, 1), t.substr(5, 1), t.substr(6, 1)];
						}
						if(!this_.isOpen) {
							clearInterval(_openStyle)
						}

					}, 300)
				};
			},
		},

		beforeDestroy() {
			var this_ = this;
			clearInterval(window_TimeCountDown);
			if(this_.ws.readyState == 1){
				this_.ws.close();
			}
		},
		computed: {
			GameType() {
				return this.data;
			},
			voioe() {
				return this.sy
			},
			W_ResultTime() { //监听开奖时间，小于0的时候更新一次开奖时间
				return this.openInfo.ResultTime;
			},
			//判断球类型显示不同的样式
			ballType() {
				if(this.data.code.includes('k3')) {
					return 'k3';
				} else if(this.data.code.includes('pk10')) {
					return 'pk10';
				} else if(this.data.code.includes('mlaft')) {
					return 'mlaft'
				} else if(this.data.code.includes('hk6')) {
					return 'hk6'
				} else {
					return 'cp';
				}
			},
		},
		watch: {
			GameType(val) { //watch 游戏类型
				var this_ = this;
				if(this_.ws.readyState == 1) {
					this_.ws.send('fun=opentime&game_id=' + val.id);
					this_.ws.send('fun=lotterydata&p_id=' + val.id +'&code='+ val.code );
				} else {
					if(this_.ws.readyState != 3) { //websocket 不可用 不需要重新连接
						this_.SocketConnect();
					}
					this_.GetTicTime();
					this_.GetLotteryData_DB();
				}
				setTimeout(() => {
					this_.getHistoryRsult();
				}, 1500)
			},
			W_ResultTime(val) {
				var this_ = this;
				if(val < -2 && this_.TriEvent && this_.ws.readyState != 1) { //防止多刷接口 刷新开盘时间的
					this_.TriEvent = false;
					this_.GetTicTime();
					setTimeout(() => {
						this_.TriEvent = true;
					}, 3000)
				};
				var Periods_dif = this_.openInfo.Nextexpect - this_.openInfo.expect;
				var z = val % 3 //是否能被三整除
				if(Periods_dif > 1 && Periods_dif < 50 && z == 0 && this_.ws.readyState != 1) { //开奖期数大于1，50是保证跨天的时候 不要一直刷开奖结果接口。
					this_.GetLotteryData_DB();
				}

			},
		}
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	#Header {
		/*height: 2.08rem;*/
	}
	
	.time-container {
		width: 20%;
		.timeClose-container {
			font-size: 0.24rem;
			font-weight: 600;
			color: #333;
			vertical-align: middle;
			transform: translateY(2px);
		}
		.padding-top-3 {
			padding-top: 3px;
		}
	}
	
	.openVideo {
		span {
			&:after {
				display: none !important;
			}
			color:$blueColor !important;
			font-size:0.4rem !important;
			margin: 0 !important;
			padding: 0 !important;
			vertical-align: -2px !important;
		}
	}
	
	.ballShow {
		display: inline-block;
		width: 0.46rem;
		height: 0.46rem;
		line-height: 0.46rem;
		text-align: center;
		margin-right: 0.08rem;
		font-size: 0;
	}
	
	.inlineBlockItem {
		margin-top: -2px;
	}
	
	.colorInherit {
		color: $blueColor !important;
	}
	
	.ball {
		background: red;
		border-radius: 50%;
		color: #fff;
		@extend .ballShow;
		font-size: 0.28rem;
	}
	/*******  快三系列  *******/
	
	.kuaisan-1 {
		@extend .ballShow;
		background: url('~static/img/public/k3/1.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.kuaisan-2 {
		@extend .ballShow;
		background: url('~static/img/public/k3/2.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.kuaisan-3 {
		@extend .ballShow;
		background: url('~static/img/public/k3/3.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.kuaisan-4 {
		@extend .ballShow;
		background: url('~static/img/public/k3/4.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.kuaisan-5 {
		@extend .ballShow;
		background: url('~static/img/public/k3/5.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.kuaisan-6 {
		@extend .ballShow;
		background: url('~static/img/public/k3/6.png') no-repeat;
		background-size: 100% 100%;
	}
	/*******  pk10系列  *******/
	
	.pk10-01,
	.pk10-1 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/1.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.pk10-02,
	.pk10-2 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/2.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.pk10-03,
	.pk10-3 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/3.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.pk10-04,
	.pk10-4 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/4.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.pk10-05,
	.pk10-5 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/5.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.pk10-06,
	.pk10-6 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/6.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.pk10-07,
	.pk10-7 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/7.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.pk10-08,
	.pk10-8 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/8.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.pk10-09,
	.pk10-9 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/9.png') no-repeat;
		background-size: 100% 100%;
	}
	
	.pk10-10,
	.pk10-10 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/10.png') no-repeat;
		background-size: 100% 100%;
	}
	/*******  幸运飞艇   *******/
	
	.mlaft-01,
	.mlaft-1 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/1.png') no-repeat;
		background-size: 100% 100%;
		border-radius: 50%;
	}
	
	.mlaft-02,
	.mlaft-2 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/2.png') no-repeat;
		background-size: 100% 100%;
		border-radius: 50%;
	}
	
	.mlaft-03,
	.mlaft-3 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/3.png') no-repeat;
		background-size: 100% 100%;
		border-radius: 50%;
	}
	
	.mlaft-04,
	.mlaft-4 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/4.png') no-repeat;
		background-size: 100% 100%;
		border-radius: 50%;
	}
	
	.mlaft-05,
	.mlaft-5 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/5.png') no-repeat;
		background-size: 100% 100%;
		border-radius: 50%;
	}
	
	.mlaft-06,
	.mlaft-6 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/6.png') no-repeat;
		background-size: 100% 100%;
		border-radius: 50%;
	}
	
	.mlaft-07,
	.mlaft-7 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/7.png') no-repeat;
		background-size: 100% 100%;
		border-radius: 50%;
	}
	
	.mlaft-08,
	.mlaft-8 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/8.png') no-repeat;
		background-size: 100% 100%;
		border-radius: 50%;
	}
	
	.mlaft-09,
	.mlaft-9 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/9.png') no-repeat;
		background-size: 100% 100%;
		border-radius: 50%;
	}
	
	.mlaft-10,
	.mlaft-10 {
		@extend .ballShow;
		background: url('~static/img/public/pk10/10.png') no-repeat;
		background-size: 100% 100%;
		border-radius: 50%;
	}
	
	@import '~static/sass/public.scss';
	.header-top {
		padding: 0.12rem 0.24rem;
		box-sizing: border-box;
		display: flex;
		position: relative;
		&:after {
			display: block;
			content: '';
			width: 100%;
			height: 1px;
			background: #ccc;
			position: absolute;
			bottom: -1px;
			left: 0;
			transform: scaleY(0.5);
		}
		.ball-container {
			flex: 1;
			.item {
				display: inline-block;
				width: 0.46rem;
				height: 0.46rem;
				line-height: 0.46rem;
				margin-top: -2px;
				font-weight: 600;
			}
		}
		.video-container {
			width: 1.4rem;
			.iconfont {
				font-size: 0.5rem;
				color: #999;
			}
		}
		.title-left,
		.title-right {
			font-size: 0.24rem;
			color: #333;
			line-height: 0.4rem;
		}
		.font-weight {
			font-weight: 600;
		}
	}
	.nobr:after{
		border: none !important;
	}
	.historyContainer {
		height: 3rem;
		display: none;
		position: relative;
		background: #f5f6f7;
		table {
			width: 100%;
			background: #f5f6f7;
			thead {
				@include border-1px(#ccc,
				top);
				tr {
					th {
						@include border-1px(#ccc,
						bottom);
						font-size: 0.24rem;
						height: 0.6rem;
					}
					th:first-child {
						position: relative;
						&:before {
							display: block;
							content: '';
							width: 1px;
							height: 100%;
							background: #ccc;
							position: absolute;
							right: 0;
							top: 0;
							transform: scaleX(0.5);
						}
					}
				}
			}
			tbody {
				tr {
					td {
						@include border-1px(#ccc,
						bottom);
						font-size: 0.24rem;
						height: 0.6rem;
						span {
							vertical-align: middle;
							display: inline-block;
							width: 0.42rem;
							height: 0.42rem;
							margin-top: 0;
							margin-right: 4px;
							line-height: 0.42rem;
						}
					}
					td:first-child {
						position: relative;
						color: #666;
						&:before {
							display: block;
							content: '';
							width: 1px;
							height: 100%;
							background: #ccc;
							position: absolute;
							right: 0;
							top: 0;
							transform: scaleX(0.5);
						}
					}
				}
			}
		}
		.shadow {
			height: 3px;
			width: 100%;
			position: absolute;
			bottom: -3px;
			left: 0;
			-webkit-box-shadow: 0 0 50px rgba(0, 0, 0, 0.3);
			box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.6);
			z-index: 6;
		}
	}
	.dongwu{
		opacity: 0;
	}
	.header-bottom {
		padding: 0.1rem 0.24rem;
		display: flex;
		position: relative;
		&:after {
			content: '';
			display: block;
			border-bottom: 1px solid #f5f5f5;
			width: 100%;
			background: #ccc;
			position: absolute;
			bottom: 0;
			left: 0;
			transform-origin: 0 0;
			transform: scaleY(0.5);
		}
		.close-time {
			margin-right: 0.3rem;
			.pull-left {
				float: left;
				font-size: 0.24rem;
				padding-top: 0.04rem;
				color: #666666;
			}
			.pull-right {
				font-size: 0.24rem;
				padding-top: 0.04rem;
				color: #ff1a18;
			}
		}
		.history {
			display: block;
			font-size: 0.24rem;
			position: absolute;
			right: -0.5rem;
			top: 50%;
			color: $blueColor;
			transform: translate(-50%, -50%);
			span {
				vertical-align: -2px;
				padding: 0 5px;
			}
		}
	}
	
	.zhiti {
		color: #666;
		font-weight: bold;display: inline-block;min-width: .46rem;float: left;text-align: center;
	}
	.nobr{width: auto;}
	.nobr{padding: 0 !important;
		a{
			padding: 0.08rem 0.1rem;
			border: 1px solid #cccccc;
		}
	}
	.tag-con {
		flex: 1;
		text-align: left;
		/*padding-bottom: 0.1rem;*/
		padding-top: 0.1rem;
		/*@include border-1px(#eeeeee,
		bottom);*/
		span {
			font-size: 0.24rem;
			padding: 0.05rem 0.07rem;
			background: #ffffff;
			border-radius: 3px;
			margin-right: 0.08rem;
			color: #666666;
			@include border1px(#333);
			&:after {border: 1px solid #333;
				border-radius: 3px;
			}
		}
	}
	
	.disLine {
		display: inline-flex;
		display: -webkit-inline-box;
	}
	
	.addfonts {
		font-weight: 900;
		color: #bebbbb;
	}
	
	.ball-color-red {
		background: #e52f33;
		border-color: #e52f33;
		color: #fff;
	}
	
	.ball-color-green {
		background: #4cbe00;
		border-color: #4cbe00;
		color: #fff;
	}
	
	.ball-color-blue {
		background: #2f84e5;
		border-color: #2f84e5;
		color: #fff;
	}
</style>