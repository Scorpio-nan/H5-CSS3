<template>
	<footer class="footer">
		<div class="delete">
			<a class="resetAll" href="javascript:;">
				<span class="iconfont icon-dustbin_icon"></span>
				<span class="delete-text">删除</span>
			</a>
		</div>
		<div class="count">
			<span>共<span class="colorInherit">{{Count}}</span>注</span>
		</div>
		<div class="import">
			<input type="tel" name="" id="betvalue" value="" class="mui-input-clear clear" v-model="betValue" oninput='this.value = this.value.replace(/\D+/g, "")'/>
			<a id="reset" href="javascript:;" class="iconfont icon-delete clear" v-if="resetBtn"></a>
		</div>
		<div class="button-warpper">
			<button class="mui-btn mui-btn-block mui-btn-blue" id="betbtn">下注</button>
		</div>
		<div class="mask" v-show="fenpan">已封盘</div>
	</footer>
</template>

<script>
	export default {
		name: 'vfooter',
		props:{
			Value:{
				type:Number,
				default:0
			},
			Count:{
				type:Number,
				default:0
			}
		},
		data() {
			return {
				betValue:'',
				resetBtn:false,
			}
		},
		mounted() {
			const that = this;
			mui.init();
			mui.ready(function() {
				//点击下注按钮弹出列表
				mui('.button-warpper').on('tap', '#betbtn', function() {
					var PIbetValue=parseInt(that.betValue);
					if(PIbetValue<=0||isNaN(PIbetValue)){
						mui.alert('请输入正确的金额');
						that.betValue = '';
						return;
					}
					$('#betvalue').blur();
					that.$emit('handleBet',PIbetValue);
				})
	
				//输入框重置
				mui('.footer').on('tap', '.clear', function() {
					that.betValue = '';
				})
			
				//清除按钮
				mui('.footer').on('tap', '.delete', function() {
					that.betValue = '';
					that.$emit('handleDelete');
				})
				
				
			})
			
			
			//键盘弹出来之后会盖住输入框
			$(function(){
				$('#betvalue').on('focus',function(){
					setTimeout(()=>{
						this.scrollIntoViewIfNeeded();
					},300)
				})
			})
			
		},
		methods: {

		},
		computed:{
			fenpan(){
				return this.$store.getters.getSealing
			},
			ClearSelect(){
				return this.$store.state.clearSelect;
			}
		},
		watch:{
			betValue(val){
				if(val != ''){
					this.resetBtn = true;
				}else{
					this.resetBtn = false;
				}
			},
			Value(val){
				this.betValue = '';
				this.$emit('handleDelete');
			},
			ClearSelect(val){
				if(val){
					this.betValue = '';
					this.$emit('handleDelete');
				}
			}
		},
	}
</script>

<style lang="scss" scoped>
@import '~static/sass/public.scss';
.mask{
	padding-top: .2rem;
	color:red;font-size:.5rem;
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	background-color: #000;
	opacity: 0.5;
	z-index: 10;
}
	.colorInherit{
		color: $blueColor;
		padding: 0 4px;
	}
	.footer {
		background: #f5f6f7;
		height:1rem;
		display:table;
		width:100%;
		/*@include border-1px(#ccc,top);*/
   		padding-top: 0.03rem;
   		position: relative;
   		&:after{
			display: block;
			content: '';
			width: 100%;
			height: 1px;
			background: #ccc;
			position: absolute;
			right: 0;
			top: 1px;
			transform: scaleY(0.5);
		}
		.delete{
			display: table-cell;
			vertical-align: middle;
			width: 1.5rem;
			position: relative;
			&:after{
				display: block;
				content: '';
				width: 2px;
				height: 100%;
				background: #ccc;
				position: absolute;
				right: 0;
				top: 0;
				transform: scaleY(0.4);
			}
		}
		.resetAll {
			color: #333333;
			border-radius: 3px;
			padding: 0.15rem 0.1rem;
			span {
				font-size: 0.4rem;
			}
			p {
				font-size: 0.24rem;
			}
			&:active {
				/*background: rgba(#ff1a18, 0.6);*/
				color: #ff1a18;
			}
			.delete-text{
				font-size: 0.24rem;
			}
		}
		.import {
			display:table-cell;
			vertical-align: middle;
			position: relative;
			width: 2.6rem;
			padding-right: 0.16rem;
			input {
				height: 0.74rem;
				margin: 0;
			}
			#reset {
				font-size: 0.5rem;
				position: absolute;
				right: 0.26rem;
				top: 0.26rem;
				color: $assistFontColor;
			}
		}
		.count{
			display:table-cell;
			vertical-align: middle;
			font-size: 0.28rem;
		}
		.button-warpper {
			vertical-align: middle;
			display:table-cell;
			padding-right: 0.16rem;
			width: 2rem;
		}
		#betbtn {
			padding: 0.14rem;
			font-size: 0.28rem;
			margin: 0;
		}
		#betvalue {
			border: 0 none;
			border: 1px solid #ccc;
			&:focus{
				border: 1px solid $blueColor;
			}
		}
	}
</style>