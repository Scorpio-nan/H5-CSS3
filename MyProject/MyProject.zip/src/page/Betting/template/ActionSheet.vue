<template>
	<div id="actionsheet">
		<transition name="fade">
				<div class="action_mask" :show="show" v-show="show"></div>
			</transition>
		<transition name="bounce">
			<div class="action" :show="show" v-show="show">
				<div class="action_title">
					<span>当前选中 <span class="arrLength">{{arr.length}}</span>注,总下注金额<span class="BET_AMT">{{arr.length>0?parseInt(arr[0].BET_AMT)*arr.length:0}}</span>元</span>
				</div>
				<div class="action_content">
					<h5 class="mui-h5 list-title">下注清单</h5>
					<div class="action-main">
						<div class="mui-scroll-wrapper" id="actionsheetScroll">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										<a href="javascript:;" class="mui-clearfix flex-layout" v-for="(item,i) in arr">
											<div class="flex-cell">
												{{item.BET_RULE}}
											</div>
											<div class="flex-cell">
												{{item.BET_CONTENT}}
											</div>
											<div class="flex-cell">
												{{item.ODDS}} * {{item.BET_AMT}}
											</div>
											<div class="flex-cell remove-item" :data-index="i">
												<span class="posiTop iconfont icon-delete" style="font-size: 24px;"></span>
											</div>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="btn-group">
					<div class="cansel mr-r">
						<button class="mui-btn mui-btn-block mui-btn-danger btn-cancel">取消</button>
					</div>
					<div class="sure">
						<button type="button" data-loading-text="提交中"  class=" mui-btn mui-btn-block mui-btn-blue btn-sure">确认</button>
					</div>
				</div>
			</div>
		</transition>
	</div>
</template>
<script>
	import api from '../../../api/lotteryUtil.js';
	export default {
		props: {
			show: {
				type: Boolean,
				default: false
			},
			arr: Array
		},
		data() {
			return {
				btn_login_disable: false,
			}
		},
		methods: {
			hideAction() {
				this.$emit('hide')
				this.$store.dispatch('handleBetPour',{
					IsShow:false,
					title:'',
					arr:[],
					type:'cp'
				});
			},
		},
		mounted() {
			const that = this;
			
			mui('#actionsheetScroll').scroll({
				deceleration: 0.0005,
				top: 0
			})
			
			
			
			mui.init();
			mui.ready(function() {
				mui('#actionsheet').on('tap', '.action_mask', function() {
					that.hideAction();
				})
				mui('#actionsheet').on('tap', '.btn-cancel', function() {
					that.hideAction();
				})

				mui('#actionsheet').on('tap', '.btn-sure', function() {
					mui('.btn-sure').button('loading');
					that.btn_login_disable = false;
					if(that.type=='cp'){
						var myStoreBetFrom=that.arr;
						if(myStoreBetFrom.length<=0){
							that.$alert('没有注单！', '错误');
							that.hideAction();
							return;
						}
						api.AppendLotBetDetail(function(data) {
							that.btn_login_disable = true;
							mui('.btn-sure').button('reset');
							var result = eval('(' + data + ')');
							if(result.status == '0') {
								that.$alert(result.msg, '错误');
							} else if(result.status == '1') {
								that.$toast('投注成功！',{duration:2000});
								that.hideAction();
								setTimeout(() => {
									that.$store.dispatch('ClearSelect',Math.random());
								}, 100)
								that.$store.dispatch('getAccount');
				   				setTimeout(() => {
									that.$store.dispatch('getUserWin');
								}, 1000)
							} else if(result.status == '2') {
								that.$alert(result.msg, '错误');
							} else if(result.status == '3') {
								that.$alert(result.msg, '错误');
							} else if(result.status == '4') {
								that.$alert(result.msg, '错误');
							} else if(result.status == '5') {
								that.$alert(result.msg, '错误');
							}else if(result.status == '6'){
								that.$alert(result.msg, '错误');
							}
						}, myStoreBetFrom);
					}else{
						var myStoreBetFrom=that.arr;
						if(myStoreBetFrom.length<=0){
							that.$alert('没有注单！', '错误');
							that.hideAction();
							return;
						}
						api.AppendHk6LotBetDetail(function(data) {
							that.btn_login_disable = true;
							mui('.btn-sure').button('reset');
							var result = eval('(' + data + ')');
							if(result.status == '0') {
								that.$alert(result.msg, '错误');
							} else if(result.status == '1') {
								that.hideAction();
								that.$toast('投注成功！',{duration:2000});
								setTimeout(() => {
									that.$store.dispatch('ClearSelect',Math.random());
								}, 100)
								
								that.$store.dispatch('getAccount');
				   				setTimeout(() => {
									that.$store.dispatch('getUserWin');
								}, 1000)
							} else if(result.status == '2') {
								that.$alert(result.msg, '错误');
							} else if(result.status == '3') {
								that.$alert(result.msg, '错误');
							} else if(result.status == '4') {
								that.$alert(result.msg, '错误');
							} else if(result.status == '5') {
								that.$alert(result.msg, '错误');
							}
						}, myStoreBetFrom);
					}
				})

				mui(".mui-table-view").on('tap', '.remove-item', function() {
					var index = $(this).data('index');
					that.$toast('"' + that.arr[index].BET_CONTENT +'" ' + ' 已删除');
					that.arr.splice(index, 1);
				})
			})
		},
		watch: {
			show(val){
				//每次初始化后滚动区滚动到顶部
				mui('#actionsheetScroll').scroll().scrollTo(0,0,100);
			}
		},
		computed: {
			islogin() {
				return this.$store.getters.checkLoginState;
			},
			type(){
				return this.$store.getters.handleBetPour.type;
			}
		}
	}
</script>
<style lang="scss" scoped>
	@import "~static/sass/public.scss";
	.flex-layout {
		display: flex !important;
		.flex-cell {
			flex: 1;
		}
		.flex-cell:last-child {
			&:active {
				background: #eee;
			}
		}
	}
	
	.action {
		position: fixed;
		left: 0;
		bottom: 0;
		width: 100%;
		height: 6rem;
		background-color: #efefef;
		z-index: 120;
		padding: 0 0.24rem;
		display: flex;
		flex-direction: column;
		-webkit-perspective: 0;
		-moz-perspective: 0;
		perspective: 0;
		.action_title {
			text-align: center;
			height: 0.6rem;
			color: #666666;
			font-size: 0.24rem;
			line-height: 0.6rem;font-weight: bold;
		}
		.action_content {
			background: #fff;
			flex: 1;
			border-radius: 5px;
			display: flex;
			flex-direction: column;
			.list-title {
				padding: 0.24rem 0;
				position: relative;
				&:after {
					display: block;
					content: '';
					height: 1px;
					width: 100%;
					position: absolute;
					bottom: 1px;
					background: #ccc;
					transform: scaleY(0.5);
				}
			}
			.action-main {
				flex: 1;
				position: relative;
			}
		}
		.arrLength{
		
		}
		.BET_AMT{
			color: #ff0400;
		}
		.btn-group {
			height: 1.5rem;
			padding: 0.2rem 0;
			display: flex;
			.cansel {
				flex: 1;
			}
			.sure {
				flex: 1;
			}
		}
		.mr-r {
			margin-right: 0.14rem;
		}
		.btn-cancel,
		.btn-sure {
			padding: 0.15rem 0;
			font-size: 0.28rem;
		}
	}
	
	.mui-table-view-cell>a:not(.mui-btn).mui-active {
		background-color: #fff;
	}
	
	.mui-table-view {
		font-size: 0.24rem;
		&:after {
			display: none;
		}
		&:before {
			display: none;
		}
	}
	
	.action_mask {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: #000;
		opacity: 0.5;
		z-index: 10;
	}
	
	.bounce-enter-active {
		animation: bounce-in .25s;
	}
	
	.bounce-leave-active {
		animation: bounce-out .25s;
	}
	
	@keyframes bounce-in {
		0% {
			transform: translateY(300px);
		}
		100% {
			transform: translateY(0px);
		}
	}
	
	@keyframes bounce-out {
		0% {
			transform: translateY(0px);
		}
		100% {
			transform: translateY(300px);
		}
	}
	.posiTop{
		position: relative;top: .035rem;
	}
	.fade-enter-active {
		animation: fade-in .35s;
	}
	
	.fade-leave-active {
		animation: fade-out .35s;
	}
	
	@keyframes fade-in {
		0% {
			opacity: 0;
		}
		100% {
			opacity: 0.5;
		}
	}
	
	@keyframes fade-out {
		0% {
			opacity: 0.5;
		}
		100% {
			opacity: 0;
		}
	}
</style>