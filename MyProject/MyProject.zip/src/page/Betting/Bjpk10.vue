<template>
	<div id="HK6">
		<div class="nav">
			<div id="mui-slide" class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
				<div class="mui-scroll">
					<a class="scroll-item handlenav" :class="navActive == i? 'nav-active':''" :data-navactive="i" href="javascript:;" v-for="(item,i) in navArr">
						{{item}}
					</a>
				</div>
			</div>
			<a href="javascript:;" class="handlelist slidetag">
				<!--<span class="more">更多</span>--><span class="iconfont icon-xiangxia1 transferdown" :class="slideDown ? 'handleUp':'handleDown'"></span>
			</a>
			<div class="nav-down-list">
				<div class="down-item-container" v-for="(item,i) in navArr">
					<a class="scroll-item down-item" :class="navActive == i? 'nav-active':''" :data-navactive="i" href="javascript:;">
						<span class="whithimport">{{item}}</span>
					</a>
				</div>
			</div>
		</div>
		<div class="main">
			<!-- 快捷  -->
			<transition :name="animate">
				<div class="shortcut" v-show="navActive == 0">
					<div class="navigation">
						<Scroller>
							<ul class="nav-warpper">
								<li class="nav-item" :data-name="item" :class="i == 0? 'select':''" v-for="(item,i) in Rank">
									<a href="javascript:;">{{item}}</span>
									</a>
								</li>
							</ul>
						</Scroller>
					</div>
					<!--快捷系列放了3个循环，分别是普通球，龙虎，大小单双-->
					<div class="select-ball-warpper">
						<div class="mui-scroll-wrapper" id="shortCon">
							<div class="mui-scroll">
								<div class=" padding-box leopard kuaijie">
									<!--普通的选中球-->
									<a href="javascript:;" class="ball-warpper mr-b" v-for="(item,i,index) in initData[queryCode+'2']" v-if="index < 10" :data-object="JSON.stringify(item)" :class="'color'+item.NUM">
										<p class="ball-title">{{item.NUM}}</p>
										<p class="ball-odds">{{item.ODDS}}</p>
									</a><!-- 
										龙虎
									--><a href="javascript:;" class="ball-warpper  mr-b lh" v-for="(item,i,index) in initData[queryCode+'12']" v-if="item.SHOWCLS == 'text' && index <2" :data-object="JSON.stringify(item)">
										<p class="ball-lh">{{item.NUM_NAME}}</p>
										<p class="ball-wz">{{item.ODDS}}</p>
									</a>
									<!-- 大小单双-->

									<a href="javascript:;" class="ball-warpper  mr-b lh" v-for="(item,i,index) in initData[queryCode+'2']" v-if="index>=10" :data-object="JSON.stringify(item)">
										<p class="ball-lh">{{item.NUM}}</p>
										<p class="ball-wz">{{item.ODDS}}</p>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</transition>

			<!--两面  后几球-->
			<div class="other-play" v-show="navActive != 0">
				<div class="mui-scroll-wrapper" id="otherSide">
					<div class="mui-scroll">
						<div class="mui-slider" id="mui-slider">
							<div class="mui-slider-group">
								<!--  两面栏目    -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 1">
										<h5 class="mui-h5 play-title">冠亚和</h5>
										<div class=" four leopard">
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'0']" v-if="item.SHOWCLS == 'text'" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>

										<h5 class="mui-h5 play-title mr-t">冠军</h5>
										<div class=" four leopard">
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'2']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'12']" v-if="item.SHOWCLS == 'text' && index<2" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">亚军</h5>
										<div class=" four leopard">
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'3']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'12']" v-if="item.SHOWCLS == 'text' && index<4 && index>=2" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第三名</h5>
										<div class=" four leopard">
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'4']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'12']" v-if="item.SHOWCLS == 'text' && index<6 && index>=4" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第四名</h5>
										<div class=" four leopard">
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'5']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'12']" v-if="item.SHOWCLS == 'text' && index<8 && index>=6" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第五名</h5>
										<div class=" four leopard">
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'6']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'12']" v-if="item.SHOWCLS == 'text' && index<10 && index>=8" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第六名</h5>
										<div class=" four leopard nolh">
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'7']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第七名</h5>
										<div class=" four leopard nolh">
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'8']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第八名</h5>
										<div class=" four leopard nolh">
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'9']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第九名</h5>
										<div class=" four leopard nolh">
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'10']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<h5 class="mui-h5 play-title mr-t">第十名</h5>
										<div class=" four leopard nolh">
											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'11']" v-if="index >= 10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

								<!--  冠亚和球类选中信息   -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 2">
										<div class=" padding-box mui-clearfix leopard gyh16">
											<a href="javascript:;" class="ball-warpper" :class="'color'+item.NUM" v-for="(item,i,index) in initData[queryCode+'0']" v-if="item.SHOWCLS != 'text'" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-title">{{item.NUM}}</p>
													<p class="ball-odds">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<!--冠亚大小单双栏目 -->
										<div class="leopard four">
											<a href="javascript:;" class="ball-warpper lh" v-for="(item,i,index) in initData[queryCode+'0']" v-if="item.SHOWCLS == 'text'" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

								<!-- 冠军 -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 3">
										<div class=" padding-box mui-clearfix leopard four">
											<a href="javascript:;" class="ball-warpper" :class="'color'+item.NUM" v-for="(item,i,index) in initData[queryCode+'2']" v-if="index<10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-title">{{item.NUM}}</p>
													<p class="ball-odds">{{item.ODDS}}</p>
												</div>
											</a>

											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'12']" v-if="item.SHOWCLS == 'text' && index <2" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<div class="leopard four">
											<a href="javascript:;" class="ball-warpper lh" v-for="(item,i,index) in initData[queryCode+'2']" v-if="index>=10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

								<!--  亚军  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 4">
										<div class=" padding-box mui-clearfix leopard four">
											<a href="javascript:;" class="ball-warpper" :class="'color'+item.NUM" v-for="(item,i,index) in initData[queryCode+'3']" v-if="index<10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-title">{{item.NUM}}</p>
													<p class="ball-odds">{{item.ODDS}}</p>
												</div>
											</a>

											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'12']" v-if="item.SHOWCLS == 'text' && index<4 && index>=2" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<div class="leopard four">
											<a href="javascript:;" class="ball-warpper lh" v-for="(item,i,index) in initData[queryCode+'3']" v-if="index>=10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

								<!--  第三名  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 5">
										<div class=" padding-box mui-clearfix leopard four">
											<a href="javascript:;" class="ball-warpper" :class="'color'+item.NUM" v-for="(item,i,index) in initData[queryCode+'4']" v-if="index<10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-title">{{item.NUM}}</p>
													<p class="ball-odds">{{item.ODDS}}</p>
												</div>
											</a>

											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'12']" v-if="item.SHOWCLS == 'text' && index<6 && index>=4" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<div class="leopard four">
											<a href="javascript:;" class="ball-warpper lh" v-for="(item,i,index) in initData[queryCode+'4']" v-if="index>=10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

								<!--  第四名  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 6">
										<div class=" padding-box mui-clearfix leopard four">
											<a href="javascript:;" class="ball-warpper" :class="'color'+item.NUM" v-for="(item,i,index) in initData[queryCode+'5']" v-if="index<10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-title">{{item.NUM}}</p>
													<p class="ball-odds">{{item.ODDS}}</p>
												</div>
											</a>

											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'12']" v-if="item.SHOWCLS == 'text' && index<8 && index>=6" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<div class="leopard four">
											<a href="javascript:;" class="ball-warpper lh" v-for="(item,i,index) in initData[queryCode+'5']" v-if="index>=10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

								<!--  第五名  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 7">
										<div class=" padding-box mui-clearfix leopard four">
											<a href="javascript:;" class="ball-warpper" :class="'color'+item.NUM" v-for="(item,i,index) in initData[queryCode+'6']" v-if="index<10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-title">{{item.NUM}}</p>
													<p class="ball-odds">{{item.ODDS}}</p>
												</div>
											</a>

											<a href="javascript:;" class="ball-warpper border-box lh" v-for="(item,i,index) in initData[queryCode+'12']" v-if="item.SHOWCLS == 'text' && index<10 && index>=8" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM_NAME}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<div class="leopard four">
											<a href="javascript:;" class="ball-warpper lh" v-for="(item,i,index) in initData[queryCode+'6']" v-if="index>=10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

								<!--  第6名  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 8">
										<div class=" padding-box mui-clearfix leopard four">
											<a href="javascript:;" class="ball-warpper" :class="'color'+item.NUM" v-for="(item,i,index) in initData[queryCode+'7']" v-if="index<10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-title">{{item.NUM}}</p>
													<p class="ball-odds">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<div class="leopard four">
											<a href="javascript:;" class="ball-warpper lh" v-for="(item,i,index) in initData[queryCode+'7']" v-if="index>=10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

								<!--  第7名  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 9">
										<div class=" padding-box mui-clearfix leopard four">
											<a href="javascript:;" class="ball-warpper" :class="'color'+item.NUM" v-for="(item,i,index) in initData[queryCode+'8']" v-if="index<10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-title">{{item.NUM}}</p>
													<p class="ball-odds">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<div class="leopard four">
											<a href="javascript:;" class="ball-warpper lh" v-for="(item,i,index) in initData[queryCode+'8']" v-if="index>=10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

								<!--  第8名  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 10">
										<div class=" padding-box mui-clearfix leopard four">
											<a href="javascript:;" class="ball-warpper" :class="'color'+item.NUM" v-for="(item,i,index) in initData[queryCode+'9']" v-if="index<10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-title">{{item.NUM}}</p>
													<p class="ball-odds">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<div class="leopard four">
											<a href="javascript:;" class="ball-warpper lh" v-for="(item,i,index) in initData[queryCode+'9']" v-if="index>=10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

								<!--  第9名  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 11">
										<div class=" padding-box mui-clearfix leopard four">
											<a href="javascript:;" class="ball-warpper" :class="'color'+item.NUM" v-for="(item,i,index) in initData[queryCode+'10']" v-if="index<10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-title">{{item.NUM}}</p>
													<p class="ball-odds">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<div class="leopard four">
											<a href="javascript:;" class="ball-warpper lh" v-for="(item,i,index) in initData[queryCode+'10']" v-if="index>=10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

								<!--  第10名  -->
								<transition :name="animate">
									<div class="mui-slider-item" v-show="navActive == 12">
										<div class=" padding-box mui-clearfix leopard four">
											<a href="javascript:;" class="ball-warpper" :class="'color'+item.NUM" v-for="(item,i,index) in initData[queryCode+'11']" v-if="index<10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-title">{{item.NUM}}</p>
													<p class="ball-odds">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
										<div class="leopard four">
											<a href="javascript:;" class="ball-warpper lh" v-for="(item,i,index) in initData[queryCode+'11']" v-if="index>=10" :data-object="JSON.stringify(item)">
												<div>
													<p class="ball-lh">{{item.NUM}}</p>
													<p class="ball-wz">{{item.ODDS}}</p>
												</div>
											</a>
										</div>
									</div>
								</transition>

							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
		<div class="footer">
			<BFooter @handleBet="HandleBet" @handleDelete="deleteSelected" :Value="Value" :Count='betLenght'></BFooter>
		</div>
	</div>
</template>

<script>
	import Scroller from '@/components/Scroller';
	import BFooter from './template/Footer';
	import api from '../../api/lotteryUtil.js';
	export default {
		name: 'HK6',
		components: {
			Scroller,
			BFooter
		},
		data() {
			return {
				swipeBack: false,
				queryCode: '',
				navActive: 0,
				navArr: ['快捷', '两面', '冠亚和', '冠军', '亚军', '第三名', '第四名', '第五名', '第六名', '第七名', '第八名', '第九名', '第十名', ],
				initData: {}, //初始化数据
				betArr: [], //投注数组
				Value: 0, //每次切换导航需要重置子组件里面的数值
				betSum: 0, //总共下注
				winSum: 0, //可赢
				betLenght: 0, //当前选中多少注
				resetBtn: false, //输入框reset
				tempIndex: 0, //暂时记录上一个index值
				animate: 'slide-in', //默认动画
				slideDown: false, //导航页签
				Style: {
					'border-radius': '50%'
				},
				Rank: ['冠军', '亚军', '季军', '第三名', '第四名', '第五名', '第六名', '第七名', '第八名', '第九名', '第十名'], //快捷选项左边栏目
				lotteryID: '',
				myBetArrayShow: {},

			}
		},
		mounted() {
			// this.init();
			const that = this;
			mui.init({
				swipeBack: this.swipeBack
			});
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});

			mui.ready(function() {
				//tab导航点击滚到第几球
				mui('.nav').on('tap', '.handlenav', function() {
					var active = $(this).data('navactive');
					that.navActive = active;
					that.handleTabChange();
				})
				
				//下拉菜单点击
				mui('.nav').on('tap', '.down-item', function() {
					var active = $(this).data('navactive');
					that.navActive = active;
					that.handleTabChange();
					mui('#mui-slide').scroll().scrollTo(-($(this).width() * active), 0, 0);
					that.slideDown = !that.slideDown;
				})
				
				//tab导航右上角icon
				mui('.nav').on('tap', '.handlelist', function() {
					if(that.slideDown) {
						$('.nav-down-list').slideUp(150);
					} else {
						$('.nav-down-list').slideDown(150);
					}
					that.slideDown = !that.slideDown;
				})

				//左侧快捷选球功能 左边栏目选中状态
				mui('.nav-warpper').on('tap', '.nav-item', function() {
					var isSelect = $(this).hasClass("select"); //判断是否选中或者失败
					if(isSelect) {
						$(this).removeClass("select");
					} else {
						$(this).addClass("select");
					};
					var Nselect=$('.nav-item.select').length
					var selects=$('.Selected').length
					that.betLenght = selects * Nselect;
				})

				//点击选中和不选中球
				mui('.main').on('tap', '.ball-warpper', function() {
					var self = $(this);
					that.SelectBall(self)
					var Nselect=$('.nav-item.select').length
					var selects=$('.Selected').length
					that.betLenght = selects * Nselect;
				})

			})
		},

		methods: {
			//点击tab清除所有记录项
			handleTabChange() {
				const that = this;
				that.Value = Math.random();
				that.deleteSelected();
				that.betLenght = 0;
				that.betSum = 0;
				mui('#shortCon').scroll().scrollTo(0, 0, 100);
				mui('#otherSide').scroll().scrollTo(0, 0, 100);
				$('.nav-down-list').slideUp(150);
			},
			//初始化本地JSON，通过queryCode变更
			simulation_data() {
				//从路由过来的值，bjpk10或者jspk10,幸运飞艇
				const that = this;
				that.queryCode = this.$route.query.code;
				$.getJSON('static/json/temp/' + that.queryCode + '.json', function(res) { //根据这个code来显示不同的JSON
					var arr = []
					that.initData = res;
				})
				//刷新页面后开始是本地JSON，延迟后再访问接口
				var t = setTimeout(() => {
					api.GetLotOddsDictList(function(itemList) {
						that.initData = itemList;
					}, that.lotteryID);
				}, 1000)
			},
			//选球功能
			SelectBall(self) {
				if(self.hasClass('Selected')) {
					self.removeClass('Selected')
				} else {
					self.addClass('Selected');
				}
			},
			//清除所有选中项
			deleteSelected() {this.betLenght = 0;
				$('.ball-warpper.Selected').attr('class', function(i, cls) {
					return cls.replace(/Selected/g, '');
				});
				$('.nav-item.select').attr('class', function(i, cls) {
					return cls.replace(/select/g, '');
				});
			},

			//点击下注按钮操作
			HandleBet(val) {
				const that = this;
				var SelectedDom = $('.Selected');
				var selectNav = $('.nav-item.select');
				var obj = {},
					betObj = {},
					name = "";
				that.betArr = [];

				//投注验证
				if(!that.islogin) {
					that.$alert('请先登录后再下注~');
					return false;
				}
				if(parseInt(val) <= 0 || val == '') {
					that.$alert('请输入正确金额~');
					return false;
				}
				if(SelectedDom.length <= 0) {
					that.$alert('请选中玩法下注~');
					return false;
				}

				if(that.navActive == 0) {
					// 两面的投注方式
					if(selectNav.length == undefined || selectNav.length <= 0) {
						that.$alert('请选中玩法下注~');
						return false;
					}
					that.betLenght = SelectedDom.length * selectNav.length;
					that.betSum = SelectedDom.length * val * selectNav.length;
					for(let i = 0; i < SelectedDom.length; i++) {
						obj = SelectedDom[i].dataset['object'];
						obj = JSON.parse(obj);
						for(let j = 0; j < selectNav.length; j++) {
							name = selectNav[j].dataset['name'];
							betObj = {
								BET_NO: obj.NUM,
								SYS_GAME_LEVEL_CODE_ID: obj.P_1ID,
								SYS_GAME_LEVEL_CODE3_ID: obj.P_3ID,
								BET_RULE: name,
								BET_CONTENT: obj.NUM_NAME,
								ODDS: obj.ODDS,
								BET_AMT: parseInt(val),
								WIN: (parseInt(val) * obj.ODDS).toFixed(2),
								CODE: obj.CODE
							}
							that.betArr.push(betObj);
						}
					}
				} else {
					//其他球的投注方式
					that.betLenght = SelectedDom.length;
					that.betSum = SelectedDom.length * val;
					for(let i = 0; i < SelectedDom.length; i++) {
						obj = SelectedDom[i].dataset['object'];
						obj = JSON.parse(obj);
						betObj = {
							BET_NO: obj.NUM,
							SYS_GAME_LEVEL_CODE_ID: obj.P_1ID,
							SYS_GAME_LEVEL_CODE3_ID: obj.P_3ID,
							BET_RULE: obj.GROUP_NAME,
							BET_CONTENT: obj.NUM_NAME,
							ODDS: obj.ODDS,
							BET_AMT: parseInt(val),
							WIN: (parseInt(val) * obj.ODDS).toFixed(2),
							CODE: obj.CODE
						}
						that.betArr.push(betObj);
					}
				}

				var dispack = {
					IsShow: true,
					title: `当前选中 ${this.betLenght} 注,总下注金额${this.betSum}元`,
					arr: that.betArr,
					type: 'cp'
				}
				this.$store.dispatch('handleBetPour', dispack);
			},
			initGame_data() {
				var this_ = this;
				//加入存储
				api.GetLotOddsDictList(function(itemList) {
					this_.initData = itemList;
				}, this_.lotteryID, this_);
			},
		},
		created() {
			var this_ = this;
			this_.queryCode = this_.$route.query.code;
			this_.lotteryID = this_.$route.query.id;
			//判断用户是否有登录状态,根据islogin来判断
			if(!this_.islogin) { //等于这个执行假数据
				this_.simulation_data();
			} else { //执行缓存或者API数据
				this_.initGame_data()
			}
		},
		watch: {
			navActive(val) {
				if(val > this.tempIndex) {
					this.animate = 'slide-out'
				} else {
					this.animate = 'slide-in'
				}
				this.tempIndex = val;
			},
			rountddata(val) {

				var this_ = this;
				this_.queryCode = this_.$route.query.code;this.Value = Math.random();
				this_.lotteryID = this_.$route.query.id;
				//判断用户是否有登录状态,根据islogin来判断
				if(!this_.islogin) {
					this_.simulation_data();
				} else {
					//true执行缓存或者API数据
					this_.initGame_data();
				}

			}
		},
		props: ['data'],
		computed: {

			rountddata() {
				return this.data.id
			},

			islogin() {
				return this.$store.getters.checkLoginState;
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	#HK6 {
		height: 100%;
		width: 100%;
		display: flex;
		flex-direction: column;
	}
	
	.nav {
		height: 0.88rem;
		background: #f5f6f7;
		position: relative;
		@include border-1px(#ccc, bottom);
		.slidetag {
			display: block;
			position: absolute;
			top: 0;
			right: 0;
			width: 1.45rem;
			height: 0.86rem;
			background: #f5f6f7;
			z-index: 6;
			font-size: 0.28rem;
			text-align: center;
			.more {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -50%);
				color: #999999;
				text-indent: -0.3rem;
				font-size: 0.24rem;
			}
			.transferdown {
				position: absolute;
				left: 0.8rem;
				top: 50%;
				transform: translate(-50%, -50%);
				color: #999999;
				font-size: 0.4rem;
			}
		}
		.nav-down-list {
			width: 100%;
			background: #f5f6f7;
			position: absolute;
			left: 0;
			z-index: 5;
			padding: 0.24rem;
			padding-bottom: 0.1rem;
			display: none;
			box-shadow: 0 5px 5px rgba(0, 0, 0, 0.1);
			.down-item-container {
				width: 25%;
				margin-bottom: 0.12rem;
				float: left;
				position: relative;
			}
			.down-item {
				border: 1px solid #ccc;
				width: 80%;
			}
		}
	}
	
	.mui-segmented-control.mui-scroll-wrapper {
		height: 0.88rem;
	}
	
	.mui-segmented-control.mui-scroll-wrapper .mui-scroll {
		height: 0.88rem;
		padding: 0.09rem 0.24rem;
		padding-right: 1.5rem;
	}
	
	.scroll-item {
		display: inline-block;
		font-size: 0.28rem;
		width: 1.52rem;
		height: 0.7rem;
		padding-top: 0.15rem;
		box-sizing: border-box;
		border-radius: 4px;
		color: $importFontColor;
		font-size: 0.28rem;
	}
	
	.mr-t {
		margin-top: 0rem;
	}
	
	.mr-b {
		margin-bottom: 0 !important;
	}
	
	.slide-in-enter-active {
		animation: slide-in .25s;
	}
	
	.slide-out-leave-active {
		animation: slide-out .25s;
	}
	
	.code {
		font-size: 0.24rem;
		color: #999999;
	}
	
	@keyframes slide-in {
		from {
			transform: translate3d(-100%, 0, 0);
		}
		to {
			transform: translate3d(0, 0, 0);
		}
	}
	
	@keyframes slide-out {
		from {
			transform: translate3d(0, 0, 0);
		}
		to {
			transform: translate3d(-100%, 0, 0);
		}
	}
	
	.nav-active {
		background: #fff;
		position: relative;
		border: 1px solid #ff1a18 !important;
		color: #ff1a18;
	}
	.footer{
		position: absolute;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 1rem;
		z-index: 100;
	}
	.main {
		/*flex: 1;*/
		/*position: relative;*/
		position: absolute;
		z-index: 1;
		height: 100%;
		width: 100%;
		top: 0.88rem;
		bottom: 1rem;
		left: 0;
		padding-bottom: 1.88rem;
		.shortcut {
			height: 100%;
			display: flex;
			position: absolute;
    		width: 100%;
    		padding-bottom:1.88rem;
			.navigation {
				width: 1.6rem;
				background: #eee;
				position: relative;
			}
			.nav-warpper {
				width: 100%;
				padding: 0.24rem 0;
				li {
					padding: 0.22rem 0;
					position: relative;
					border-top: 1px solid #eeeeee;
					&:before {
						content: '';
						display: block;
						width: 0.15rem;
						height: 0.15rem;
						background: #cccccc;
						border-radius: 50%;
						position: absolute;
						left: 0.1rem;
						top: 0.12rem;
						box-shadow: 1px 1px 0px 0px #777777 inset;
					}
					a {
						font-size: 0.28rem;
					}
				}
				.select {
					background: #fff;
					&:after {
						content: '';
						display: block;
						width: 0.15rem;
						height: 0.15rem;
						background: red;
						border-radius: 50%;
						position: absolute;
						left: 0.1rem;
						top: 0.12rem;
						box-shadow: 1px 1px 0px 0px #8e0807 inset;
					}
					a {
						color: #ff1a18;
					}
				}
			}
			.select-ball-warpper {
				flex: 1;
				background: #fff;
				position: relative;
			}
		}
		#shortCon {
			position: absolute;
			width: 100%;
			height: 100%;
			background: #ffffff;
		}
	}
	
	.other-play {
		width: 100%;
		height: 100%;
		position: relative;
		background: #ffffff;
	}
	
	.border-box.Selected {
		// background: $bgColor !important;
		// color: #fff !important;
		// border-color: $warnColor !important;
	}
	
	.ball-warpper.Selected {
		.ball {
			// background: $bgColor !important;
			// color: #fff !important;
			// border-color: $warnColor !important;
		}
	}
	
	.animated {
		animation-duration: .55s;
		animation-fill-mode: both;
	}
	
	@keyframes fadeIn {
		from {
			opacity: 0;
			z-index: 0;
			display: none;
		}
		to {
			opacity: 1;
			z-index: 100;
			display: block;
		}
	}
	
	.fadeIn {
		animation-name: fadeIn;
	}
	
	@keyframes fadeOut {
		from {
			opacity: 1;
			z-index: 100;
			display: block;
		}
		to {
			opacity: 0;
			z-index: 0;
			display: none;
		}
	}
	
	.fadeOut {
		animation-name: fadeOut;
		display: none !important;
	}
	
	.mot_tc {
		position: fixed;
		top: 0;
		left: 0;
		background-color: #000;
		opacity: 0.5;
		height: 100%;
		width: 100%;
		z-index: 9;
	}
	
	.fade-enter-active {
		animation: fade-in .35s;
	}
	
	.fade-leave-active {
		animation: fade-out .35s;
	}
	
	@keyframes fade-in {
		0% {
			opacity: 0;
		}
		100% {
			opacity: 0.5;
		}
	}
	
	@keyframes fade-out {
		0% {
			opacity: 0.5;
		}
		100% {
			opacity: 0;
		}
	}
	
	.leopard {
		overflow: hidden;
		margin-left: 0.2rem;
		.Selected {
			border: 1px solid $warnColor !important;
			
			:after {
				content: '';
				width: 0.5rem;
				height: 0.5rem;
				background: url(~static/img/public/pk10/right.png);
				position: absolute;
				right: -.02rem;
				top: -.02rem;
				background-size: 100% auto;
			}
		}
		.ball-warpper {
			position: relative;
			width: 1.2rem;
			height: 1rem;
			padding: 0.1rem 0.12rem;
			margin-right: 0.2rem;
			margin-top: 0.2rem;
			text-align: center;
			display: inline-block;
			box-sizing: border-box;
			vertical-align: middle;
			border-radius: 3px;
			border: 1px solid transparent;
			.ball-odds {}
		}
		.lh {
			border: 1px solid $tipsFontColor;
			width: 1.2rem;
			height: 1rem;
			.ball-lh {
				font-size: 0.32rem;
				color: $importFontColor;
				font-weight: 600;
			}
			.ball-wz {
				font-size: 0.28rem;
				margin-top: -0.05rem;
				color: $normalFontColor;
			}
			&.Selected {
				border: 1px solid $warnColor;
				background: $bgColor;
				p{
    				color: $warnColor !important;
				}
			}
		}
	}
	
	.mui-slider .mui-slider-group .mui-slider-item{
		padding-bottom: 0.2rem;
	}
	.mui-slider-item>h5 {
		font-size: 0.32rem;
		color: #666666;
		font-weight: 600;
		margin: 0.3rem 0 0 0;
	}
	
	//快捷   显示4个
	.kuaijie {
		.ball-warpper {
			width: 1.2rem;
		}
	}
	
	//两面 显示4个比快捷宽
	.four {
		.ball-warpper {
			width: 1.6rem;
		}
	}
	
	//冠亚和
	// .gyh16>.ball-warpper:nth-child(16){
	// }
	// .gyh16>.ball-warpper:nth-child(17){
	// }
	.other-play {
		background: #fff;
	}
	
	.color1 {
		background: #fffb08;
		font-weight: 600;
	}
	
	.color2 {
		background: #008bf9;
		font-weight: 600;
	}
	
	.color3 {
		background: #4c4d51;
	}
	
	.color4 {
		background: #f47a00;
	}
	
	.color5 {
		background: #8ff9f9;
	}
	
	.color6 {
		background: #420aff;
	}
	
	.color7 {
		background: #e3e3e3;
	}
	
	.color8 {
		background: #dd0400;
	}
	
	.color9 {
		background: #770100;
	}
	
	.color10 {
		background: #2bc610;
	}
	
	.color11 {
		background: #fffb08;
	}
	
	.color12 {
		background: #008bf9;
	}
	
	.color13 {
		background: #4c4d51;
	}
	
	.color14 {
		background: #f47a00;
	}
	
	.color15 {
		background: #8ff9f9;
	}
	
	.color16 {
		background: #420aff;
	}
	
	.color17 {
		background: #e3e3e3;
	}
	
	.color18 {
		background: #dd0400;
	}
	
	.color19 {
		background: #770100;
	}
	
	.ball-title {
		font-size: 0.48rem;
		color: #fff;
		font-weight: 600;
		font-style: italic;
		-webkit-text-stroke: 1px #333333;
	}
	
	.ball-odds {
		font-size: 0.28rem;
		color: #fff;
		font-weight: 600;
		-webkit-text-stroke: 0.5px #333333;
	}
</style>