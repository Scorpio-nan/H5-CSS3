<template>
	<div id="hk6">
		<div class="nav">
			<div id="mui-slide" class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
				<div class="mui-scroll">
					<a class="scroll-item handlenav" :class="navActive == i? 'nav-active':''" :data-navactive="i" href="javascript:;" v-for="(item,i) in navArr">
						{{item.name}}
					</a>
				</div>
			</div>
			<a href="javascript:;" class="handlelist slidetag">
				<!--<span class="more">更多</span>--><span class="iconfont icon-xiangxia1 transferdown" :class="slideDown ? 'handleUp':'handleDown'"></span>
			</a>
			<div class="nav-down-list">
				<div class="down-item-container" v-for="(item,i) in navArr">
					<a class="scroll-item down-item" :class="navActive == i? 'nav-active':''" :data-navactive="i" href="javascript:;" :data-id="item.id">
						<span class="whithimport">{{item.name}}</span>
					</a>
				</div>
			</div>
		</div>
		<div class="main">
			<transition :name="transitionName">
				<router-view class="child-view"></router-view>
			</transition>
		</div>
	</div>
</template>

<script>
	export default {
		name: 'hk6',
		data() {
			return {
				swipeBack: false,
				navActive: 0,
				p3_id: 698,
				queryCode: 'hk6',
				lotteryID: '27',
				ShowTime: false,
				navArr: [{
					name: '特码',
					code: 'TeMaA'
				}, {
					name: '特码生肖',
					code: 'TeMaShengXiao'
				}, {
					name: '正码特',
					code: 'ZhengMaTe'
				}, {
					name: '正码',
					code: 'ZhengMa'
				}, {
					name: '总和',
					code: 'ZongHe'
				}, {
					name: '一肖/尾数',
					code: 'YiXiaoWeiShu'
				}, {
					name: '连码',
					code: 'LianMa'
				}, {
					name: '合肖',
					code: 'HeXiao'
				}, {
					name: '生肖连',
					code: 'ShengXiaoLian'
				}, {
					name: '尾数连',
					code: 'WeiShuLian'
				}, {
					name: '全不中',
					code: 'QuanBuZhong'
				}],
				animate: 'slide-in', //默认动画
				slideDown: false, //导航页签
				leftSideActive: 0,
				transitionName: 'slide-left',
			}
		},
		mounted() {
			this.init();
			const that = this;
			mui.init({
				swipeBack: this.swipeBack
			});

			mui('#mui-slide').scroll({
				deceleration: 0.0005
			});

			mui.ready(function() {

				//tab导航点击滚到第几球
				mui('.nav').on('tap', '.handlenav', function() {
					var active = $(this).data('navactive');
					that.navActive = active;
					that.handleTabChange(active);
				})

				//tab导航右上角icon
				mui('.nav').on('tap', '.handlelist', function() {
					if(that.slideDown) {
						$('.nav-down-list').slideUp(150);
					} else {
						$('.nav-down-list').slideDown(150);
					}
					that.slideDown = !that.slideDown;
				})

				//下拉菜单点击事件
				mui('.nav').on('tap', '.down-item', function() {
					var active = $(this).data('navactive');
					that.navActive = active;
					that.handleTabChange(active);
					mui('#mui-slide').scroll().scrollTo(-($(this).width() * active), 0, 0);
					that.slideDown = !that.slideDown;
				})

			})
		},
		methods: {
			//点击tab清除所有记录项
			handleTabChange(active) {
				const that = this;
				if(!that.logined) {
					mui.alert('请登录');
					return;
				}
				$('.nav-down-list').slideUp(150);
				var Routerpath = that.navArr[active].code;
				that.$router.push({
					path: Routerpath,
					query: {
						p3_id: that.navArr[active].id,
						id: that.lotteryID,
						code: that.queryCode,
						name: that.$route.query.name,
					}
				});
			},

			//初始化
			init() {
				this.queryCode = this.$route.query.code;
				const that = this;
				var Active = that.$route.path.split('/')[1];
				var k = 1;
				for(var i = 0; i < this.navArr.length; i++) {
					if(Active.indexOf(that.navArr[i].code) != -1) {
						if(k) {
							that.navActive = i;
							k = 0;
						}
					}
				}
			},
			initOddsLottery(_id) {
				var that = this;
				that.lotteryID = _id;
				$.getJSON('static/json/temp/six/' + that.queryCode + '-title.json', function(data) {
					that.ShowTime = true;
					for(var i = 0; i < data.length; i++) {
						if(data[i].text == that.navArr[i].name) {
							that.navArr[i].id = data[i].id;
						}
					}
				})
			},
		},
		created() {
			this.$store.dispatch('checkLoginState')
			this.$store.dispatch('getTemashow')
			var that = this;
			that.queryCode = that.$route.query.code;
			that.lotteryID = that.$route.query.id;
			this.init();
			that.initOddsLottery(that.lotteryID);
		},
		watch: {

		},
		computed: {
			logined() {
				return this.$store.getters.checkLoginState;
			}
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	#hk6 {
		display: flex;
		flex-direction: column;
	}
	
	.nav {
		height: 0.88rem;
		background: #f5f6f7;
		position: relative;
		@include border-1px(#ccc, bottom);
		.slidetag {
			display: block;
			position: absolute;
			top: 0;
			right: 0;
			width: 1.45rem;
			height: 0.86rem;
			background: #f5f6f7;
			z-index: 10;
			font-size: 0.28rem;
			text-align: center;
			.more {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -50%);
				color: #999999;
				text-indent: -0.3rem;
				font-size: 0.24rem;
			}
			.transferdown {
				position: absolute;
				left: 0.8rem;
				top: 50%;
				transform: translate(-50%, -50%);
				color: #999999;
				font-size: 0.4rem;
			}
		}
		.nav-down-list {
			width: 100%;
			background: #f5f6f7;
			position: absolute;
			left: 0;
			z-index: 11;
			padding: 0.24rem;
			padding-bottom: 0.1rem;
			display: none;
			box-shadow: 0 5px 5px rgba(0, 0, 0, 0.1);
			.down-item-container {
				width: 25%;
				margin-bottom: 0.12rem;
				float: left;
				position: relative;
			}
			.down-item {
				border: 1px solid #ccc;
				width: 80%;
			}
		}
	}
	
	.mui-segmented-control.mui-scroll-wrapper {
		height: 0.88rem;
	}
	
	.mui-segmented-control.mui-scroll-wrapper .mui-scroll {
		height: 0.88rem;
		padding: 0.09rem 0.24rem;
		padding-right: 1.5rem;
	}
	
	.scroll-item {
		display: inline-block;
		font-size: 0.28rem;
		border-radius: 4px;
		color: #333333;
		width: 1.52rem;
		height: 0.7rem;
		padding-top: 0.14rem;
		box-sizing: border-box;
	}
	
	.mr-t {
		margin-top: 0.2rem;
	}
	
	.mr-b {
		margin-bottom: 0.3rem !important;
	}
	
	.slide-in-enter-active {
		animation: slide-in .25s;
	}
	
	.slide-out-leave-active {
		animation: slide-out .25s;
	}
	
	@keyframes slide-in {
		from {
			transform: translate3d(-100%, 0, 0);
		}
		to {
			transform: translate3d(0, 0, 0);
		}
	}
	
	@keyframes slide-out {
		from {
			transform: translate3d(0, 0, 0);
		}
		to {
			transform: translate3d(-100%, 0, 0);
		}
	}
	
	.nav-active {
		background: #ffffff;
		position: relative;
		color: #ff1a18;
		border: 1px solid #ff1a18 !important;
	}
	
	.main {
		flex: 1;
		position: relative;
	}
	
	.animated {
		animation-duration: .55s;
		animation-fill-mode: both;
	}
	
	@keyframes fadeIn {
		from {
			opacity: 0;
			z-index: 0;
			display: none;
		}
		to {
			opacity: 1;
			z-index: 100;
			display: block;
		}
	}
	
	.fadeIn {
		animation-name: fadeIn;
	}
	
	@keyframes fadeOut {
		from {
			opacity: 1;
			z-index: 100;
			display: block;
		}
		to {
			opacity: 0;
			z-index: 0;
			display: none;
		}
	}
	
	.fadeOut {
		animation-name: fadeOut;
		display: none !important;
	}
	
	.fade-enter-active {
		animation: fade-in .35s;
	}
	
	.fade-leave-active {
		animation: fade-out .35s;
	}
	
	@keyframes fade-in {
		0% {
			opacity: 0;
		}
		100% {
			opacity: 0.5;
		}
	}
	
	@keyframes fade-out {
		0% {
			opacity: 0.5;
		}
		100% {
			opacity: 0;
		}
	}
	
	.child-view {
		position: absolute;
		width: 100%;
		transition: all .45s cubic-bezier(.55, 0, .1, 1);
		top: 0;
		bottom: 0;
		left: 0;
		right: 0;
		background: $bgColor;
		-webkit-backface-visibility: hidden;
		-webkit-transform-style: preserve-3d;
		z-index: 10;
	}
	
	.slide-left-enter,
	.slide-right-leave-active {
		opacity: 1;
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
		z-index: 1000;
	}
	
	.slide-left-leave-active,
	.slide-right-enter {
		opacity: 1;
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
	}
</style>