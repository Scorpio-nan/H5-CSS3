<template>
	<transition name="slide">
		<div id="Index">
			<div class="mui-off-canvas-wrap mui-draggable">
				<div class="mui-inner-wrap">
					<!-- 菜单容器 -->
					<aside class="mui-off-canvas-left" id="aside">
						<header class="aside-header" :style="IsApp ? appStyle : ''">
							<a class="mui-icon mui-action-menu mui-icon-back mui-pull-left backCenter"><span class="backFont mui-pull-right">返回首页</span></a>
						</header>
						<div class="aside-main">
							<div class="left-tab">
								<Scroller>
									<!-- 左边的导航页签 -->
									<ul class="aside-left-con">
										<li class="aside-item" data-active="0" :class="activeIndex == 0? 'active-red': ''">
											<a href="javascript:;">热门</a>
										</li>
										<li class="aside-item" data-active="1" :class="activeIndex == 1? 'active-green': ''">
											<a href="javascript:;">时时彩</a>
										</li>
										<li class="aside-item" data-active="2" :class="activeIndex == 2? 'active-blue': ''">
											<a href="javascript:;">11选5</a>
										</li>
										<li class="aside-item" data-active="3" :class="activeIndex == 3? 'active-light-red': ''">
											<a href="javascript:;">赛车</a>
										</li>
										<li class="aside-item" data-active="4" :class="activeIndex == 4? 'active-rgb': ''">
											<a href="javascript:;">快乐十分</a>
										</li>
										<li class="aside-item" data-active="5" :class="activeIndex == 5? 'active-plur': ''">
											<a href="javascript:;">快三</a>
										</li>
									</ul>
								</Scroller>
							</div>
							<div class="right-tab">
								<Scroller>
									<!-- 左边的彩票玩法 -->
									<ul class="side-right-con mui-clearfix">
										<li v-for="(item,i) in hotGame" class="mui-pull-left side-right-item mui-text-left mui-ellipsis" :class="selectIndex == i ? 'selectActive': ''" :data-select="i">
											<img :src="'static/img/temp/'+ item.CODE +'.png'" alt="" /> {{item.LOTTERY_TICKET_NAME}}
										</li>
									</ul>
								</Scroller>
							</div>
						</div>
					</aside>
					<!-- 主页面标题 -->
					<div id="content">
						<header class="mui-bar mui-bar-nav" id="header" :style="IsApp ? appStyle : ''">
							<!--  侧滑菜单     -->
							<a class="mui-icon mui-action-menu mui-go-back mui-pull-left" v-show="path != 'rule' && path != '/gameLong' && path != '/OpenResult' && path != '/BetDetail'">
								<!--<span class="backFont iconfont icon-icon-81"></span>-->
							</a>
							<!--  路由返回   -->
							<a class="mui-icon mui-history-back mui-icon-back mui-pull-left clickback1" v-show="path == 'rule' || path == '/gameLong' || path == '/OpenResult' || path == '/BetDetail'">
								<span class="backFont mui-pull-right"></span>
							</a>
							<h1 class="mui-title" v-if="$route.path == '/hk6_rule'" :style="{left: 40 + 'px'}">六合彩规则</h1>
							<!--<h1 class="mui-title" v-else>{{$route.query.title}}</h1>-->
							<h1 class="mui-title" v-else :style="path == 'rule' || path == '/gameLong' || path == '/OpenResult' || path == '/BetDetail' ? {left: 40 + 'px'} : ''">{{ishk6?hk6Type:$route.query.title}} <span class="iconfont icon-icon-81" v-if="path != 'rule' && path != '/gameLong' && path != '/OpenResult' && path != '/BetDetail'"></span></h1>

							<a class="mui-icon mui-icon-bars mui-pull-right propPiker"></a>
							<a class="mui-pull-right UserMoney">&yen;
								<CountUp class="userWin" :start-val="0" :end-val="parseFloat(Account.Wallet)" :duration="2" :decimals="2"></CountUp>
							</a>
						</header>
						<!-- 主页面内容容器 -->
						<div class="lot-main">
							<!--  如果页面是开奖结果、两面长龙、游戏规则就隐藏头部      -->
							<VHeader :data="itemDatas" v-show="path != 'rule' && path != '/gameLong' && path != '/OpenResult' && path != '/BetDetail'" :sy=islingSheng></VHeader>
							<div class="main-container">
								<transition :name="transitionName">
									<router-view class="child-view" :data=itemDatas></router-view>
								</transition>
							</div>
							<!--右上角弹出菜单-->
							<transition name="fadeIn">
								<div class="model-container animated" v-show="propover">
									<transition name="SlideUp">
										<ul class="container-list" v-show="propover">
											<li class="list-item triangle" data-index="0">
												<a href="javascript:;">即时注单<span class="userWin">&yen;{{UserWin.Now}}</span></a>
											</li>
											<li class="list-item" data-index="1">
												<a href="javascript:;">开奖结果</a>
											</li>
											<li class="list-item" data-index="2">
												<a href="javascript:;">游戏规则</a>
											</li>
											<li class="list-item" data-index="3"  v-if="$route.query.code !='hk6' && $route.query.code != 'jisuhk6' ">
												<a href="javascript:;">两面长龙</a>
											</li>
											<li class="list-item" data-index="4"  v-if="$route.query.code !='hk6' && $route.query.code != 'jisuhk6' ">
												<a href="javascript:;">今日输赢 <span class="userWin">&yen;<CountUp :start-val="1" :end-val="parseFloat(UserWin.Win)" :duration="3" :decimals="2"></CountUp></span></a>
											</li>
											<li class="list-item">
												<a class="mui-table" href="javascript:;">
													<span class="mui-table-cell mui-vertical">铃声</span>
													<div  class="mui-switch mui-table-cell mui-active" id="switch">
														<div class="mui-switch-handle"></div>
													</div>
												</a>
											</li>
											
										</ul>
									</transition>
								</div>
							</transition>
						</div>
						<div class="mui-off-canvas-backdrop"></div>
					</div>
				</div>
			</div>
			<div style="display: none;">
				<audio controls="controls" id="aplayMusic_cuttime" src="static/img/music/cuttime.mp3" type="audio/mp3"></audio>
			</div>
			<!--  投注弹框      -->
			<ActionSheet :show="handlePour.IsShow" @hide="handleAction" :arr="handlePour.arr">
				<template>
					<span slot="title">{{handlePour.title}}</span>
				</template>
			</ActionSheet>
		</div>
	</transition>
</template>

<script>
	import ActionSheet from './template/ActionSheet.vue';
	import VHeader from './template/Header.vue';
	import Scroller from '@/components/Scroller';
	import WebApi from '@/api/webUtil';
	import CountUp from '@/components/CountUp';
	export default {
		props: {
			datas: Object
		},
		name: 'Index',
		components: {
			VHeader,
			ActionSheet,
			Scroller,
			CountUp
		},
		data() {
			return {
				cuttimeMusic: './static/img/music/cuttime.mp3',
				staringMusic: './static/img/music/staring.mp3',
				islingSheng:true,
				ishk6: false,
				appStyle: {
					'height': '1.32rem',
					'padding-top': '0.4rem'
				},
				hk6Type:'十分六合彩',
				title: '彩票游戏',
				hotGame: [], //热门系列
				eleven: [], //11选5系列
				ssc: [], //实时彩系列
				racing: [], //赛车系列
				klsfc: [], //快乐十分系列
				kthree: [], //快三系列
				lotArr: [], //其他分类
				activeIndex: 0,
				selectIndex: 100,
				itemDatas: {
					name: '香港六合彩',
					code: 'hk6',
					id: 27,
					title: '香港六合彩'
				},
				propover: false,
				transitionName: 'slide-left',
				IsApp: lib.IsApp,
			}
		},
		beforeRouteUpdate(to, from, next) {
			let isBack = this.$router.isBack
			if(isBack) {
				this.transitionName = 'slide-right'
			} else {
				this.transitionName = 'slide-left'
			}
			this.$router.isBack = false
			next();
		},
		mounted() {
			const that = this;
			this.Routerpath(this.$route.query.code);
			var pachCode = this.$route.query.code;
			if(that.ishk6) {if(that.$route.path.split('/')[1] == 'LotIndex') {pachCode = 'HK6'} else {pachCode = that.$route.path.split('/')[1];}};
//			this.onRouterClick(pachCode, this.$route.query.id, this.$route.query.name, this.$route.query.title);
			if(that.$route.query.id=='27'){that.hk6Type='香港六合彩'}else{that.hk6Type='十分六合彩'};
			mui.init();
			mui.ready(function() {
				mui('#header').on('tap', '.mui-action-menu', function() {
					mui('.mui-off-canvas-wrap').offCanvas().toggle();
				})

				mui('#header').on('tap', '.mui-history-back', function() {
					that.$router.goBack();
				})

				mui('#aside').on('tap', '.backCenter', function() {
					that.$router.replace('/')
				})

				mui('.left-tab').on('tap', '.aside-item', function() {
					var activeIndex = $(this).data('active');
					that.activeIndex = activeIndex;
					that.selectIndex = 100;
					switch(activeIndex) {
						case 0:
							that.init();
							break;
						case 1:
							that.hotGame = that.ssc;
							break;
						case 2:
							that.hotGame = that.eleven;
							break;
						case 3:
							that.hotGame = that.racing;
							break;
						case 4:
							that.hotGame = that.klsfc;
							break;
						default:
							that.hotGame = that.kthree;
							break;
					}
				})

				mui('.right-tab').on('tap', '.side-right-item', function() {
					mui('.mui-off-canvas-wrap').offCanvas().toggle();
					var selectIndex = $(this).data('select');
					that.selectIndex = selectIndex;
					that.onRouterClick(that.hotGame[selectIndex].CODE, that.hotGame[selectIndex].ID, that.hotGame[selectIndex].LOTTERY_TICKET_NAME, that.hotGame[selectIndex].LOTTERY_TICKET_NAME)
					if(that.$route.query.id=='27'){that.hk6Type='香港六合彩'}else{that.hk6Type='十分六合彩'};
				})
				mui('#header').on('tap', '.propPiker', function() {
					that.handleModel();
				})

				mui('.lot-main').on('tap', '.model-container', function() {
					that.propover = false;
					$('.container-list').slideUp(250);
				})

				mui('.container-list').on('tap', '.list-item', function() {
					var index = $(this).data('index');
					if(index == 0) {
						that.$router.push({
							path: '/BetDetail',
							query: {
								id: that.$route.query.id,
								title: '注单明细',
								name: that.$route.query.name,
								code: that.$route.query.code
							}
						})
					} else if(index == 1) {
						that.$router.push({
							path: '/OpenResult',
							query: {
								title: '开奖结果',
								id: that.$route.query.id,
								name: that.$route.query.name,
								code: that.$route.query.code

							}
						})
					} else if(index == 2) {
						that.$router.push({
							path: that.Introduce(),
							query: {
								id: that.$route.query.id,
								title: '游戏规则',
								name: that.$route.query.name,
								code: that.$route.query.code
							}
						})
					} else if(index == 3) {
						that.$router.push({
							path: '/gameLong',
							query: {
								id: that.$route.query.id,
								title: '两面长龙',
								name: that.$route.query.name,
								code: that.$route.query.code
							}
						})
					}
					that.handleModel();

					//点击穿透hack
					return false;
				})

				mui('.container-list').on('tap', '.mui-switch', function() {
					var isActive = document.querySelector('#switch').classList.contains("mui-active");
					if(isActive) {
						$(this).removeClass('mui-active');that.islingSheng=false;
					} else {
						$(this).addClass('mui-active');
						that.islingSheng=true;
					}

					//点击穿透hack
					return false;
				})
			})
			
			if(this.islogin){
				that.$store.dispatch('getAccount');
			}
			
			if(lib.IsApp) {
				document.addEventListener('plusready', function() {
					var webview = plus.webview.currentWebview();
					plus.key.addEventListener('backbutton', function() {
						webview.canBack(function(e) {
							if(e.canBack) {
								webview.back();
							} else {
								mui.plusReady(function() {
									//首页返回键处理
									//处理逻辑：1秒内，连续两次按返回键，则退出应用；
									var first = null;
									plus.key.addEventListener('backbutton', function() {
										//首次按键，提示‘再按一次退出应用’
										if(!first) {
											first = new Date().getTime();
											mui.toast('再按一次退出应用');
											setTimeout(function() {
												first = null;
											}, 1000);
										} else {
											if(new Date().getTime() - first < 1500) {
												plus.runtime.quit();
											}
										}
									}, false);
								});
							}
						})
					});
				});
			}
		},
		methods: {
			onRouterClick(_code, __id, __name, _title) {
				var Routerpath = this.Routerpath(_code);
				if(this.ishk6) {
					var pachCode = this.$route.query.code;
					if(_code=='hk6'){_code = 'hk6'}else if(_code=='jisuhk6'){_code = 'jisuhk6'}else{if(pachCode=='hk6'){_code = 'hk6'}else{_code = 'jisuhk6'}}
				}
				let obj = {
					id: __id,
					code: _code,
					name: __name,
					title: _title
				}
				this.itemDatas = obj;
				this.$router.push({
					path: Routerpath,
					query: {
						id: __id,
						code: _code,
						name: __name,
						title: _title,
					}
				});
			},
			//彩票游戏界面复用
			Routerpath(code) {
				if(code) {
					if(code == 'hk6' || code == 'jisuhk6') {
						this.ishk6 = true;
						return '/hk6';
					} else {
						this.ishk6 = false;
					}
					if(code == 'cqssc' || code == 'xjssc' || code == 'jsssc' || code == 'tjssc' || code == 'ynssc') {
						return '/SSC';
					} else if(code.indexOf("k3") >= 0) {
						return '/cp3';
					} else if(code.indexOf("11x5") >= 0) {
						return '/cp11';
					} else if(code == 'tjklsf' || code == 'gdklsf' || code == 'cqklsf' || code == 'gxklsf') {
						return '/gdklsf';
					} else if(code == 'mlaft' || code == 'jspk10' || code == 'bjpk10') {
						return '/bjpk10';
					} else if(code == 'hk6' || code == 'jisuhk6') {
						return '/hk6';
					} else {
						this.ishk6 = true;
						return '/' + code;
					}
				}

			},
			handleNavChange(index) {

			},
			init() {
				const that = this;
				this.hotGame = [];
				this.eleven = [];
				this.ssc = [];
				this.racing = [];
				this.klsfc = [];
				this.kthree = [];
				WebApi.GetMobileList(2, function(res) {
					var hk6 = {CODE: "hk6",ID: 27,LOTTERY_TICKET_NAME: "香港六合彩",MOBILE_IND: "1",MOBILE_LOGO_URL: "/img/base/jisuhk6.png",PARA_NAME: "香港六合彩",PERIODS_NO: "0",REMARK: "香港六合彩",}
					var jishuhk6 = {CODE: "jisuhk6",ID: 1827,LOTTERY_TICKET_NAME: "十分六合彩",MOBILE_IND: "1",MOBILE_LOGO_URL: "/img/base/jisuhk6.png",PARA_NAME: "十分六合彩",PERIODS_NO: "0",REMARK: "十分六合彩",}
					that.hotGame.push(hk6);
					that.hotGame.push(jishuhk6);
					res.forEach((item, i, arr) => {
						if(arr[i].CODE.indexOf('cpyx') == -1) {
							if(arr[i].CODE.indexOf('jisuhk6') == -1) {
								that.hotGame.push(arr[i]);
							}
						}
						if(arr[i].CODE.indexOf('11x5') != -1) {
							that.eleven.push(arr[i]);
						} else if(arr[i].CODE.indexOf('ssc') != -1) {
							that.ssc.push(arr[i]);
						} else if(arr[i].CODE.indexOf('k3') != -1) {
							that.kthree.push(arr[i]);
						} else if(arr[i].CODE.indexOf('klsf') != -1) {
							that.klsfc.push(arr[i]);
						} else if(arr[i].CODE.indexOf('bjpk10') != -1 || arr[i].CODE.indexOf('jspk10') != -1 || arr[i].CODE.indexOf('mlaft') != -1) {
							that.racing.push(arr[i]);
						} else {
							that.lotArr.push(arr[i]);
						}
					});
				})
			},

			//彩票游戏规则复用
			Introduce() {
				localStorage.setItem('GameRule', JSON.stringify(this.itemDatas));
				let ID = this.itemDatas.id;
				let code = this.itemDatas.code;
				if(ID == 16 || ID == 19 || ID == 1055) {
					return '/bjpk10_rule';
				} else if(ID == 595 || ID == 596 || ID == 17 || ID == 18 || ID == 1043) {
					return '/cqssc_rule';
				} else if(ID == 20 || ID == 21 || ID == 855) {
					return '/gdklsf_rule';
				} else if(code.indexOf('k3') >= 0) {
					return '/kuaisan_rule';
				} else if(code.indexOf('11x5') > 0) {
					return '/11x5_rule';
				} else if(ID == 27 || ID == 1827) {
					return '/hk6_rule';
				} else {
					return '/' + this.itemDatas.code + '_rule';
				}
			},
			handleModel() {
				const that = this;
				that.propover = !that.propover;
			},
			handleAction() {
				this.$store.dispatch('handleBetPour', {
					IsShow: false,
					title: '',
					arr: []
				});
			}
		},
		created() {
			const that = this;
			that.itemDatas=that.CitemDatas;
			this.title = this.$route.query.title;
			this.init();
			var t = setTimeout(() => {
				this.$store.dispatch('getAccount');
				this.$store.dispatch('getUserWin');
			}, 2500)
		},
		computed: {
			CitemDatas(){
				return {name: this.$route.query.name,code: this.$route.query.code,id: this.$route.query.id,title: this.$route.query.title}
			},
			islogin() {
				return this.$store.getters.checkLoginState;
			},
			handlePour() {
				return this.$store.getters.handleBetPour;
			},
			path() {
				var path = this.$route.path;
				if(path.indexOf('_rule') != -1) {
					return 'rule'
				} else {
					return path;
				}
			},
			Account() {
				var UserArr = this.$store.getters.getAccount;
				var obj = {
					Wallet: '',
					Integral: ''
				}
				for(let i = 0; i < UserArr.length; i++) {
					if(UserArr[i].ACC_BAL_CD == 'my_wallet') {
						obj.Wallet = UserArr[i].ACC_BAL.toFixed(2);
					} else {
						obj.Integral = UserArr[i].ACC_BAL.toFixed(2);
					}
				}
				return obj;
			},
			UserWin() {
				var UserWin = this.$store.getters.getUserWin;
				if(UserWin != null && UserWin != undefined) {
					if(UserWin.length > 0) {
						return {
							Win: UserWin[0].WIN_AMT.toFixed(2),
							Now: UserWin[0].NOWBET_AMT.toFixed(2)
						}
					} else {
						return {
							Win: '0.00',
							Now: '0.00'
						}
					}
				} else {
					return {
						Win: '0.00',
						Now: '0.00'
					}
				}
			}
		},
		beforeUpdate() {
			if(!this.islogin) {
				this.$store.dispatch('checkLoginState');
			}
		},
		watch: {

		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	#Index,
	#content {
		width: 100%;
		height: 100%;
		position: relative;
	}
	
	.mui-vertical {
		width: 0.8rem;
		transform: translateY(-0.18rem);
	}
	
	#header {
		position: static !important;
		background: $titleBgColor;
		box-shadow: 0 0 0 rgba(0, 0, 0, 0);
		color: #fff !important;
		a {
			color: #fff !important;
		}
		.mui-title {
			color: #fff;
			font-size: 0.32rem;
			text-align: left;
			left: 0.24rem;
			.iconfont{
				font-size: 0.34rem;
				vertical-align: -1px;
			}
		}
		.mui-go-back {
			padding-left: 140px;
			margin-right: -10px;
		    margin-left: -10px;
		    padding-right: 10px;
		    padding-top: 35px;
		}
		.mui-icon-back:before,
		.mui-icon-left-nav:before {
			font-size: 0.48rem;
			transform: translateY(3px);
		}
		.UserMoney {
			padding: 0.24rem;
		}
	}
	
	#aside {
		display: flex;
		flex-direction: column;
	}
	
	#content {
		display: flex;
		flex-direction: column;
	}
	
	.lot-main {
		position: relative;
		height: 100%;
		width: 100%;
		display: flex;
		flex-direction: column;
		.main-container {
			flex: 1;
			position: relative;
		}
	}
	
	.backFont {
		font-size: 0.28rem;
		margin-top: 0.15rem;
	}
	
	.aside-header {
		height: 44px;
		background: $titleBgColor;
		line-height: 44px;
		color: #fff !important;
		a {
			color: #fff !important;
			padding: 10px;
		}
	}
	
	.aside-main {
		flex: 1;
		position: relative;
		background: $bgColor;
		display: flex;
	}
	
	.mui-content {
		background: $bgColor;
	}
	
	.left-tab {
		width: 0.7rem;
		position: relative;
		.aside-left-con {
			width: 100%;
		}
		.aside-item {
			height: 2.2rem;
			position: relative;
			a {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -50%);
				font-weight: 600;
			}
		}
	}
	
	.aside-left-con {
		background: #eee;
		li {
			padding: 0.1rem 0.15rem;
			font-size: 0.28rem;
			position: relative;
			&:after {
				display: block;
				content: '';
				position: absolute;
				height: 2px;
				background: #fff;
				width: 0.7rem;
				position: absolute;
				bottom: 0;
				left: 0rem;
			}
			a {
				color: $normalFontColor;
			}
		}
		li:last-child {
			&:after {
				display: none;
			}
		}
		.active-red {
			background: red;
			a {
				color: #fff;
			}
		}
		.active-green {
			background: #ff5536;
			a {
				color: #fff;
			}
		}
		.active-blue {
			background: #00d56d;
			a {
				color: #fff;
			}
		}
		.active-light-red {
			background: #ad23ff;
			a {
				color: #fff;
			}
		}
		.active-rgb {
			background: #0099CC;
			a {
				color: #fff;
			}
		}
		.active-plur {
			background: #eba002;
			a {
				color: #fff;
			}
		}
	}
	
	.right-tab {
		flex: 1;
		position: relative;
		background: #fff;
	}
	
	.side-right-con {
		.side-right-item {
			width: 50%;
			font-size: 0.28rem;
			padding: 0.24rem 0;
			text-indent: 0.1rem;
			padding-left: 0.1rem;
			img {
				display: inline-block;
				width: 0.9rem;
				height: 0.9rem;
			}
		}
		.iconfont {
			text-indent: 0.2rem;
		}
		.selectActive {
			background: #F5F6F7;
			box-sizing: border-box;
			box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.2);
			position: relative;
			&:after {
				content: '';
				display: block;
				width: 0.38rem;
				height: 0.38rem;
				position: absolute;
				bottom: 0;
				right: -1px;
				background: url('~static/img/public/lottery_selecet.png') no-repeat;
				background-size: 100% 100%;
			}
		}
	}
	
	.child-view {
		position: absolute;
		width: 100%;
		transition: all .45s cubic-bezier(.55, 0, .1, 1);
		top: 0;
		bottom: 0;
		left: 0;
		right: 0;
		background: $bgColor;
		-webkit-backface-visibility: hidden;
		-webkit-transform-style: preserve-3d;
		z-index: 10;
		/*will-change: transform;*/
	}
	
	.slide-left-enter,
	.slide-right-leave-active {
		opacity: 1;
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
		z-index: 1000;
		/*-webkit-backface-visibility: hidden;
		perspective: 1000;*/
	}
	
	.slide-left-leave-active,
	.slide-right-enter {
		opacity: 1;
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
		/*-webkit-backface-visibility: hidden;
		perspective: 1000;*/
	}
	
	.mui-switch.mui-active .mui-switch-handle {
		transform: translate(27px, 0);
	}
	
	.model-container {
		position: absolute;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		background: rgba(0, 0, 0, 0.5);
		z-index: 100;
		.container-list {
			position: absolute;
			right: 0.24rem;
			top: 0.03rem;
			background: #fff;
			border-radius: 4px;
			width: 2.4rem;
			li {
				padding: 0.15rem;
				position: relative;
				&:after {
					content: '';
					display: block;
					border-bottom: 1px solid #999;
					width: 100%;
					background: #ccc;
					position: absolute;
					bottom: 0;
					left: 0;
					transform-origin: 0 0;
					transform: scaleY(0.5);
				}
			}
			li:last-child {
				padding-bottom: 0;
				&:after {
					display: none;
				}
			}
			a {
				font-size: 0.28rem;
			}
			.triangle {
				&:before {
					content: '';
					display: block;
					width: 0.4rem;
					height: 0.4rem;
					background: #fff;
					position: absolute;
					z-index: -1;
					top: -0.15rem;
					right: 0.1rem;
					transform: rotate(45deg);
				}
			}
			.userWin {
				color: green;
				padding: 2px 5px;
			}
		}
		#switch {
			width: 57px;
		}
	}
	.clickback1{
		padding-right: 1.8rem !important;
	}
	.mot_tc {
		position: absolute;
		top: 0;
		left: 0;
		background-color: #000;
		opacity: 0.5;
		height: 100%;
		width: 100%;
		z-index: 14;
	}
	/*
	 	刚进入页面初始化动画
	 * */
	
	.slide-enter-active {
		animation: slide-in .35s;
	}
	
	.slide-leave-active {
		animation: slide-out .35s;
	}
	
	@keyframes slide-in {
		0% {
			transform: translate3d(100%, 0, 0);
		}
		100% {
			transform: translate3d(0%, 0, 0);
		}
	}
	
	@keyframes slide-out {
		0% {
			transform: translate3d(0%, 0, 0);
		}
		100% {
			transform: translate3d(100%, 0, 0);
		}
	}
	/*
	 	顶部弹出页签遮罩动画
	 * */
	
	.fadeIn-enter-active {
		animation: fade-in .35s;
	}
	
	.fadeIn-leave-active {
		animation: fade-out .35s;
	}
	
	@keyframes fade-in {
		0% {
			opacity: 0;
		}
		100% {
			opacity: 1;
		}
	}
	
	@keyframes fade-out {
		0% {
			opacity: 1;
		}
		100% {
			opacity: 0;
		}
	}
	/*
	 	顶部弹出页签动画
	 * */
	
	.SlideUp-enter-active {
		animation: SlideUp .2s;
	}
	
	.SlideUp-leave-active {
		animation: SlideDown .35s;
	}
	
	@keyframes SlideUp {
		0% {
			height: 0;
			overflow: hidden;
		}
		100% {
			height: 2.26rem;
			overflow: hidden;
		}
	}
	
	@keyframes SlideDown {
		0% {
			height: 2.26rem;
			overflow: hidden;
		}
		100% {
			height: 0;
			overflow: hidden;
		}
	}
</style>