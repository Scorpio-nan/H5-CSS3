<template>
	<div id="GuildList">
		<ul class="mui-table-view listbox">
			<li class="mui-table-view-cell item" v-for="item in list" :data-index=item.id>
				<a class="mui-navigate-right mui-text-left">
					{{ item.title }}
				</a>
			</li>
		</ul>
	</div>
</template>

<script>
	export default {
		props: {
			datas: Object
		},
		name: 'Index',
		data() {
			return {
				list:[
					{id: 0, title: '注册代理'},
					{id: 1, title: '进入代理中心'},
					{id: 2, title: '查看收益'},
					{id: 3, title: '生成邀请码以及管理邀请码'},
					{id: 4, title: '自助创建下级账号'},
					{id: 5, title: '查看下级 账号及功能'},
					{id: 6, title: '查看下级投注报表与财务报表'},
					{id: 7, title: '查看下级财务'},
					{id: 8, title: '查看下级注单'},
					{id: 9, title: '如何使用赔率计算'}
				],
				index:''
			}
			
		},
		mounted(){
			const that =this;
			mui.init();
			mui.ready(function(){
				mui('.listbox').on('tap','.item',function(e){
					var index = $(this).data('index');
					that.index = index;
					console.log(that.index)
					
					localStorage.setItem('index',that.index)
					
					that.$router.push({
						path: '/GuildSwiperList',
					})
					
				})
			})
		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	.mui-table-view-cell{
		height: .88rem;
		margin-bottom: 1px;
		font-family: "microsoft yahei";
		@include border-1px(#ccc,bottom);
		
		.mui-navigate-right{
			font-family: "microsoft yahei";
			font-size: .28rem;
		}
		&:after{
			left: 0;
		}
	}
</style>