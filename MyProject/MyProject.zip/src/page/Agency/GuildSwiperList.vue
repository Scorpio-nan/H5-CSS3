<template>
	<div id="GuildSwperList">
		<!--轮播图主组件-->
		<div class="mui-slider">
			<div class="mui-slider-group">
				
				<div class="mui-slider-item" v-for="item in list">
					<!-- 具体内容 -->
					<img :src=item.src alt=" ">
				</div>
		
			</div>
			
			<div class="mui-slider-indicator">
				<div class="mui-indicator" v-for='i in list.length'></div>
				
			</div>
		</div>
		<!--显示圆点-->
		
	</div>
</template>

<script>
	export default {
		name: 'GuildSwperList',
		data() {
			return {
				list: [
					{id:0,src:'static/img/guildimgs/0.png'},
					{id:1,src:'static/img/guildimgs/1.png'},
					{id:2,src:'static/img/guildimgs/2.png'},
					{id:3,src:'static/img/guildimgs/3.png'},
					{id:4,src:'static/img/guildimgs/4.png'},
					{id:5,src:'static/img/guildimgs/5.png'},
					{id:6,src:'static/img/guildimgs/6.png'},
					{id:7,src:'static/img/guildimgs/7.png'},
					{id:8,src:'static/img/guildimgs/8.png'},
					{id:9,src:'static/img/guildimgs/9.png'}
				],
				index:''
			}
		},
		mounted() {
			
			let that = this;
			that.index = localStorage.getItem('index')
			mui('.mui-slider-indicator .mui-indicator')[that.index].classList.add('mui-active')
			mui.init();
			mui.ready(function() {
				//获得slider插件对象
				var slider = mui('.mui-slider');
				
				slider.slider().gotoItem(that.index);//跳转到第index张图片，index从0开始；
				slider.slider({
					interval: 0 //自动轮播周期，若为0则不自动播放，默认为0；
				});
			});

		}
	}
</script>

<style scoped lang='scss'>
	.mui-slider-group{
		width: 100%;
		height: 100%;
		padding-bottom: .5rem;
		margin: auto;
		img{
			padding:.6rem 1.15rem .4rem 1.15rem;
		}
	}
	.mui-slider-indicator{
		padding-top: .4rem;
		.mui-indicator{
			width: .22rem;
			height: .22rem;
			box-shadow: none;
			
		}
		.mui-active{
			background-color: #19b4f5;
		}
	}
	.mui-indicator{
		margin: 0 .05rem;
	}
</style>