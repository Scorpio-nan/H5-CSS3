<template>
	<div class="AgencyDevelopCourse">
		<div class="mui-scroll-wrapper" id="refreshContainer">
			<div class="mui-scroll">
				<!--顶部图片区域 高度290像素 2.9rem-->
				<div class="banner">
					<img src="static/img/guildimgs/banner.png" />
				</div>
				<!--中部导航 高度593像素 5.93rem-->
				<div class="nav">
					<!--标题字体32px 0.32rem 上边距40px .4rem-->
					<h1 class="title">注册开户说明</h1>
					<!--文章字体22px 0.22rem 上边距21px .21rem-->
					<p class="content">注册成功后 , 代理账户可自行娱乐游戏和发展线下代理或会员</p>
					<!--文章字体22px 0.22rem 上边距22px .22rem height240px 2.4rem 上边距40px .4rem-->
					<div class="functionBlock">
						<div>
							<!--标题28px .28rem-->
							<h1>功能一</h1>
							<p class="one">代理账户</p>
							<p class="two">自行娱乐</p>
						</div>
						<div>
							<!--标题28px .28rem height66px .66rem-->
							<h1>功能二</h1>
							<p class="one">发展</p>
							<p class="two">线下代理</p>
						</div>
						<div>
							<!--标题28px .28rem-->
							<h1>功能三</h1>
							<p class="one">发展</p>
							<p class="two">下线会员</p>
						</div>
					</div>
					<div class="btnContainer">
						<button class="tobeAgent">点击获取代理发展教程</button>
					</div>
				</div>

				<!--二维码区域-->
				<div class="saoma">
					<div class="logo">
						<img src="static/img/guildimgs/chat.png" alt="1" />
						<p class="p">代理微信咨询</p>
						<p>KK77448825</p>
					</div>
					<div class="logo">
						<img src="static/img/guildimgs/qq.png" alt="2" />
						<p class="p">代理微信咨询</p>
						<p>KK77448825</p>
					</div>
				</div>

				<!--代理流水洗码模式-->
				<div class="runningWater">
					<h1>代理流水洗码模式</h1>
					<p>流水洗码是根据下级会员所产生的有效投注计算不计输赢 , 代理即可赚取</p>
					<div class="commission">
						<div class="left">
							<span>代理流水洗码模式</span><br />
							<span>(下级会员+下级代理发展的会员)</span>
						</div>
						<div class="left1">
							<div class="middle">
								<span class="mui-icon mui-icon-closeempty"></span>
								<span>分润点 =</span>
							</div>
							<div class="right">
								<span>佣金</span><br />
								<span>( 代理收益 )</span>
							</div>
						</div>
					</div>
				</div>
				
				<!--代理共赢亮点-->
				<div class="agencyWin">
					<h1>代理共赢亮点</h1>
					<div class="agency-item mr-t">
						<h1>佣金日结</h1>
						<p>佣金日结，于次日12:00 - 13:00自动派送至游戏账号自行提款即可</p>
					</div>
					<div class="agency-item mr-t">
						<h1>有效注单</h1>
						<p>代理发展线下会员必须是真实有效，如虚假注册或无风险下注产生有效投注将取消佣金派送或代理资格</p>
					</div>
					<div class="agency-item mr-t">
						<h1>资源合作</h1>
						<p>如果您有好的推广资源</p>
						<p>请立即向公司申请定制邀请注册验证码专属推广网站</p>
					</div>
				</div>
				
				<CopyRight></CopyRight>
			</div>
		</div>
	</div> 
</template>

<script>
	import CopyRight from '@/components/CopyRight'
	export default {
		mounted() {
			let that = this;
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					bounce: true,
					indicators: true,
					deceleration: 0.0009
				});
				mui('.btnContainer').on('tap','.tobeAgent',function(){
					that.$router.push({
						path: 'GuildList'
					})
				})
			})
		},
		components:{
			CopyRight
		}
	}
</script>

<style scoped lang="scss" type="text/css">
	.AgencyDevelopCourse {
		/*position: relative;*/
		width: 100%;
		height: 100%;
		background-color: #F5F6F7;
		.banner img {
			width: 100%;
			height: auto;
		}
		.nav {
			width: 100%;
			height: 5.93rem;
			background-color: #fff;
			.title {
				display: inline-block;
				margin-top: .4rem;
				font-size: .32rem;
				font-weight: 400;
				color: #333333;
			}
			.content {
				display: block;
				padding-top: .21rem;
				width: 4.1rem;
				line-height: .3rem;
				margin: auto;
				font-size: .22rem;
				color: #333333;
			}
			.functionBlock {
				display: flex;
				width: 100%;
				padding: .2rem .4rem 0 .4rem;
				div {
					width: 1.8rem;
					height: 2.4rem;
					border: 1px solid #18B4F6;
					border-radius: .06rem;
					margin: auto;
					h1 {
						padding: .19rem;
						font-size: .28rem;
						background-color: #18B4F6;
						color: #fff;
					}
					.one {
						font-size: .26rem;
						color: #666;
						padding-top: .42rem;
						height: 0;
					}
					.two {
						font-size: .32rem;
						color: #333;
						height: 0;
						font-weight: bold;
						margin-top: .6rem;
					}
				}
			}
			.btnContainer {
				width: 100%;
				height: 1.68rem;
				button {
					width: 5rem;
					padding: .22rem;
					background-color: #EC5156;
					font-size: .36rem;
					color: #fff;
					margin: .45rem;
					font-weight: bold;
				}
			}
		}
	}
	
	.saoma {
		display: flex;
		width: 100%;
		height: 3.6rem;
		padding-top: .4rem;
		padding: .4rem 1.4rem;
		background-color: #fff;
		margin-top: .16rem;
		.logo {
			flex: 1;
			height: 1.72rem;
			width: 1.72rem;
			display: inline-block;
			background-color: #fff;
			img {
				height: 1.72rem;
				width: 1.72rem;
			}
			p {
				display: block;
				height: 0;
				margin-top: .25rem;
				color: #333;
				padding-top: .25rem;
			}
			.p {
				margin-top: 0 !important;
			}
		}
	}
	
	.runningWater {
		padding-top: .6rem !important;
		padding: .2rem;
		margin-top: .16rem;
		background-color: #fff;
		h1 {
			font-weight: 400;
			color: #333;
		}
		p {
			display: block;
			margin: .2rem auto;
			width: 4.58rem;
			font-size: .24rem;
			line-height: .3rem;
			color: #333;
		}
	}
	
	.commission {
		width: 100%;
		color: #fff;
		display: flex;
		background: #F5F6F7;
		padding: 0.24rem 0.1rem;
		div {
			flex: 1;
			display: inline-block;
			color: #333;
		}
		.left {
			width: 6rem;
			line-height: .3rem;
		}
		.left span {
			display: inline-block;
			flex: 1;
			font-size: .24rem;
		}
		.left1 {
			display: flex;
			flex: 1;
			.middle span {
				display: inline-block;
				flex: 1;
				font-size: .28rem;
				height: .55rem;
				line-height: .52rem;
				margin-right: -.2rem;
			}
			.right span {
				flex: 1;
				font-size: .28rem;
			}
			.middle {
				padding: .2rem 0;
				padding-top: .1rem;
				line-height: .25rem;
				.mui-icon-closeempty {
					font-size: .55rem;
					font-weight: bold;
					vertical-align: middle;
				}
			}
			.right {
				padding-top: .02rem;
				line-height: .3rem;
			}
		}
	}
	
	.agencyWin{
		margin-top: 0.16rem;
		padding: 0.24rem;
		background: #fff;
		padding-top: 0.6rem;
		h1{
			font-weight: 300;
			color: #333;
		}
		.agency-item{
			text-align: left;
			padding: 0.24rem;
			background: #F5F6F7;
			color: #666;
			p{
				font-size: 0.24rem;
			}
		}
		.mr-t{
			margin-top: 0.16rem;
		}
	}
	
	.lastTitle p{
		font-size: .28rem;
		color: #666 !important;
		text-align: center !important;
		padding-top: .8rem;
		padding-bottom: .98rem;
	}
</style>