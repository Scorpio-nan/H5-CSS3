<template>
	<div id="Index">
		<header class="mui-bar mui-bar-nav title-border mui-clearfix" id="Title" :style="isApp ? appStyle : ''" :class="$route.path == '/' ? 'bg-white':''">
			<a href="javascript:;" class="mui-pull-left color-white" v-show="$route.path != '/' && $route.path != '/Center'"><span class="mui-icon mui-icon-back clickback"></span></a>
			<a href="javascript:;" class="downloadApp" v-show="$route.path == '/' && !isApp">APP下载</a>
			<a href="javascript:;" class="joinAgent" v-show="$route.path == '/' && isApp">代理加盟</a>
			<a href="javascript:;" class="Center-service" v-show="$route.path == '/Center'">
				<span class="iconfont icon-icon-9"></span>
				<p>客服</p>
			</a>
			<img class="mui-pull-left logo" src="static/img/index/logo1.png" v-show="$route.path == '/'" />
			<h1 class="mui-title color-white" v-show="$route.path != '/'">{{$route.meta.title}}</h1>
			<div class="service" v-show="$route.path == '/'">
				<a href="javascript:;" class=" redbag animate">
					<img src="static/img/public/red-packet.png" />
				</a>
				<!--   v-show="!islogin"  -->
				<a href="javascript:;" class=" Register" v-show="!islogin">
					<span class="iconfont icon-icon-21"></span>
					<p>注册</p>
				</a>
				<a href="javascript:;" class=" Service">
					<span class="iconfont icon-icon-9"></span>
					<p>客服</p>
				</a>
			</div>
		</header>
		<div class="mui-content">
			<transition :name="transitionName">
				<router-view class="child-view"></router-view>
			</transition>
			<div class="Login-tips mui-clearfix" v-show="$route.path != '/Login' && $route.path != '/Register' && !islogin">
				<div class="mui-text-left mui-pull-left tips">
					<p class="font-14">登陆后，精彩无限~</p>
					<p class="font-12">注册登录立马领取8元红包，精彩不停</p>
				</div>
				<button type="button" class="mui-btn mui-btn-primary mui-pull-right mr-t link-login">立即登录</button>
			</div>
		</div>


		<footer class="footer border-1px" v-show="$route.meta.IsShow">
			<a href="javascript:;" class="nav-item" data-index="0" :class="index == 0 ? 'nav-active' : ''">
				<span class="iconfont icon-icon-68"></span>
				<p>首页</p>
			</a>
			<a href="javascript:;" class="nav-item" data-index="1" :class="index == 1 ? 'nav-active' : ''">
				<span class="iconfont icon-icon-4"></span>
				<p>存款</p>
			</a>
			<a href="javascript:;" class="nav-item" data-index="2" :class="index == 2 ? 'nav-active' : ''">
				<span class="iconfont icon-icon-3"></span>
				<p>投注记录</p>
			</a>
			<a href="javascript:;" class="nav-item" data-index="3" :class="index == 3 ? 'nav-active' : ''">
				<span class="iconfont icon-icon-2"></span>
				<p>额度转换</p>
			</a>
			<a href="javascript:;" class="nav-item" data-index="4" :class="index == 4 ? 'nav-active' : ''">
				<span class="iconfont icon-icon-10"></span>
				<p>个人中心</p>
			</a>
		</footer>

		<!-- 公告弹窗 -->
		<transition name="fadeIn">
			<div id="Noticetcbox" v-show="NoticetcShow">
				<transition name="bounce">
					<div class="Noticetc">
						<div class="posbox">
							<div class="NtcContent"></div>
							<img  class="Notclose" src="static/img/public/red_over.png" alt="">
						</div>
						<button class="closebtn">我知道了</button>
					</div>
				</transition>
			</div>
		</transition>

		<!--   红包活动     -->
		<transition name="fadeIn">
			<div class="redbag-mask" v-show="RedbagShow">
				<transition name="bounce">
					<div class="redbag-container" v-show="RedbagShow">
						<a href="javascript:;" class="close-model">
							<img src="static/img/public/red_over.png" />
						</a>
						<div class="CountNumber">
							&yen;<CountUp :start-val="1" :end-val="winPrize" :duration="1" :decimals="2"></CountUp>
						</div>
						<button class="mui-btn mui-btn-mini get">{{innerText}}</button>
					</div>
				</transition>
			</div>
		</transition>
	</div>
</template>
<script>
	import CountUp from '@/components/CountUp';
	import Index from '@page/Betting/LotIndex';
	import report from '@/api/report'
	export default {
		name: 'Index',
		components: {
			CountUp
		},
		data() {
			return {
				index_ofpath: [{
					path: '/',
					index: 0
				}, {
					path: '/Rechargeonline',
					index: 1
				}, {
					path: '/BettingRecord',
					index: 2
				}, {
					path: '/QuotaConversion',
					index: 3
				}, {
					path: '/Center',
					index: 4
				}],
				this_index_ofpath: '/',
				list: 1321,
				index: 0,
				transitionName: 'slide-left',
				appStyle: {'height': '1.32rem','padding-top': '0.4rem'},
				isApp: lib.IsApp,
				RedbagShow: false,
				innerText: '登录领取红包',
				winPrize:0,
				NoticetcShow:false,
			}
		},
		beforeRouteUpdate(to, from, next) {
			let isBack = this.$router.isBack
			if(isBack) {
				this.transitionName = 'slide-right'
			} else {
				this.transitionName = 'slide-left'
			}
			this.$router.isBack = false
			next();
		},
		updated() {
			var this_ = this;
			this_.this_index_ofpath = this.$route.path;
		},
		methods: {
			init() {
				var that = this;
			},
			initIndex() {
				var this_ = this
				for(var i = 0; i < this_.index_ofpath.length; i++) {
					if(this_.index_ofpath[i].path == this_.this_index_ofpath) {
						this_.index = this_.index_ofpath[i].index;
						return false
					} else {
						this_.index = -1;
					}
				}
			},
			//判断用户是否登录，如果没有登录，就跳转登录页面
			RouterTo(path) {
				if(!this.islogin) {
					this.$alert('请登录后查看');
					return;
				}
				this.$router.push({
					path: path
				})
			},
			setCookie(){
				var now = new Date();
				now.setTime(now.getTime() + 5 * 60 * 1000);//当前时间+5分钟过期时间
				$.cookie('tc','1',{ expires: now, path: "/", domain: window.DomainName });
			},
			// delCookie(){
			// 	$.cookie('tc',null);
			// }
		},
		mounted() {
			const that = this;
			this.init();
			this.initIndex();
			mui.init();
			mui.ready(function() {
				var current = 0;
				mui('.footer').on('tap', '.nav-item', function() {
					var index = $(this).data('index');
					that.index = index;
					if(index > current) {
						that.transitionName = 'slide-right';
						current = index;
					} else {
						that.transitionName = 'slide-left';
						current = index;
					}
					if(index == 0) {
						that.$router.push({
							path: '/'
						})
					} else if(index == 1) {
						that.RouterTo('/Rechargeonline');
					} else if(index == 2) {
						that.RouterTo('/BettingRecord');
					} else if(index == 3) {
						that.RouterTo('/QuotaConversion');
					} else if(index == 4) {
						that.RouterTo('/Center');
					}
					
				})

				//登录按钮
				mui('.Login-tips').on('tap', '.link-login', function() {
					that.$router.push({
						path: 'Login'
					})
				})

				//头部返回按钮
				mui('#Title').on('tap', '.mui-icon-back', function() {
					that.$router.goBack();
				})

				//APP下载页面
				mui('#Title').on('tap', '.downloadApp', function() {
					that.$router.push({
						path: 'Download'
					});
				})

				//头部注册按钮
				mui('.service').on('tap', '.Register', function() {
					that.$router.push({
						path: 'Register'
					})
				})

				//				加入代理
				mui('.title-border').on('tap', '.joinAgent', function() {
					that.$router.push({
						path: 'AgencyDevelopCourse'
					})
				})

				mui('.service').on('tap', '.Service', function() {

					//判断是否APP端还是wap端，如果是wap端就直接打开新窗口，如果是APP端，需要调用手机的原生浏览器
					if(lib.IsApp) {
						mui.plusReady(function() {
							plus.runtime.openURL(lib.ServiceLink);
						});
					} else {
						var wi = window.open('target:about', '_blank');
						wi.location.href = lib.ServiceLink;
					}
				})
				
				//会员中心页面里面的客服链接
				mui('#Title').on('tap', '.Center-service', function() {
					if(lib.IsApp) {
						mui.plusReady(function() {
							plus.runtime.openURL(lib.ServiceLink);
						});
					} else {
						var wi = window.open('target:about', '_blank');
						wi.location.href = lib.ServiceLink;
					}
				})
				
				
				
				//点击红包按钮
				mui('.service').on('tap', '.redbag', function() {
					that.RedbagShow = true;
					that.winPrize = 100000;
				})

				//红包遮罩
				mui('#Index').on('tap', '.redbag-mask', function() {
					that.RedbagShow = false;
					that.winPrize = 0;
				})

				//点击弹出红包的领取按钮
				mui('.redbag-mask').on('tap', '.get', function() {
					//点击穿透hack
					return false;
				})

				//公告遮罩
				mui('#Index').on('tap', '#Noticetcbox', function() {
					that.NoticetcShow = false;
					that.setCookie()
				})
				//阻止公告穿透
				mui('#Index').on('tap', '.Noticetc', function() {
					return false
				})
				//关闭公告
				mui('#Index').on('tap', '.Notclose', function() {
					that.NoticetcShow = false;
					that.setCookie()
				})
				mui('#Index').on('tap', '.closebtn', function() {
					that.NoticetcShow = false;
					that.setCookie()

				})
			})

			if(this.islogin){
				that.$store.dispatch('getAccount');
			}

			if(!$.cookie('tc')){
				//公告弹窗
				setTimeout(function() {
					var postdata = {
						notice_type: 7,
						window_ind: '1',
					}				
					report.GetNotice($(".NtcContent"), postdata);
					that.NoticetcShow = true
				}, 500)				
			}

			if(lib.IsApp) {
				document.addEventListener('plusready', function() {
					var webview = plus.webview.currentWebview();
					plus.key.addEventListener('backbutton', function() {
						webview.canBack(function(e) {
							if(e.canBack) {
								webview.back();
							} else {
								mui.plusReady(function() {
									//首页返回键处理
									//处理逻辑：1秒内，连续两次按返回键，则退出应用；
									var first = null;
									plus.key.addEventListener('backbutton', function() {
										//首次按键，提示‘再按一次退出应用’
										if(!first) {
											first = new Date().getTime();
											that.$router.goBack();
											setTimeout(function() {
												first = null;
											}, 1000);
										} else {
											if(new Date().getTime() - first < 1500) {
												plus.runtime.quit();
											}
										}
									}, false);
								});
							}
						})
					});
				});
			}
		},
		watch: {
			'$route' (to, from) {
				const toDepth = to.path.split('/').length
				const fromDepth = from.path.split('/').length
				//this.transitionName = toDepth < fromDepth ? 'slide-right' : 'slide-left'
				switch(to.path) {
					case '/':
						this.index = 0;
						break;
					case '/BankCard':
						this.index = 1;
						break;
				}
			},
			
			islogin(val){},
			
			
			this_index_ofpath() {
				this.initIndex();
			}
		},
		computed: {
			islogin() {
				return this.$store.getters.checkLoginState;
			}
		},
		created() {
			this.$store.dispatch('checkLoginState');
			console.log()
		}
	}
</script>

<style scoped lang="scss">
	@import '~static/sass/public.scss';
	.font-14 {
		font-size: 0.28rem;
		color: #fff;
		transform: translateY(1px);
	}
	
	.font-12 {
		font-size: 0.24rem;
		color: #ccc;
	}
	
	.mr-t {
		margin-top: 0.12rem;
	}
	.Center-service{
		position: absolute;
		left: 0.24rem;
		bottom: 0.06rem;
		color: #fff;
		.iconfont{
			font-size: 0.4rem;
		}
		p{
			color: #fff;
			font-size: 0.24rem;
			line-height: 0.28rem;
		}
	}
	#Noticetcbox{
		width: 100%;
		height: 100%;
		position: fixed;
		background: rgba(0, 0, 0, 0.3);
		z-index: 125;
		.Noticetc{
			position: absolute;
			left: 50%;
			top: 50%;
			background: #fff;
			padding:0.24rem;
			border-radius:3px;
			transform: translate(-50%, -50%);
			width: 5.2rem;
			height: 6.5rem;
			padding-bottom: 1rem;
			.posbox{
				position: relative;
				height: 100%;
				.NtcContent{			
					height: 100%; 
					overflow:scroll;
				}
				img{
					width: 0.8rem;
					height: 0.8rem;
					display: block;
					position: absolute;
					right: 0.1rem;
					top: -0.8rem;
					transform: translate(50%, -50%);
				}
			}
			.closebtn{
				width: 100%;
				height: 0.6rem;
				background: none;
				border: 0;
				font-size: 0.28rem;
				/* padding-top: 0.2rem; */
				border: 1px solid $blueColor;
				margin-top:0.2rem;
				color:$blueColor;
			}
		}
	}
	.redbag-mask {
		width: 100%;
		height: 100%;
		position: fixed;
		background: rgba(0, 0, 0, 0.7);
		z-index: 120;
		.redbag-container {
			position: absolute;
			left: 50%;
			top: 50%;
			transform: translate(-50%, -50%);
			width: 4.8rem;
			height: 5.88rem;
			background: url('~static/img/public/redbag-bg.png') no-repeat;
			background-size: 100% 100%;
			.close-model {
				width: 0.8rem;
				height: 0.8rem;
				display: block;
				position: absolute;
				right: 0;
				top: 0;
				transform: translate(50%, -50%);
				img {
					display: block;
					width: 100%;
					height: 100%;
				}
			}
			.get {
				border-radius: 30px;
				border: 0 none;
				background: #f2b570;
				color: #fff;
				font-size: 0.26rem;
				transform: translateY(4.8rem);
			}
			.CountNumber{
				position: absolute;
				left: 50%;
				top: 70%;
				transform: translate(-50%,-50%);
				font-size:0.6rem;
				font-weight: 600;
				color:#F2F302;
				text-indent: 0.06rem;
			}
		}
	}
	
	#Index {
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		position: relative;
		.color-white {
			color: #fff;
		}
		.logo {
			height: 0.6rem;
			width: auto;
			position: absolute;
			left: 50%;
			bottom: -0.18rem;
			transform: translate(-50%, -50%);
		}
		.downloadApp,
		.joinAgent {
			position: absolute;
			left: 0.9rem;
			bottom: -0.18rem;
			transform: translate(-50%, -50%);
			font-size: 0.24rem;
			color: $blueColor;
			padding: 0.06rem 0.16rem;
			border: 1px solid $blueColor;
			border-radius: 4px;
			&:active {
				background: $blueColor;
				color: #fff;
			}
		}
		.service {
			font-size: 0.24rem;
			color: $blueColor;
			position: absolute;
			right: 0;
			bottom: 0;
			padding-right: 0.24rem;
			a {
				padding: 0 0.1rem;
				line-height: 18px;
				color: $blueColor;
				display: inline-block;
				&:active {
					color: rgba($blueColor, 0.6);
				}
				&:active p {
					color: rgba($blueColor, 0.6);
				}
				&:last-child {
					padding-right: 0;
				}
			}
			.iconfont {
				font-size: 0.4rem;
			}
			p {
				font-size: 0.22rem;
				line-height: 0.24rem;
				color: $blueColor;
			}
			.redbag {
				width: 0.54rem;
				height: 0.75rem;
				padding: 0;
				vertical-align: -3px;
				margin-right: 5px;
				img {
					display: block;
					width: 100%;
					height: 100%;
				}
			}
		}
		.mui-content {
			flex: 1;
			background: $bgColor;
			overflow: auto;
			position: relative;
			padding: 0;
			&:-webkit-scrollbar {
				display: none;
			}
		}
		.Login-tips {
			padding: 0.1rem 0.3rem;
			background: rgba(0, 0, 0, 0.7);
			width: 100%;
			position: absolute;
			bottom: 0;
			left: 0;
			z-index: 100;
			.tips {
				color: $tipsFontColor;
				padding-top: 3px;
			}
			.link-login {
				font-size: 0.28rem;
			}
		}
		.footer {
			height: 0.96rem;
			background: #fff;
			box-shadow: 0 -1px 1px #ccc;
			display: flex;
			width: 100%;
		}
		.border-1px {
			@include border-1px(#ccc,
			'top')
		}
		.slide-item {
			display: block;
			width: 100%;
			height: 2.4rem;
		}
		.nav-item {
			flex: 1;
			color: #555555;
			padding: 0;
			box-sizing: border-box;
			padding-top: 0.08rem;
			.iconfont {
				font-size: 0.44rem;
			}
			p {
				font-size: 0.24rem;
			}
		}
		.nav-active {
			color: $titleBgColor;
			p {
				color: $titleBgColor;
			}
		}
	}
	
	#Title {
		position: relative;
		background: $titleBgColor;
		box-shadow: 0 0 0 rgba(0, 0, 0, 0);
	}
	
	.bg-white {
		background: #fff !important;
	}
	
	.child-view {
		position: absolute;
		width: 100%;
		transition: all .45s cubic-bezier(.55, 0, .1, 1);
		top: 0;
		bottom: 0;
		left: 0;
		right: 0;
		background: $bgColor;
		-webkit-backface-visibility: hidden;
		-webkit-transform-style: preserve-3d;
		z-index: 10;
	}
	
	.slide-left-enter,
	.slide-right-leave-active {
		opacity: 1;
		-webkit-transform: translate3d(100%, 0, 0);
		transform: translate3d(100%, 0, 0);
		z-index: 1000;
	}
	
	.slide-left-leave-active,
	.slide-right-enter {
		opacity: 1;
		-webkit-transform: translate3d(-100%, 0, 0);
		transform: translate3d(-100%, 0, 0);
	}
	
	.header {
		position: absolute;
		height: 0.88rem;
		width: 100%
	}
	.clickback{
		padding-right: 1rem !important;
	}
	@keyframes slide-left {
		from {}
		to {}
	}
	
	@keyframes slide-right {
		from {}
		to {}
	}
	
	.animate {
		animation: shake 0.45s infinite ease-in-out;
		transform-origin: 50% 50%;
	}
	
	@keyframes shake {
		0% {
			transform: rotate3d(0, 0, 1, 0deg);
		}
		25% {
			transform: rotate3d(0, 0, 1, -15deg);
		}
		50% {
			transform: rotate3d(0, 0, 1, 0deg);
		}
		75% {
			transform: rotate3d(0, 0, 1, 15deg);
		}
		100% {
			transform: rotate3d(0, 0, 1, 0deg);
		}
	}
	/* 
	 *	红包遮罩淡入淡出
	 ***/
	
	.fadeIn-enter-active {
		animation: fade-in .5s;
	}
	
	.fadeIn-leave-active {
		animation: fade-out .5s;
	}
	
	@keyframes fade-in {
		0% {
			opacity: 0;
		}
		100% {
			opacity: 1;
		}
	}
	
	@keyframes fade-out {
		0% {
			opacity: 1;
		}
		100% {
			opacity: 0;
		}
	}
	/*
	 *  红包里面的小包包弹出
	 ***/
	
	.bounce-enter-active {
		animation: bounceIn .35s;
		transform-origin: 0 0;
	}
	
	.bounce-leave-active {
		animation: bounceOut .35s;
		transform-origin: 0 0;
	}
	
	@keyframes bounceIn {
		0% {
			opacity: 0;
			transform: scale3d(0, 0, 0)translate(-50%, -50%);
		}
		20% {
			transform: scale3d(.2, .2, .2)translate(-50%, -50%);
		}
		40% {
			transform: scale3d(.4, .4, .4)translate(-50%, -50%);
		}
		60% {
			opacity: 1;
			transform: scale3d(.6, .6, .6)translate(-50%, -50%);
		}
		80% {
			transform: scale3d(.8, .8, .8)translate(-50%, -50%);
		}
		to {
			opacity: 1;
			transform: scale3d(1, 1, 1)translate(-50%, -50%);
		}
	}
	
	@keyframes bounceOut {
		20% {
			transform: scale3d(.9, .9, .9)translate(-50%, -50%);
		}
		50%,
		55% {
			opacity: 1;
			transform: scale3d(1.1, 1.1, 1.1)translate(-50%, -50%);
		}
		to {
			opacity: 0;
			transform: scale3d(.3, .3, .3)translate(-50%, -50%);
		}
	}
</style>