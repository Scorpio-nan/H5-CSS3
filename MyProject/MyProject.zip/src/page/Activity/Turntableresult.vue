<template>
    <div class="Turntablerecord">
        <h3>我的中奖纪录</h3>
        <ul>
            <li v-for="(item,i) in msg" :key="i">
                <div class="borderbox">
                    <div class="left">
                        <img v-if="!item.iswin" src="static/img/public/chouj/refuel.png" alt="">
                        <img v-else src="static/img/public/chouj/yes.png" alt="">
                    </div>
                    <div class="right">
                        <p><span>幸运大抽奖红包</span> <span>¥{{item.price}}</span></p>
                        <p><span>获取时间 : {{item.date}}</span> <span>{{item.Awards}}</span></p>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                msg:[
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"一等奖",iswin:true},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"一等奖",iswin:true},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"一等奖",iswin:true},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"未中奖",iswin:false},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"一等奖",iswin:true},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"未中奖",iswin:false},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"一等奖",iswin:true},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"未中奖",iswin:false},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"一等奖",iswin:true},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"未中奖",iswin:false},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"一等奖",iswin:true},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"未中奖",iswin:false},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"一等奖",iswin:true},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"未中奖",iswin:false},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"一等奖",iswin:true},
                    {price:1000,date:"2018-1-8 10:35:26",Awards:"未中奖",iswin:false}
                ],
                show:false
            }
        },
    }
</script>

<style lang="scss" scoped>
    @import '~static/sass/public.scss';
    .Turntablerecord{
        height: 100%;

        h3{
            font-size: 0.28rem;
            color: $normalFontColor;
            padding:0.4rem 0;
            font-weight: normal;
        }
        li{
            padding: 0 0.24rem 0.24rem 0.24rem;
            .borderbox{
                border-radius:3px;
                border: 1px dotted #f07377;
                font-size:0.24rem;
                background: #fff;
                overflow: hidden;
                padding:0 0.24rem;
                color: #f07377;
                .left{
                    float: left;
                    width:20%;
                    img{
                        width: 1rem;
                        height:auto;
                        float: left;
                    }
                }
                .right{
                    float: left;
                    width:80%;
                    p:nth-child(1){
                        padding-top:0.16rem;
                        width: 100%;
                        font-size:0.28rem;
                        overflow: hidden;
                        span:nth-child(1){
                            color:$importFontColor;
                            float: left;
                        }
                        span:nth-child(2){
                            color:$warnColor;
                            float: right;
                            font-weight:600;
                        }
                    }
                    p:nth-child(2){
                        font-size:0.24rem;
                        overflow: hidden;
                        span:nth-child(1){
                            float: left;
                        }
                        span:nth-child(2){
                            float: right;
                        }
                    }
                }
            }
        }
    }

</style>
