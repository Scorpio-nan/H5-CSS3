<template>
	<div id="discount">
		<div class="mui-content">
			<div class="header">
				<div id="segmentedControl" class="mui-segmented-control mui-segmented-control-inverted mui-segmented-control-primary">
					<a class="mui-control-item  mui-active" href="#item1">
						红包资讯
					</a>
					<a class="mui-control-item" href="#item2">
						转盘资讯
					</a>
				</div>
			</div>
			<div>
				<div id="item1" class="mui-control-content mui-active">
					<div class="mui-scroll-wrapper" id="refreshContainer">
						<div class="mui-scroll">
							<div class="DiscountsActivityContainer ">
								<p class="todayMessage ">今日累计存款合计</p>
								<p class="todayTotal">¥ 600000000</p>
								<p class="todayAllProgress">今日存款完成进度</p>
								<div class="process">
									<div id="todayTotalProcess2" class="mui-progressbar">
										<span></span>
									</div>
									
									<div class="processnum">60%</div>
								
								</div>
								<p class="againPay">在充值100元 , 可领取红包一个</p>
								<h6 class="hint">* 提示:您今日已抽奖 10 次 , 您还有 2 次抽奖机会</h6>
							</div>
							<button class="getRedBag">领取红包</button>
							<p class="searchActivity" >查看活动详情</p>
							<ul class="activityList">
								<li>
									<img src="static/img/activity/refuel.png" alt="" />
									<div class="text">
										<p class="bigRedBag">幸运大抽奖红包</p>
										<p>获取时间 : 2017-7-26 15:30:29</p>
									</div>
									<div class="text floatStyle">
										<p class="colorStyle">¥1000</p>
										<p>一等奖</p>
									</div>
								</li>
								<li>
									<img src="static/img/activity/refuel.png" alt="" />
									<div class="text">
										<p class="bigRedBag">幸运大抽奖红包</p>
										<p>获取时间 : 2017-7-26 15:30:29</p>
									</div>
									<div class="text floatStyle">
										<p class="colorStyleWhite">¥1000</p>
										<p class="anotherAward">一等奖</p>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div id="item2" class="mui-control-content">
					<div class="mui-scroll-wrapper" id="refreshContainer">
						<div class="mui-scroll">
							<div class="dial">
								<p class="todayMessage ">今日累计存款合计</p>
								<p class="todayTotal">¥ 600000000</p>
								<p class="todayAllProgress">今日存款完成进度</p>
								<div class="process">
									<div id="todayTotalProcess2" class="mui-progressbar">
										<span></span>
									</div>
									
									<div class="processnum">60%</div>
								
								</div>
								<p class="againPay">领取下次抽奖活动您还需充值200元</p>
							</div>

							<div class="todayAddUp">
								<p class="todayMessage ">今日累计注单量</p>
								<p class="todayTotal">¥ 6000000000088</p>
								<p class="todayAllProgress">今日注单完成进度</p>
								<div class="process">
									<div id="todayTotalProcess2" class="mui-progressbar">
										<span></span>
									</div>
									
									<div class="processnum">60%</div>
								
								</div>
								<p class="againPay">领取下次抽奖活动您还需充值200元</p>
							</div>
							<button class="clickLotteryDraw">点击抽奖</button>
							<p >查看活动详情</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<DiscountsActivityAlert v-if="is_show" class="alert">
			<div class="content">
				<h5>活动详情</h5>
				<div>
					<p>1、 您当前的积分为0, 可以抽奖: 0次</p>
					<p>2、 每次抽奖需要 1000 积分</p>
					<p>3、 积分不足不能参与抽奖活动,抽奖次数不限</p>
					<p>4、抽到非现金奖项请直接联系客服进行处理</p>
					<p>5、抽到实物 , 请与客服联系提供收货地址 , 我们将以邮寄的方式将实物邮寄到您手上</p>
				</div>
				<div>
					<p>1、独乐乐不如众乐乐 好友同乐利益互赢</p>
					<p>2、多年来我们与亚洲享有盛名的网络博彩娱乐集团合作</p>
					<p>3、为广大客户提供最优质的游戏体验</p>
					<p>4、由菲律宾博彩执照公司审核监控</p>
					<p>5、联合开发的彩票游戏 , 保证公平公正</p>
				</div>
			</div>
		</DiscountsActivityAlert>
	</div>
</template>

<script>
	import DiscountsActivityAlert from './DiscountsActivityAlert'
	export default {
		data() {
			return {
				is_show: false
			}
		},
		mounted() {
			let that = this
			mui.init();
			mui.ready(function() {
				mui('.mui-scroll-wrapper').scroll({
					bounce: true,
					indicators: true,
					deceleration: 0.0009
				});
				
				mui('.mui-control-content').on('tap', '.searchActivity', function() {
						that.is_show = !that.is_show
				})
				mui('body').on('tap', '#DiscountsActivityAlert', function() {
						that.is_show = !that.is_show
				})
						
			})
		},
		components: {
			DiscountsActivityAlert
		},
		methods: {
		}
	}
</script>

<style lang="scss" scoped>
	/*弹出层*/
	.process{
		position: relative;
		.processnum{
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			font-size: .24rem;
			color: #666;
			margin-top: .06rem;
		}
	}
	.alert {
		.content {
			position: relative;
			top: 2.14rem;
			width: 6.5rem;
			height: 7.5rem;
			background-color: #fff;
			margin: auto;
			border-radius: .1rem;
			h5 {
				color: #000;
				font-size: .28rem;
				font-weight: bold;
				padding: .4rem 0;
			}
			div{
				padding: .4rem;
				padding-top: 0;
				text-align: left;
				p{
					font-size: .24rem;
					color: #666
				}
			}			
		}
	}
	/*红包资讯*/
	
	.header {
		background-color: #fff;
	}
	
	.discount {
		position: relative;
		width: 100%;
		height: 100%;
	}
	
	.mui-control-content {
		background-color: white;
		min-height: 10rem;
	}
	
	@media only screen and (min-height: 812px) {
		.mui-control-content {
			min-height: 13rem;
		}
	}
	
	.mui-control-content .mui-loading {
		margin-top: 50px;
	}
	
	.mui-control-item {
		padding-top: .16rem;
		padding-bottom: .1rem;
	}
	
	.mui-segmented-control {
		padding-top: .1rem;
	}
	
	.title {
		color: #333;
		font-size: .28rem;
		text-align: left;
	}
	
	.money {
		color: #ff1a18;
		font-size: .4rem;
		background-color: #eee;
		text-align: left;
		padding-left: .1rem;
		margin-top: .2rem;
		padding: .06rem;
	}
	
	.progress {
		margin-top: .35rem;
		font-size: 0.28rem;
		color: #666;
		text-align: left;
	}
	
	.mui-progressbar {
		height: .5rem;
		background-color: #EEEEEE;
		color: #000;
		line-height: .5rem;
		.mui-scrollbar-indicator {
			display: block;
			transform: translate3d(0px, 0px, 0px) translateZ(0px);
		}
	}
	
	.mui-progressbar span {
		background: #4CBE00;
		transform: translate3d(-60%, 0px, 0px);
	}
	
	.recharge {
		text-align: left;
		font-size: .24rem;
		color: #999;
		margin-top: .1rem;
		margin-left: .1rem;
	}
	
	.hint {
		font-size: .24rem;
		color: #F07377;
		margin-top: 1.08rem;
	}
	
	.getRedBag {
		width: 92%;
		padding: .3rem;
		background-color: #3493FF;
		font-size: .32rem;
		color: #fff;
		margin-top: .73rem;
	}
	
	.searchActivity {
		font-size: .24rem;
		color: #666;
		margin: .5rem;
	}
	
	.activityList {
		padding-bottom: .5rem;
		li {
			border: 1px dashed red;
			height: 1.2rem;
			width: 92%;
			margin: .15rem auto;
			border-radius: .07rem;
			img {
				height: 1.08rem;
				margin-top: .08rem;
				float: left;
				margin-left: .1rem;
			}
			.text {
				float: left;
				display: inline-block;
				text-align: left;
				line-height: .45rem;
				margin-top: .2rem;
				margin-left: .2rem;
			}
			.colorStyle {
				float: right;
				color: #ec5055;
				font-weight: bold;
				font-size: .3rem;
			}
			.floatStyle {
				float: right;
				margin-right: .2rem;
			}
		}
	}
	
	.bigRedBag {
		font-size: .28rem;
		color: #666
	}
	
	.bigRedBag+p {
		font-size: .28rem;
	}
	/*转盘资讯*/
	
	#item2 {
		background-color: #F5F6F7;
	}
	
	.dial {
		margin-top: .16rem;
		padding: .16rem .64rem .55rem .64rem;
		background-color: #fff;
		p {
			text-align: left;
		}
		.todayMessage {
			font-size: .28rem;
			color: #333;
			margin: .5rem 0 .2rem 0;
		}
		.todayTotal {
			background-color: #EEEEEE;
			font-size: .4rem;
			color: #ff1a18;
			padding: .05rem;
			padding-left: .22rem;
		}
		.todayAllProgress {
			margin-top: .35rem;
			font-size: .28rem;
			color: #666;
		}
		.mui-progressbar {
			margin: .1rem 0 .1rem 0;
			font-size: .24rem;
			color: #999;
			padding-bottom: .55rem;
		}
	}
	
	.todayAddUp {
		margin-top: .16rem;
		padding: .16rem .64rem .55rem .64rem;
		background-color: #fff;
		p {
			text-align: left;
		}
		.todayMessage {
			font-size: .28rem;
			color: #333;
			margin: .5rem 0 .2rem 0;
		}
		.todayTotal {
			background-color: #EEEEEE;
			font-size: .4rem;
			color: #ff1a18;
			padding: .05rem;
			padding-left: .22rem;
		}
		.todayAllProgress {
			margin-top: .35rem;
			font-size: .28rem;
			color: #666;
		}
		.mui-progressbar {
			margin: .1rem 0 .1rem 0;
			font-size: .24rem;
			color: #999;
			padding-bottom: .55rem;
		}
	}
	
	.clickLotteryDraw {
		width: 95%;
		height: .88rem;
		background-color: #3793FF;
		font-size: .32rem;
		margin-bottom: .5rem;
		color: #fff
	}
	
	.clickLotteryDraw+p {
		padding-bottom: .5rem;
	}
	
	.DiscountsActivityContainer {
		margin-top: .16rem;
		padding: .16rem .64rem 0 .64rem;
		background-color: #fff;
		p {
			text-align: left;
		}
		.todayMessage {
			font-size: .28rem;
			color: #333;
			margin: .5rem 0 .2rem 0;
		}
		.todayTotal {
			background-color: #EEEEEE;
			font-size: .4rem;
			color: #ff1a18;
			padding: .05rem;
			padding-left: .22rem;
		}
		.todayAllProgress {
			margin-top: .35rem;
			font-size: .28rem;
			color: #666;
		}
		.mui-progressbar {
			margin: .1rem 0 .1rem 0;
			font-size: .24rem;
			color: #999;
			padding-bottom: .55rem;
		}
	}
	
	.colorStyleWhite {
		color: transparent
	}
</style>