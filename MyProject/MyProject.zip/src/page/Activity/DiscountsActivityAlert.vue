<template>
	<div id="DiscountsActivityAlert" class="discount">
		
			<slot></slot>

	</div>
</template>

<script>
	export default {
//		props: {
//			show: Boolean,
//		},
//		methods: {
//			hideAction() {
//				this.$emit('hide')
//			},
//		},
//		mounted() {
//			const that = this;
//
//			mui.init();
//			mui.ready(function() {
//				mui('#DiscountsActivityAlert').on('tap', '.action_mask', function() {
//					that.hideAction();
//				})
//			})
//		},
	}
</script>

<style lang="scss" scoped>
	.discount {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, .5);
		z-index: 99;
	}
</style>