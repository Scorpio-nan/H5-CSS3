<template>
	<div id="Turntable">
		<div class="mui-scroll-wrapper">
			<div class="mui-scroll">
				<img class="" src="static/img/public/chouj/turnplate1.png" />
				<div class="contens">
					<div class="containerbox">
						<div class="title"><span>我的获奖记录</span></div>
						<div class="zhuanpanbox">
							<div class="Turntableall" :class="isBgNum">						
								<div class="canvaslist" v-for="(item,index) in List" :class="zproatenum">{{item.PRIZE_NAME}}</div>
							</div>						
							<img :src=imageUrl class="btn" v-on:click="rotatego" />
						</div>

						<div class="contentext">
							<div class="lunbo">恭喜XXX获得兰博基尼一台</div>
							<div class="shuoming">抽奖活动说明</div>
							<div class="guize">
								<p>1、您当前积分为:<span id="">0</span>，可以抽奖：<span id="">0</span>次</p>
								<p>2、每次抽奖需要 10000 积分</p>
								<p>3、积分不足不能参与抽奖活动，抽奖次数不限</p>
								<p>4、抽到非现金奖项的请直接联系客服进行处理</p>
								<p>5、抽到实物，请与客服联系提供收货地址，我们将以邮寄的方式将实物邮寄到您手上</p>
								<p class="p1">如有疑问请联系微信在服或</p>
								<p>QQ客服577522227</p>
							</div>
						</div>
					</div>
				</div>
			</div>					
		</div>
	<transition name="fadeIn">	
		<div class="boxshadow" v-show="isShow">
			<transition name="bounce">
				<div class="Winningbox">
					<img v-show="!flag" src="static/img/public/chouj/nothing.png"/>			
					<p class="Wintitle">{{flag?"恭喜你获得":"很遗憾没有中奖~"}}{{iswinname}}</p>
					<div class="nothing" v-show="!flag">再来一次</div>
					
					<img v-show="flag" src="static/img/public/chouj/win.png"/>
					<p class="winnum" v-show="flag">{{iswinnum}}元</p>
					
					<div class="winclose"></div>
				</div>
			</transition>
		</div>
	</transition>	
	</div>
</template>

<script>
	import api from '@/api/report'
	import 'static/script/awardRotate'
	export default {
		name: 'lottery',
		data: function() {
			return {
				imageUrl:"static/img/public/chouj/pointer.png",
				easejoy_bean: 0, //积分
				lottery_ticket: 0, //抽奖次数
				List: [], //奖品列表
//				colors: ["#FFFFFF", "#5fcbd5", "#FFFFFF", "#5fcbd5", "#FFFFFF", "#5fcbd5", "#FFFFFF", "#5fcbd5", "#FFFFFF", "#5fcbd5"], //大转盘奖品区块对应背景颜色
				bRotate: false, //false:停止;ture:旋转	
				flag:false,
				isShow:false,
				iswinname:"",
				iswinnum:"",
				isBgNum:"",//大圆背景
				zproatenum:"",//转盘份数类名
				actSlyderList:[],//中奖/参与记录

			}
		},
		created() {

				

		},
		computed: {

		},
		mounted() {
			mui.init();
			this.getList1();
			this.getList2();
			// this.getList3();
			this.getList4();
			this.getList5();
			var that=this
			mui('.mui-scroll-wrapper').scroll({
				deceleration: 0.0005
			});
			
			mui('body').on('tap','.boxshadow',function(){
				that.isShow=false
			})
			mui('#Turntable').on('tap','.title',function(){
				that.$router.push({
					path:'Turntables'
				})
			})
		},
		methods: {
			rotateTimeOut() {
				var this_=this
				$('.Turntableall').rotate({
					angle: 0,
					animateTo: 2160,
					duration: 8000,
					callback: function() {
						this_.$alert('网络超时，请检查您的网络设置！');
					}
				});
			},
			//
			rotateFn(item, txt) {
				
				var angles = item * (360 / this.List.length) - (360 / (this.List.length * 2));
				console.log("角度1"+"------------"+angles)
				

				angles = 360 - angles;
				console.log("角度2"+"------------"+angles)
				$('.Turntableall').stopRotate();
				$('.Turntableall').rotate({
					angle: 0,
					animateTo: angles + 1800,
					duration: 8000,
					callback: function () { //回调
						// alert('恭喜中奖了');

					}
				});
			},
			//随机数
			rnd(n, m) {
				var random = Math.floor(Math.random() * (m - n + 1) + n);
				return random;
			},
			rotatego() {
				var that = this;

				that.flag=false
				that.iswinname=""
				that.iswinnum=""

				if(that.bRotate) return;
				that.List.bRotate = !that.bRotate;
				//获取随机数(奖品个数范围)
				var item = that.rnd(1, that.List.length);
				
				if(that.List[item-1].PRIZE_NAME != "谢谢参与"){
					that.flag=true
					that.iswinname=that.List[item-1].PRIZE_NAME//奖品名字
					that.iswinnum=that.List[item-1].PRIZE_AMT//奖品金额
													//SORT 几等奖
													//NEED_DILIVERY_IND  1为实物  0为彩金
				}

				console.log("随机数"+item)
				
				//奖品数量等于10,指针落在对应奖品区域的中心角度[252, 216, 180, 144, 108, 72, 36, 360, 324, 288]
				that.rotateFn(item,that.List[item-1].PRIZE_NAME);
				/* switch (item) {
					case 1:
						rotateFn(252, turnplate.restaraunts[0]);
						break;
					case 2:
						rotateFn(216, turnplate.restaraunts[1]);
						break;
					case 3:
						rotateFn(180, turnplate.restaraunts[2]);
						break;
					case 4:
						rotateFn(144, turnplate.restaraunts[3]);
						break;
					case 5:
						rotateFn(108, turnplate.restaraunts[4]);
						break;
					case 6:
						rotateFn(72, turnplate.restaraunts[5]);
						break;
					case 7:
						rotateFn(36, turnplate.restaraunts[6]);
						break;
					case 8:
						rotateFn(360, turnplate.restaraunts[7]);
						break;
					case 9:
						rotateFn(324, turnplate.restaraunts[8]);
						break;
					case 10:
						rotateFn(288, turnplate.restaraunts[9]);
						break;
				} */
				console.log(that.List[item-1].PRIZE_NAME);
				setTimeout(function(){
					that.isShow=true
				},7200)
			},			
			getList1(){//轮盘活动--活动参与记录表
				var that = this;
				var postData = {
					rows: 200,
					mob: 1,
					sidx: 'DRAW_DTT',
					sord: 'desc',
				}
				api.GetActSlyderResult(postData,function(data){
					var SlyderData = eval(data);
						console.log('记录全', SlyderData)
					if(SlyderData.rows) {
						that.actSlyderList = SlyderData.rows;
						console.log('记录', that.actSlyderList)
									/*
						* 1,ID表id, 2,PRIZE_AMT 领取的彩金数量  3，RN 是否领取  4 ,ATTR2 是否是实物
						* ISget：是否领取，0为未领取，1为已领取，2为待审核，3谢谢参与
						*/
					}
				})
			},
			getList2(){//轮盘活动--统计当前会员每日参与轮盘活动的信息
				var that = this;
				api.GetUserActSlyder(function(data){
					console.log('参与信息',data)
				})
			},
			// getList3(){//轮盘活动—领奖及提交联系人地址信息 
			// 	var that = this;
			// 	api.PostActSlyderResultAddress(function(data){
				// 		console.log("4"+data)
			// 	})
			// },
			getList4(){//获取轮盘信息 轮盘活动--奖项配置表
				var that = this;
				api.GetActSlyderAdventuresConfig(function(data){
					console.log('奖品配置', data)
					that.List=data
					if(that.List.length ==5){
						that.isBgNum="bg5"
						that.zproatenum="canvaslist5"
					}else if(that.List.length ==6){
						that.isBgNum="bg6"
						that.zproatenum="canvaslist6"
					}else if(that.List.length ==7){
						that.isBgNum="bg7"
						that.zproatenum="canvaslist7"
					}else{
						return
					}
				})
			},
			getList5(){//轮盘活动--抽奖
				var that = this;
				api.GetActSlyderPrize(function(data){
					console.log('抽奖',data)
				})
			},

		}
	}
</script>

<style lang="scss" scoped>
	@import '~static/sass/public.scss';
	#Turntable {
		width: 100%;
		height: 100%;
		position: relative;
		background: linear-gradient(to bottom, #e53c28 0%, #fe8b3c 100%);
		img {
			width: 100%;
			height: auto;
		}
		.boxshadow{
			width: 100%;
			height: 100%;
			z-index:1000000;
			position:relative;
			background:rgba(0,0,0,0.3);
			.Winningbox{
				width: 4rem;
				height: 6rem;
				position: absolute;
				left: 50%;
				top: 50%;
				margin-top:-1.7rem;
				margin-left:-2rem;
				background:url(~static/img/public/chouj/win.png) no-repeat;
				background-size:100% auto;
				img{
					width: 100%;
					height:100%;
				}
				.Wintitle{
					position: absolute;
				    left: 0;
				    top: 2rem;
				    text-align: center;
				    width: 100%;
				    color: #fff;
				    font-size: 0.32rem;
				}
				.nothing{
					position: absolute;
					bottom: 0.3rem;
				    left: 50%;
				    transform: translateX(-50%);
				    font-size:0.24rem;
				    padding:0.1rem 0.4rem;
					color:#faed00;
					border-radius:30px;
					border:1px solid #faed00;
				}
				.winnum{
					position:absolute;
					bottom:2rem;
					left: 50%;
					width: 100%;
					text-align:center;
					transform: translateX(-50%);
					font-size: 0.72rem;
					color:#faed00;
				}
				.winclose{
					width: 1rem;
					height: 1rem;
					position: absolute;
					right: 0;
					top: 0;
				}
			}
			
		}
		.contens {
			padding: 0 0.24rem 0.24rem 0.24rem;
			.containerbox {
				background: #fff;
				margin-top: -0.2rem;
				border-radius: 16px;
				padding: 0.7rem 0.4rem 0.4rem 0.4rem;
				.title {
					font-size: 0.3rem;
					color: #f04628;
					font-weight: normal;
					margin-bottom: 0.45rem;
					text-align: center;
					span {
						padding-bottom: 0.04rem;
						border-bottom: 1px solid #f04628;
					}
				}
				.zhuanpanbox {
					margin: 0 auto;
					width: 6.2rem;
					height: 6.2rem;
					background: #fbda30;
					border-radius: 50%;
					box-shadow: 0px 0px 5px #f8c314 , 0px 2px 5px #ce9e03;
					position: relative;
					.btn {
						position: absolute;
						width: auto;
						height: 2rem;
						left: 50%;
						top: 50%;
						transform: translate(-50%, -50%);
					}
					.Turntableall{
						background:url(~static/img/public/chouj/plate_up.png) no-repeat;
						background-size:6rem auto;
						width: 6rem;
						height: 6rem;
						position:absolute;
						left: 50%;
						top: 50%;
						margin-top:-3rem;
						margin-left:-3rem;
					}
					.bg5{
						background:url(~static/img/public/chouj/five.png) no-repeat;
						background-size:6rem auto;
					}
					.bg6{
						background:url(~static/img/public/chouj/six.png) no-repeat;
						background-size:6rem auto;
					}
					.bg7{
						background:url(~static/img/public/chouj/seven.png) no-repeat;
						background-size:6rem auto;
					}
					.canvaslist{
						position:absolute;
						left: 50%;
						top: 50%;
						text-align: center;
						word-wrap: break-word; 
						word-break: normal; 
						margin-top:-2.6rem;
						margin-left:-0.9rem;
						width: 1.8rem;
						height: 2.6rem;
						transform-origin:50% 100%;
						color:#fff;
						text-shadow:2px 0px 1px #ef4528, -2px 0px 1px #ef4528, 0px 2px 1px #ef4528, 0px -2px 1px #ef4528;
					}
					//默认8份 对应角度↓↓↓22.5    7份25.7   6份30  5份36     ↑↑↑默认宽度1.8，一行可显示5个字（最多两行10字），其余份数需对应修改宽度
					.canvaslist:first-child {
						 transform:rotate(23deg);
					}
					.canvaslist:nth-child(2) {
						transform:rotate(68deg);
					}
					.canvaslist:nth-child(3) {
						transform:rotate(113deg);
					}
					.canvaslist:nth-child(4) {
						transform:rotate(158deg);
					}
					.canvaslist:nth-child(5) {
						transform:rotate(-158deg);
					}
					.canvaslist:nth-child(6) {
						transform:rotate(-113deg);
					}
					.canvaslist:nth-child(7) {
						transform:rotate(-68deg);
					}
					.canvaslist:last-child {
						transform:rotate(-23deg);
					}
		// 7份25.7
					.canvaslist7:first-child {
						 transform:rotate(25.7deg);
					}
					.canvaslist7:nth-child(2) {
						transform:rotate(77.1deg);
					}
					.canvaslist7:nth-child(3) {
						transform:rotate(128.5deg);
					}
					.canvaslist7:nth-child(4) {
						transform:rotate(180deg);
					}
					.canvaslist7:nth-child(5) {
						transform:rotate(231.3deg);
					}
					.canvaslist7:nth-child(6) {
						transform:rotate(282.7deg);
					}
					.canvaslist7:nth-child(7) {
						transform:rotate(334deg);
					}
		// 6份30
					.canvaslist6:first-child {
						 transform:rotate(30deg);
					}
					.canvaslist6:nth-child(2) {
						transform:rotate(90deg);
					}
					.canvaslist6:nth-child(3) {
						transform:rotate(150deg);
					}
					.canvaslist6:nth-child(4) {
						transform:rotate(-150deg);
					}
					.canvaslist6:nth-child(5) {
						transform:rotate(-90deg);
					}
					.canvaslist6:nth-child(6) {
						transform:rotate(-30deg);
					}
		// 5份36
					.canvaslist5:first-child {
						 transform:rotate(36deg);
					}
					.canvaslist5:nth-child(2) {
						transform:rotate(108deg);
					}
					.canvaslist5:nth-child(3) {
						transform:rotate(180deg);
					}
					.canvaslist5:nth-child(4) {
						transform:rotate(252deg);
					}
					.canvaslist5:nth-child(5) {
						transform:rotate(-36deg);
					}
				}
				.contentext {
					padding: 0.6rem 0.2rem 0 0.2rem;
					.lunbo {
						width: 5rem;
						font-size: 0.24rem;
						color: $importFontColor;
						margin: auto;
						padding: 0.2rem 0;
						text-align: center;
						border: 1px solid $tipsFontColor;
						border-radius: 3px;
					}
					.shuoming {
						width: 2.2rem;
						padding: 0.1rem 0;
						font-size: 0.28rem;
						color: #fff;
						margin: auto;
						margin-top: 0.4rem;
						margin-bottom: 0.35rem;
						border-radius: 30px;
						background: #ef4528;
						position: relative;
					}
					.shuoming:after {
						content: '';
						height: 2px;
						position: absolute;
						background: #ef4528;
						left: 2rem;
						top: 50%;
						width: 2rem;
					}
					.shuoming:before {
						content: '';
						height: 2px;
						position: absolute;
						background: #ef4528;
						right: 2rem;
						top: 50%;
						width: 2rem;
					}
					.guize {
						text-align: left;
						p {
							font-size: 0.24rem;
							color: $normalFontColor;
						}
						.p1 {
							margin-top: 0.4rem;
						}
					}
				}
			}
		}
	}
	
	
	/* 
	 *	红包遮罩淡入淡出
	 ***/
	
	.fadeIn-enter-active {
		animation: fade-in .5s;
	}
	
	.fadeIn-leave-active {
		animation: fade-out .5s;
	}
	
	@keyframes fade-in {
		0% {
			opacity: 0;
		}
		100% {
			opacity: 1;
		}
	}
	
	@keyframes fade-out {
		0% {
			opacity: 1;
		}
		100% {
			opacity: 0;
		}
	}
	/*
	 *  红包里面的小包包弹出
	 ***/
	
	.bounce-enter-active {
		animation: bounceIn .35s;
		transform-origin: 0 0;
	}
	
	.bounce-leave-active {
		animation: bounceOut .35s;
		transform-origin: 0 0;
	}
	
	@keyframes bounceIn {
		0% {
			opacity: 0;
			transform: scale3d(0, 0, 0)translate(-50%, -50%);
		}
		20% {
			transform: scale3d(.2, .2, .2)translate(-50%, -50%);
		}
		40% {
			transform: scale3d(.4, .4, .4)translate(-50%, -50%);
		}
		60% {
			opacity: 1;
			transform: scale3d(.6, .6, .6)translate(-50%, -50%);
		}
		80% {
			transform: scale3d(.8, .8, .8)translate(-50%, -50%);
		}
		to {
			opacity: 1;
			transform: scale3d(1, 1, 1)translate(-50%, -50%);
		}
	}
	
	@keyframes bounceOut {
		20% {
			transform: scale3d(.9, .9, .9)translate(-50%, -50%);
		}
		50%,
		55% {
			opacity: 1;
			transform: scale3d(1.1, 1.1, 1.1)translate(-50%, -50%);
		}
		to {
			opacity: 0;
			transform: scale3d(.3, .3, .3)translate(-50%, -50%);
		}
	}
</style>