export const LOGIN_STATE = 'LOGIN_STATE'
export const HANDLEBETPOUR = 'HANDLEBETPOUR'
export const ACCOUNT = 'ACCOUNT'
export const GETUSERINFO = 'GETUSERINFO'
export const GET_TEMA_SHOW = "GET_TEMA_SHOW"
export const USERGROUP = 'USERGROUP'
export const ACCOUNTLIST = 'ACCOUNTLIST'
export const GETMSGLIST = 'GETMSGLIST'
export const GETMSGNUM = 'GETMSGNUM'//消息总数
export const GET_GAME_ID = "GET_GAME_ID"
export const GET_GAME_0LIST = "GET_GAME_0LIST"
export const GET_GAME_1LIST = "GET_GAME_1LIST"
export const GET_GAME_2LIST = "GET_GAME_2LIST"
export const GET_GAME_3LIST = "GET_GAME_3LIST"
export const USERWIN = 'USERWIN'
export const CLEARSELECT = 'CLEARSELECT'

