export default{
	loginState:false,		//登录状态
	handlePour:{			//点击下注按钮
		IsShow:false,
		title:'',
		TeMaShow: {},
		arr:[],
		type:'cp'
	},	
	TeMaShow: {},
	account:{},				//用户余额
	userInfo:{},			//用户登录信息
	userGroup:{},			//获取当前用户组信息
	accountList:{},			//数组字典缓存
	Msglist:[],				//获取消息列表
	Msgnum:'',				//获取消息总数
	id : '16',
	game0List: [],			//体育赛事列表
	game1List: [],			//彩票游戏列表
	game2List: [],			//真人视讯列表
	game3List: [],			//电子游艺列表
	imageList: [],	
	userWin:0,				//获取用户投注输赢
	clearSelect:'',			//投注完成之后，清除所有的选中项
	Sealing:false,			//封盘状态
}
