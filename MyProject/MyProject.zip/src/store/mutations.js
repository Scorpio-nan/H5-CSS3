//import {
//	LOGIN_STATE,
//	TRANSFER_ACCOUNT
//} from './mutation_types';
import * as types from './mutation_types';
export default{
	[types.GET_TEMA_SHOW](state, res) {
		state.TeMaShow = res
	},
	[types.LOGIN_STATE](state,res){
		state.loginState = res;
	},
	[types.HANDLEBETPOUR](state,res){
		state.handlePour = res;
	},
	[types.ACCOUNT](state,res){
		state.account = res;
	},
	[types.GET_GAME_ID](state,res){
		state.id = res;
	},
	[types.GETUSERINFO](state,res){
		state.userInfo = res;
	},
	[types.USERGROUP](state,res){
		state.userGroup = res;
	},
	[types.ACCOUNTLIST](state,res){
		state.accountList = res;
	},
	[types.GETMSGLIST](state,res){
		state.Msglist = res;
	},
	Sealing(state,res){
		state.Sealing=res;
	},
	[types.GET_GAME_0LIST](state, res) {
		state.game0List = res
	},
	[types.GET_GAME_1LIST](state, res) {
		state.game1List = res
	},
	[types.GET_GAME_2LIST](state, res) {
		state.game2List = res
	},
	[types.GET_GAME_3LIST](state, res) {
		state.game3List = res
	},
	[types.GETMSGNUM](state,res){
		state.Msgnum = res;
	},
	[types.USERWIN](state,res){
		state.userWin = res;
	},
	[types.CLEARSELECT](state,res){
		state.clearSelect = res;
	},
}
