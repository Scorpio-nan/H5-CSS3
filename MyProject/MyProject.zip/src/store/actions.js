import {
	LOGIN_STATE,
	HANDLEBETPOUR,
	ACCOUNT,
	GETUSERINFO,
	USERGROUP,
	ACCOUNTLIST,
	GETMSGLIST,
	GETMSGNUM,
	GET_TEMA_SHOW,
	GET_GAME_ID,
	GET_GAME_0LIST,
	GET_GAME_1LIST,
	GET_GAME_2LIST,
	GET_GAME_3LIST,
	USERWIN,
	CLEARSELECT,
} from './mutation_types';
import api from '@/api/userUtil';
import web from '@/api/webUtil';
import lotapi from '@/api/lotteryUtil';
export default{
	checkLoginState({commit}){
		api.CheckSession(function(res){
			commit(LOGIN_STATE,res);
			localStorage.setItem('UserSession',res);
		})
	},
	handleBetPour({commit},res){
		commit(HANDLEBETPOUR,res);
	},
	getTemashow({commit}) {
		lotapi.GetHk6OddsDictList(function(res) {
			commit( GET_TEMA_SHOW, res);
		});
	},
	//體育賽事
	getGame0List: function({
		commit
	}) {
		web.GetGameClassBig(1, function(data) {
			var list = eval('(' + data + ')')
			commit( GET_GAME_0LIST, list);
		})
	}, //彩票游戏
	getGame1List: function({
		commit
	}) {
		web.GetGameClassBig(2, function(data) {
			var list = eval('(' + data + ')')
			commit( GET_GAME_1LIST, list);
		})
	}, //真人
	getGame2List: function({
		commit
	}) {
		web.GetGameClassBig(3, function(data) {
			var list = eval('(' + data + ')')
			commit(GET_GAME_2LIST, list);
		})
	}, //电子游艺
	getGame3List: function({
		commit
	}) {
		web.GetGameClassBig(9, function(data) {
			var list = eval('(' + data + ')')
			commit(GET_GAME_3LIST, list);
		})
	},
	
	getgameid:function({commit},game_id){
    	commit(GET_GAME_ID,game_id)
   	},
   	
	getAccount({commit},type){
		//获取账户余额     如果传参数就是获取当前传过来的参数类型的余额，不传参数就是钱包和反水
		if(type){
			if(type == 'all') type = '';
			api.GetAccount(type,function(res){
				var data = {};
				data['allmoney'] = res.allmoney;
				for(var i = 0; i < res.accBalInfo.length; i++) {
					var item = res.accBalInfo[i];
					data[item.ACC_BAL_CD] = parseFloat(item.ACC_BAL).toFixed(2) + '';
				}
				res.data = data;
				commit(ACCOUNT, res);
			})
		}else{
			api.GetAccountNew(function(res){
				commit(ACCOUNT, res);
			})
		}
	},
	getUserInfo({commit}){
		api.GetUserInfo(function(res) {
			commit(GETUSERINFO, res);
		})
	},
	getMsgList({commit}){
		api.GetMessageList(function(res) {
			commit(GETMSGLIST, res);
		})
	},//获取消息列表
	getMsgNum({commit}){
		api.GetNoReadMessageCount(function(res) {
			commit(GETMSGNUM, res);
		})
	},//获取消息总数
	getUserGroup({commit}){
		var UserGroup = localStorage.getItem('UserGroup');
		if(UserGroup != null){
			commit(USERGROUP, JSON.parse(UserGroup));
		}else{
			api.GetUserGroup((res)=>{
				localStorage.setItem('UserGroup',res);
				commit(USERGROUP, JSON.parse(res));
			})
		}
	},
	getAccountList({commit}){
		var AccountList = localStorage.getItem('AccountList');
		if(AccountList != null){
			commit(ACCOUNTLIST,JSON.parse(AccountList));
		}else{
			api.GetAccountList((res)=>{
				localStorage.setItem('AccountList',JSON.stringify(res));
				commit(ACCOUNTLIST, res);
			})
		}
	},
	getUserWin({commit}){
		api.Getuserwin(res=>{
			commit(USERWIN, res);
		})
	},
	ClearSelect({commit},res){
		commit(CLEARSELECT,res);
	}
}
